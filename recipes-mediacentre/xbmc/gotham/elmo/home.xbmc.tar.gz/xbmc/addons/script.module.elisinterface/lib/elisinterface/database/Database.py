import sys
import time
import os
import shutil


from SqliteDatabase  import SqliteDatabase
from util.Logger import LOG_TRACE, LOG_WARN, LOG_ERR


E_DB_READY			= 0
E_DB_CREATE			= 1
E_DB_OPEN			= 2
E_DB_CONNECT		= 3



class Database(object):
	def __init__(self):
		#LOG_TRACE('DB TEST:init')
		self.mStatus = E_DB_READY
		self.mConnect = None
		self.mEngin = None
		self.Create( )


	def GetEnginName( self ) :
		return "Sqlite"


	def Create( self ) :
		self.mEngin = SqliteDatabase( )
		self.mStatus = E_DB_CREATE		
		return True


	def Open( self, aPath ) :
		#LOG_TRACE('DB TEST ' )
		if self.mStatus < E_DB_CREATE :
			LOG_ERR('Database is not created')
			return False
			
		if self.mStatus >= E_DB_OPEN :
			LOG_ERR('Database is already created')
			return True

		if self.mEngin.DoOpen( aPath ) == True :
			self.mStatus = E_DB_OPEN
			return True
		else :
			LOG_ERR('Open Fail')

		return False


	def Connect( self ) :
		#LOG_TRACE('DB TEST')
		if self.mStatus < E_DB_OPEN :
			LOG_ERR('Database is not opened')
			return False
		
		if self.mEngin.DoConnect() == True :
			self.mStatus = E_DB_CONNECT
		else :
			LOG_ERR('Connect Fail')

		return False


	def Execute( self, aCmd ):
		#LOG_TRACE('DB TEST')
		if self.mStatus < E_DB_CONNECT	:
			LOG_ERR('Database is not connected')
			return None

		return self.mEngin.DoExecute( aCmd )


	def Commit( self ):
		#LOG_TRACE('DB TEST')
		if self.mStatus < E_DB_CONNECT	:
			LOG_ERR('Database is not connected')
		
		return self.mEngin.DoCommit( )


	def GetStatus( self ):
		#LOG_TRACE('DB TEST mStatus=%d' %self.mStatus)
		return self.mStatus


	def Close( self ) :
		if self.mStatus >= E_DB_OPEN :		
			self.mEngin.DoClose( )
			self.mStatus = E_DB_READY


	def IsOpened( self ) :
		#OG_TRACE('DB TEST status=%d' %self.mStatus)
		if self.mStatus >= E_DB_OPEN :
			return True

		return False


	def IsConnected( self ) :
		#OG_TRACE('DB TEST status=%d' %self.mStatus)
		if self.mStatus >= E_DB_CONNECT :
			return True

		return False


	def GetDatabasePath( self ) :
		#OG_TRACE('DB TEST path=%s' %self.mEngin.GetDatabasePath() )	
		return self.mEngin.GetDatabasePath()
	
	
