import xbmc
import xbmcgui
import sys
import time
import os
import shutil


from database.Database  import Database
from util.Logger import LOG_TRACE, LOG_WARN, LOG_ERR
from ElisClass import *


DEFAULT_RECORD_DB_PATH = '/tmp/recordinfo.db'


class ElisRecordDB( Database ) :
	def __init__( self, aPath = None ) :
		Database.__init__( self )
		self.mResult = None
		ret = True
		
		if aPath == None :
			ret = self.Open( DEFAULT_RECORD_DB_PATH )
		else :
			ret = self.Open( aPath )

		if ret == False :
			return

		self.Connect( )


	def Record_GetCount( self, aServiceType ) :
		req = 'SELECT COUNT(*) FROM tblRecordInfo'
		req +=' WHERE ServiceType=%d' % aServiceType
		
		reply = self.Execute( req )

		if reply == None :
			return 0

		for count in reply :
			print count
			return count[0]


	def Record_GetRecordInfo( self, aIndex, aServiceType ) :
		self.Record_GetList( aServiceType )
		
		if self.mResult == None :
			return None
		if aIndex >= 0 and aIndex < len(self.mResult) :
			return self.mResult[aIndex]


	def Record_GetList( self , aServiceType ) :	
		req = 'SELECT * FROM tblRecordInfo'
		req +=' WHERE ServiceType=%d' % aServiceType
		req +=' ORDER BY StartTime'

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for record in reply :
			self.Record_Parse( record )

		count = len( self.mResult )
		if count <= 0 :
			return None

		return self.mResult


	def Record_Parse( self, aRecord ) :
		elisRecord = ElisERecordInfo( )
		elisRecord.reset( )
		key									= aRecord[0]
		elisRecord.mRecordKey				= aRecord[1]
		elisRecord.mFolderNumber			= aRecord[2]
		elisRecord.mChannelName				= aRecord[3].encode('utf-8')
		elisRecord.mRecordName				= aRecord[4].encode('utf-8')						
		elisRecord.mStartTime				= aRecord[5]
		elisRecord.mDuration				= aRecord[6]
		elisRecord.mPlayedOffset			= aRecord[7]
		elisRecord.mChannelNo				= aRecord[8]
		elisRecord.mServiceType				= aRecord[9]
		elisRecord.mServiceId				= aRecord[10]
		elisRecord.mVpid					= aRecord[11]
		elisRecord.mApid					= aRecord[12]
		elisRecord.mLocked					= aRecord[13]		
		"""
		elisRecord.mHas16_9Video				= aRecord[13]
		elisRecord.mHasSubtitles				= aRecord[14]
		elisRecord.mHasHardOfHearingSub			= aRecord[15]
		elisRecord.mHasStereoAudio				= aRecord[16]
		elisRecord.mHasMultichannelAudio		= aRecord[17]
		elisRecord.mHasDolbyDigital				= aRecord[18]
		elisRecord.mIsSeries					= aRecord[19]
		elisRecord.mHasTimer					= aRecord[20]
		elisRecord.mTimerId						= aRecord[21]
		elisRecord.mAgeRating					= aRecord[22]
		"""
		#elisRecord.printdebug()
		self.mResult.append( elisRecord )


