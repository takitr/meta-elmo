import sys
import time
import os
import shutil


from database.Database  import Database
from util.Logger import LOG_TRACE, LOG_WARN, LOG_ERR


DEFAULT_PROPERTY_DB_PATH = '/tmp/property.db'


class ElisPropertyDB( Database ) :
	def __init__( self, aPath = None ) :
		Database.__init__( self )
		self.mResult = None
		ret = True
		
		if aPath == None :
			ret = self.Open( DEFAULT_PROPERTY_DB_PATH )
		else :
			ret = self.Open( aPath )

		if ret == False :
			return

		self.Connect( )


	def Enum_GetProp( self, mName ) :
		req = 'SELECT * FROM tblPropertyEnum'
		req += " WHERE PropName='%s'" % mName

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None
		else :
			for val in reply :
				return val[2]


	def Int_GetProp( self, mName ) :
		req = 'SELECT * FROM tblPropertyInt'
		req += " WHERE PropName='%s'" % mName

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None
		else :
			for val in reply :
				return val[2]