import os
import sys
import time
from inspect import currentframe
import inspect


gLogOut = 0

E_LOG_NORMAL = 0
E_LOG_ERR    = 2
E_LOG_WARN   = 1
E_LOG_DEBUG  = 0
E_LOG_NONE   = 999
#E_DEBUG_LEVEL = E_LOG_NORMAL #E_LOG_NONE
E_DEBUG_LEVEL = E_LOG_NONE



def LOG_TRACE( msg ):
	MLOG( E_LOG_DEBUG, msg )


def LOG_ERR( msg ):
	MLOG( E_LOG_ERR, msg )


def LOG_WARN( msg ):
	MLOG( E_LOG_WARN, msg )


def MLOG( level=0, msg=None ) :
	if E_DEBUG_LEVEL > level :
		return



	curframe = inspect.currentframe()
	calframe = inspect.getouterframes(curframe, 2)
	filePath = calframe[2][1]


	filename = os.path.basename( filePath )
	lineno   = calframe[2][2]
	filefunc = calframe[2][3]

	#if level >= 0 and level <= 18 :
	if gLogOut == 0 :
		print '[%s() %s:%s]%s'% (filefunc, filename, lineno, msg)

	else :
		color = 33 #black
		if level == E_LOG_ERR :
			color = 31 #red
		elif level == E_LOG_WARN :
			color = 37 #green ?
		print '\033[1;%sm[%s() %s:%s]%s\033[1;m'% (color, filefunc, filename, lineno, msg)



def LOG_INIT( ):
	
	#mbox.ini -- path : xbmc_root / script.mbox / mbox.ini
	import re, xbmcaddon, shutil
	rd=0
	#self.fd=0
	#inifile = 'mbox.ini'
	logpath = ''
	logfile = ''
	logmode = ''
	inifile = ''
	scriptDir = xbmcaddon.Addon('script.mbox').getAddonInfo('path')

	try:
		inifile = os.path.join(scriptDir, 'mbox.ini')

		rd = open( inifile, 'r' )
		for line in rd.readlines() :
			ret   = re.sub( '\n', '', line )
			value = re.split( '=', ret )
			if value[0] == 'log_path' :
				logpath = value[1]
			elif value[0] == 'log_file' :
				logfile = value[1]
			elif value[0] == 'log_mode' :
				logmode = value[1]

		print 'inifile[%s] logmod[%s] logfile[%s] rd[%s]'% (inifile, logmode, logfile, rd )

	except Exception, e:
		print 'exception[%s]'% e
		logmode = 'stdout'
		logfile = os.path.join(scriptDir, 'default.log')
		print 'inifile[%s] logmod[%s] logfile[%s] rd[%s]'% (inifile, logmode, logfile, rd )



