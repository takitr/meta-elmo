import sys
import time
import os
import shutil


from database.Database  import Database
from util.Logger import LOG_TRACE, LOG_WARN, LOG_ERR
from ElisClass import *


DEFAULT_EPG_DB_PATH = '/tmp/epg.db'
E_EPG_DB_CF_PATH = '/tmp/epgcf.db'
E_EPG_DB_CF 					= 1
E_EPG_DB_CF_GET_BY_CHANNEL		= 0
E_EPG_DB_CF_GET_BY_CURRENT		= 1
E_EPG_DB_CF_GET_BY_FOLLOWING	= 2

class ElisEPGDB( Database ) :
	def __init__( self, aPath = None ) :
		Database.__init__( self )
		self.mResult = None
		ret = True
		
		if aPath == None :
			ret = self.Open( DEFAULT_EPG_DB_PATH )
		elif aPath == E_EPG_DB_CF :
			ret = self.Open( E_EPG_DB_CF_PATH )
		else :
			ret = self.Open( aPath )

		if ret == False :
			return

		self.Connect( )


	def Epgevent_Get( self , aEventId,  aSid,  aTsid, aOnid,  aStartTime ) :

		req = 'SELECT * FROM tblEPG'
		req +=' WHERE Sid=%d' % aSid
		req +=' AND Tsid=%d' % aTsid
		req +=' AND Onid=%d' % aOnid
		req +=' AND StartTime =%d' % aStartTime
		req +=' LIMIT 1'		
		
		#LOG_TRACE( 'REQ = %s' % req )

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for epg in reply :
			self.Epgevent_Parse( epg )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult[0]


	def Epgevent_GetList( self , aSid,  aTsid,  aOnid,  aGmtFrom, aGmtUntil, aMaxCount ) :	
		req = 'SELECT * FROM tblEPG'
		req +=' WHERE Sid=%d' % aSid
		req +=' AND Tsid=%d' % aTsid
		req +=' AND Onid=%d' % aOnid
		req +=' AND ( StartTime BETWEEN %d AND %d' %( aGmtFrom, aGmtUntil )
		req +=' OR (StartTime+Duration) BETWEEN %d AND %d )' %( aGmtFrom, aGmtUntil )
		req +=' ORDER BY StartTime'
		if aMaxCount > 0 :
			req +=' LIMIT %d' % aMaxCount

		#LOG_TRACE('REQ=%s' % req )
		
		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for epg in reply :
			self.Epgevent_Parse( epg )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' %count )
		if count <= 0 :
			return None

		return self.mResult


	def Epgevent_GetCurrent( self , aSid,  aTsid, aOnid, aGmtTime ) :	
		req = 'SELECT * FROM tblEPG'
		req +=' WHERE Sid=%d' % aSid
		req +=' AND Tsid=%d' % aTsid
		req +=' AND Onid=%d' % aOnid
		req +=' AND StartTime <= %d' % aGmtTime
		req +=' AND (StartTime+Duration) > %d' % aGmtTime
		#req +=' ORDER BY StartTime'
		req +=' ORDER BY key DESC'
		req +=' LIMIT 1'

		#LOG_TRACE( 'REQ=%s' % req )
		
		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for epg in reply :
			self.Epgevent_Parse( epg )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult[0]


	def Epgevent_GetCurrentList( self, aGmtTime ) :
		req = 'SELECT * FROM tblEPG'
		req +=' WHERE StartTime <= %d' %aGmtTime
		req +=' AND (StartTime+Duration) > %d' %aGmtTime

		#LOG_TRACE('REQ=%s' %req )
		
		reply = self.Execute( req )
		if reply == None :
			LOG_WARN('Has no result')
			return None

		self.mResult = []

		for epg in reply :
			self.Epgevent_Parse( epg )

		count = len( self.mResult )
		#LOG_TRACE('count=%d' %count )
		if count <= 0 :
			return None

		return self.mResult


	def Epgevent_GetFollowing( self , aSid,  aTsid, aOnid, aGmtTime ) :
		req = 'SELECT * FROM tblEPG'
		req +=' WHERE Sid=%d' % aSid
		req +=' AND Tsid=%d' % aTsid
		req +=' AND Onid=%d' % aOnid
		req +=' AND StartTime > %d' % aGmtTime
#		req +=' AND (StartTime+Duration) > %d' %aGmtTime
		req +=' ORDER BY StartTime'		
		req +=' LIMIT 1'

		#LOG_TRACE( 'REQ = %s' % req )
		
		reply = self.Execute( req )
		if reply == None :
			LOG_WARN(' Has no result ')
			return None

		self.mResult = []

		for epg in reply :
			self.Epgevent_Parse( epg )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult[0]


	def Epgevent_GetFollowingList( self, aGmtTime ) :
		req = 'select A.* from tblEPG A inner join ( '
		req += 'select sid, tsid, onid, Min(StartTime) as startTime '
		req += 'from tblEPG where startTime > %d ' % aGmtTime
		req += 'group by sid, tsid, onid ) B on A.Sid = B.sid and A.Tsid = B.tsid '
		req += 'and A.Onid = B.onid and A.startTime = B.startTime' 
		
		#req ='select * from tblEPG where startTime >'
		#req +=' ( select starttime + duration from tblEPG where startTime <= %d and starttime + duration > %d group by Sid, Tsid, Onid )' %(aGmtTime, aGmtTime )

		#LOG_TRACE( 'REQ = %s' % req )
		
		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for epg in reply :
			self.Epgevent_Parse( epg )

		count = len( self.mResult )
		#LOG_TRACE( 'count=%d' % count )
		if count <= 0 :
			return None

		return self.mResult


	def Epgevent_GetListFromEpgCF( self, aTable = E_EPG_DB_CF_GET_BY_CHANNEL ) :

		if aTable == E_EPG_DB_CF_GET_BY_CHANNEL :
			reqTable = 'tblChannelEPG'
		elif aTable == E_EPG_DB_CF_GET_BY_CURRENT :
			reqTable = 'tblCurrentEPG'
		elif aTable == E_EPG_DB_CF_GET_BY_FOLLOWING :
			reqTable = 'tblFollowingEPG'
		
		req = 'SELECT * FROM %s'% reqTable

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for epg in reply :
			self.Epgevent_Parse( epg )

		count = len( self.mResult )
		#LOG_TRACE( 'count=%d' % count )
		if count <= 0 :
			return None

		return self.mResult


	def Epgevent_GetCurrentByChannelFromEpgCF( self ) :
		req = 'SELECT * FROM tblChannelEPG limit 1'

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for epg in reply :
			self.Epgevent_Parse( epg )

		count = len( self.mResult )
		#LOG_TRACE( 'count=%d' % count )
		if count <= 0 :
			return None

		return self.mResult



	def Epgevent_Parse( self, aEPG ) :
		epgEvent = ElisIEPGEvent( )
		epgEvent.reset( )
		key									= aEPG[0]
		epgEvent.mEventName					= aEPG[1].encode('utf-8')
		epgEvent.mEventDescription			= aEPG[2].encode('utf-8')
		epgEvent.mStartTime					= aEPG[3]
		epgEvent.mDuration					= aEPG[4]						
		epgEvent.mSid						= aEPG[5]
		epgEvent.mTsid						= aEPG[6]
		epgEvent.mOnid						= aEPG[7]
		epgEvent.mEventId					= aEPG[8]
		epgEvent.mContentTag				= aEPG[9]
		epgEvent.mHasVisuallyImpairedAudio	= aEPG[10]
		epgEvent.mHasHardOfHearingAudio		= aEPG[11]
		epgEvent.mHasHDVideo				= aEPG[12]
		epgEvent.mHas16_9Video				= aEPG[13]
		epgEvent.mHasSubtitles				= aEPG[14]
		epgEvent.mHasHardOfHearingSub		= aEPG[15]
		epgEvent.mHasStereoAudio			= aEPG[16]
		epgEvent.mHasMultichannelAudio		= aEPG[17]
		epgEvent.mHasDolbyDigital			= aEPG[18]
		epgEvent.mIsSeries					= aEPG[19]
		epgEvent.mHasTimer					= aEPG[20]
		epgEvent.mTimerId					= aEPG[21]
		epgEvent.mAgeRating					= aEPG[22]
#		epgEvent.printdebug()
		self.mResult.append( epgEvent )

