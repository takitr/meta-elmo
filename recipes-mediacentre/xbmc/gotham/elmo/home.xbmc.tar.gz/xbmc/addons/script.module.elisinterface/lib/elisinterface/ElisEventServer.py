#!/usr/bin/python
import os
import sys
import time
from net.Net import EventServer, EventHandler, EventRequest
import select
from odict import odict
from decorator import decorator
import thread
from threading import Thread
from ElisEventClass import *

receiverPort 		= 54321

print 'ElisEventServer'

gThreads = odict()

@decorator
def RunThread(func, *args, **kwargs):
	worker = Thread(target = func, name=func.__name__, args = args, kwargs = kwargs)
	gThreads[worker.getName()] = worker
	worker.start()
	return worker
	
__elismgr = None

def getInstance():
	global __elismgr
	if not __elismgr:
		print 'lael98 check create instance'
		__elismgr = ElisEventMgr()
	#else:
		#print 'lael98 check already windowmgr is created'

	return __elismgr
class ElisEventHandler( EventHandler ):
	def handle( self ):
		
		print 'lael98 check handle ElisEventHandler'
		
		#cur_thread = threading.currentThread()
		'''
		print "lael98 check threadname %s" % cur_thread.getName()
		'''

		request = EventRequest( self.request )
		
		while 1:
			fd_sets = select.select([self.request], [], [], 0.5 )
			if not fd_sets[0]:
				if getInstance().shutdowning:
					break
				else :
					continue

			event = request.ReadMsg()
			self.DoEvent( event )
			print 'handle end --->!!!!!!!!!!!!!!!!!'
	

	def DoEvent( self, event ):
		for i in range( len( event ) ):
			print 'received reply[%d] ---> %s' %(i,event[i])

		elisevent=ElisEvent.ParseElisEvent(event)
		elisevent.printdebug()
		print 'elisevent name %s'%elisevent.getName()
'''
		self.bus.Publish( elisevent )
'''

class ElisEventRecevier( EventServer ): pass


class ElisEventMgr( object ):
	def __init__( self ):
		print 'lael98 check ElisMgr init'
		print 'check test'
		self.shutdowning = False
		print 'check test netconfig.receiverPort=%d' %receiverPort		
		self.receiver = ElisEventRecevier(('', receiverPort), ElisEventHandler )
		print 'check test'

	def getCommander( self ):
		return self.commander

	def getEventBus( self ):
		return self.eventBus
	
	@RunThread
	def run( self ):
		print 'lael98 check ElisMgr run...'
		self.receiver.serve_forever()
		print 'lael98 check ElisMgr run2...'

	def shutdown( self ):
		print 'lael98 check ElisMgr shutdown...'
		self.shutdowning = True
		self.receiver.shutdown()		
