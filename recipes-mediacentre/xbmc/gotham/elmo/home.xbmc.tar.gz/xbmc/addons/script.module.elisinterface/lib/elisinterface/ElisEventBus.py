#Channel :  [Number, PresentationNumber, Name, ServiceType, Locked, IsCA, IsHD, Nid, Sid, Tsid, Onid, CarrierType ]
#EPG : [ EventId, EventName, Sid, Tsid, Onid, StartTime, Duration, ContentTag, Components, IsSeries, HasTimer, TimerId, AgeRating ]
#EPG_Description : [EventId, Description ]
#Satellite  : [Longitude, Band, Name]
#Satellite Carrier : [Frequency, Symbolrate, Polarization, FECMode, Tsid, Onid, Nid]
#ConfiguredSatellite : [TunerIndex, SlotNumber, SatelliteLongitude, BandType, FrequencyLevel, DisEqc11, DisEqcMode, DisEqcRepeat,
#				   IsConfigUsed, LnbType, MotorizedType, LowLNB, HighLNB, LNBThreshold, MotorizedData,
#				   IsOneCable, OneCablePin, OneCableMDU, OneCableLoFreq1, OneCableLoFreq2, OneCableUBSlot, OneCableUBFreq]
#PlayerStatus [ Mode, Key, ServiceType, StartTimeInMs, PlayTimeInMs, EndTimeInMs, Speed, IsTimeshiftPending ]
#RecordInfo [ RecordKey, FolderNumber, StartTime, Duration, PlayedOffset(longlong), ChannelNo, ServiceType, ChannelName, RecordName, Sid, Vpid, Apid, Locked ]

import thread
import time
import weakref

class ElisEventBus(object):
	def __init__(self):
		self.mListeners = {}
		self.mEventQueue = []
		self.mLock = thread.allocate_lock()
		self.mEnableThread = True
		thread.start_new_thread( self.Publish,() )
		#self.Publish()
		
	def Register(self, aListener, aAddFirst=False):
		self.mLock.acquire() 

		listener = self.mListeners.get( aListener.GetName(), None)
		
		if listener :
			del self.mListeners[aListener.GetName()]

		self.mListeners[aListener.GetName()]= weakref.proxy( aListener )

		self.mLock.release()

	def Deregister(self, aListener):
		try:
			self.mLock.acquire()
			listener = self.mListeners.get( aListener.GetName(), None )
			if listener == None :
				print 'WARN Cannot find listener=%s' %aListener.GetName()
			else:
				del self.mListeners[aListener.GetName()]
		finally:
			self.mLock.release()

	def AddEvent(self, aEvent):
		#print 'Publishing event %s to %d listeners' % (aEvent, len(self.mListeners))
		self.mLock.acquire()
		self.mEventQueue.insert( 0, aEvent )
		self.mLock.release()

	def Shutdown(self ):
		self.mLock.acquire() 
		self.mEnableThread = False
		self.mLock.release()

	def Publish( self  ) :
		while( self.mEnableThread ) :
			self.mLock.acquire()
			if len( self.mEventQueue	) <= 0 :
				self.mLock.release()
				time.sleep(0.2)
				continue
			event = self.mEventQueue.pop()

			#print 'publish event=%s' %event

			try:
				listener = self.mListeners.get( 'GlobalEvent', None)
				if listener :
					listener.onEvent( event )

			except Exception, ex:
				print 'Error publishing event %s to %s ex=%s' % (event, listener, ex)


			for key, listener in self.mListeners.iteritems():
				try:
					if key == 'GlobalEvent' : continue
					listener.onEvent( event )

				except Exception, ex:
					print 'Error publishing event %s to %s ex=%s' % (event, listener, ex)

			self.mLock.release()
			#time.sleep(0.1)
