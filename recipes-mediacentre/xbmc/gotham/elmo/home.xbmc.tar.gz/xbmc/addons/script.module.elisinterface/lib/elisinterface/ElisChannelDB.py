import sys
import time
import os
import shutil
from copy import deepcopy

from database.Database import Database
from ElisEnum import ElisEnum
from ElisClass import *
from util.Logger import LOG_TRACE, LOG_WARN, LOG_ERR


DEFAULT_CHANNEL_DB_PATH = '/tmp/channel.db'
E_TABLE_BED_ZAPPING     = 'tblZappingChannel'
E_TABLE_BED_ALLCHANNEL  = 'tblChannel'
E_TABLE_ALLCHANNEL = 0
E_TABLE_ZAPPING = 1


class ElisChannelDB( Database ) :
	def __init__( self, aPath = None ) :
		Database.__init__( self )
		self.mResult = None
		#self.mSkip = False #edit mode : skip all, list mode : skipped=0 only
		ret = True

		if aPath == None :
			ret = self.Open( DEFAULT_CHANNEL_DB_PATH )
		else :
			ret = self.Open( aPath )

		if ret == False :
			return
		self.Connect( )


	def Zappingmode_GetCurrent( self ) :
		req = 'SELECT * FROM tblZappingMode'
		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for zappingmode in reply :
			self.Zappingmode_GetCurrent_Parse( zappingmode )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult[0]


	def Channel_GetCount( self, aServiceType = 1, aDBTable = E_TABLE_ALLCHANNEL ) :
		reqTable = E_TABLE_BED_ALLCHANNEL

		if aDBTable :
			reqTable = E_TABLE_BED_ZAPPING

		req = 'SELECT count(*) FROM %s'% reqTable
		reqType = ' where ServiceType=%s'% aServiceType
		req = req + reqType
		reply = self.Execute( req )

		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		reply = reply.fetchall()
		reply = list(reply[0])

		return reply[0]


	def Channel_GetByOne( self, aSid ) :
		req = 'select a.* from tblChannel as a,'
		req += ' (select sid,tsid,onid from tblZappingChannel where sid=%s limit 1) as b'% ( aSid )
		req += ' where a.sid=b.sid and a.tsid=b.tsid and a.onid=b.onid'
 		reply = self.Execute( req )

		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []
		self.Channel_GetList_Parse( reply, 0 )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult[0]


	def Channel_GetList( self, aServiceType, aZappingMode, aSortingMode, aLongitude=-1, aBand=-1, aCAid=-1, aFavName='', aSkip=False, aDBTable = E_TABLE_ALLCHANNEL ) :
		req = ''
		reqType = ''
		reqMode = ''
		reqSort = ''
		reqSkip = ' and Skipped=0'
		reqTable = E_TABLE_BED_ALLCHANNEL
		offset = 0

		if aDBTable :
			reqTable = E_TABLE_BED_ZAPPING

		reqType = ' where ServiceType=%s'% aServiceType
		if aSkip :
			reqSkip = ''

		if aSortingMode == ElisEnum.E_SORT_BY_DEFAULT :
			reqSort = ' order by Number'
		elif aSortingMode == ElisEnum.E_SORT_BY_NUMBER :
			reqSort = ' order by Number'
		elif aSortingMode == ElisEnum.E_SORT_BY_ALPHABET :
			reqSort = ' order by Name'
		elif aSortingMode == ElisEnum.E_SORT_BY_HD :
			reqSort = ' order by IsHD desc'

		#reqField= 'Number, Presentation, Name, ServiceType, Locked, IsCA, IsHD, Nid, Sid, Tsid, Onid, CarrierType,CarrierType, Skipped, IsBlank, Longitude, Band, Frequency, SymbolRate, FECMode, Polarization'
		reqField= '*'
		if aZappingMode == ElisEnum.E_MODE_ALL :
			#req = 'SELECT * FROM %s'% reqTable
			req = 'SELECT %s FROM %s'% (reqField,reqTable)
			reqMode = ''

		elif aZappingMode == ElisEnum.E_MODE_SATELLITE :
			#req = 'SELECT * FROM %s'% reqTable
			req = 'SELECT %s FROM %s'% (reqField,reqTable)
			reqMode = ' and Longitude=%s and Band=%s'% (aLongitude, aBand)

		elif aZappingMode == ElisEnum.E_MODE_CAS :
			#req = 'SELECT * FROM %s'% reqTable
			req = 'SELECT %s FROM %s'% (reqField,reqTable)
			reqMode = ' and IsCA=%s'% aCAid
			
		elif aZappingMode == ElisEnum.E_MODE_FAVORITE :
			if reqTable == E_TABLE_BED_ZAPPING :
				reqTuner = ''
				if aLongitude == 1 :
					reqTuner = ' WHERE key = 1'
				req = 'SELECT a.* FROM tblFavoriteChannel AS a,'
				req += ' (SELECT DISTINCT Longitude, Frequency, SymbolRate, Band, Polarization FROM tblZappingChannel %s) AS b'% reqTuner
				req += ' WHERE a.Longitude = b.Longitude AND a.Frequency = b.Frequency AND a.SymbolRate = b.SymbolRate AND a.Band = b.Band AND a.Polarization = b.Polarization'
				req += ' and a.GroupName = \'%s\''% aFavName
				reqType = ' and ServiceType=%s'% aServiceType
			else :
				req = 'SELECT * FROM tblFavoriteChannel'
				reqMode = ' and GroupName=\'%s\''% aFavName

			reqSort = ' order by key'
			offset = 1

		elif aZappingMode == ElisEnum.E_MODE_NETWORK :
			return None


		req = req + reqType + reqMode + reqSkip + reqSort
		reply = self.Execute( req )

		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []
		self.Channel_GetList_Parse( reply, offset )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult


	def Favorite_GetList( self, aServiceType ) :
		req = 'SELECT * FROM tblFavoriteGroup'
		req += ' WHERE ServiceType=%d' % aServiceType
		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		reply = reply.fetchall()
		#LOG_TRACE('reply[%s]'% reply)

		if not reply :
			return None

		count = len( reply )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		for iFavGroup in reply :
			self.Favorite_GetList_Parse( iFavGroup, count )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult


	def Satellite_GetByChannelNumber( self, aNumber, aType, aDBTable = E_TABLE_ALLCHANNEL ) :
		reqTable = E_TABLE_BED_ALLCHANNEL
		if aDBTable :
			reqTable = E_TABLE_BED_ZAPPING

		req = 'SELECT Longitude,Band FROM %s'% reqTable
		req += ' Where Number=%s and ServiceType=%s'% (aNumber, aType)
		
		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		reply = reply.fetchall()
		#LOG_TRACE('reply[%s]'% reply)

		if not reply :
			return None

		count = len( reply )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None


		req = 'SELECT * FROM tblConfiguredSatelliteInfo'
		req += ' Where Longitude=%s and Band=%s'% (reply[0][0], reply[0][1])

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for satellite in reply :
			self.Satellite_GetConfiguredList_Parse( satellite )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult[0]


	def Satellite_GetList( self, aSortOrder ) :
		req = 'SELECT * FROM tblSatellite'
		if aSortOrder == ElisEnum.E_SORTING_FAVORITE :
			req += ' ORDER BY key'
		elif aSortOrder == ElisEnum.E_SORTING_ALPHABET :
			req += ' ORDER BY Name'
		else :
			req += ' ORDER BY Longitude'

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for satellite in reply :
			self.Satellite_GetList_Parse( satellite )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult


	def Satellite_GetListByChannel( self ) :
		req = 'SELECT DISTINCT s.key, s.longitude, s.band, s.name' 
		req +=' FROM tblSatellite AS s INNER JOIN tblChannel AS c'
		req +=' WHERE s.longitude = c.longitude AND s.band = c.band'

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []
		for satellite in reply :
			self.Satellite_GetList_Parse( satellite )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult


	def Satellite_GetConfiguredList( self, aSortOrder ) :
		req = 'SELECT * FROM tblConfiguredSatelliteInfo'
		if aSortOrder == ElisEnum.E_SORT_LONGITUDE :
			req += ' ORDER BY Longitude'
		elif aSortOrder == ElisEnum.E_SORT_NAME :
			req += ' ORDER BY Name'
		else :
			req += ' ORDER BY key'

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for satellite in reply :
			self.Satellite_GetConfiguredList_Parse( satellite )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult


	def Satelliteconfig_GetList( self, aTunerNumber ) :
		req = 'SELECT * FROM tblSatelliteConfig'
		req += ' WHERE TunerIndex=%d' % aTunerNumber

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for satellite in reply :
			self.Satelliteconfig_GetList_Parse( satellite )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult


	def Transponder_GetList( self, aLongitude, aBand ) :
		req = 'SELECT * FROM tblSCarrier'
		req +=' WHERE Longitude=%d' % aLongitude
		req +=' AND Band=%d' % aBand

		reply = self.Execute( req )
		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for transponder in reply :
			self.Transponder_GetList_Parse( transponder )

		count = len( self.mResult )
		#LOG_TRACE( 'count = %d' % count )
		if count <= 0 :
			return None

		return self.mResult


	def Satellite_GetList_Parse( self, aSatellite ) :
		satelliteAll = ElisISatelliteInfo( )
		satelliteAll.reset( )
		key									= aSatellite[0]
		satelliteAll.mLongitude				= aSatellite[1]
		satelliteAll.mBand					= aSatellite[2]
		satelliteAll.mName					= aSatellite[3].encode('utf-8')
		self.mResult.append( satelliteAll )


	def Satellite_GetConfiguredList_Parse( self, aSatellite ) :
		satellite = ElisISatelliteInfo( )
		satellite.reset( )
		key									= aSatellite[0]
		satellite.mLongitude				= aSatellite[1]
		satellite.mBand						= aSatellite[2]
		satellite.mName						= aSatellite[3].encode('utf-8')
		self.mResult.append( satellite )


	def Satelliteconfig_GetList_Parse( self, aSatellite ) :
		satellite = ElisISatelliteConfig( )
		satellite.reset( )
		key									= aSatellite[0]
		satellite.mTunerIndex				= aSatellite[1]
		satellite.mSlotNumber				= aSatellite[2]
		satellite.mSatelliteLongitude		= aSatellite[3]
		satellite.mBandType					= aSatellite[4]
		satellite.mFrequencyLevel			= aSatellite[5]
		satellite.mDisEqc11					= aSatellite[6]
		satellite.mDisEqcMode				= aSatellite[7]
		satellite.mDisEqcRepeat				= aSatellite[8]
		satellite.mIsConfigUsed				= aSatellite[9]
		satellite.mLnbType					= aSatellite[10]
		satellite.mMotorizedType			= aSatellite[11]
		satellite.mLowLNB					= aSatellite[12]
		satellite.mHighLNB					= aSatellite[13]
		satellite.mLNBThreshold				= aSatellite[14]
		satellite.mMotorizedData			= aSatellite[15]
		satellite.mIsOneCable				= aSatellite[16]
		satellite.mOneCablePin				= aSatellite[17]
		satellite.mOneCableMDU				= aSatellite[18]
		satellite.mOneCableLoFreq1			= aSatellite[19]
		satellite.mOneCableLoFreq2			= aSatellite[20]
		satellite.mOneCableUBSlot			= aSatellite[21]
		satellite.mOneCableUBFreq			= aSatellite[22]
		self.mResult.append( satellite )


	def Transponder_GetList_Parse( self, aTransponder ) :
		transponder = ElisITransponderInfo( )
		transponder.reset( )
		key									= aTransponder[0]
		transponder.mFrequency				= aTransponder[2]
		transponder.mSymbolRate				= aTransponder[3]
		transponder.mPolarization			= aTransponder[6]
		transponder.mFECMode				= aTransponder[5]
		self.mResult.append( transponder )


	def Zappingmode_GetCurrent_Parse( self, aZappingmode ) :
		zappingmodeAll = ElisIZappingMode( )
		zappingmodeAll.reset( )
		key														= aZappingmode[0]
		zappingmodeAll.mMode									= aZappingmode[1]
		zappingmodeAll.mSortingMode								= aZappingmode[2]
		zappingmodeAll.mServiceType								= aZappingmode[3]
		zappingmodeAll.mFavoriteGroup.mGroupName				= aZappingmode[4].encode('utf-8')
		zappingmodeAll.mFavoriteGroup.mServiceType				= aZappingmode[5]
		zappingmodeAll.mFavoriteGroup.mFavoriteChannelCount		= aZappingmode[6]
		zappingmodeAll.mINetworkInfo.mNid						= aZappingmode[7]
		zappingmodeAll.mINetworkInfo.mName						= aZappingmode[8].encode('utf-8')
		zappingmodeAll.mSatelliteInfo.mLongitude				= aZappingmode[9]
		zappingmodeAll.mSatelliteInfo.mBand						= aZappingmode[10]
		zappingmodeAll.mSatelliteInfo.mName						= aZappingmode[11].encode('utf-8')
		zappingmodeAll.mCasInfo.mName							= aZappingmode[12].encode('utf-8')
		zappingmodeAll.mCasInfo.mChannelCount					= aZappingmode[13]
		zappingmodeAll.mCasInfo.mCAId							= aZappingmode[14]
		self.mResult.append( zappingmodeAll )


	def Favorite_GetList_Parse( self, aFavorite, aCount ) :
		iFavGroup = ElisIFavoriteGroup( )
		iFavGroup.reset( )
		key													= aFavorite[0]
		iFavGroup.mGroupName								= aFavorite[1].encode('utf-8')
		iFavGroup.mServiceType								= aFavorite[2]
		iFavGroup.mFavoriteChannelCount						= aCount
		self.mResult.append( iFavGroup )


	def Channel_GetList_Parse2( self, iChannel, aIChannel ) :
		iChannel.parseReturnBuffer(aIChannel)

		return iChannel

	def Channel_GetList_Parse( self, aReply, idx ) :

		for aIChannel in aReply :
			mDVBS = ElisIDVBSCarrier( aIChannel[13+idx] ,aIChannel[16+idx] ,aIChannel[14+idx] ,aIChannel[15+idx] ,aIChannel[17+idx] ,aIChannel[18+idx] )
			iCarrier = ElisICarrier( aIChannel[12+idx] , ElisIDVBCCarrier() , ElisIDVBTCarrier() , mDVBS )
			iChannel = ElisIChannel( aIChannel[1+idx] ,aIChannel[2+idx] ,aIChannel[3+idx].encode('utf-8') ,aIChannel[4+idx] ,aIChannel[5+idx] ,aIChannel[8+idx] ,aIChannel[9+idx] ,aIChannel[21+idx] ,aIChannel[19+idx] ,aIChannel[20+idx] ,aIChannel[22+idx] ,aIChannel[12+idx] ,aIChannel[6+idx] ,aIChannel[7+idx], iCarrier )
			"""
			iChannel = ElisIChannel()
			#iChannel.reset( )
			#key											= aIChannel[0]

			iChannel.mNumber							= aIChannel[1+idx]
			iChannel.mPresentationNumber				= aIChannel[2+idx]
			iChannel.mName								= aIChannel[3+idx].encode('utf-8')
			iChannel.mServiceType						= aIChannel[4+idx]
			iChannel.mLocked							= aIChannel[5+idx]
			iChannel.mSkipped							= aIChannel[6+idx]
			iChannel.mIsBlank							= aIChannel[7+idx]
			iChannel.mIsCA								= aIChannel[8+idx]
			iChannel.mIsHD								= aIChannel[9+idx]
			#iChannel.mLockStartTime					= aIChannel[10+idx]
			#iChannel.mLockEndTime						= aIChannel[11+idx]
			iChannel.mCarrierType						= aIChannel[12+idx]

			#------DEPRECATED-----
			#iChannel.mCarrier.mDVBC.mFrequency			= 
			#iChannel.mCarrier.mDVBC.mSymbolRate		= 
			#iChannel.mCarrier.mDVBC.mQAM				= 
			#iChannel.mCarrier.mDVBT.mFrequency			= 
			#iChannel.mCarrier.mDVBT.mBand				= 

			iChannel.mCarrier = ElisICarrier()
			iChannel.mCarrier.mDVBS = ElisIDVBSCarrier()
			#iChannel.mCarrier = iCarrier
			#iChannel.mCarrier.mDVBS = iDVBS
			iChannel.mCarrier.mDVBS.mSatelliteLongitude	= aIChannel[13+idx]
			iChannel.mCarrier.mDVBS.mFrequency			= aIChannel[14+idx]
			iChannel.mCarrier.mDVBS.mSymbolRate			= aIChannel[15+idx]
			iChannel.mCarrier.mDVBS.mSatelliteBand		= aIChannel[16+idx]
			iChannel.mCarrier.mDVBS.mFECValue			= aIChannel[17+idx]
			iChannel.mCarrier.mDVBS.mPolarization		= aIChannel[18+idx]
			iChannel.mSid								= aIChannel[19+idx]
			iChannel.mTsid								= aIChannel[20+idx]
			iChannel.mNid								= aIChannel[21+idx]
			iChannel.mOnid								= aIChannel[22+idx]
			"""
			self.mResult.append( iChannel )







