import sys
import time
import os
import shutil

from util.Logger import LOG_TRACE, LOG_WARN, LOG_ERR


class SqliteDatabase( object ):
	def __init__(self):
		self.mDatabasePath = None
		self.mCursor = None

	
	def DoOpen( self, aPath ) :
		self.mDatabasePath = aPath
		return True


	def DoConnect( self ) :
		try:
			from sqlite3 import dbapi2 as sqlite3
		except:
			LOG_ERR('connect err')
			from pysqlite2 import dbapi2 as sqlite3

		try:
			self.mConnect = sqlite3.connect( self.mDatabasePath )
			self.mConnect.isolation_level = None

			self.mCursor = self.mConnect.cursor( )
		except Exception, ex:
			LOG_ERR('DB TEST ex=%s' %ex)
			self.mConnect = None
			return False

		return True


	def DoExecute( self, aCmd ):
		#LOG_TRACE('DB TEST aCmd=%s' %aCmd)
		self.mResult = None
		self.mResult = self.mCursor.execute( aCmd )
		return self.mResult
		

	def DoCommit( self ):
		self.mConnect.commit( )
		return True


	def DoClose( self ) :

		if self.mCursor :
			self.mCursor.close( )

		if self.mConnect :
			self.mConnect.close( )

		return True

	def GetDatabasePath( self ) :
		return self.mDatabasePath



