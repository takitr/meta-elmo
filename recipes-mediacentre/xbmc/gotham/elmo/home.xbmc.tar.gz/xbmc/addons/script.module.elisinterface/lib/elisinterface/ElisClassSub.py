
from ElisEnum import ElisEnum
"""
# ElisInterface Classes for Python UI\n
# ElisCommand Interface Classes\n
# @package ElisCommander\n
# This Class describes all structure of Python UI.\n
# All functions of this class have it's equavalent functions in M/W on C++\n
# @author doliyu@marusys.com, jhshin@marusys.com\n
# @date	02.12.2011\n
# @file elisclass.py\n
"""

	
class ElisPseudoFolder( object ): 
		""" 
		ElisPseudoFolder Record Navigation PseudoFolder\n
		\brief Record Navigation PseudoFolder\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mPFolderType	PseudoFoler Type: E_NAV_PFOLDER_ROOT, E_NAV_PFOLDER_CHANNEL, E_NAV_PFOLDER_DATE, E_NAV_PFOLDER_GENRE, E_NAV_PFOLDER_TIMER
		Integer	mLevel	0:PFolder Root, 1:Folders, 2:Recordings
		Integer	mIndex	index
		Integer	mChannelNo	Channel Number
		Integer	mServiceType	Service Type :
		String	mChannelName	Channel Name
		Integer	mYear	Year
		Integer	mMonth	Month
		Integer	mContentTag	ContentTag
		Integer	mTimerId	TimerId
		Integer	mIsTimerSeries	Is TimerSeries

		"""

		def __init__(self, amPFolderType = 0 ,amLevel = 0 ,amIndex = 0 ,amChannelNo = 0 ,amServiceType = 0 ,amChannelName = "No Name" ,amYear = 0 ,amMonth = 0 ,amContentTag = 0 ,amTimerId = 0 ,amIsTimerSeries = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, PseudoFoler Type: E_NAV_PFOLDER_ROOT, E_NAV_PFOLDER_CHANNEL, E_NAV_PFOLDER_DATE, E_NAV_PFOLDER_GENRE, E_NAV_PFOLDER_TIMER
			###
			self.mPFolderType= amPFolderType

			### 
			# Type: Integer, 0:PFolder Root, 1:Folders, 2:Recordings
			###
			self.mLevel= amLevel

			### 
			# Type: Integer, index
			###
			self.mIndex= amIndex

			### 
			# Type: Integer, Channel Number
			###
			self.mChannelNo= amChannelNo

			### 
			# Type: Integer, Service Type :
			###
			self.mServiceType= amServiceType

			### 
			# Type: String, Channel Name
			###
			self.mChannelName= amChannelName

			### 
			# Type: Integer, Year
			###
			self.mYear= amYear

			### 
			# Type: Integer, Month
			###
			self.mMonth= amMonth

			### 
			# Type: Integer, ContentTag
			###
			self.mContentTag= amContentTag

			### 
			# Type: Integer, TimerId
			###
			self.mTimerId= amTimerId

			### 
			# Type: Integer, Is TimerSeries
			###
			self.mIsTimerSeries= amIsTimerSeries

		def reset(self):
			"""
				Reset to default value
			"""
			self.mPFolderType= 0
			self.mLevel= 0
			self.mIndex= 0
			self.mChannelNo= 0
			self.mServiceType= 0
			self.mChannelName= "No Name"
			self.mYear= 0
			self.mMonth= 0
			self.mContentTag= 0
			self.mTimerId= 0
			self.mIsTimerSeries= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mPFolderType)
			req.append('%d' %self.mLevel)
			req.append('%d' %self.mIndex)
			req.append('%d' %self.mChannelNo)
			req.append('%d' %self.mServiceType)
			req.append(self.mChannelName)
			req.append('%d' %self.mYear)
			req.append('%d' %self.mMonth)
			req.append('%d' %self.mContentTag)
			req.append('%d' %self.mTimerId)
			req.append('%d' %self.mIsTimerSeries)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mPFolderType= int(ret[offset])
			offset=offset+1
			self.mLevel= int(ret[offset])
			offset=offset+1
			self.mIndex= int(ret[offset])
			offset=offset+1
			self.mChannelNo= int(ret[offset])
			offset=offset+1
			self.mServiceType= int(ret[offset])
			offset=offset+1
			self.mChannelName= ret[offset]
			offset=offset+1
			self.mYear= int(ret[offset])
			offset=offset+1
			self.mMonth= int(ret[offset])
			offset=offset+1
			self.mContentTag= int(ret[offset])
			offset=offset+1
			self.mTimerId= int(ret[offset])
			offset=offset+1
			self.mIsTimerSeries= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  PseudoFolder'
			print 'mPFolderType= %d'%self.mPFolderType
			print 'mLevel= %d'%self.mLevel
			print 'mIndex= %d'%self.mIndex
			print 'mChannelNo= %d'%self.mChannelNo
			print 'mServiceType= %d'%self.mServiceType
			print 'mChannelName= %s'%self.mChannelName
			print 'mYear= %d'%self.mYear
			print 'mMonth= %d'%self.mMonth
			print 'mContentTag= %d'%self.mContentTag
			print 'mTimerId= %d'%self.mTimerId
			print 'mIsTimerSeries= %d'%self.mIsTimerSeries

class ElisPriority( object ): 
		""" 
		ElisPriority Record Navigation Priority\n
		\brief Record Navigation Priority\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mPriorityType	Mode : E_NAV_PRIORITY_ROOT, E_NAV_PRIORITY_USER, E_NAV_PRIORITY_MOST_WATCHED, E_NAV_PRIORITY_UNWATCHED,E_NAV_PRIORITY_WATCHED
		Integer	mLevel	0:Priority Root, 1:Recordings

		"""

		def __init__(self, amPriorityType = ElisEnum.E_NAV_TYPE_ALL ,amLevel = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Mode : E_NAV_PRIORITY_ROOT, E_NAV_PRIORITY_USER, E_NAV_PRIORITY_MOST_WATCHED, E_NAV_PRIORITY_UNWATCHED,E_NAV_PRIORITY_WATCHED
			###
			self.mPriorityType= amPriorityType

			### 
			# Type: Integer, 0:Priority Root, 1:Recordings
			###
			self.mLevel= amLevel

		def reset(self):
			"""
				Reset to default value
			"""
			self.mPriorityType= ElisEnum.E_NAV_TYPE_ALL
			self.mLevel= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mPriorityType)
			req.append('%d' %self.mLevel)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mPriorityType= int(ret[offset])
			offset=offset+1
			self.mLevel= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  Priority'
			print 'mPriorityType= %d'%self.mPriorityType
			print 'mLevel= %d'%self.mLevel

class ElisUserFolder( object ): 
		""" 
		ElisUserFolder Record Navigation UserFolder\n
		\brief Record Navigation UserFolder\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mFolderNumber	Mode : E_NAV_TYPE_ALL, E_NAV_PFOLDER_CHANNEL, E_NAV_TYPE_PSEUDO_FOLDER, E_NAV_TYPE_PRIORITY
		Integer	mParentFolder	Parent Folder

		"""

		def __init__(self, amFolderNumber = ElisEnum.E_NAV_TYPE_ALL ,amParentFolder = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Mode : E_NAV_TYPE_ALL, E_NAV_PFOLDER_CHANNEL, E_NAV_TYPE_PSEUDO_FOLDER, E_NAV_TYPE_PRIORITY
			###
			self.mFolderNumber= amFolderNumber

			### 
			# Type: Integer, Parent Folder
			###
			self.mParentFolder= amParentFolder

		def reset(self):
			"""
				Reset to default value
			"""
			self.mFolderNumber= ElisEnum.E_NAV_TYPE_ALL
			self.mParentFolder= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mFolderNumber)
			req.append('%d' %self.mParentFolder)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mFolderNumber= int(ret[offset])
			offset=offset+1
			self.mParentFolder= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  UserFolder'
			print 'mFolderNumber= %d'%self.mFolderNumber
			print 'mParentFolder= %d'%self.mParentFolder

class ElisISO639Lang( object ): 
		""" 
		ElisISO639Lang Language Code\n
		\brief Language Code\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		String	mLanguageCode	Language Code

		"""

		def __init__(self, amLanguageCode = "ENG"):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: String, Language Code
			###
			self.mLanguageCode= amLanguageCode

		def reset(self):
			"""
				Reset to default value
			"""
			self.mLanguageCode= "ENG"

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append(self.mLanguageCode)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mLanguageCode= ret[offset]
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ISO639Lang'
			print 'mLanguageCode= %s'%self.mLanguageCode
			

class ElisIWeeklyTimer( object ): 
		""" 
		ElisIWeeklyTimer Timer Information\n
		\brief Timer Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mDate	Date
		Integer	mStartTime	Start Time
		Integer	mDuration	Duration

		"""

		def __init__(self, amDate = 0 ,amStartTime = 0 ,amDuration = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Date
			###
			self.mDate= amDate

			### 
			# Type: Integer, Start Time
			###
			self.mStartTime= amStartTime

			### 
			# Type: Integer, Duration
			###
			self.mDuration= amDuration

		def reset(self):
			"""
				Reset to default value
			"""
			self.mDate= 0
			self.mStartTime= 0
			self.mDuration= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mDate)
			req.append('%d' %self.mStartTime)
			req.append('%d' %self.mDuration)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mDate= int(ret[offset])
			offset=offset+1
			self.mStartTime= int(ret[offset])
			offset=offset+1
			self.mDuration= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IWeeklyTimer'
			print 'mDate= %d'%self.mDate
			print 'mStartTime= %d'%self.mStartTime
			print 'mDuration= %d'%self.mDuration


class ElisCIMMIMenuDataItem( object ): 
		""" 
		ElisCIMMIMenuDataItem CI MMI Menu Data Item\n
		\brief CI MMI Menu Data Item\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		String	mText	Title

		"""

		def __init__(self, amText = "No Title"):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: String, Title
			###
			self.mText= amText

		def reset(self):
			"""
				Reset to default value
			"""
			self.mText= "No Title"

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append(self.mText)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mText= ret[offset]
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  CIMMIMenuDataItem'
			print 'mText= %s'%self.mText

