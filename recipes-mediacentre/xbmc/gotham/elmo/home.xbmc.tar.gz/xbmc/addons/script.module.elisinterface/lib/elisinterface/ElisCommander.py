
from net.Net import EventCommander
from ElisAction import ElisAction
from ElisEnum import ElisEnum
from ElisClass import *
import thread
from decorator import decorator


gLock = thread.allocate_lock()

@decorator
def ElisLock(func, *args, **kw):
	gLock.acquire()
	try :
		print 'ElisEnter %s' % func.__name__
		result =  func(*args, **kw)
		print 'ElisLeave %s' % func.__name__		
		return result
		
	finally:
		gLock.release( )

def ParseReturnInteger(ret):
		return int(ret[0])


def ParseReturnBool(ret):
		if ret[0].upper() == 'TRUE':
			return True
		else :
			return False

class ElisCommander( EventCommander ): 
		""" 
		@addtogroup ElisInterface_Python
		ElisInterface for Python UI
		@{
		ElisCommand Interface Class
		@package ElisCommander
		This Class describes all functions between m/w and Python UI.
		All functions of this class have it's equavalent functions in M/W on C++
		@author doliyu@marusys.com, jhshin@marusys.com
		@date	02.12.2011
		@file ElisCommander.py
		"""

		@ElisLock
		def SetElisReady(self ,  aPeerAddress) :
			"""
			Socket connect
			@param    aPeerAddress  String  M/W IP addrss
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.SetElisReady )
			req.append(aPeerAddress)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def App_Ready(self ) :
			"""
			XBMC Ready for Key event Received
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.App_Ready )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Zappingmode_GetCurrent(self ) :
			"""
			Get Current ZappingMode
			@return    IZappingMode  Struct  Zapping Mode
				\n[\n
				]\n
			
			"""
			req = []
			req.append( ElisAction.Zappingmode_GetCurrent )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIZappingMode = ElisIZappingMode()
				retIZappingMode.parseReturnBuffer( reply, 0 )
				return retIZappingMode
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIZappingMode = ElisIZappingMode()
				retIZappingMode.mError = int(reply[1])
				return retIZappingMode
			else :
				return None
				

		@ElisLock
		def Zappingmode_SetCurrent(self ,  IZappingMode) :
			"""
			Set Current ZappingMode
			@param    IZappingMode  Struct ElisIZappingMode  Zapping Mode
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Zappingmode_SetCurrent )
			for ele in IZappingMode:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_Get(self ,  channelNumber,  serviceType) :
			"""
			Get Current by number
			@param    channelNumber  Integer  Channel Number 
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return    IChannel  Struct  Channel Information
				\n[\n
				]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_Get )
			req.append('%d' %channelNumber)
			req.append('%d' %serviceType)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				return retIChannel
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.mError = int(reply[1])
				return retIChannel
			else :
				return None
				

		@ElisLock
		def Channel_GetByTwolDs(self ,  Sid,  Onid) :
			"""
			Get Current by Sid and Onid
			@param    Sid  Integer  Service ID
			@param    Onid  Integer  Original Network ID
			@return    IChannel  Struct  Channel Information
				\n[\n
				]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_GetByTwolDs )
			req.append('%d' %Sid)
			req.append('%d' %Onid)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				return retIChannel
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.mError = int(reply[1])
				return retIChannel
			else :
				return None
				

		@ElisLock
		def Channel_GetByFourIDs(self ,  channelNumber,  Sid,  Onid,  TSid) :
			"""
			Get Current by Sid ,Onid, TSid, Channel Number
			@param    channelNumber  Integer  Channel Number
			@param    Sid  Integer  Service ID
			@param    Onid  Integer  Original Network ID
			@param    TSid  Integer  Transport Stream ID
			@return    IChannel  Struct  Channel Information
				\n[\n
				]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_GetByFourIDs )
			req.append('%d' %channelNumber)
			req.append('%d' %Sid)
			req.append('%d' %Onid)
			req.append('%d' %TSid)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				return retIChannel
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.mError = int(reply[1])
				return retIChannel
			else :
				return None
				

		@ElisLock
		def Channel_InvalidateCurrent(self ) :
			"""
			Invalidete Current Channel
			@return      Bool  TRUE or FALSE
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_InvalidateCurrent )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_SetCurrent(self ,  channelNumber,  serviceType) :
			"""
			Set Current Channel
			@param    channelNumber  Integer  Channel Number of Current Channel
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return      Bool  TRUE or FALSE
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_SetCurrent )
			req.append('%d' %channelNumber)
			req.append('%d' %serviceType)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_GetCurrent(self ) :
			"""
			Get Current Channel
			@return    IChannel  Struct  Channel Information
				\n[\n
				]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_GetCurrent )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				return retIChannel
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.mError = int(reply[1])
				return retIChannel
			else :
				return None
				

		@ElisLock
		def Channel_GetPrev(self ) :
			"""
			Get Prev Channel
			@return    IChannel  Struct  Channel Information
				\n[\n
				]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_GetPrev )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				return retIChannel
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.mError = int(reply[1])
				return retIChannel
			else :
				return None
				

		@ElisLock
		def Channel_GetNext(self ) :
			"""
			Get Next Channel
			@return    IChannel  Struct  Channel Information
				\n[\n
				]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_GetNext )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				return retIChannel
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.mError = int(reply[1])
				return retIChannel
			else :
				return None
				

		@ElisLock
		def Channel_GetList(self ,  serviceType,  zappingMode,  sortingMode) :
			"""
			Get Channel List for All
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    zappingMode  Integer  Zapping Mode : E_MODE_ALL, E_MODE_FAVORITE, E_MODE_NETWORK, E_MODE_SATELLITE, E_MODE_CAS
			@param    sortingMode  Integer  Sorting Mode :E_SORT_BY_DEFAULT, E_SORT_BY_ALPHABET, E_SORT_BY_CARRIER, E_SORT_BY_NUMBER, E_SORT_BY_HD
			@return    IChannel  Struct  Channel Information
				\n[\n[\n
				]\n]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_GetList )
			req.append('%d' %serviceType)
			req.append('%d' %zappingMode)
			req.append('%d' %sortingMode)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retIChannel = ElisIChannel()
						retIChannel.parseReturnBuffer( reply, 0 )
						retValue.append( retIChannel )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retIChannel = ElisIChannel()
						retIChannel.mError = int(reply[1])
						retValue.append( retIChannel )
						return retValue
					else :
						return None
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				retValue.append( retIChannel )
			

		@ElisLock
		def Channel_GetByPresentationNumber(self ,  aPresentationNumber,  IZappingMode) :
			"""
			Get Channel by Presentation Number
			@param    aPresentationNumber  Integer  Channel Number
			@param    IZappingMode  Struct ElisIZappingMode  IZappingMode
			@return    IChannel  Struct  Channel Information
				\n[\n[\n
				]\n]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_GetByPresentationNumber )
			req.append('%d' %aPresentationNumber)
			for ele in IZappingMode:
				ele.appendReqBuffer(req)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retIChannel = ElisIChannel()
						retIChannel.parseReturnBuffer( reply, 0 )
						retValue.append( retIChannel )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retIChannel = ElisIChannel()
						retIChannel.mError = int(reply[1])
						retValue.append( retIChannel )
						return retValue
					else :
						return None
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				retValue.append( retIChannel )
			

		@ElisLock
		def Channel_GetPresentationNumber(self ,  aNumber,  aServiceType) :
			"""
			Get Presentation Number
			@param    aNumber  Integer  Channel Number
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return      Integer  Presentation Number
			"""
			req = []
			req.append( ElisAction.Channel_GetPresentationNumber )
			req.append('%d' %aNumber)
			req.append('%d' %aServiceType)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Channel_FlushHistory(self ) :
			"""
			Channel History Flush
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channel_FlushHistory )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_GetPreviousChannelNumber(self ) :
			"""
			Get Pervious Channel Number
			@return      Integer  Pervious Channel Number
			"""
			req = []
			req.append( ElisAction.Channel_GetPreviousChannelNumber )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Channel_GetHistoryCount(self ) :
			"""
			Get History Count
			@return      Integer  History Count
			"""
			req = []
			req.append( ElisAction.Channel_GetHistoryCount )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Channel_GetHistory(self ,  aIndex) :
			"""
			Get History
			@param    aIndex  Integer  History index
			@return      Integer  History Number
			"""
			req = []
			req.append( ElisAction.Channel_GetHistory )
			req.append('%d' %aIndex)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Channel_SetInitialBlank(self ,  aBlank) :
			"""
			Set Initial Blank for Channel
			@param    aBlank  Integer  Blank Value
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channel_SetInitialBlank )
			req.append('%d' %aBlank)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_GetInitialBlank(self ) :
			"""
			Get History
			@return      Integer  Channel Initial Blank
			"""
			req = []
			req.append( ElisAction.Channel_GetInitialBlank )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Channel_AddHistory(self ,  aChannelNumber,  aServiceType) :
			"""
			Add History
			@param    aChannelNumber  Integer  Channel Number
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channel_AddHistory )
			req.append('%d' %aChannelNumber)
			req.append('%d' %aServiceType)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_SetHD(self ,  aHD,  IChannel) :
			"""
			Set HD for Channel
			@param    aHD  Integer  HD Set
			@param    IChannel  Struct ElisIChannel  IChannel
			@return      Bool  TRUE or FALSE
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_SetHD )
			req.append('%d' %aHD)
			for ele in IChannel:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_CurrentAudioChannel(self ) :
			"""
			Get Current Audio of Channel
			@return      Integer  Current Audio
			"""
			req = []
			req.append( ElisAction.Channel_CurrentAudioChannel )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Channel_GetListBySatellite(self ,  serviceType,  zappingMode,  sortingMode,  longitude,  band) :
			"""
			Get Channel List by Satellite
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    zappingMode  Integer  Zapping Mode : E_MODE_ALL, E_MODE_FAVORITE, E_MODE_NETWORK, E_MODE_SATELLITE, E_MODE_CAS
			@param    sortingMode  Integer  Sorting Mode :E_SORT_BY_DEFAULT, E_SORT_BY_ALPHABET, E_SORT_BY_CARRIER, E_SORT_BY_NUMBER, E_SORT_BY_HD
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Band :Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			@return    IChannel  Struct  Channel Information
				\n[\n[\n
				]\n]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_GetListBySatellite )
			req.append('%d' %serviceType)
			req.append('%d' %zappingMode)
			req.append('%d' %sortingMode)
			req.append('%d' %longitude)
			req.append('%d' %band)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retIChannel = ElisIChannel()
						retIChannel.parseReturnBuffer( reply, 0 )
						retValue.append( retIChannel )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retIChannel = ElisIChannel()
						retIChannel.mError = int(reply[1])
						retValue.append( retIChannel )
						return retValue
					else :
						return None
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				retValue.append( retIChannel )
			

		@ElisLock
		def Channel_GetListByFavorite(self ,  serviceType,  zappingMode,  sortingMode,  favoriteName) :
			"""
			Get Channel List by Favorite
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    zappingMode  Integer  Zapping Mode : E_MODE_ALL, E_MODE_FAVORITE, E_MODE_NETWORK, E_MODE_SATELLITE, E_MODE_CAS
			@param    sortingMode  Integer  Sorting Mode :E_SORT_BY_DEFAULT, E_SORT_BY_ALPHABET, E_SORT_BY_CARRIER, E_SORT_BY_NUMBER, E_SORT_BY_HD
			@param    favoriteName  String  Favorite Name
			@return    IChannel  Struct  Channel Information
				\n[\n[\n
				]\n]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_GetListByFavorite )
			req.append('%d' %serviceType)
			req.append('%d' %zappingMode)
			req.append('%d' %sortingMode)
			req.append(favoriteName)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retIChannel = ElisIChannel()
						retIChannel.parseReturnBuffer( reply, 0 )
						retValue.append( retIChannel )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retIChannel = ElisIChannel()
						retIChannel.mError = int(reply[1])
						retValue.append( retIChannel )
						return retValue
					else :
						return None
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				retValue.append( retIChannel )
			

		@ElisLock
		def Channel_GetListByFTACas(self ,  serviceType,  zappingMode,  sortingMode,  CAId) :
			"""
			Get Channel List by FTA_CA
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    zappingMode  Integer  Zapping Mode : E_MODE_ALL, E_MODE_FAVORITE, E_MODE_NETWORK, E_MODE_SATELLITE, E_MODE_CAS
			@param    sortingMode  Integer  Sorting Mode :E_SORT_BY_DEFAULT, E_SORT_BY_ALPHABET, E_SORT_BY_CARRIER, E_SORT_BY_NUMBER, E_SORT_BY_HD
			@param    CAId  Integer  CAId : E_FTA_CHANNEL, E_MEDIAGUARD, E_VIACCESS, E_NAGRA, E_IRDETO, E_CONAX, E_CRYPTOWORKS, E_NDS, E_BETADIGITAL,  E_OTHERS
			@return    IChannel  Struct  Channel Information
				\n[\n[\n
				]\n]\n
			
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_GetListByFTACas )
			req.append('%d' %serviceType)
			req.append('%d' %zappingMode)
			req.append('%d' %sortingMode)
			req.append('%d' %CAId)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retIChannel = ElisIChannel()
						retIChannel.parseReturnBuffer( reply, 0 )
						retValue.append( retIChannel )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retIChannel = ElisIChannel()
						retIChannel.mError = int(reply[1])
						retValue.append( retIChannel )
						return retValue
					else :
						return None
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				retValue.append( retIChannel )
			

		@ElisLock
		def Favorite_GetList(self ,  serviceType) :
			"""
			Get Favorit List
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return    IFavoriteGroup  Struct  Favoirte Group Information
				\n[\n[\n
				]\n]\n
			
			@see   IFavoriteGroup
			"""
			req = []
			req.append( ElisAction.Favorite_GetList )
			req.append('%d' %serviceType)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retIFavoriteGroup = ElisIFavoriteGroup()
						retIFavoriteGroup.parseReturnBuffer( reply, 0 )
						retValue.append( retIFavoriteGroup )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retIFavoriteGroup = ElisIFavoriteGroup()
						retIFavoriteGroup.mError = int(reply[1])
						retValue.append( retIFavoriteGroup )
						return retValue
					else :
						return None
				retIFavoriteGroup = ElisIFavoriteGroup()
				retIFavoriteGroup.parseReturnBuffer( reply, 0 )
				retValue.append( retIFavoriteGroup )
			

		@ElisLock
		def Fta_cas_GetList(self ,  serviceType) :
			"""
			Get FTA_CAS List
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return    IChannelCASInfo  Struct  CAS Information
				\n[\n[\n
				]\n]\n
			
			@see   IChannelCASInfo
			"""
			req = []
			req.append( ElisAction.Fta_cas_GetList )
			req.append('%d' %serviceType)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retIChannelCASInfo = ElisIChannelCASInfo()
						retIChannelCASInfo.parseReturnBuffer( reply, 0 )
						retValue.append( retIChannelCASInfo )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retIChannelCASInfo = ElisIChannelCASInfo()
						retIChannelCASInfo.mError = int(reply[1])
						retValue.append( retIChannelCASInfo )
						return retValue
					else :
						return None
				retIChannelCASInfo = ElisIChannelCASInfo()
				retIChannelCASInfo.parseReturnBuffer( reply, 0 )
				retValue.append( retIChannelCASInfo )
			

		@ElisLock
		def Channel_SkipByNumber(self ,  aSet,  serviceType,  EInteger) :
			"""
			Channel Delete
			@param    aSet  Integer  Skip Value : 1 or 0
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    EInteger  Struct ElisEInteger  Channel Number Information
			@return      Bool  TRUE or FALSE
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_SkipByNumber )
			req.append('%d' %aSet)
			req.append('%d' %serviceType)
			for ele in EInteger:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_Skip(self ,  aSet,  IChannel) :
			"""
			Channel Skip Set/Reset
			@param    aSet  Integer  Skip Value : 1 or 0
			@param    IChannel  Struct ElisIChannel  Channel Information
			@return      Bool  TRUE or FALSE
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_Skip )
			req.append('%d' %aSet)
			for ele in IChannel:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_LockByNumber(self ,  aLock,  serviceType,  EInteger) :
			"""
			Channel Delete
			@param    aLock  Integer  Lock Value : 1 or 0
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    EInteger  Struct ElisEInteger  Channel Number Information
			@return      Bool  TRUE or FALSE
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_LockByNumber )
			req.append('%d' %aLock)
			req.append('%d' %serviceType)
			for ele in EInteger:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_Lock(self ,  aLock,  IChannel) :
			"""
			Channel Lock Set/Reset
			@param    aLock  Integer  Lock Value : 1 or 0
			@param    IChannel  Struct ElisIChannel  Channel Information
			@return      Bool  TRUE or FALSE
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_Lock )
			req.append('%d' %aLock)
			for ele in IChannel:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_DeleteByNumber(self ,  serviceType,  aUseDB,  EInteger) :
			"""
			Channel Delete
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    aUseDB  Integer  Use DB Value : 0 = Not Use, 1 = Use
			@param    EInteger  Struct ElisEInteger  Channel Number Information
			@return      Bool  TRUE or FALSE
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_DeleteByNumber )
			req.append('%d' %serviceType)
			req.append('%d' %aUseDB)
			for ele in EInteger:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_Delete(self ,  aUseDB,  IChannel) :
			"""
			Channel Delete
			@param    aUseDB  Integer  Use DB Value : 0 = Not Use, 1 = Use
			@param    IChannel  Struct ElisIChannel  Channel Number Information
			@return      Bool  TRUE or FALSE
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_Delete )
			req.append('%d' %aUseDB)
			for ele in IChannel:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_Save(self ) :
			"""
			Channel Save
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channel_Save )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_Backup(self ) :
			"""
			Channel Backup
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channel_Backup )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_DeleteAll(self ) :
			"""
			Channel Delete All
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channel_DeleteAll )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_Move(self ,  aServiceType,  aInsertedNumber,  IChannel) :
			"""
			Move Channel
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    aInsertedNumber  Integer  Insert Number
			@param    IChannel  Struct ElisIChannel  Channel Information 
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channel_Move )
			req.append('%d' %aServiceType)
			req.append('%d' %aInsertedNumber)
			for ele in IChannel:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_Restore(self ,  aRestore) :
			"""
			Channel Restore
			@param    aRestore  Integer  Restore Value : 1 or 0
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channel_Restore )
			req.append('%d' %aRestore)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_GetZappingList(self ,  aSync) :
			"""
			Channel Get Zapping List
			@param    aSync  Integer  aSync: 1(aSync DB Update), 0(Sync DB Update)
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channel_GetZappingList )
			req.append('%d' %aSync)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Favoritegroup_GetGroupCount(self ,  serviceType) :
			"""
			Get Group Count of FavoriteGroup
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return      Integer  Total Group Count of FavoriteGroup
			"""
			req = []
			req.append( ElisAction.Favoritegroup_GetGroupCount )
			req.append('%d' %serviceType)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Favoritegroup_Create(self ,  groupName,  serviceType) :
			"""
			FavoriteGroup Create
			@param    groupName  String  FavoirteGroup Name
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return      Integer  Favorite Group Index
			"""
			req = []
			req.append( ElisAction.Favoritegroup_Create )
			req.append(groupName)
			req.append('%d' %serviceType)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Favoritegroup_GetByIndex(self ,  index,  serviceType) :
			"""
			Get FavoriteGroup by Favorite index 
			@param    index  Integer  FavoriteGroup index
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return    IFavoriteGroup  Struct  Favoirte Group Information
				\n[\n
				]\n
			
			@see   IFavoriteGroup
			"""
			req = []
			req.append( ElisAction.Favoritegroup_GetByIndex )
			req.append('%d' %index)
			req.append('%d' %serviceType)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIFavoriteGroup = ElisIFavoriteGroup()
				retIFavoriteGroup.parseReturnBuffer( reply, 0 )
				return retIFavoriteGroup
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIFavoriteGroup = ElisIFavoriteGroup()
				retIFavoriteGroup.mError = int(reply[1])
				return retIFavoriteGroup
			else :
				return None
				

		@ElisLock
		def Favoritegroup_GetByGroupName(self ,  groupName,  serviceType) :
			"""
			Get FavoriteGroup by Favorite Name 
			@param    groupName  String  FavoirteGroup Name
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return    IFavoriteGroup  Struct  Favoirte Group Information
				\n[\n
				]\n
			
			@see   IFavoriteGroup
			"""
			req = []
			req.append( ElisAction.Favoritegroup_GetByGroupName )
			req.append(groupName)
			req.append('%d' %serviceType)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIFavoriteGroup = ElisIFavoriteGroup()
				retIFavoriteGroup.parseReturnBuffer( reply, 0 )
				return retIFavoriteGroup
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIFavoriteGroup = ElisIFavoriteGroup()
				retIFavoriteGroup.mError = int(reply[1])
				return retIFavoriteGroup
			else :
				return None
				

		@ElisLock
		def Favoritegroup_Remove(self ,  groupName,  serviceType) :
			"""
			FavoirteGroup Remove
			@param    groupName  String  FavoirteGroup Name
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Favoritegroup_Remove )
			req.append(groupName)
			req.append('%d' %serviceType)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Favoritegroup_ChangeName(self ,  groupName,  serviceType,  groupNewName) :
			"""
			FavoirteGroup Change Name
			@param    groupName  String  FavoirteGroup Name
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    groupNewName  String  FavoirteGroup New Name
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Favoritegroup_ChangeName )
			req.append(groupName)
			req.append('%d' %serviceType)
			req.append(groupNewName)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Favoritegroup_AddChannelByNumber(self ,  groupName,  serviceType,  EInteger) :
			"""
			Favorite Group Add Channel
			@param    groupName  String  FavoirteGroup Name
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    EInteger  Struct ElisEInteger  Channel Number Information
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Favoritegroup_AddChannelByNumber )
			req.append(groupName)
			req.append('%d' %serviceType)
			for ele in EInteger:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Favoritegroup_AddChannel(self ,  groupName,  channelNumber,  serviceType) :
			"""
			Favorite Group Add Channel
			@param    groupName  String  FavoirteGroup Name
			@param    channelNumber  Integer  Channel Number 
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Favoritegroup_AddChannel )
			req.append(groupName)
			req.append('%d' %channelNumber)
			req.append('%d' %serviceType)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Favoritegroup_RemoveChannelByNumber(self ,  groupName,  serviceType,  EInteger) :
			"""
			Favorite Group Remove Channel
			@param    groupName  String  FavoirteGroup Name
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    EInteger  Struct ElisEInteger  Channel Number Information
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Favoritegroup_RemoveChannelByNumber )
			req.append(groupName)
			req.append('%d' %serviceType)
			for ele in EInteger:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Favoritegroup_RemoveChannel(self ,  groupName,  channelNumber,  serviceType) :
			"""
			Favorite Group Remove Channel
			@param    groupName  String  FavoirteGroup Name
			@param    channelNumber  Integer  Channel Number 
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Favoritegroup_RemoveChannel )
			req.append(groupName)
			req.append('%d' %channelNumber)
			req.append('%d' %serviceType)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def FavoriteGroup_GetChannel(self ,  aGroupName,  aServiceType,  aChannelIndex) :
			"""
			Get Channel by index of Favorite Group
			@param    aGroupName  String  FavoirteGroup Name
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    aChannelIndex  Integer  Channel Index 
			@return    IChannel  Struct  IChannel
				\n[\n
				]\n
			
			"""
			req = []
			req.append( ElisAction.FavoriteGroup_GetChannel )
			req.append(aGroupName)
			req.append('%d' %aServiceType)
			req.append('%d' %aChannelIndex)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.parseReturnBuffer( reply, 0 )
				return retIChannel
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIChannel = ElisIChannel()
				retIChannel.mError = int(reply[1])
				return retIChannel
			else :
				return None
				

		@ElisLock
		def FavoriteGroup_ChangeFavoriteName(self ,  aGroupName,  aServiceType,  aChannelIndex,  aNewName) :
			"""
			Change Channel Name of FavoriteGroup
			@param    aGroupName  String  FavoirteGroup Name
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    aChannelIndex  Integer  Channel Index 
			@param    aNewName  String  New Name
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.FavoriteGroup_ChangeFavoriteName )
			req.append(aGroupName)
			req.append('%d' %aServiceType)
			req.append('%d' %aChannelIndex)
			req.append(aNewName)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def FavoriteGroup_MoveChannels(self ,  aGroupName,  aInsertPosition,  aServiceType,  IChannel) :
			"""
			Move Channel of Favorite Group
			@param    aGroupName  String  FavoirteGroup Name
			@param    aInsertPosition  Integer  Insert Position
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    IChannel  Struct ElisIChannel  IChannel 
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.FavoriteGroup_MoveChannels )
			req.append(aGroupName)
			req.append('%d' %aInsertPosition)
			req.append('%d' %aServiceType)
			for ele in IChannel:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Epgevent_GetPresent(self ) :
			"""
			Get EPG of Present
			@return    IEPGEvent  Struct  Elis EPG Event
				\n[\n
				]\n
			
			@see   IEPGEvent
			@todo   mStartTime return Type :  time_t
			"""
			req = []
			req.append( ElisAction.Epgevent_GetPresent )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIEPGEvent = ElisIEPGEvent()
				retIEPGEvent.parseReturnBuffer( reply, 0 )
				return retIEPGEvent
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIEPGEvent = ElisIEPGEvent()
				retIEPGEvent.mError = int(reply[1])
				return retIEPGEvent
			else :
				return None
				

		@ElisLock
		def Epgevent_GetFollowing(self ) :
			"""
			Get EPG of Following
			@return    IEPGEvent  Struct  Elis EPG Event
				\n[\n
				]\n
			
			@see   IEPGEvent
			@todo   mStartTime return Type :  time_t
			"""
			req = []
			req.append( ElisAction.Epgevent_GetFollowing )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIEPGEvent = ElisIEPGEvent()
				retIEPGEvent.parseReturnBuffer( reply, 0 )
				return retIEPGEvent
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIEPGEvent = ElisIEPGEvent()
				retIEPGEvent.mError = int(reply[1])
				return retIEPGEvent
			else :
				return None
				

		@ElisLock
		def Epgevent_Get(self ,  eventId,  sid,  tsid,  onid,  startTime) :
			"""
			Get EPG Event
			@param    eventId  Integer  EPG Event ID 
			@param    sid  Integer  Service ID
			@param    tsid  Integer  Transport Stream ID
			@param    onid  Integer  Original Network ID
			@param    startTime  Integer  EPG Event Start Time (ms)
			@return    IEPGEvent  Struct  Elis EPG Event
				\n[\n
				]\n
			
			@see   IEPGEvent
			@todo   mStartTime return Type :  time_t
			"""
			req = []
			req.append( ElisAction.Epgevent_Get )
			req.append('%d' %eventId)
			req.append('%d' %sid)
			req.append('%d' %tsid)
			req.append('%d' %onid)
			req.append('%d' %startTime)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIEPGEvent = ElisIEPGEvent()
				retIEPGEvent.parseReturnBuffer( reply, 0 )
				return retIEPGEvent
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIEPGEvent = ElisIEPGEvent()
				retIEPGEvent.mError = int(reply[1])
				return retIEPGEvent
			else :
				return None
				

		@ElisLock
		def Epgevent_GetDescription(self ,  eventId,  sid,  tsid,  onid,  startTime) :
			"""
			Get EPG Event
			@param    eventId  Integer  EPG Event ID 
			@param    sid  Integer  Service ID
			@param    tsid  Integer  Transport Stream ID
			@param    onid  Integer  Original Network ID
			@param    startTime  Integer  EPG Event Start Time (ms)
			@return    mEventDescription  char  Elis EPG Event
			@see   IEPGEvent
			@todo   mStartTime return Type :  time_t
			"""
			req = []
			req.append( ElisAction.Epgevent_GetDescription )
			req.append('%d' %eventId)
			req.append('%d' %sid)
			req.append('%d' %tsid)
			req.append('%d' %onid)
			req.append('%d' %startTime)

			reply= self.Command(req)
			return reply

		@ElisLock
		def Epgevent_GetList(self ,  sid,  tsid,  onid,  gmtFrom,  gmtUntil,  maxCount) :
			"""
			Get EPG Event List
			@param    sid  Integer  Service ID
			@param    tsid  Integer  Transport Stream ID
			@param    onid  Integer  Original Network ID
			@param    gmtFrom  Integer  EPG Event Start Time (ms)
			@param    gmtUntil  Integer  EPG Event Start Time (ms)
			@param    maxCount  Integer  EPG Event Start Time (ms)
			@return    IEPGEvent  Struct  Elis EPG Event
				\n[\n[\n
				]\n]\n
			
			@see   IEPGEvent
			@todo   mStartTime return Type :  time_t
			"""
			req = []
			req.append( ElisAction.Epgevent_GetList )
			req.append('%d' %sid)
			req.append('%d' %tsid)
			req.append('%d' %onid)
			req.append('%d' %gmtFrom)
			req.append('%d' %gmtUntil)
			req.append('%d' %maxCount)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retIEPGEvent = ElisIEPGEvent()
						retIEPGEvent.parseReturnBuffer( reply, 0 )
						retValue.append( retIEPGEvent )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retIEPGEvent = ElisIEPGEvent()
						retIEPGEvent.mError = int(reply[1])
						retValue.append( retIEPGEvent )
						return retValue
					else :
						return None
				retIEPGEvent = ElisIEPGEvent()
				retIEPGEvent.parseReturnBuffer( reply, 0 )
				retValue.append( retIEPGEvent )
			

		@ElisLock
		def EPGEvent_ReceiveCurrent(self ) :
			"""
			Receive Current EIT
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.EPGEvent_ReceiveCurrent )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Epgevnt_GetCurrentDB(self ,  aServiceType,  aStartNumber,  aEndNumber) :
			"""
			Get Current EPG Event Current DB
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    aStartNumber  Integer  Start Channel Number
			@param    aEndNumber  Integer  End Channel Number
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Epgevnt_GetCurrentDB )
			req.append('%d' %aServiceType)
			req.append('%d' %aStartNumber)
			req.append('%d' %aEndNumber)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Epgevent_GetFollowingDB(self ,  aServiceType,  aStartNumber,  aEndNumber) :
			"""
			Get Following EPG Event Follow DB
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    aStartNumber  Integer  Start Channel Number
			@param    aEndNumber  Integer  End Channel Number
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Epgevent_GetFollowingDB )
			req.append('%d' %aServiceType)
			req.append('%d' %aStartNumber)
			req.append('%d' %aEndNumber)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Epgevent_GetChannelDB(self ,  aSid,  aTsid,  aOnid) :
			"""
			Get One Channel EPG Event Follow DB
			@param    aSid  Integer  Service ID
			@param    aTsid  Integer  Transport Stream ID
			@param    aOnid  Integer  Original Network ID
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Epgevent_GetChannelDB )
			req.append('%d' %aSid)
			req.append('%d' %aTsid)
			req.append('%d' %aOnid)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Satellite_GetByChannelNumber(self ,  number,  serviceType) :
			"""
			Get Satellite Information By ChannelNumber
			@param    number  Integer  Channel Number
			@param    serviceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@return    ISatelliteInfo  Struct  Satellite Information
				\n[\n
				]\n
			
			@see   ISatelliteInfo
			"""
			req = []
			req.append( ElisAction.Satellite_GetByChannelNumber )
			req.append('%d' %number)
			req.append('%d' %serviceType)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retISatelliteInfo = ElisISatelliteInfo()
				retISatelliteInfo.parseReturnBuffer( reply, 0 )
				return retISatelliteInfo
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retISatelliteInfo = ElisISatelliteInfo()
				retISatelliteInfo.mError = int(reply[1])
				return retISatelliteInfo
			else :
				return None
				

		@ElisLock
		def Satellite_Get(self ,  longitude,  band) :
			"""
			Get Satellite Information 
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			@return    ISatelliteInfo  Struct  Satellite Information
				\n[\n
				]\n
			
			@see   ISatelliteInfo
			"""
			req = []
			req.append( ElisAction.Satellite_Get )
			req.append('%d' %longitude)
			req.append('%d' %band)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retISatelliteInfo = ElisISatelliteInfo()
				retISatelliteInfo.parseReturnBuffer( reply, 0 )
				return retISatelliteInfo
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retISatelliteInfo = ElisISatelliteInfo()
				retISatelliteInfo.mError = int(reply[1])
				return retISatelliteInfo
			else :
				return None
				

		@ElisLock
		def Satellite_GetList(self ,  sortOrder) :
			"""
			Get Satellite List 
			@param    sortOrder  Integer  Sort Order : E_SORTING_ORBITAL, E_SORTING_ALPHBET, E_SORTING_FAVORITE
			@return    ISatelliteInfo  Struct  Satellite Information
				\n[\n[\n
				]\n]\n
			
			@see   ISatelliteInfo
			"""
			req = []
			req.append( ElisAction.Satellite_GetList )
			req.append('%d' %sortOrder)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retISatelliteInfo = ElisISatelliteInfo()
						retISatelliteInfo.parseReturnBuffer( reply, 0 )
						retValue.append( retISatelliteInfo )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retISatelliteInfo = ElisISatelliteInfo()
						retISatelliteInfo.mError = int(reply[1])
						retValue.append( retISatelliteInfo )
						return retValue
					else :
						return None
				retISatelliteInfo = ElisISatelliteInfo()
				retISatelliteInfo.parseReturnBuffer( reply, 0 )
				retValue.append( retISatelliteInfo )
			

		@ElisLock
		def Satellite_Add(self ,  longitude,  band,  name) :
			"""
			Satellite ADD
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			@param    name  String  Satellite name
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Satellite_Add )
			req.append('%d' %longitude)
			req.append('%d' %band)
			req.append(name)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Satellite_ChangeName(self ,  longitude,  band,  newName) :
			"""
			Satellite Change Name
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			@param    newName  String  Satellite newName
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Satellite_ChangeName )
			req.append('%d' %longitude)
			req.append('%d' %band)
			req.append(newName)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Satellite_Delete(self ,  longitude,  band) :
			"""
			Satellite Delete
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Satellite_Delete )
			req.append('%d' %longitude)
			req.append('%d' %band)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Satellite_GetConfiguredList(self ,  sortOrder) :
			"""
			Get Satellite List for Configured
			@param    sortOrder  Integer  Sort Order :  E_SORT_LONGITUDE, E_SORT_NAME, E_SORT_INSERTED
			@return    ISatelliteInfo  Struct  Satellite Information
				\n[\n[\n
				]\n]\n
			
			@see   ISatelliteInfo
			"""
			req = []
			req.append( ElisAction.Satellite_GetConfiguredList )
			req.append('%d' %sortOrder)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retISatelliteInfo = ElisISatelliteInfo()
						retISatelliteInfo.parseReturnBuffer( reply, 0 )
						retValue.append( retISatelliteInfo )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retISatelliteInfo = ElisISatelliteInfo()
						retISatelliteInfo.mError = int(reply[1])
						retValue.append( retISatelliteInfo )
						return retValue
					else :
						return None
				retISatelliteInfo = ElisISatelliteInfo()
				retISatelliteInfo.parseReturnBuffer( reply, 0 )
				retValue.append( retISatelliteInfo )
			

		@ElisLock
		def SatelliteConfig_GetByISatellite(self ,  aTunerNo,  ISatelliteInfo) :
			"""
			Get SatelliteConfig List by Satellite
			@param    aTunerNo  Integer  Tuner Number
			@param    ISatelliteInfo  Struct ElisISatelliteInfo  Satellite information
			@return    ISatelliteConfig  Struct  Satellite Config List
				\n[\n[\n
				]\n]\n
			
			@see   ISatelliteConfig
			"""
			req = []
			req.append( ElisAction.SatelliteConfig_GetByISatellite )
			req.append('%d' %aTunerNo)
			for ele in ISatelliteInfo:
				ele.appendReqBuffer(req)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retISatelliteConfig = ElisISatelliteConfig()
						retISatelliteConfig.parseReturnBuffer( reply, 0 )
						retValue.append( retISatelliteConfig )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retISatelliteConfig = ElisISatelliteConfig()
						retISatelliteConfig.mError = int(reply[1])
						retValue.append( retISatelliteConfig )
						return retValue
					else :
						return None
				retISatelliteConfig = ElisISatelliteConfig()
				retISatelliteConfig.parseReturnBuffer( reply, 0 )
				retValue.append( retISatelliteConfig )
			

		@ElisLock
		def SatelliteTuner_SendDiSEqC(self ,  aTunerNo,  aData,  aDataLength) :
			"""
			Send Diseqc
			@param    aTunerNo  Integer  Tuner Number
			@param    aData  String  Diseqc Data
			@param    aDataLength  Integer  Data Length
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.SatelliteTuner_SendDiSEqC )
			req.append('%d' %aTunerNo)
			req.append(aData)
			req.append('%d' %aDataLength)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Transponder_GetList(self ,  longitude,  band) :
			"""
			Get Transponder List of Satellite
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			@return    ITransponderInfo  Struct  Transponder Information
				\n[\n[\n
				]\n]\n
			
			@see   ITransponderInfo
			"""
			req = []
			req.append( ElisAction.Transponder_GetList )
			req.append('%d' %longitude)
			req.append('%d' %band)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retITransponderInfo = ElisITransponderInfo()
						retITransponderInfo.parseReturnBuffer( reply, 0 )
						retValue.append( retITransponderInfo )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retITransponderInfo = ElisITransponderInfo()
						retITransponderInfo.mError = int(reply[1])
						retValue.append( retITransponderInfo )
						return retValue
					else :
						return None
				retITransponderInfo = ElisITransponderInfo()
				retITransponderInfo.parseReturnBuffer( reply, 0 )
				retValue.append( retITransponderInfo )
			

		@ElisLock
		def Transponder_HasCompatible(self ,  longitude,  band,  ITransponderInfo) :
			"""
			Transponder
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			@param    ITransponderInfo  Struct ElisITransponderInfo  Transponder information
			@return      Bool   TRUE or FALSE
			@see   ITransponderInfo
			"""
			req = []
			req.append( ElisAction.Transponder_HasCompatible )
			req.append('%d' %longitude)
			req.append('%d' %band)
			for ele in ITransponderInfo:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Transponder_Add(self ,  longitude,  band,  ITransponderInfo) :
			"""
			Transponder Add
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			@param    ITransponderInfo  Struct ElisITransponderInfo  Transponder information
			@return      Bool   TRUE or FALSE
			@see   ITransponderInfo
			"""
			req = []
			req.append( ElisAction.Transponder_Add )
			req.append('%d' %longitude)
			req.append('%d' %band)
			for ele in ITransponderInfo:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Transponder_Delete(self ,  longitude,  band,  ITransponderInfo) :
			"""
			Transponder Delete
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			@param    ITransponderInfo  Struct ElisITransponderInfo  Transponder information
			@return      Bool   TRUE or FALSE
			@see   ITransponderInfo
			"""
			req = []
			req.append( ElisAction.Transponder_Delete )
			req.append('%d' %longitude)
			req.append('%d' %band)
			for ele in ITransponderInfo:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Satelliteconfig_GetList(self ,  tunerNo) :
			"""
			Get Satellite Config List 
			@param    tunerNo  Integer  Tuner Number 
			@return    ISatelliteConfig  Struct  Satellite Configure Information
				\n[\n[\n
				]\n]\n
			
			@see   ISatelliteConfig
			"""
			req = []
			req.append( ElisAction.Satelliteconfig_GetList )
			req.append('%d' %tunerNo)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retISatelliteConfig = ElisISatelliteConfig()
						retISatelliteConfig.parseReturnBuffer( reply, 0 )
						retValue.append( retISatelliteConfig )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retISatelliteConfig = ElisISatelliteConfig()
						retISatelliteConfig.mError = int(reply[1])
						retValue.append( retISatelliteConfig )
						return retValue
					else :
						return None
				retISatelliteConfig = ElisISatelliteConfig()
				retISatelliteConfig.parseReturnBuffer( reply, 0 )
				retValue.append( retISatelliteConfig )
			

		@ElisLock
		def Satelliteconfig_GetFirstAvailablePos(self ,  tunerNo,  currentSlotNo) :
			"""
			Get First Available Position
			@param    tunerNo  Integer  Tuner Number
			@param    currentSlotNo  Integer  Current Slot Number
			@return      Integer  First Available Position Number
			"""
			req = []
			req.append( ElisAction.Satelliteconfig_GetFirstAvailablePos )
			req.append('%d' %tunerNo)
			req.append('%d' %currentSlotNo)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Satelliteconfig_SaveList(self ,  ISatelliteConfig) :
			"""
			Get Satellite Config List 
			@param    ISatelliteConfig  Struct ElisISatelliteConfig  Satellite Configure Information
			@return      Bool  TRUE or FALSE
			@see   ISatelliteConfig
			"""
			req = []
			req.append( ElisAction.Satelliteconfig_SaveList )
			for ele in ISatelliteConfig:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Satelliteconfig_DeleteAll(self ) :
			"""
			Delete of Satellite Config
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Satelliteconfig_DeleteAll )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Datetime_GetGMTTime(self ) :
			"""
			Get GMT Time
			@return      Integer   GMT Time ms
			"""
			req = []
			req.append( ElisAction.Datetime_GetGMTTime )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Datetime_GetLocalOffset(self ) :
			"""
			Get Offset Time
			@return      Integer  Offset Time sec
			"""
			req = []
			req.append( ElisAction.Datetime_GetLocalOffset )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Datetime_GetLocalTime(self ) :
			"""
			Get Local Time
			@return      Integer   Local Time ms
			"""
			req = []
			req.append( ElisAction.Datetime_GetLocalTime )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Datetime_SetLocalOffset(self ,  aTime) :
			"""
			Set Offset Time
			@param    aTime  Integer  Offset Time
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Datetime_SetLocalOffset )
			req.append('%d' %aTime)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Datetime_SetSystemUTCTime(self ,  aTime) :
			"""
			Set UTC Time of Micom
			@param    aTime  Integer  GMT Time
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Datetime_SetSystemUTCTime )
			req.append('%d' %aTime)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Motorized_Stop(self ,  tunerNo) :
			"""
			diseqc command for Motorized Stop
			@param    tunerNo  Integer  Tuner Index
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Motorized_Stop )
			req.append('%d' %tunerNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Motorized_GoWest(self ,  tunerNo) :
			"""
			diseqc command for Go West
			@param    tunerNo  Integer  Tuner Index
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Motorized_GoWest )
			req.append('%d' %tunerNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Motorized_GoEast(self ,  tunerNo) :
			"""
			diseqc command for Go East
			@param    tunerNo  Integer  Tuner Index
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Motorized_GoEast )
			req.append('%d' %tunerNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Motorized_StepWest(self ,  tunerNo) :
			"""
			diseqc command for Step West
			@param    tunerNo  Integer  Tuner Index
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Motorized_StepWest )
			req.append('%d' %tunerNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Motorized_StepEast(self ,  tunerNo) :
			"""
			diseqc command for Step East
			@param    tunerNo  Integer  Tuner Index
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Motorized_StepEast )
			req.append('%d' %tunerNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Motorized_SetEastLimit(self ,  tunerNo) :
			"""
			diseqc command for Set East Limit
			@param    tunerNo  Integer  Tuner Index
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Motorized_SetEastLimit )
			req.append('%d' %tunerNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Motorized_SetWestLimit(self ,  tunerNo) :
			"""
			diseqc command for Set West Limit
			@param    tunerNo  Integer  Tuner Index
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Motorized_SetWestLimit )
			req.append('%d' %tunerNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Motorized_ResetLimit(self ,  tunerNo) :
			"""
			diseqc command for Reset Limit
			@param    tunerNo  Integer  Tuner Index
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Motorized_ResetLimit )
			req.append('%d' %tunerNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Motorized_GotoNull(self ,  tunerNo) :
			"""
			diseqc command for Go To NULL
			@param    tunerNo  Integer  Tuner Index
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Motorized_GotoNull )
			req.append('%d' %tunerNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Motorized_SavePosition(self ,  tunerNo,  posNo) :
			"""
			diseqc command for Save Position
			@param    tunerNo  Integer  Tuner Index
			@param    posNo  Integer  Position Index
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Motorized_SavePosition )
			req.append('%d' %tunerNo)
			req.append('%d' %posNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_GetStatus(self ) :
			"""
			Get Status of Player
			@return    IPlayerStatus  Struct  Player Status Information
				\n[\n
				]\n
			
			"""
			req = []
			req.append( ElisAction.Player_GetStatus )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIPlayerStatus = ElisIPlayerStatus()
				retIPlayerStatus.parseReturnBuffer( reply, 0 )
				return retIPlayerStatus
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIPlayerStatus = ElisIPlayerStatus()
				retIPlayerStatus.mError = int(reply[1])
				return retIPlayerStatus
			else :
				return None
				

		@ElisLock
		def Player_StartTimeshiftPlayback(self ,  playbackMode,  data) :
			"""
			Start Timeshift of Playback
			@param    playbackMode  Integer  playbackMode : E_IPLAYER_TIMESHIFT_START_PAUSE, E_IPLAYER_TIMESHIFT_START_REWIND,  E_IPLAYER_TIMESHIFT_START_REPLAY
			@param    data  Integer  Offset time ms
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_StartTimeshiftPlayback )
			req.append('%d' %playbackMode)
			req.append('%d' %data)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_StartInternalRecordPlayback(self ,  recordKey,  serviceType,  offsetms,  speed) :
			"""
			Start Internal Record of Playback
			@param    recordKey  Integer  Record Key
			@param    serviceType  Integer  Service Type
			@param    offsetms  Integer  Offset Time Ms
			@param    speed  Integer  Speed Value
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_StartInternalRecordPlayback )
			req.append('%d' %recordKey)
			req.append('%d' %serviceType)
			req.append('%d' %offsetms)
			req.append('%d' %speed)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_Stop(self ) :
			"""
			Stop of Playback
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_Stop )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_SetSpeed(self ,  speed) :
			"""
			Set Speed of Playback
			@param    speed  Integer  Play Speed
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_SetSpeed )
			req.append('%d' %speed)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_JumpTo(self ,  milisec) :
			"""
			Jump to time Play 
			@param    milisec  Integer  Jump Time ms
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_JumpTo )
			req.append('%d' %milisec)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_JumpBy(self ,  milisec) :
			"""
			Jump By time Play 
			@param    milisec  Integer  Jump Time ms
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_JumpBy )
			req.append('%d' %milisec)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_JumpToIFrame(self ,  milisec) :
			"""
			Jump to IFrame Play
			@param    milisec  Integer  Jump to IFrame ms
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_JumpToIFrame )
			req.append('%d' %milisec)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_JumpByIFrame(self ,  milisec) :
			"""
			Jump By IFrame Play
			@param    milisec  Integer  Jump to IFrame ms
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_JumpByIFrame )
			req.append('%d' %milisec)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_Pause(self ) :
			"""
			Pause of Playback
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_Pause )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_Resume(self ) :
			"""
			Resume of Playback
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_Resume )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_SetVolume(self ,  absVolume) :
			"""
			Set Volume of Playback 
			@param    absVolume  Integer  Volume Value
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_SetVolume )
			req.append('%d' %absVolume)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_GetVolume(self ) :
			"""
			Get Volume of Playback
			@return      Integer   Volume Value
			"""
			req = []
			req.append( ElisAction.Player_GetVolume )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Player_SetMute(self ,  mute) :
			"""
			Set Mute of Playback 
			@param    mute  Integer  Mute Value : 1(Mute on), 0(Mute off)
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_SetMute )
			req.append('%d' %mute)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_GetMute(self ) :
			"""
			Get Mute Statue of Playback
			@return      Integer   Mute Statue  : 1(Mute on), 0(Mute off)
			"""
			req = []
			req.append( ElisAction.Player_GetMute )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Player_AVBlank(self ,  blank,  force) :
			"""
			Set Blank/Mute of AV
			@param    blank  Integer  Blank : true or false
			@param    force  Integer  Force : true or false
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_AVBlank )
			req.append('%d' %blank)
			req.append('%d' %force)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_VideoBlank(self ,  blank,  force) :
			"""
			Set Blank/Mute of Video
			@param    blank  Integer  Blank : true or false
			@param    force  Integer  Force : true or false
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_VideoBlank )
			req.append('%d' %blank)
			req.append('%d' %force)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_AVMute(self ,  mute,  force) :
			"""
			Set Mute of AV
			@param    mute  Integer  Blank : true or false
			@param    force  Integer  Force : true or false
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_AVMute )
			req.append('%d' %mute)
			req.append('%d' %force)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_StopLivePlayer(self ) :
			"""
			Stop of LivePlayer
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_StopLivePlayer )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_SetVIdeoSize(self ,  posX,  posY,  width,  height) :
			"""
			Set Video Size of Player
			@param    posX  Integer  Position X
			@param    posY  Integer  Position Y
			@param    width  Integer  Width
			@param    height  Integer  Height
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_SetVIdeoSize )
			req.append('%d' %posX)
			req.append('%d' %posY)
			req.append('%d' %width)
			req.append('%d' %height)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_IsVideoValid(self ) :
			"""
			Video Valid
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_IsVideoValid )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_GetTimeshiftRecordedTime(self ) :
			"""
			Get Timeshift Recorded Time
			@return      Integer  Recorded Time Ms
			"""
			req = []
			req.append( ElisAction.Player_GetTimeshiftRecordedTime )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Player_Skip(self ,  aDirection,  aCount) :
			"""
			Player Skip
			@param    aDirection  Integer  Direction
			@param    aCount  Integer  Count
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_Skip )
			req.append('%d' %aDirection)
			req.append('%d' %aCount)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Record_GetCount(self ,  serviceType) :
			"""
			Get Count of Record
			@param    serviceType  Integer  service Type
			@return      Integer   Record total Count
			"""
			req = []
			req.append( ElisAction.Record_GetCount )
			req.append('%d' %serviceType)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Record_GetRecordInfo(self ,  index,  serviceType) :
			"""
			Get Record Informationl
			@param    index  Integer  Recode Index
			@param    serviceType  Integer  service Type
			@return    ERecordInfo  Struct  Record Information
				\n[\n
				]\n
			
			@see   ERecordInfo
			"""
			req = []
			req.append( ElisAction.Record_GetRecordInfo )
			req.append('%d' %index)
			req.append('%d' %serviceType)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retERecordInfo = ElisERecordInfo()
				retERecordInfo.parseReturnBuffer( reply, 0 )
				return retERecordInfo
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retERecordInfo = ElisERecordInfo()
				retERecordInfo.mError = int(reply[1])
				return retERecordInfo
			else :
				return None
				

		@ElisLock
		def Record_GetRecordInfoByKey(self ,  key) :
			"""
			Get Record Informationl by Record Key
			@param    key  Integer  Recode Id
			@return    ERecordInfo  Struct  Record Information
				\n[\n
				]\n
			
			@see   ERecordInfo
			"""
			req = []
			req.append( ElisAction.Record_GetRecordInfoByKey )
			req.append('%d' %key)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retERecordInfo = ElisERecordInfo()
				retERecordInfo.parseReturnBuffer( reply, 0 )
				return retERecordInfo
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retERecordInfo = ElisERecordInfo()
				retERecordInfo.mError = int(reply[1])
				return retERecordInfo
			else :
				return None
				

		@ElisLock
		def Record_StartRecord(self ,  channelNo,  serviceType,  duration,  recordName,  aForceDecrypted) :
			"""
			Start Record
			@param    channelNo  Integer  Record Channel Number
			@param    serviceType  Integer  Record Service Type
			@param    duration  Integer  Record Duration Time
			@param    recordName  String  Record Name
			@param    aForceDecrypted  Integer  Force Decrypted enable/disable : volue 1 or 0
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Record_StartRecord )
			req.append('%d' %channelNo)
			req.append('%d' %serviceType)
			req.append('%d' %duration)
			req.append(recordName)
			req.append('%d' %aForceDecrypted)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Record_StopRecord(self ,  channelNo,  serviceType,  key) :
			"""
			Stop Record
			@param    channelNo  Integer  Record Channel Number
			@param    serviceType  Integer  Record Service Type
			@param    key  Integer  Record Id
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Record_StopRecord )
			req.append('%d' %channelNo)
			req.append('%d' %serviceType)
			req.append('%d' %key)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Record_GetRunningRecorderCount(self ) :
			"""
			Get Running Record Count
			@return      Integer  Running Record Count
			"""
			req = []
			req.append( ElisAction.Record_GetRunningRecorderCount )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Record_GetRunningRecordInfo(self ,  index) :
			"""
			Get Running Record Informationl
			@param    index  Integer  Recode Index
			@return    ERecordInfo  Struct  Record Information
				\n[\n
				]\n
			
			@see   ERecordInfo
			"""
			req = []
			req.append( ElisAction.Record_GetRunningRecordInfo )
			req.append('%d' %index)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retERecordInfo = ElisERecordInfo()
				retERecordInfo.parseReturnBuffer( reply, 0 )
				return retERecordInfo
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retERecordInfo = ElisERecordInfo()
				retERecordInfo.mError = int(reply[1])
				return retERecordInfo
			else :
				return None
				

		@ElisLock
		def Record_GetPartitionSize(self ) :
			"""
			Get Partition Size
			@return      Integer  Parition Size
			"""
			req = []
			req.append( ElisAction.Record_GetPartitionSize )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Record_GetFreeMBSize(self ) :
			"""
			Get Free MB Size
			@return      Integer  Free MB Size
			"""
			req = []
			req.append( ElisAction.Record_GetFreeMBSize )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Record_DeleteRecord(self ,  key,  serviceType) :
			"""
			Delete Record
			@param    key  Integer  Record Id
			@param    serviceType  Integer  Record Service Type
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Record_DeleteRecord )
			req.append('%d' %key)
			req.append('%d' %serviceType)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Record_SetLock(self ,  key,  serviceType,  lock) :
			"""
			Set Lock of Record
			@param    key  Integer  Record Id
			@param    serviceType  Integer  Record Service Type
			@param    lock  Integer  Record Lock  Value : true or false
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Record_SetLock )
			req.append('%d' %key)
			req.append('%d' %serviceType)
			req.append('%d' %lock)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Record_Rename(self ,  key,  serviceType,  newName) :
			"""
			Record Rename 
			@param    key  Integer  Record Id
			@param    serviceType  Integer  Record Service Type
			@param    newName  String  New Name of Record
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Record_Rename )
			req.append('%d' %key)
			req.append('%d' %serviceType)
			req.append(newName)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Record_IsRecording(self ,  key,  serviceType) :
			"""
			Recording Check
			@param    key  Integer  Record Id
			@param    serviceType  Integer  Record Service Type
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Record_IsRecording )
			req.append('%d' %key)
			req.append('%d' %serviceType)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Enum_GetProp(self ,  name) :
			"""
			Get Enum Property
			@param    name  String  Property Name
			@return      Integer  Property Value
			"""
			req = []
			req.append( ElisAction.Enum_GetProp )
			req.append(name)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Int_GetProp(self ,  name) :
			"""
			Get Int Property
			@param    name  String  Property Name
			@return      Integer  Property Value
			"""
			req = []
			req.append( ElisAction.Int_GetProp )
			req.append(name)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Enum_SetProp(self ,  name,  Property) :
			"""
			Set Enum Property
			@param    name  String  Property Name
			@param    Property  Integer  Property Value
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Enum_SetProp )
			req.append(name)
			req.append('%d' %Property)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Int_SetProp(self ,  name,  Property) :
			"""
			Set Int Property
			@param    name  String  Property Name
			@param    Property  Integer  Property Value
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Int_SetProp )
			req.append(name)
			req.append('%d' %Property)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_SearchByCarrier(self ,  longitude,  band,  ITransponderInfo) :
			"""
			Channel Search by Carrier
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Carrier Index
			@param    ITransponderInfo  Struct ElisITransponderInfo  Transponder information
			@return      Bool   TRUE or FALSE
			@see   ITransponderInfo
			"""
			req = []
			req.append( ElisAction.Channel_SearchByCarrier )
			req.append('%d' %longitude)
			req.append('%d' %band)
			for ele in ITransponderInfo:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channelscan_BySatellite(self ,  longitude,  band) :
			"""
			Channel Search by Satellite
			@param    longitude  Integer  Satellite Longitude
			@param    band  Integer  Band Type : E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channelscan_BySatellite )
			req.append('%d' %longitude)
			req.append('%d' %band)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channelscan_BySatelliteList(self ,  ISatelliteInfo) :
			"""
			Channel Search by Satellite List
			@param    ISatelliteInfo  Struct ElisISatelliteInfo  Satellite Information
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channelscan_BySatelliteList )
			for ele in ISatelliteInfo:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channelscan_Abort(self ) :
			"""
			Channel Scan Abort
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Channelscan_Abort )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Subtitle_Get(self ,  index) :
			"""
			Get Subtitle Information
			@param    index  Integer  Subtitle Index
			@return    ISubtitle  Struct  Subtitle information
				\n[\n
				]\n
			
			@see   ISubtitle
			"""
			req = []
			req.append( ElisAction.Subtitle_Get )
			req.append('%d' %index)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retISubtitle = ElisISubtitle()
				retISubtitle.parseReturnBuffer( reply, 0 )
				return retISubtitle
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retISubtitle = ElisISubtitle()
				retISubtitle.mError = int(reply[1])
				return retISubtitle
			else :
				return None
				

		@ElisLock
		def Subtitle_GetCount(self ) :
			"""
			Get Subtitle Count 
			@return      Integer  Property Value
			"""
			req = []
			req.append( ElisAction.Subtitle_GetCount )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Subtitle_Select(self ,  pid,  pageId,  subId) :
			"""
			Select Subtitle
			@param    pid  Integer  
			@param    pageId  Integer  
			@param    subId  Integer  
			@return      Integer  Property Value
			"""
			req = []
			req.append( ElisAction.Subtitle_Select )
			req.append('%d' %pid)
			req.append('%d' %pageId)
			req.append('%d' %subId)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Subtitle_GetSelected(self ) :
			"""
			Get Subtitle Information
			@return    ESubtitle  Struct  ID information for Selected Subtitle
				\n[\n
				]\n
			
			@see   ISubtitle
			"""
			req = []
			req.append( ElisAction.Subtitle_GetSelected )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retESubtitle = ElisESubtitle()
				retESubtitle.parseReturnBuffer( reply, 0 )
				return retESubtitle
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retESubtitle = ElisESubtitle()
				retESubtitle.mError = int(reply[1])
				return retESubtitle
			else :
				return None
				

		@ElisLock
		def Subtitle_Show(self ) :
			"""
			Subtitle Show
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Subtitle_Show )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Subtitle_Hide(self ) :
			"""
			Subtitle Hide
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Subtitle_Hide )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Subtitle_IsShowing(self ) :
			"""
			Subtitle IsShowing 
			@return      Integer  Showing Value
			"""
			req = []
			req.append( ElisAction.Subtitle_IsShowing )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Teletext_Show(self ) :
			"""
			Teletext Show
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Teletext_Show )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Teletext_NotifyHide(self ) :
			"""
			Teletext Notify Hide
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Teletext_NotifyHide )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Teletext_IsShowing(self ) :
			"""
			Teletext IsShowing 
			@return      Integer  Showing Value
			"""
			req = []
			req.append( ElisAction.Teletext_IsShowing )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Teletext_Hide(self ) :
			"""
			Teletext Hide
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Teletext_Hide )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Frontdisplay_GetMaxStringLength(self ) :
			"""
			Get Max String Length
			@return      Integer  Max String Length Value
			"""
			req = []
			req.append( ElisAction.Frontdisplay_GetMaxStringLength )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Frontdisplay_SetMessage(self ,  message) :
			"""
			Set Message for Front Display
			@param    message  String  Message
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Frontdisplay_SetMessage )
			req.append(message)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Frontdisplay_SetIcon(self ,  iconIndex,  onoff) :
			"""
			Set Icon for Front Display
			@param    iconIndex  Integer  Icon Index
			@param    onoff  Integer  On or Off
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Frontdisplay_SetIcon )
			req.append('%d' %iconIndex)
			req.append('%d' %onoff)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Frontdisplay_SetLEDMessage(self ,  message) :
			"""
			Set Message for LED Front Display
			@param    message  String  Message
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Frontdisplay_SetLEDMessage )
			req.append(message)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Frontdisplay_SetLedOnOff(self ,  ledNumber,  onoff) :
			"""
			Set LED On and Off forFront Display
			@param    ledNumber  Integer  Led Number
			@param    onoff  Integer  On or Off
			@return      Bool  TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Frontdisplay_SetLedOnOff )
			req.append('%d' %ledNumber)
			req.append('%d' %onoff)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Audiotrack_GetCount(self ) :
			"""
			Get Count of Audio Track
			@return      Integer  Count of Audio Track
			"""
			req = []
			req.append( ElisAction.Audiotrack_GetCount )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Audiotrack_Get(self ,  index) :
			"""
			Get for Audio Track Information
			@param    index  Integer  Audio Track Index
			@return    IAudioTrack  Struct  Audio Track information
				\n[\n
				]\n
			
			@see   IAudioTrack
			"""
			req = []
			req.append( ElisAction.Audiotrack_Get )
			req.append('%d' %index)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIAudioTrack = ElisIAudioTrack()
				retIAudioTrack.parseReturnBuffer( reply, 0 )
				return retIAudioTrack
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIAudioTrack = ElisIAudioTrack()
				retIAudioTrack.mError = int(reply[1])
				return retIAudioTrack
			else :
				return None
				

		@ElisLock
		def Audiotrack_GetSelectedIndex(self ) :
			"""
			Get Selected Audio Index
			@return      Integer  Index of Audio Track
			"""
			req = []
			req.append( ElisAction.Audiotrack_GetSelectedIndex )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Audiotrack_select(self ,  index) :
			"""
			Select of Audio Track
			@param    index  Integer  Audio Track Index
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Audiotrack_select )
			req.append('%d' %index)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Cicam_GetSlotCount(self ) :
			"""
			Get Count of Slot 
			@return      Integer  Count of Slot
			"""
			req = []
			req.append( ElisAction.Cicam_GetSlotCount )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Cicam_IsInserted(self ,  slotNo) :
			"""
			Is Inserted of Slot number 
			@param    slotNo  Integer  Slot Number
			@return      Integer  Result of Inserted 
			"""
			req = []
			req.append( ElisAction.Cicam_IsInserted )
			req.append('%d' %slotNo)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Cicam_GetInfo(self ,  slotNo) :
			"""
			Get for Audio Track Information
			@param    slotNo  Integer  Slot Number
			@return    ICICAM  Struct  CI CAM Information
				\n[\n
				]\n
			
			@see   ICICAM
			"""
			req = []
			req.append( ElisAction.Cicam_GetInfo )
			req.append('%d' %slotNo)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retICICAM = ElisICICAM()
				retICICAM.parseReturnBuffer( reply, 0 )
				return retICICAM
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retICICAM = ElisICICAM()
				retICICAM.mError = int(reply[1])
				return retICICAM
			else :
				return None
				

		@ElisLock
		def Cicam_EnterMMI(self ,  slotNo) :
			"""
			MMI Menu Enter
			@param    slotNo  Integer  Slot Number
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Cicam_EnterMMI )
			req.append('%d' %slotNo)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Cicam_SendMenuAnswer(self ,  slotNo,  answer) :
			"""
			Send Menu Answer 
			@param    slotNo  Integer  Slot Number
			@param    answer  Integer  Answer Number
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Cicam_SendMenuAnswer )
			req.append('%d' %slotNo)
			req.append('%d' %answer)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Cicam_SendEnqAnswer(self ,  aSlotNo,  aOK,  aAnswer,  aAnswerLength) :
			"""
			Send Enq Answer 
			@param    aSlotNo  Integer  Slot Number
			@param    aOK  Integer  OK
			@param    aAnswer  String  Answer
			@param    aAnswerLength  Integer  Answer Length
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Cicam_SendEnqAnswer )
			req.append('%d' %aSlotNo)
			req.append('%d' %aOK)
			req.append(aAnswer)
			req.append('%d' %aAnswerLength)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Dvbtuner_IsViewingTunerLocked(self ) :
			"""
			Is Viewing Tuner Locked 
			@return      Integer  Result of Locked 
			"""
			req = []
			req.append( ElisAction.Dvbtuner_IsViewingTunerLocked )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Update_LoadChannelList(self ) :
			"""
			Load Channel List Update
			@return      Integer  Result of update : E_IUPDATE_SUCCESS, E_IUPDATE_CANNOT_FIND, E_IUPDATE_PARSING_ERROR, E_IUPDATE_INVALID_FILE, E_IUPDATE_ALREDY_UPDATED,E_IUPDATE_UNKNOWN_ERROR
			"""
			req = []
			req.append( ElisAction.Update_LoadChannelList )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Update_SaveChannelList(self ) :
			"""
			Save Channel List Update
			@return      Integer  Result of update : E_IUPDATE_SUCCESS, E_IUPDATE_CANNOT_FIND, E_IUPDATE_PARSING_ERROR, E_IUPDATE_INVALID_FILE, E_IUPDATE_ALREDY_UPDATED,E_IUPDATE_UNKNOWN_ERROR
			"""
			req = []
			req.append( ElisAction.Update_SaveChannelList )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Update_UpdateFimware(self ) :
			"""
			Fimware Update 
			@return      Integer  Result of update : E_IUPDATE_SUCCESS, E_IUPDATE_CANNOT_FIND, E_IUPDATE_PARSING_ERROR, E_IUPDATE_INVALID_FILE, E_IUPDATE_ALREDY_UPDATED,E_IUPDATE_UNKNOWN_ERROR
			"""
			req = []
			req.append( ElisAction.Update_UpdateFimware )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Otimodule_GetModuleConut(self ) :
			"""
			Get Module Count 
			@return      Integer  Count of Module 
			"""
			req = []
			req.append( ElisAction.Otimodule_GetModuleConut )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Otimodule_GetModule(self ,  index) :
			"""
			Get OTIModule Information
			@param    index  Integer  Module Index
			@return    IOTIModule  Struct  OTIModule Information
				\n[\n
				]\n
			
			@see   IOTIModule
			"""
			req = []
			req.append( ElisAction.Otimodule_GetModule )
			req.append('%d' %index)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIOTIModule = ElisIOTIModule()
				retIOTIModule.parseReturnBuffer( reply, 0 )
				return retIOTIModule
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIOTIModule = ElisIOTIModule()
				retIOTIModule.mError = int(reply[1])
				return retIOTIModule
			else :
				return None
				

		@ElisLock
		def Otimodule_UpdateSW(self ) :
			"""
			SW Update by OTIModule
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Otimodule_UpdateSW )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Otimodule_UpdateCL(self ) :
			"""
			Channel List Update by OTIModule
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Otimodule_UpdateCL )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_EnableUpdate(self ) :
			"""
			Blitter Enable Function For Elis Interface 
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_EnableUpdate )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_UpdateEnabled(self ) :
			"""
			Is Blitter Enable Function
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_UpdateEnabled )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_Shutdown(self ) :
			"""
			System Shutdown
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_Shutdown )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_FactoryReset(self ) :
			"""
			Property Reset
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_FactoryReset )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_SetDefaultChannelList(self ) :
			"""
			Reset Channel List
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_SetDefaultChannelList )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_SetManualChannelList(self ,  aPath) :
			"""
			Reset Channel List for Manual
			@param    aPath  String  ChannelList file Path
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_SetManualChannelList )
			req.append(aPath)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_GetVersion(self ) :
			"""
			Get System Version
			@return    ESystemVersion  Struct  System Version
				\n[\n
				]\n
			
			@see   ESystemVersion
			"""
			req = []
			req.append( ElisAction.System_GetVersion )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retESystemVersion = ElisESystemVersion()
				retESystemVersion.parseReturnBuffer( reply, 0 )
				return retESystemVersion
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retESystemVersion = ElisESystemVersion()
				retESystemVersion.mError = int(reply[1])
				return retESystemVersion
			else :
				return None
				

		@ElisLock
		def System_GetHDMISinkInfo(self ) :
			"""
			Get HDMISink Information : NULL Return -> HDMI Not Connect
			@return    IHDMIVideoFormat  Struct   HDMISink Information
				\n[\n[\n
				]\n]\n
			
			@see   IHDMIVideoFormat
			"""
			req = []
			req.append( ElisAction.System_GetHDMISinkInfo )

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retIHDMIVideoFormat = ElisIHDMIVideoFormat()
						retIHDMIVideoFormat.parseReturnBuffer( reply, 0 )
						retValue.append( retIHDMIVideoFormat )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retIHDMIVideoFormat = ElisIHDMIVideoFormat()
						retIHDMIVideoFormat.mError = int(reply[1])
						retValue.append( retIHDMIVideoFormat )
						return retValue
					else :
						return None
				retIHDMIVideoFormat = ElisIHDMIVideoFormat()
				retIHDMIVideoFormat.parseReturnBuffer( reply, 0 )
				retValue.append( retIHDMIVideoFormat )
			

		@ElisLock
		def System_SetAVSwitch(self ,  avswitch) :
			"""
			Set AV Switch
			@param    avswitch  Integer  av Switch Type : E_ISYSTEM_AV_SWITCH_TV,E_ISYSTEM_AV_SWITCH_VCR,E_ISYSTEM_AV_SWITCH_SAT
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_SetAVSwitch )
			req.append('%d' %avswitch)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_GetAVSwitch(self ) :
			"""
			Get AV Switch
			@return      Integer  av Switch Type : E_ISYSTEM_AV_SWITCH_TV,E_ISYSTEM_AV_SWITCH_VCR,E_ISYSTEM_AV_SWITCH_SAT
			"""
			req = []
			req.append( ElisAction.System_GetAVSwitch )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def System_BlitProfileStart(self ) :
			"""
			Blit Profile Start
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_BlitProfileStart )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_BlitProfileEnd(self ) :
			"""
			Blit Profile End
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_BlitProfileEnd )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_SetMainFrameEnabled(self ) :
			"""
			Set Main Frame Enabled
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_SetMainFrameEnabled )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_MainFrameEnabled(self ) :
			"""
			Main Frame Enabled
			@return      Integer   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_MainFrameEnabled )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def System_SetMenuPrepared(self ) :
			"""
			Set Menu Prepared
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_SetMenuPrepared )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_MenuPrepared(self ) :
			"""
			Menu Prepared
			@return      Integer   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_MenuPrepared )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def System_ShowWebPage(self ,  aUrl,  aRedraw) :
			"""
			Show Web Page
			@param    aUrl  String  Web Url
			@param    aRedraw  Integer  Redraw flag
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_ShowWebPage )
			req.append(aUrl)
			req.append('%d' %aRedraw)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_CloseWebPage(self ) :
			"""
			Close Web Page
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_CloseWebPage )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def System_Reboot(self ) :
			"""
			System Reboot
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.System_Reboot )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_GetCount(self ) :
			"""
			Get Count of RecordItem by current RecordNavigation Type
			@return      Integer  Get Count of RecordItem
			"""
			req = []
			req.append( ElisAction.RecordItem_GetCount )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def RecordItem_GetAllCount(self ) :
			"""
			Get Count of RecordItem by All
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordItem_GetAllCount )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_Refresh(self ) :
			"""
			Refreshing Record Item
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordItem_Refresh )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_Get(self ,  index) :
			"""
			Get Record Item Information
			@param    index  Integer  Record Item Index
			@return    IRecordItem  Struct   Record Item Information
				\n[\n
				]\n
			
			@see   IRecordItem
			"""
			req = []
			req.append( ElisAction.RecordItem_Get )
			req.append('%d' %index)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIRecordItem = ElisIRecordItem()
				retIRecordItem.parseReturnBuffer( reply, 0 )
				return retIRecordItem
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIRecordItem = ElisIRecordItem()
				retIRecordItem.mError = int(reply[1])
				return retIRecordItem
			else :
				return None
				

		@ElisLock
		def RecordItem_GetByKey(self ,  key) :
			"""
			Get Record Item Information by Key
			@param    key  Integer  Record Key
			@return    IRecordItem  Struct   Record Item Information
				\n[\n
				]\n
			
			@see   IRecordItem
			"""
			req = []
			req.append( ElisAction.RecordItem_GetByKey )
			req.append('%d' %key)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIRecordItem = ElisIRecordItem()
				retIRecordItem.parseReturnBuffer( reply, 0 )
				return retIRecordItem
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIRecordItem = ElisIRecordItem()
				retIRecordItem.mError = int(reply[1])
				return retIRecordItem
			else :
				return None
				

		@ElisLock
		def RecordItem_GetCurrentPosByKey(self ,  aRecordKey) :
			"""
			Get Current Position by Key
			@param    aRecordKey  Integer  Record Key
			@return      Integer   Play position Second
			"""
			req = []
			req.append( ElisAction.RecordItem_GetCurrentPosByKey )
			req.append('%d' %aRecordKey)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def RecordItem_GetCurrentPosByIndex(self ,  aRecordIndex) :
			"""
			Get Current Position by Index
			@param    aRecordIndex  Integer  Record Index
			@return      Integer   Play position Second
			"""
			req = []
			req.append( ElisAction.RecordItem_GetCurrentPosByIndex )
			req.append('%d' %aRecordIndex)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock		
		def RecordItem_Delete(self ,  IRecordItem) :
			"""
			Delete RecordItem
			@param    IRecordItem  Struct ElisIRecordItem   Record Item Information
			@return      Bool   TRUE or FALSE
			@see   IRecordItem
			"""
			req = []
			req.append( ElisAction.RecordItem_Delete )
			for ele in IRecordItem:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_SetPriority(self ,  aKey,  aNewPriority) :
			"""
			Set Priority of RecordItem
			@param    aKey  Integer  Record Key
			@param    aNewPriority  Integer  New Priority
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordItem_SetPriority )
			req.append('%d' %aKey)
			req.append('%d' %aNewPriority)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_ChangeLock(self ,  aLocked,  IRecordItem) :
			"""
			Change Lock of RecordItem
			@param    aLocked  Integer  Locke Value
			@param    IRecordItem  Struct ElisIRecordItem   Record Item Information
			@return      Bool   TRUE or FALSE
			@see   IRecordItem
			"""
			req = []
			req.append( ElisAction.RecordItem_ChangeLock )
			req.append('%d' %aLocked)
			for ele in IRecordItem:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_ChangeName(self ,  aNewName,  IRecordItem) :
			"""
			Change Name of RecordItem
			@param    aNewName  String  New Name
			@param    IRecordItem  Struct ElisIRecordItem   Record Item Information
			@return      Bool   TRUE or FALSE
			@see   IRecordItem
			"""
			req = []
			req.append( ElisAction.RecordItem_ChangeName )
			req.append(aNewName)
			for ele in IRecordItem:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_GetEventInfo(self ,  aKey) :
			"""
			Get EPG Event Information by Key
			@param    aKey  Integer  Record Key
			@return    IEPGEvent  Struct   EPG Event Information
				\n[\n
				]\n
			
			@see   IEPGEvent
			"""
			req = []
			req.append( ElisAction.RecordItem_GetEventInfo )
			req.append('%d' %aKey)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIEPGEvent = ElisIEPGEvent()
				retIEPGEvent.parseReturnBuffer( reply, 0 )
				return retIEPGEvent
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIEPGEvent = ElisIEPGEvent()
				retIEPGEvent.mError = int(reply[1])
				return retIEPGEvent
			else :
				return None
				

		@ElisLock
		def RecordFolder_Create(self ,  aName,  aParentFolder) :
			"""
			Create Folder
			@param    aName  String  Folder Name
			@param    aParentFolder  Integer  Parent Folder
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordFolder_Create )
			req.append(aName)
			req.append('%d' %aParentFolder)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordFolder_MoveFolder(self ,  aFolderNumber,  aParentFolder) :
			"""
			Move Folder
			@param    aFolderNumber  Integer  Folder Number
			@param    aParentFolder  Integer  Parent Folder
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordFolder_MoveFolder )
			req.append('%d' %aFolderNumber)
			req.append('%d' %aParentFolder)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordFolder_MoveRecording(self ,  aRecordKey,  aParentFolder) :
			"""
			Move Record
			@param    aRecordKey  Integer  Record Key
			@param    aParentFolder  Integer  Parent Folder
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordFolder_MoveRecording )
			req.append('%d' %aRecordKey)
			req.append('%d' %aParentFolder)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_SetDecrypt(self ,  aRecordKey) :
			"""
			Set Decrypt
			@param    aRecordKey  Integer  Record Key
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordItem_SetDecrypt )
			req.append('%d' %aRecordKey)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_RemoveDecrypt(self ,  aRecordKey) :
			"""
			Remove Decrypt
			@param    aRecordKey  Integer  Record Key
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordItem_RemoveDecrypt )
			req.append('%d' %aRecordKey)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_ExportToUSB(self ,  aMountPoint,  IRecordItem) :
			"""
			Export To USB
			@param    aMountPoint  String  Mount Point
			@param    IRecordItem  Struct ElisIRecordItem   Record Item Information
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordItem_ExportToUSB )
			req.append(aMountPoint)
			for ele in IRecordItem:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_StopExportUSB(self ) :
			"""
			Stop Export USB
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordItem_StopExportUSB )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_HasRecordablePartition(self ) :
			"""
			Has Recordable Partition
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordItem_HasRecordablePartition )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_GetPartitionInfo(self ,  aCount) :
			"""
			Get Partition Information
			@param    aCount  Integer  Count
			@return    IRecordPartitionInfo  Struct   Partition Information
				\n[\n
				]\n
			
			@see   IRecordPartitionInfo
			"""
			req = []
			req.append( ElisAction.RecordItem_GetPartitionInfo )
			req.append('%d' %aCount)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIRecordPartitionInfo = ElisIRecordPartitionInfo()
				retIRecordPartitionInfo.parseReturnBuffer( reply, 0 )
				return retIRecordPartitionInfo
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIRecordPartitionInfo = ElisIRecordPartitionInfo()
				retIRecordPartitionInfo.mError = int(reply[1])
				return retIRecordPartitionInfo
			else :
				return None
				

		@ElisLock
		def RecordItem_MakeUSBPartitionRecordable(self ,  aDeviceName) :
			"""
			Make USB Partition Recordable
			@param    aDeviceName  String  Device Name
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordItem_MakeUSBPartitionRecordable )
			req.append(aDeviceName)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordItem_GetCurrentRecorderNoByKey(self ,  aRecordKey) :
			"""
			Get Current Recorder Index by Key
			@param    aRecordKey  Integer  Record Key
			@return      Integer   Record Index
			"""
			req = []
			req.append( ElisAction.RecordItem_GetCurrentRecorderNoByKey )
			req.append('%d' %aRecordKey)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def RecordItem_GetRecorderNoByAcsID(self ,  aACSId) :
			"""
			Get Current Recorder Index by ASCID
			@param    aACSId  Integer  ACS ID
			@return      Integer   Record Index
			"""
			req = []
			req.append( ElisAction.RecordItem_GetRecorderNoByAcsID )
			req.append('%d' %aACSId)

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def ScanHelper_Start(self ) :
			"""
			Scan Helper Start
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.ScanHelper_Start )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def ScanHelper_Stop(self ,  aAutomaticRecover) :
			"""
			Scan Helper Stop
			@param    aAutomaticRecover  Integer  Automatic Recover
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.ScanHelper_Stop )
			req.append('%d' %aAutomaticRecover)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def ScanHelper_ChangeContextByCarrier(self ,  ICarrier) :
			"""
			Change Context by Carrier
			@param    ICarrier  Struct ElisICarrier  Carrier Information
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.ScanHelper_ChangeContextByCarrier )
			for ele in ICarrier:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def ScanHelper_ChangeContext(self ,  ITransponderInfo,  ISatelliteConfig) :
			"""
			Change Context
			@param    ITransponderInfo  Struct ElisITransponderInfo  Transponder Information
			@param    ISatelliteConfig  Struct ElisISatelliteConfig  SatelliteConfig Information
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.ScanHelper_ChangeContext )
			for ele in ITransponderInfo:
				ele.appendReqBuffer(req)
			for ele in ISatelliteConfig:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_GetOTRInfo(self ) :
			"""
			Get On Time Record Timer Information 
			@return    IOTRInfo  Struct   Timer Information
				\n[\n
				]\n
			
			@see   IOTRInfo
			"""
			req = []
			req.append( ElisAction.Timer_GetOTRInfo )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIOTRInfo = ElisIOTRInfo()
				retIOTRInfo.parseReturnBuffer( reply, 0 )
				return retIOTRInfo
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIOTRInfo = ElisIOTRInfo()
				retIOTRInfo.mError = int(reply[1])
				return retIOTRInfo
			else :
				return None
				

		@ElisLock
		def Timer_AddOTRTimer(self ,  mFromEPG,  aFixedDuration,  aCopyTimeshift,  aTimerName,  aForceDecrypt,  aEventId,  aSid,  aTsid,  aOnid) :
			"""
			Add On Time Record Timer
			@param    mFromEPG  Integer  From EPG
			@param    aFixedDuration  Integer  Fixed Duration 
			@param    aCopyTimeshift  Integer  Copy Timeshift
			@param    aTimerName  String  Timer Name
			@param    aForceDecrypt  Integer  ForceDecrypt
			@param    aEventId  Integer  Event ID
			@param    aSid  Integer  Service ID
			@param    aTsid  Integer  Transport Stream ID
			@param    aOnid  Integer  Original Network ID
			@return    EInteger  Struct   Integer array : index 0 (time id or error) index 1~ (conflictList Timer ID), if size() > 1 than confictlist exist
				\n[\n[\n
				]\n]\n
			
			@see   IOTRInfo
			"""
			req = []
			req.append( ElisAction.Timer_AddOTRTimer )
			req.append('%d' %mFromEPG)
			req.append('%d' %aFixedDuration)
			req.append('%d' %aCopyTimeshift)
			req.append(aTimerName)
			req.append('%d' %aForceDecrypt)
			req.append('%d' %aEventId)
			req.append('%d' %aSid)
			req.append('%d' %aTsid)
			req.append('%d' %aOnid)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.parseReturnBuffer( reply, 0 )
						retValue.append( retEInteger )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.mError = int(reply[1])
						retValue.append( retEInteger )
						return retValue
					else :
						return None
				retEInteger = ElisEInteger()
				retEInteger.parseReturnBuffer( reply, 0 )
				retValue.append( retEInteger )
			

		@ElisLock
		def Timer_AddManualTimer(self ,  aChannelNo,  aServiceType,  aStartTime,  aDuration,  aTimerName,  aForceDecrypt) :
			"""
			Add Manual Timer
			@param    aChannelNo  Integer  Channel Number
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    aStartTime  Integer  Start Time
			@param    aDuration  Integer  Record Duration
			@param    aTimerName  String  Timer Name
			@param    aForceDecrypt  Integer  ForceDecrypt
			@return    EInteger  Struct   Integer array : index 0 (time id or error) index 1~ (conflictList Timer ID), if size() > 1 than confictlist exist
				\n[\n[\n
				]\n]\n
			
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_AddManualTimer )
			req.append('%d' %aChannelNo)
			req.append('%d' %aServiceType)
			req.append('%d' %aStartTime)
			req.append('%d' %aDuration)
			req.append(aTimerName)
			req.append('%d' %aForceDecrypt)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.parseReturnBuffer( reply, 0 )
						retValue.append( retEInteger )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.mError = int(reply[1])
						retValue.append( retEInteger )
						return retValue
					else :
						return None
				retEInteger = ElisEInteger()
				retEInteger.parseReturnBuffer( reply, 0 )
				retValue.append( retEInteger )
			

		@ElisLock
		def Timer_AddEPGTimer(self ,  aForceDecrypt,  aForceThisEvent,  IEPGEvent) :
			"""
			Add EPG Timer
			@param    aForceDecrypt  Integer  Force Decrypt
			@param    aForceThisEvent  Integer  Force This Event
			@param    IEPGEvent  Struct ElisIEPGEvent  EPG Event Information
			@return    EInteger  Struct   Integer array : index 0 (time id or error) index 1~ (conflictList Timer ID), if size() > 1 than confictlist exist
				\n[\n[\n
				]\n]\n
			
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_AddEPGTimer )
			req.append('%d' %aForceDecrypt)
			req.append('%d' %aForceThisEvent)
			for ele in IEPGEvent:
				ele.appendReqBuffer(req)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.parseReturnBuffer( reply, 0 )
						retValue.append( retEInteger )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.mError = int(reply[1])
						retValue.append( retEInteger )
						return retValue
					else :
						return None
				retEInteger = ElisEInteger()
				retEInteger.parseReturnBuffer( reply, 0 )
				retValue.append( retEInteger )
			

		@ElisLock
		def Timer_AddSeriesTimer(self ,  IEPGEvent) :
			"""
			Add Series Timer
			@param    IEPGEvent  Struct ElisIEPGEvent  EPG Event Information
			@return    EInteger  Struct   Integer array : index 0 (time id or error) index 1~ (conflictList Timer ID), if size() > 1 than confictlist exist
				\n[\n[\n
				]\n]\n
			
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_AddSeriesTimer )
			for ele in IEPGEvent:
				ele.appendReqBuffer(req)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.parseReturnBuffer( reply, 0 )
						retValue.append( retEInteger )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.mError = int(reply[1])
						retValue.append( retEInteger )
						return retValue
					else :
						return None
				retEInteger = ElisEInteger()
				retEInteger.parseReturnBuffer( reply, 0 )
				retValue.append( retEInteger )
			

		@ElisLock
		def Timer_AddWeeklyTimer(self ,  aChannelNo,  aServiceType,  aStartTime,  aExpiryTime,  aTimerName,  aWeeklyTimerCount,  IWeeklyTimer) :
			"""
			Add Weekly Timer
			@param    aChannelNo  Integer  Channel Number
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    aStartTime  Integer  Start Time
			@param    aExpiryTime  Integer  Expiry Time
			@param    aTimerName  String  Timer Name
			@param    aWeeklyTimerCount  Integer  Weekly Timer Count
			@param    IWeeklyTimer  Struct ElisIWeeklyTimer  Weekly Timer Information
			@return    EInteger  Struct   Integer array : index 0 (time id or error) index 1~ (conflictList Timer ID), if size() > 1 than confictlist exist
				\n[\n[\n
				]\n]\n
			
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_AddWeeklyTimer )
			req.append('%d' %aChannelNo)
			req.append('%d' %aServiceType)
			req.append('%d' %aStartTime)
			req.append('%d' %aExpiryTime)
			req.append(aTimerName)
			req.append('%d' %aWeeklyTimerCount)
			for ele in IWeeklyTimer:
				ele.appendReqBuffer(req)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.parseReturnBuffer( reply, 0 )
						retValue.append( retEInteger )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.mError = int(reply[1])
						retValue.append( retEInteger )
						return retValue
					else :
						return None
				retEInteger = ElisEInteger()
				retEInteger.parseReturnBuffer( reply, 0 )
				retValue.append( retEInteger )
			

		@ElisLock
		def Timer_AddKeywordTimer(self ,  aChannelNo,  aServiceType,  aKeyword,  aTitleOnly,  aForceDecrypt) :
			"""
			Add Keyword Timer
			@param    aChannelNo  Integer  Channel Number
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    aKeyword  String  Keyword
			@param    aTitleOnly  Integer  Title Only
			@param    aForceDecrypt  Integer  ForceDecrypt
			@return    EInteger  Struct   Integer array : index 0 (time id or error) index 1~ (conflictList Timer ID), if size() > 1 than confictlist exist
				\n[\n[\n
				]\n]\n
			
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_AddKeywordTimer )
			req.append('%d' %aChannelNo)
			req.append('%d' %aServiceType)
			req.append(aKeyword)
			req.append('%d' %aTitleOnly)
			req.append('%d' %aForceDecrypt)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.parseReturnBuffer( reply, 0 )
						retValue.append( retEInteger )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retEInteger = ElisEInteger()
						retEInteger.mError = int(reply[1])
						retValue.append( retEInteger )
						return retValue
					else :
						return None
				retEInteger = ElisEInteger()
				retEInteger.parseReturnBuffer( reply, 0 )
				retValue.append( retEInteger )
			

		@ElisLock
		def Timer_EditSeriesTimer(self ,  aTimerId,  aEventId,  aSid,  aTsid,  aOnid,  aNewEventId,  aNewSid,  aNewTsid,  aNewStartTime,  aNewDuration) :
			"""
			Edit Series Timer
			@param    aTimerId  Integer  Timer ID
			@param    aEventId  Integer  Event ID
			@param    aSid  Integer  Service ID
			@param    aTsid  Integer  Transport Stream ID
			@param    aOnid  Integer  Original Network ID
			@param    aNewEventId  Integer  New Event ID
			@param    aNewSid  Integer  New Service ID
			@param    aNewTsid  Integer  New Transport Stream ID
			@param    aNewStartTime  Integer  New Start Time
			@param    aNewDuration  Integer  Record Duration
			@return      Bool   TRUE or FALSE
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_EditSeriesTimer )
			req.append('%d' %aTimerId)
			req.append('%d' %aEventId)
			req.append('%d' %aSid)
			req.append('%d' %aTsid)
			req.append('%d' %aOnid)
			req.append('%d' %aNewEventId)
			req.append('%d' %aNewSid)
			req.append('%d' %aNewTsid)
			req.append('%d' %aNewStartTime)
			req.append('%d' %aNewDuration)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_EditWeeklyTimer(self ,  aTimerId,  aDate,  aStartTime,  aDuration,  aNewStartTime,  aNewDuration) :
			"""
			Edit Weekly Timer
			@param    aTimerId  Integer  Timer ID
			@param    aDate  Integer  Date
			@param    aStartTime  Integer  Start Time
			@param    aDuration  Integer  Record Duration
			@param    aNewStartTime  Integer  New Start Time
			@param    aNewDuration  Integer  Record Duration
			@return      Bool   TRUE or FALSE
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_EditWeeklyTimer )
			req.append('%d' %aTimerId)
			req.append('%d' %aDate)
			req.append('%d' %aStartTime)
			req.append('%d' %aDuration)
			req.append('%d' %aNewStartTime)
			req.append('%d' %aNewDuration)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_AddWeeklyTimerItem(self ,  aTimerId,  aDate,  aStartTime,  aDuration) :
			"""
			Add Weekly Timer Item
			@param    aTimerId  Integer  Timer ID
			@param    aDate  Integer  Date
			@param    aStartTime  Integer  Start Time
			@param    aDuration  Integer  Record Duration
			@return      Bool   TRUE or FALSE
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_AddWeeklyTimerItem )
			req.append('%d' %aTimerId)
			req.append('%d' %aDate)
			req.append('%d' %aStartTime)
			req.append('%d' %aDuration)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_EditOneWeeklyTimer(self ,  aTimerId,  aStartTime,  aDuration,  aNewStartTime,  aNewDuration) :
			"""
			Edit One Weekly Timer
			@param    aTimerId  Integer  Timer ID
			@param    aStartTime  Integer  Start Time
			@param    aDuration  Integer  Record Duration
			@param    aNewStartTime  Integer  New Start Time
			@param    aNewDuration  Integer  Record Duration
			@return      Bool   TRUE or FALSE
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_EditOneWeeklyTimer )
			req.append('%d' %aTimerId)
			req.append('%d' %aStartTime)
			req.append('%d' %aDuration)
			req.append('%d' %aNewStartTime)
			req.append('%d' %aNewDuration)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_OneKeywordTimer(self ,  aTimerId,  aStartTime,  aDuration,  aNewStartTime,  aNewDuration) :
			"""
			Edit One Keyword Timer
			@param    aTimerId  Integer  Timer ID
			@param    aStartTime  Integer  Start Time
			@param    aDuration  Integer  Record Duration
			@param    aNewStartTime  Integer  New Start Time
			@param    aNewDuration  Integer  Record Duration
			@return      Bool   TRUE or FALSE
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_OneKeywordTimer )
			req.append('%d' %aTimerId)
			req.append('%d' %aStartTime)
			req.append('%d' %aDuration)
			req.append('%d' %aNewStartTime)
			req.append('%d' %aNewDuration)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_GetRunningTimers(self ) :
			"""
			Get Running Timer
			@return    ITimer  Struct   Timer Information
				\n[\n[\n
				]\n]\n
			
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_GetRunningTimers )

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retITimer = ElisITimer()
						retITimer.parseReturnBuffer( reply, 0 )
						retValue.append( retITimer )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retITimer = ElisITimer()
						retITimer.mError = int(reply[1])
						retValue.append( retITimer )
						return retValue
					else :
						return None
				retITimer = ElisITimer()
				retITimer.parseReturnBuffer( reply, 0 )
				retValue.append( retITimer )
			

		@ElisLock
		def Timer_StopRecordingByRecordKey(self ,  aRecordKey) :
			"""
			Stop Recording By RecordKey
			@param    aRecordKey  Integer  Record Key
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Timer_StopRecordingByRecordKey )
			req.append('%d' %aRecordKey)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_EditRunningTimer(self ,  aTimerId,  aNewEndTime) :
			"""
			Edit Running Timer
			@param    aTimerId  Integer  Timer ID
			@param    aNewEndTime  Integer   New End Time
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Timer_EditRunningTimer )
			req.append('%d' %aTimerId)
			req.append('%d' %aNewEndTime)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_GetTimerCount(self ) :
			"""
			Get Count of Timer
			@return      Integer  Get Count of Timer
			"""
			req = []
			req.append( ElisAction.Timer_GetTimerCount )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Timer_GetByIndex(self ,  aIndex) :
			"""
			Get Timer Information by Index
			@param    aIndex  Integer  Timer Index
			@return    ITimer  Struct   Timer Information
				\n[\n
				]\n
			
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_GetByIndex )
			req.append('%d' %aIndex)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retITimer = ElisITimer()
				retITimer.parseReturnBuffer( reply, 0 )
				return retITimer
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retITimer = ElisITimer()
				retITimer.mError = int(reply[1])
				return retITimer
			else :
				return None
				

		@ElisLock
		def Timer_GetById(self ,  aTimerId) :
			"""
			Get Timer Information by Id
			@param    aTimerId  Integer  Timer Index
			@return    ITimer  Struct   Timer Information
				\n[\n
				]\n
			
			@see   ITimer
			"""
			req = []
			req.append( ElisAction.Timer_GetById )
			req.append('%d' %aTimerId)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retITimer = ElisITimer()
				retITimer.parseReturnBuffer( reply, 0 )
				return retITimer
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retITimer = ElisITimer()
				retITimer.mError = int(reply[1])
				return retITimer
			else :
				return None
				

		@ElisLock
		def Timer_GetEPGOffset(self ) :
			"""
			Get EPG Time Offset
			@return    ITIMEREPGOffset  Struct   Timer Information
				\n[\n
				]\n
			
			@see   ITIMEREPGOffset
			"""
			req = []
			req.append( ElisAction.Timer_GetEPGOffset )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retITIMEREPGOffset = ElisITIMEREPGOffset()
				retITIMEREPGOffset.parseReturnBuffer( reply, 0 )
				return retITIMEREPGOffset
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retITIMEREPGOffset = ElisITIMEREPGOffset()
				retITIMEREPGOffset.mError = int(reply[1])
				return retITIMEREPGOffset
			else :
				return None
				

		@ElisLock
		def Timer_SetEPGOffset(self ,  ITIMEREPGOffset) :
			"""
			Set EPG Time Offset
			@param    ITIMEREPGOffset  Struct ElisITIMEREPGOffset  Timer Information
			@return      Bool   TRUE or FALSE
			@see   ITIMEREPGOffset
			"""
			req = []
			req.append( ElisAction.Timer_SetEPGOffset )
			for ele in ITIMEREPGOffset:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_DeleteTimer(self ,  aTimerId) :
			"""
			Delete Timer
			@param    aTimerId  Integer   Timer ID
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Timer_DeleteTimer )
			req.append('%d' %aTimerId)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_ChangePriority(self ,  aTimerId,  aNewPriority) :
			"""
			Change Priority of Timer
			@param    aTimerId  Integer  Timer ID
			@param    aNewPriority  Integer   Timer Priority : E_ITIMER_PRIORITY_NORMAL, E_ITIMER_PRIORITY_HIGH
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Timer_ChangePriority )
			req.append('%d' %aTimerId)
			req.append('%d' %aNewPriority)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Timer_ChangeName(self ,  aTimerId,  aName) :
			"""
			Change Name of Timer
			@param    aTimerId  Integer   Timer ID
			@param    aName  String   New Name of Timer
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Timer_ChangeName )
			req.append('%d' %aTimerId)
			req.append(aName)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def RecordNavigation_Get(self ) :
			"""
			Get Record Navigation
			@return    IRecordNavigation  Struct   Timer Information
				\n[\n
				]\n
			
			"""
			req = []
			req.append( ElisAction.RecordNavigation_Get )

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retIRecordNavigation = ElisIRecordNavigation()
				retIRecordNavigation.parseReturnBuffer( reply, 0 )
				return retIRecordNavigation
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retIRecordNavigation = ElisIRecordNavigation()
				retIRecordNavigation.mError = int(reply[1])
				return retIRecordNavigation
			else :
				return None
				

		@ElisLock
		def RecordNavigation_Set(self ,  IRecordNavigation) :
			"""
			Get Record Navigation
			@param    IRecordNavigation  Struct ElisIRecordNavigation   Timer Information
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.RecordNavigation_Set )
			for ele in IRecordNavigation:
				ele.appendReqBuffer(req)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def NetWork_SaveSetting(self ) :
			"""
			IP Config Save
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.NetWork_SaveSetting )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def NetWork_DHCPStart(self ) :
			"""
			DHCP Start
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.NetWork_DHCPStart )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def AppMediaPlayer_Control(self ,  aStart) :
			"""
			XBMC Media Player Start
			@param    aStart  Integer  Media Player Start :1 or True (Start), 0 orFalse(Stop) 
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.AppMediaPlayer_Control )
			req.append('%d' %aStart)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Conax_GetInformation(self ,  mCardID) :
			"""
			Conax SmartCard Get Information
			@param    mCardID  Integer  Card ID
			@return    EConaxInfo  Struct   Conax SmartCard Information
				\n[\n
				]\n
			
			"""
			req = []
			req.append( ElisAction.Conax_GetInformation )
			req.append('%d' %mCardID)

			
			reply= self.Command(req)
			reply.remove('LASTMESSAGE')
			if len(reply) >0 and reply[0].upper() != 'NULL':
				retEConaxInfo = ElisEConaxInfo()
				retEConaxInfo.parseReturnBuffer( reply, 0 )
				return retEConaxInfo
			elif len(reply) >0 and reply[0].upper() == 'NULL':
				retEConaxInfo = ElisEConaxInfo()
				retEConaxInfo.mError = int(reply[1])
				return retEConaxInfo
			else :
				return None
				

		@ElisLock
		def AppHBBTV_Ready(self ,  aReady) :
			"""
			HBB TV Application Contorl Ready
			@param    aReady  Integer  Ready  :1 or True (OK), 0 orFalse(NOK) 
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.AppHBBTV_Ready )
			req.append('%d' %aReady)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def ExternalMediaPlayer_Started(self ,  aSuccess) :
			"""
			External MediaPlayer Started
			@param    aSuccess  Integer  Sucess
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.ExternalMediaPlayer_Started )
			req.append('%d' %aSuccess)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def ExternalMediaPlayer_SetSpeed(self ,  aSuccess) :
			"""
			External MediaPlayer Started
			@param    aSuccess  Integer  Sucess
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.ExternalMediaPlayer_SetSpeed )
			req.append('%d' %aSuccess)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def ExternalMediaPlayer_SeekStream(self ,  aSuccess) :
			"""
			External MediaPlayer Started
			@param    aSuccess  Integer  Sucess
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.ExternalMediaPlayer_SeekStream )
			req.append('%d' %aSuccess)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def ExternalMediaPlayer_StopPlay(self ,  aSuccess) :
			"""
			External MediaPlayer Started
			@param    aSuccess  Integer  Sucess
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.ExternalMediaPlayer_StopPlay )
			req.append('%d' %aSuccess)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_SetCurrentAsync(self ,  aChannelNumber,  aServiceType,  aAsync) :
			"""
			Set Current Channel for ASync
			@param    aChannelNumber  Integer  Channel Number of Current Channel
			@param    aServiceType  Integer  Service Type :E_SERVICE_TYPE_INVALID, E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO, E_SERVICE_TYPE_DATA
			@param    aAsync  Integer  Async Flag Set for Channel Change
			@return      Bool  TRUE or FALSE
			@see   IChannel
			"""
			req = []
			req.append( ElisAction.Channel_SetCurrentAsync )
			req.append('%d' %aChannelNumber)
			req.append('%d' %aServiceType)
			req.append('%d' %aAsync)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_CreateBookmark(self ) :
			"""
			Bookmark Create
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_CreateBookmark )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_DeleteBookmark(self ,  aRecordKey,  aOffset) :
			"""
			Bookmark delete
			@param    aRecordKey  Integer  Record Key
			@param    aOffset  Integer  Position Offset
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Player_DeleteBookmark )
			req.append('%d' %aRecordKey)
			req.append('%d' %aOffset)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Player_GetBookmarkList(self ,  aRecordKey) :
			"""
			Get Bookmark list by Record Key
			@param    aRecordKey  Integer  Record Key
			@return    EBookmark  Struct   Bookmark Struct
				\n[\n[\n
				]\n]\n
			
			"""
			req = []
			req.append( ElisAction.Player_GetBookmarkList )
			req.append('%d' %aRecordKey)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retEBookmark = ElisEBookmark()
						retEBookmark.parseReturnBuffer( reply, 0 )
						retValue.append( retEBookmark )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retEBookmark = ElisEBookmark()
						retEBookmark.mError = int(reply[1])
						retValue.append( retEBookmark )
						return retValue
					else :
						return None
				retEBookmark = ElisEBookmark()
				retEBookmark.parseReturnBuffer( reply, 0 )
				retValue.append( retEBookmark )
			

		@ElisLock
		def Format_Record_Archive(self ) :
			"""
			Format Record Archive
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Format_Record_Archive )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Format_Media_Archive(self ) :
			"""
			Format Media Archive
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Format_Media_Archive )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Make_Dedicated_HDD(self ) :
			"""
			Make Dedicated HdD(Change Media Size)
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Make_Dedicated_HDD )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Format_USB_Storage(self ,  aPath) :
			"""
			Format Usb Storage
			@param    aPath  String  Usb Mount Path
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Format_USB_Storage )
			req.append(aPath)

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Power_Save_Mode(self ) :
			"""
			Power Save Mode Setting
			@return      Bool   TRUE or FALSE
			"""
			req = []
			req.append( ElisAction.Power_Save_Mode )

			reply= self.Command(req)
			return ParseReturnBool(reply)
		

		@ElisLock
		def Channel_GetStatus(self ) :
			"""
			Get Status of Channel Change
			@return      Integer   Lock Status: 0(Sucess) , 1(No Signal), 2 (Scrambled)
			"""
			req = []
			req.append( ElisAction.Channel_GetStatus )

			reply= self.Command(req)
			return ParseReturnInteger(reply)
		

		@ElisLock
		def Property_GetValue(self ,  aPropName) :
			"""
			Get Property Value
			@param    aPropName  String  Property Name
			@return    PropertyEnumValue  Struct   PropertyMapValue Struct
				\n[\n[\n
				]\n]\n
			
			"""
			req = []
			req.append( ElisAction.Property_GetValue )
			req.append(aPropName)

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retPropertyEnumValue = ElisPropertyEnumValue()
						retPropertyEnumValue.parseReturnBuffer( reply, 0 )
						retValue.append( retPropertyEnumValue )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retPropertyEnumValue = ElisPropertyEnumValue()
						retPropertyEnumValue.mError = int(reply[1])
						retValue.append( retPropertyEnumValue )
						return retValue
					else :
						return None
				retPropertyEnumValue = ElisPropertyEnumValue()
				retPropertyEnumValue.parseReturnBuffer( reply, 0 )
				retValue.append( retPropertyEnumValue )
			

		@ElisLock
		def USB_GetMountPath(self ) :
			"""
			Get Usb Mount Path
			@return    EChar  Struct   Char Struct
				\n[\n[\n
				]\n]\n
			
			"""
			req = []
			req.append( ElisAction.USB_GetMountPath )

			
			self.Send( req )
			retValue = []
			while 1:
				reply=self.Read()
				if reply[len(reply)-1].upper() == 'LASTMESSAGE':
					reply.remove('LASTMESSAGE')
					if len(reply) >0 and reply[0].upper() != 'NULL':
						retEChar = ElisEChar()
						retEChar.parseReturnBuffer( reply, 0 )
						retValue.append( retEChar )
						return retValue
					elif len(reply) >0 and reply[0].upper() == 'NULL':
						retEChar = ElisEChar()
						retEChar.mError = int(reply[1])
						retValue.append( retEChar )
						return retValue
					else :
						return None
				retEChar = ElisEChar()
				retEChar.parseReturnBuffer( reply, 0 )
				retValue.append( retEChar )
			

		"""
		@}
		"""
		
