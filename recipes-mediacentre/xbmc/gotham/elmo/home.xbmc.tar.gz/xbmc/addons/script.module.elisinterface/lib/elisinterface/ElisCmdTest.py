#!/usr/bin/python
from ElisCommander import ElisCommander
from ElisAction import ElisAction
from ElisEnum import ElisEnum
from ElisCommandTest import ElisCommandTest
from ElisClass import *
from ElisEventServer import ElisEventMgr
import ElisEventServer

import sys
import getopt
'''
commander = ElisCommander(('192.168.101.131',12345))
'''
global aLoop 
commander=ElisCommandTest()
commander.testSetElisReady()


def elistest(options):
	print'options = ',options
	
	if(len(options) ==0 ):
		return 0
			
#	for op in options:
	if options[0] == 'property_int':
		commander.testPropInt()
		print 'property_int : Property Init test - getProp and setProp of Audio Volume'
	elif options[0] == 'test':
		zappingmode = ElisIZappingMode()
		zappingmode.reset()
		zappingmode.mMode = ElisEnum.E_MODE_FAVORITE
		zappingmode.printdebug()

	elif options[0] == 'channelscan_bysatellite':
		commander.testChannelScanBySatellite()
		print 'channelscan_bysatellite : Channel Scan by Satellite Test - Param - Longitude(192), Band(E_BAND_KU)'
		
	elif options[0] == 'channelscan_bycarrier':
		commander.testChannelScanByCarriers()
		print 'channelscan_bycarrier : Channel Scan by Carriers Test - Param - Longitude(192), Band(E_BAND_KU), Carrier([11303,22000,ElisEnum.E_LNB_HORIZONTAL,ElisEnum.E_DVBS2_8PSK_2_3, 0, 0, 0 ])'

	elif options[0] == 'channelscan_abort':
		commander.testChannelscan_Abort()
		print 'channelscan_abort : Channel Scan Abort'

	elif options[0] == 'satelliteconfig_savelist':
		commander.testSatelliteconfigSaveList()
		print 'satelliteconfig_savelist : Satellite Config Save List - Param  - ISatelliteConfig Class [0,1,192,ElisEnum.E_BAND_KU,0,ElisEnum.E_SWITCH_DISABLED,ElisEnum.E_SWITCH_2OF4,0,	1, ElisEnum.E_LNB_UNIVERSAL,0,9750,10600,11700,0,0,0,0,0,0,0,0]'

	elif options[0] == 'zappingmode_getcurrent':
		commander.testZappingMode_GetCurrent()
		print 'zappingmode_getcurrent : Get Current of Zapping Mode'

	elif options[0] == 'zappingmode_setcurrent':
		commander.testZappingMode_SetCurrent()
		print 'zappingmode_setcurrent : Set Curret of Zapping Mode - Param IZappingMide class ['

	elif options[0] == 'channel_get':
		commander.testChannel_Get()
		print 'channel_get : Get Channel - Param - Channel number (1), Service Type(E_TYPE_TV)'

	elif options[0] == 'channel_setcurrent':
		commander.testChannel_SetCurrent()
		print 'channel_setcurrent : Set Current Channel - Param - Channel number (1), Service Type(E_TYPE_TV)'

	elif options[0] == 'channel_getcurrent':
		commander.testChannel_GetCurret()
		print 'channel_getcurrent : Get Current Channel'

	elif options[0] == 'channel_getprev':
		commander.testChannel_GetPrev()		
		print 'channel_getprev : Get Prev Channel'

	elif options[0] == 'channel_getnext':
		commander.testChannel_GetNext()
		print 'channel_getnext : Get Next Channel'

	elif options[0] == 'channel_getlist':
		commander.testChannel_GetList()
		print 'channel_getlist : Get Channel List - Param - Service Type(E_TYPE_TV), Zapping Mode(E_MODE_ALL) Zapping sort mode (E_SORT_BY_DEFAULT)'
		
	elif options[0] == 'channel_getlits_bysatellite':
		commander.testChannel_GetListBySatellite()
		print 'channel_getlist_bysatellite : Get Channel List by Satellite - Param -Service Type(E_TYPE_TV), Zapping Mode(E_MODE_ALL) Zapping sort mode (E_SORT_BY_DEFAULT) Logitude(192), Band(E_BAND_KU)'

	elif options[0] == 'channel_getlist_byfavorite':
		commander.testChannel_GetListByFavorite()
		print 'channel_getlist_byfavorite : Get Channel List By Favorite - Param - Service Type(E_TYPE_TV), Zapping Mode(E_MODE_ALL) Zapping sort mode (E_SORT_BY_DEFAULT), Favorite Name(1.Free)'

	elif options[0] == 'channel_getlist_byftacas':
		commander.testChannel_GetListByFTACas()
		print 'channel_getlist_byftacas : Get Channel List by FTA/CAS - Param - Service Type(E_TYPE_TV), Zapping Mode(E_MODE_ALL) Zapping sort mode (E_SORT_BY_DEFAULT) CAS ID(E_FTA_CHANNEL)'

	elif options[0] == 'favorite_getlist':
		commander.testFavorite_GetList()
		print 'favorite_getlist : Get Favorite List -Param - Service Type(E_TYPE_TV)'

	elif options[0] == 'fta_cas_getlist':
		commander.testFta_cas_GetList()
		print 'fta_cas_getlist : Get FTA/CAS list - Param -Service Type(E_TYPE_TV)'

	elif options[0] == 'channel_getcarrier_fordvbs':
		commander.testChannel_GetCarrierForDVBS()
		print 'channel_getcarrier_fordvbs : Get Carrier of Channel for DVBS'

	elif options[0] == 'channel_getcarrier_fordvbt':
		commander.testChannel_GetCarrierForDVBT()
		print 'channel_getcarrier_fordvbt : Get Carrier of Channel for DVBT'

	elif options[0] == 'channel_getcarrier_fordvbc':
		commander.testChannel_GetCarrierForDVBC()
		print 'channel_getcarrier_fordvbc : Get Carrier of Channel for DVBC'

	elif options[0] =='channel_delete':
		commander.testChannel_Delete()
		print 'channel_delete'

	elif options[0] == 'channel_lock':
		if(len(options) > 2):	
			lock=int(options[1])
			number=int(options[2])
			commander.testChannel_Lock(lock, number)
		else:
			print'Please Input Channel Number or Lock status'

	elif options[0] == 'channel_skip':
		if(len(options) > 2):	
			skip=int(options[1])
			number=int(options[2])
			commander.testChannel_Skip(skip, number)
		else:
			print'Please Input Channel Number or skip status'

	elif options[0] =='channel_deletebynumber':
		commander.testChannel_DeleteByNumber()		
	
	elif options[0] == 'channel_save':
		commander.testChannel_Save()
		print 'channel_save : Channel Save'

	elif options[0] == 'channel_deleteall':
		commander.testChannel_DeleteAll()
		print 'channel_deleteall : All channel  Delet'

	elif options[0] == 'channel_restore':
		commander.testChannel_Restore()
		print 'channel_restore : Channel Restore'

	elif options[0] == 'favoritegroup_getgroupcount':
		commander.testFavoritegroup_GetGroupCount()
		print 'favoritegroup_getgroupcount : Get Group Count of Favorite Group - Param - service type (E_TYPE_TV)' 

	elif options[0] == 'favoritegroup_create':
		print 'test....'
		commander.testFavoritegroup_Create()
		print 'favoritegroup_create : Favorite Group Create - Param - service type (E_TYPE_TV)'

	elif options[0] == 'favoritegrup_getbyindex':
		commander.testFavoritegroup_GetByIndex()
		print 'favoritegrup_getbyindex : Get Favorite Group by Index - Param - service type (E_TYPE_TV)'

	elif options[0] == 'favoritegroup_getbygroupname':
		commander.testFavoritegroup_GetByGroupName()
		print 'favoritegroup_getbygroupname : Get Favorite Group by Group Name - Param - Favorite Group Name(1.Free), service type (E_TYPE_TV)'

	elif options[0] == 'favoritegroup_remove':
		commander.testFavoritegroup_Remove()
		print 'favoritegroup_remove : Favorite Group Remove - Param - Favorite Group Name(1.Free), service type (E_TYPE_TV)'

	elif options[0] =='fav_changename':
		commander.testFavoritegroup_ChangeName()

	elif options[0] == 'fav_addchannel':
		commander.testFavoritegroup_AddChannel()

	elif options[0] == 'fav_deletechannel':		
		commander.testFavoritegroup_RemoveChannel()
		
	elif options[0] == 'epgevent_getpresent':
		commander.testEpgevnet_GetPresent()
		print 'Epgevent_GetPresent : Get Present EPG'

	elif options[0] == 'epgevent_getfollowing':
		commander.testEpgevnet_GetFollowing()
		print 'epgevent_getfollowing'

	elif options[0] == 'epgevent_getlist':
		commander.testEpgevent_GetList()
		print 'epgevent_getlist : Egp Event Get list - Parm - Get channel'

	elif options[0] == 'satellite_getbychannelnumber':
		commander.testSatellite_GetByChannelNumber()
		print 'satellite_getbychannelnumber: Get Satellite by Channel Number- Param - Channel Number(1), Service Type(ElieEnum.E_SERVICE_TYPE_TV'

	elif options[0] == 'satellite_get':
		commander.testSatellite_Get()
		print 'satellite_get : Get Satellite - Param -Longitude(192), Band(ElisEnum.E_BAND_KU)'

	elif options[0] == 'satellite_getlist':	
		commander.testSatellite_GetList()
		print 'satellite_getlist : Get Satellite List - Param - Band(ElisEnum.E_BAND_KU)'

	elif options[0] == 'satellite_add':
		commander.testSatellite_Add()
		print 'satellite_add : Add Satellite Add - Param - Longitude(192), Band(ElisEnum.E_BAND_KU), Satellite Name(AISA3)'

	elif options[0] == 'satellite_changename':
		commander.testSatellite_ChangeName()
		print 'satellite_changename : Satellte Change Name - Param - Longitude(192), Band(ElisEnum.E_BAND_KU), Satellite New Name(NewName)'

	elif options[0] == 'satellite_delete':
		commander.testSatellite_Delete()
		print 'satellite_delete : Delete Satellite - Param -Longitude(192), Band(ElisEnum.E_BAND_KU) '

	elif options[0] == 'satellite_getconfiguredlist':
		commander.testSatellite_GetConfiguredList()
		print 'satellite_getconfiguredlist : Get Configured Satellite List - Param - Satellite Sort(ElisEnum.E_SORT_LONGITUDE)'

	elif options[0] == 'transponder_getlist':
		commander.testTransponder_GetList()
		print 'transponder_getlist : Get Transponder List - Param -Longitude(192), Band(ElisEnum.E_BAND_KU) '

	elif options[0] == 'transponder_hascompatible':
		commander.testTransponder_HasCompatible()
		print 'transponder_hascompatible : Transponder Has Compatible - Param - Longitude(192), Band(ElisEnum.E_BAND_KU), ElisITransponderInfo()'

	elif options[0] == 'transponder_add':
		commander.testTransponder_Add()
		print 'transponder_add : Add Transponder - Param - Longitude(192), Band(ElisEnum.E_BAND_KU), ElisITransponderInfo()'

	elif options[0] == 'transponder_delete':
		commander.testTransponder_Delete()
		print 'transponder_delete : Delete Transpoder - Param - Longitude(192), Band(ElisEnum.E_BAND_KU), ElisITransponderInfo()'

	elif options[0] == 'satelliteconfig_getlist':
		commander.testSatelliteconfig_GetList()
		print 'satelliteconfig_getlist : Get SatelliteConfig List - Param - Tuner Number(0)'

	elif options[0] == 'satelliteconfig_getfirstavailablepos':
		commander.testSatelliteconfig_GetFirstAvailablePos()
		print 'satelliteconfig_getfirstavailablepos : Get First Available Position - Param - Tuner Numbe(0), SlotNumber(0)'

	elif options[0] == 'satelliteconfig_deleteall':
		commander.testSatelliteconfig_DeleteAll()
		print 'satelliteconfig_deleteall : Delete All Setellite Config '

	elif options[0] == 'datetime_getgmttime':
		commander.testDatetime_GetGMTTime()
		print 'datetime_getgmttime : Get GMT Time'

	elif options[0] == 'datetime_getlocaloffset':
		commander.testDatetime_GetLocalOffset()
		print 'datetime_getlocaloffset'

	elif options[0] == 'datetime_getlocaltime':
		commander.testDatetime_GetLocalTime()
		print 'datetime_getlocaltime : Get Local Time'

	elif options[0] == 'motorized_stop':
		commander.testMotorized_Stop()
		print 'motorized_stop : Motorized Stop - Param - Tuner Number(0)'

	elif options[0] == 'motorized_gowest':
		commander.testMotorized_GoWest()
		print 'motorized_gowest : Motorized Go West - Param - Tuner Number(0)'

	elif options[0] == 'motorized_goeast':
		commander.testMotorized_GoEast()
		print 'motorized_goeast : Motorized Go Ease - Param - Tuner Number(0)'

	elif options[0] == 'motorized_stepwest':
		commander.testMotorized_StepWest()
		print 'motorized_stepwest : Motorized Step West - Param - Tuner Number(0)'

	elif options[0] == 'motorized_stepeast':
		commander.testMotorized_StepEast()
		print 'motorized_stepeast : Motorized Step East - Param - Tuner Number(0)'

	elif options[0] == 'motorized_seteastlimit':	
		commander.testMotorized_SetEastLimit()
		print 'motorized_seteastlimit : Motorized Set East Limit - Param - Tuner Number(0)'

	elif options[0] == 'motorized_setwestlimit':	
		commander.testMotorized_SetWestLimit()
		print 'motorized_setwestlimit : Motorized Set West Limit - Param - Tuner Number(0)'

	elif options[0] == 'motorized_resetlimit':
		commander.testMotorized_ResetLimit()
		print 'motorized_resetlimit : Motorized Reset Limit - Param - Tuner Number(0)'

	elif options[0] == 'motorized_gotonull':		
		commander.testMotorized_GotoNull()
		print 'motorized_gotonull : Motorized Go To Null - Param - Tuner Number(0)'

	elif options[0] == 'motorized_saveposition':
		commander.testMotorized_SavePosition()
		print 'motorized_saveposition : Motorized Save Position - Param - Tuner Number(0) Position(1)'

	elif options[0] == 'player_getstatus':
		commander.testplayer_GetStatus()
		print 'player_getstatus : Get Player Status'

	elif options[0] == 'player_starttimeshiftplayback':	
		commander.testPlayer_StartTimeshiftPlayback()
		print 'player_starttimeshiftplayback : Player Start of TimeShift PlayBack - Param - PlayBack Mode(ElisEnum.E_IPLAYER_TIMESHIFT), Time (0ms)' 

	elif options[0] == 'player_startinternal':
		commander.testPlayer_StartInternalRecordPlayback()
		print 'player_startinternal : Player Start of Internal Record PlayBack - Param - RecordKey(1), ServiceType(ElisEnum.E_SERVICE_TYPE_TV), Offset Time(0), Speed(100) 100: 1x'

	elif options[0] == 'player_stop':
		commander.testPlayer_Stop()
		print 'player_stop : Stop for Player'

	elif options[0] == 'player_setspeed':
		commander.testPlayer_SetSpeed()
		print 'player_setspeed : Set Speed for Player - Param - Speed Value(200) 200 :2x'

	elif options[0] == 'player_jumpto':
		commander.testPlayer_JumpTo()
		print 'player_jumpto : Jump To Player of time - Param - Offset Time (5000)'

	elif options[0] == 'player_jumptoiframe':
		commander.testPlayer_JumpToIFrame()
		print 'player_jumptoiframe : Jump To Player of IFrame - Param - Offset Time (5000)'

	elif options[0] == 'player_pause':
		commander.testPlayer_Pause()
		print 'player_pause : Pause of Player'

	elif options[0] == 'player_resume':
		commander.testPlayer_Resume()
		print 'player_resume : Resume of Player'

	elif options[0] == 'player_setvolume':
		commander.testPlayer_SetVolume()
		print 'player_setvolume : Set Volume of Player - Param - Volume Value(10)'

	elif options[0] == 'player_getvolume':
		commander.testPlayer_GetVolume()
		print 'player_getvolume : Get Volume of Player'

	elif options[0] == 'player_setmute':
		commander.testPlayer_SetMute()
		print 'player_setmute : Set Mute of Player - Param - Mute Flag(1)'

	elif options[0] == 'player_getmute':
		commander.testPlayer_GetMute()
		print 'player_getmute : Get Mute of Player'

	elif options[0] == 'player_avblank':		
		commander.testPlayer_AVBlank()
		print 'player_avblank : AV Blank of Player - Param - Blank(1), Force(0)'

	elif options[0] == 'player_videoblank':
		commander.testPlayer_VideoBlank()
		print 'player_videoblank : Video Blank of Player - Param - Blank(1), Force(0)'

	elif options[0] == 'player_avmute':
		commander.testPlayer_AVMute()
		print 'player_avmute : AV Mute of Player - Param - Mute(1), Force(0)'

	elif options[0] == 'player_stopliveplayer'	:
		commander.testPlayer_StopLivePlayer()
		print 'player_stopliveplayer : Stop Player of Live'

	elif options[0] == 'player_setvideosize':
		commander.testPlayer_SetVIdeoSize()
		print 'player_setvideosize : Set Video Size of Player - Param x(0), y(0), width(1280), hight(720)'

	elif options[0] == 'player_isvideovalid':
		commander.testPlayer_IsVideoValid()
		print 'player_isvideovalid : Is Video Valid of Player'

	elif options[0] =='system_factoryreset':
		commander.testSystem_FactoryReset()
		print 'system_factoryreset : Factroy Reset'

	elif options[0] == 'system_defaultchannel':
		commander. testSystem_SetDefaultChannelList()
		print 'system_defaultchannel : Set Default Channel List'
		
	elif options[0] =='recordnav_get':
		commander.testRecordNavigation_Get()
		print 'recordnav_get'
		
	elif options[0] =='recordnav_set':
		commander.testRecordNavigation_Set()
		print 'recordnav_set'
		
	elif options[0] =='ipconfig':
		commander.testNetworkIpConfig()
		print 'NetWorkIpconfig'

	elif options[0]=='dhcp_start':
		commander.testDHCP_Start()
		print 'DHCP Start'

	elif options[0] =='conax_getinfo':
		commander.testConax_GetInformation()
		print 'Conax Get Information'
		
	elif options[0] =='channel_dbtest':
		commander.testChannel_db()
		print 'channel db read'
		
	elif options[0] =='epg_dbtest':
		commander.testEPG_db()
		print 'epg db read'

	elif options[0]=='prop_dbtest':
		commander.testProperty_db()
		print 'Property db read'

	elif options[0] == 'channelchange':
		if(len(options) > 1):	
			print'number = ',int(options[1])
			number=int(options[1])
			commander.testChannelChange(number)
		else:
			print'Please Input Channel Number '

	elif options[0] == 'channel_up':
		commander.testChannelUp()

	elif options[0] == 'channel_down':
		commander.testChannelDown()		

	elif options[0] == 'record_lock':
		if(len(options) > 2):	
			rec_key=int(options[1])
			lock = int(options[2])
			commander.testRecord_SetLock(rec_key, lock)
		else:
			print'Please Input Record Key or lock'

	elif options[0] == 'recordinfo_rename':
		if(len(options) > 2):	
			rec_key=int(options[1])
			newname = options[2]
			commander.testRecord_Rename(rec_key, newname)
		else:
			print'Please Input Record Key or lock'

	elif options[0] == 'record_delete':
		if(len(options) > 1):	
			rec_key=int(options[1])
			commander.testRecord_DeleteRecord(rec_key)
		else:
			print'Please Input Record Key'

	elif options[0] == 'recordlist':
		commander.testRecordInfoList()

	elif options[0] == 'recordplay':
		if(len(options) > 1):	
			print'RecordKey = ',int(options[1])
			rec_index=int(options[1])
			commander.testRecordPlayback(rec_index)
		else:
			print'Please Input Record Key '

	elif options[0] == 'recordstop':
		if(len(options) > 2):	
			print'RecordKey = ',int(options[1])
			channel_no=int(options[1])
			rec_key = int(options[2])
			commander.testRecordStop(channel_no, rec_key)
		else:
			print'Please Input Record Key or Channel Number'

	elif options[0] == 'recordstart':
		if(len(options) > 3):	
			print'RecordKey = ',int(options[1])
			channel_no=int(options[1])
			rec_duration = int(options[2])
			record_name = options[3]
			commander.testRecordStart(channel_no, rec_duration, record_name)
		else:
			print'Please Input Record Key or Channel Number or Record Name'
			print' recordstart channel_number  duration(sec) Record_Name , EX) recordstart 1 3600 testrecord'

	elif options[0] == 'recordinglist':		
		commander.testRecordRunningList()

	elif options[0] == 'recordinfo_dbtest':
		commander.testRecordInfo_db()

	elif options[0] == 'sat_dbtest':
		commander.testSatellite_db()

	elif options[0] == 'carrier_dbtest':
		commander.testTransponder_db()

	elif options[0] == 'satconfig_dbtest':
		commander.testSatelliteConfigured_db()

	elif options[0] == 'configsatinfo_dbtest':
		commander.testConfiguredSatelliteInfo()

	elif options[0] == 'fav_dbtest':
		commander.testFavGroup()

	elif options[0] == 'favchannel_dbtest':
		commander.testFavGroupChannel()

	elif options[0] == 'zappingchannel':
		commander.testZappingChannelList()

	elif options[0] == 'zapping_dbtest':
		commander.testZappingChannel()

	elif options[0] == 'zappingmode_dbtest':
		commander.testZappingModeDB()

	elif options[0] == 'addepgtimer':
		commander.testTimer_AddEPG()

	elif options[0] == 'get_timer_count':
		commander.testTimer_GetCount()

	elif options[0] == 'get_timer_list':
		commander.testTimer_GetList()

	elif options[0] == 'timer_delete':
		if(len(options) > 1):	
			print'timer_index = ',int(options[1])
			timer_id=int(options[1])
			commander.testTimer_delete(timer_id)
		else:
			print'Please Input Record Key '

	elif options[0] == 'addmanualtimer':
		commander.testTimer_AddManual()

	elif options[0] == 'factoryreset':
		commander.testSystem_FactoryReset()

	elif options[0] == 'addweeklytimer':
		commander.testTimer_AddWeekly();

	elif options[0] == 'mediaplayer':
		if(len(options) > 1):	
			print'aStart = ',int(options[1])
			aStart=int(options[1])
			commander.testAppMediaPlayer_Control(aStart)
		else:
			print'Please Input Record Key '	

	elif options[0] == 'front_setmessage':
		commander.testFrontdisplay_SetMessage()

	elif options[0] == 'get_current':
		if(len(options) > 2):	
			aStart=int(options[1])
			aEnd = int(options[2])
			commander.testGetCurrentEventDB(aStart, aEnd)
		else:
			print'Please Input Start Channel Number or End Channel Number'

	elif options[0] == 'get_following':
		if(len(options) > 2):	
			aStart=int(options[1])
			aEnd = int(options[2])
			commander.testGetFollowingEventDB(aStart, aEnd)
		else:
			print'Please Input Start Channel Number or End Channel Number'

	elif options[0] == 'get_channelepgdb':
		commander.testGetChannelEventDB()

	elif options[0] == 'subtitle_getcount':
		commander.testSubtitle_GetCount()

	elif options[0] == 'get_runningtimer':
		commander.testTimer_GetRunningTimers()

	elif options[0] == 'zapping_test':
		commander.testZappingTest()

	elif options[0] == 'mmi_test':
		commander.testCicam_EnterMMI()

	elif options[0] == 'mmi_answer':
		if(len(options) > 1):
			answer = int(options[1])
			commander.testCicam_SendMenuAnswer(answer)
		else:
			print'plase input answer number'

	elif options[0] == 'ci_sendma':
		commander.testCicam_SendMenuAnswer(0)

	elif options[0] == 'record_get_event':
		if(len(options) > 1):
			key = int(options[1])
			commander.testRecordInfoGetEvt(key)
		else:
			print'Please Input Record key'

	elif options[0] == 'help':
		print 'property_int : Property Init test - getProp and setProp of Audio Volume'
		print 'channelscan_bysatellite : Channel Scan by Satellite Test'
		print 'channelscan_bycarrier : Channel Scan by Carriers Test'
		print 'channelscan_abort : Channel Scan Abort'
		print 'satelliteconfig_deleteall : Satellite Config Delete All'
		print 'satelliteconfig_savelist : Satellite Config Save List'
		print 'zappingmode_getcurrent : Get Current of Zapping Mode'
		print 'zappingmode_setcurrent : Set Curret of Zapping Mode'
		print 'channel_get : Get Channel'
		print 'channel_setcurrent : Set Current Channel'
		print 'channel_getcurrent : Get Current Channel'
		print 'channel_getprev : Get Prev Channel'
		print 'channel_getnext : Get Next Channel'
		print 'channel_getlist : Get Channel List'		
		print 'channel_getlist_bysatellite : Get Channel List by Satellite'
		print 'channel_getlist_byfavorite : Get Channel List By Favorite'
		print 'channel_getlist_byftacas : Get Channel List by FTA/CAS'
		print 'favorite_getlist : Get Favorite List'
		print 'fta_cas_getlist : Get FTA/CAS list'
		print 'channel_getcarrier_fordvbs : Get Carrier of Channel for DVBS'
		print 'channel_getcarrier_fordvbt : Get Carrier of Channel for DVBT'
		print 'channel_getcarrier_fordvbc : Get Carrier of Channel for DVBC'
		print 'channel_save : Channel Save'
		print 'channel_deleteall : All channel  Delet'
		print 'channel_restore : Channel Restore'
		print 'favoritegroup_getgroupcount : Get Group Count of Favorite Group' 
		print 'favoritegroup_create : Favorite Group Create'
		print 'favoritegrup_getbyindex : Get Favorite Group by Index'
		print 'favoritegroup_getbygroupname : Get Favorite Group by Group Name'
		print 'favoritegroup_remove : Favorite Group Remove'
		print 'epgevent_getpresent : Get Present EPG'
		print 'epgevent_getfollowing'
		print 'epgevent_getlist : Egp Event Get list'
		print 'satellite_getbychannelnumber: Get Satellite by Channel Number'			
		print 'satellite_get : Get Satellite'
		print 'satellite_getlist : Get Satellite List'			
		print 'satellite_add : Add Satellite Add'
		print 'satellite_changename : Satellte Change Name'
		print 'satellite_delete : Delete Satellite'
		print 'satellite_getconfiguredlist : Get Configured Satellite List'
		print 'transponder_getlist : Get Transponder List'
		print 'transponder_hascompatible : Transponder Has Compatible'
		print 'transponder_add : Add Transponder'
		print 'transponder_delete : Delete Transpoder'
		print 'satelliteconfig_getlist : Get SatelliteConfig List'
		print 'satelliteconfig_getfirstavailablepos : Get First Available Position'
		print 'datetime_getgmttime : Get GMT Time'
		print 'datetime_getlocaloffset'
		print 'datetime_getlocaltime : Get Local Time'
		print 'motorized_stop : Motorized Stop'
		print 'motorized_gowest : Motorized Go West'
		print 'motorized_goeast : Motorized Go Ease'
		print 'motorized_stepwest : Motorized Step West'
		print 'motorized_stepeast : Motorized Step East'
		print 'motorized_seteastlimit : Motorized Set East Limit'
		print 'motorized_setwestlimit : Motorized Set West Limit'
		print 'motorized_resetlimit : Motorized Reset Limit'
		print 'motorized_gotonull : Motorized Go To Null'
		print 'motorized_saveposition : Motorized Save Position'
		print 'player_getstatus : Get Player Status'
		print 'player_starttimeshiftplayback : Player Start of TimeShift PlayBack' 
		print 'player_startinternal : Player Start of Internal Record PlayBack'
		print 'player_stop : Stop for Player'
		print 'player_setspeed : Set Speed for Player'
		print 'player_jumpto : Jump To Player of time'
		print 'player_jumptoiframe : Jump To Player of IFrame'
		print 'player_pause : Pause of Player'
		print 'player_resume : Resume of Player'
		print 'player_setvolume : Set Volume of Player'
		print 'player_getvolume : Get Volume of Player'
		print 'player_setmute : Set Mute of Player'
		print 'player_getmute : Get Mute of Player'
		print 'player_avblank : AV Blank of Player'
		print 'player_videoblank : Video Blank of Player'
		print 'player_avmute : AV Mute of Player'
		print 'player_stopliveplayer : Stop Player of Live'
		print 'player_setvideosize : Set Video Size of Player'
		print 'player_isvideovalid : Is Video Valid of Player'			
		print 'system_factoryreset : Factroy Reset'
		print 'system_defaultchannel : Set Default Channel List'
		print 'channelchange  number: Channel Change by number, ex) channelchange 10'
		print 'channel_up : Channel Up'
		print 'channel_down : Channel Down'
		print 'recordlist : Get RecordInfo List'
		print 'recordplay RecordKey: Player_StartInternalRecordPlayback by RecordKey, ex) recordplay 3'
		print 'recordstart : Record Start ,  recordstart channel_number  duration(sec) Record_Name , EX) recordstart 1 3600 testrecord'
		print 'recordstop : Record Stop , ex) recordstop channel_number record_key'
		print 'recordinglist : Get Running Record List'

		
	elif options[0]=='q':
		print 'quit'
		commander.testElisEventServerQuit()
		return 1
	else:
		print 'Unkonw Command',options[0]

			
def Test_Program():
	global aLoop 
	aLoop = True
	while aLoop:
		options = []		
		options = raw_input('cmd>>')
		test_op=options.split()
		ret = elistest(test_op)
		if ret == 1:
			aLoop = False


Test_Program()

