
from ElisCommander import ElisCommander
from ElisProperty import ElisPropertyEnum, ElisPropertyInt
from ElisAction import ElisAction
from ElisEnum import ElisEnum
from ElisClass import *
from ElisClassSub import *


from ElisEventServer import ElisEventMgr
import ElisEventServer

import time

import sqlite3

targetIp			= '127.0.0.1'
myIp				= '127.0.0.1'

receiverPort 		= 54321
commanderPort		= 12345


class ElisCommandTest(object):
	def __init__(self):
		#self.mCommander = ElisCommander(("/var/eliscommand"))
		self.mCommander = ElisCommander((targetIp,commanderPort))
		#self.recevier=ElisEventServer.getInstance().run()

	def testElisEventServerQuit(self):
		#ElisEventServer.getInstance().shutdown()
		print'shotdown'
		
	def testSetElisReady(self):
		ret = []
		ret = self.mCommander.SetElisReady(myIp)		
		print 'SetElisReady = %s'%ret

	def testAll( self ):
		#self.testPropEnum()
		#self.testPropInt()
		#self.testSatelliteconfig_DeleteAll()
		#self.testSatelliteconfigSaveList()
		#self.testChannelScanBySatellite()
		#self.testChannelScanByCarriers()
		pass

	def testPropEnum( self ):
		prop = ElisPropertyEnum( 'Last ServiceType', self.mCommander )
		print 'prop test %s' %prop.getProp()
		print 'prop test (TV): %s' %prop.getPropStringByIndex( 0 )
		print 'prop test (Radio): %s' %prop.getPropStringByIndex( 1 )		
		print 'prop test (Last ServiceType): %s' %prop.getName()
		print 'prop test (TV or Radio): %s' %prop.getPropString()
		prop.SetProp( 2 )
		print 'prop test 2 Radio : %d %s' %( prop.getProp(), prop.getPropString())
		prop.SetPropIndex( 0 )
		print 'prop test 1 TV : %d %s' %( prop.getProp(), prop.getPropString())
		prop.SetPropString( 'Radio' )
		print 'prop test 2 Radio : %d %s' %( prop.getProp(), prop.getPropString())

	def testPropInt( self ):
		propInt = ElisPropertyInt( 'Audio Volume', self.mCommander  )
		print 'propint test =%d' %propInt.GetProp()
		propInt.SetProp( 30 )
		print 'propint test =%d' %propInt.GetProp()

	def testChannelScanBySatellite( self ):
		self.mCommander.Channelscan_BySatellite( 192, ElisEnum.E_BAND_KU )

	def testChannelScanByCarriers( self ):
		prop = ElisPropertyEnum( 'Channel Search Mode', self.mCommander )
		prop.SetProp( 0 )
		prop = ElisPropertyEnum( 'Network Search', self.mCommander )
		prop.SetProp( 1 )
		carriers = ElisITransponderInfo()
		carriers.reset()
		carriers.mFrequency = 11303
		carriers.mSymbolRate = 22000
		carriers.mPolarization=ElisEnum.E_LNB_HORIZONTAL
		carriers.mFECMode=ElisEnum.E_DVBS2_8PSK_2_3
		input_carriers = []
		input_carriers.append(carriers)
		#self.mCommander.Channel_SearchByCarrier( 192, ElisEnum.E_BAND_KU, input_carriers )
		ret = self.mCommander.Channel_SearchByCarrier( 192, ElisEnum.E_BAND_KU, input_carriers )
		print 'carrier serach ret = %s'%ret
		

	def testChannelscan_Abort(self):
		ret = []
		ret = self.mCommander.Channelscan_Abort()
		print 'channel scan abort = %s'%ret

	def testSatelliteconfigSaveList( self ) :
		sat_configlist = ElisISatelliteConfig()
		sat_configlist.mTunerIndex = 0
		sat_configlist.mSlotNumber = 0
		sat_configlist.mSatelliteLongitude = 192
		sat_configlist.mBandType = ElisEnum.E_BAND_KU
		sat_configlist.mFrequencyLevel = 0
		sat_configlist.mDisEqc11 = ElisEnum.E_SWITCH_DISABLED
		sat_configlist.mDisEqcMode = ElisEnum.E_SWITCH_1OF4
		sat_configlist.mDisEqcRepeat = 0
		sat_configlist.mIsConfigUsed =1
		sat_configlist.mLnbType = ElisEnum.E_LNB_UNIVERSAL
		sat_configlist.mMotorizedType = 0
		sat_configlist.mLowLNB = 9750
		sat_configlist.mHighLNB = 10600
		sat_configlist.mLNBThreshold = 11700
		sat_configlist.mMotorizedData =0 
		sat_configlist.mIsOneCable = 0
		sat_configlist.mOneCablePin = 0
		sat_configlist.mOneCableMDU = 0
		sat_configlist.mOneCableLoFreq1 = 0
		sat_configlist.mOneCableLoFreq2 = 0
		sat_configlist.mOneCableUBSlot = 0
		sat_configlist.mOneCableUBFreq = 0	
		configuredList = []
		configuredList.append(sat_configlist)
		sat1_configlist = ElisISatelliteConfig()
		sat1_configlist.mTunerIndex = 1
		sat1_configlist.mSlotNumber = 0
		sat1_configlist.mSatelliteLongitude = 192
		sat1_configlist.mBandType = ElisEnum.E_BAND_KU
		sat1_configlist.mFrequencyLevel = 0
		sat1_configlist.mDisEqc11 = ElisEnum.E_SWITCH_DISABLED
		sat1_configlist.mDisEqcMode = ElisEnum.E_SWITCH_1OF4
		sat1_configlist.mDisEqcRepeat = 0
		sat1_configlist.mIsConfigUsed =1
		sat1_configlist.mLnbType = ElisEnum.E_LNB_UNIVERSAL
		sat1_configlist.mMotorizedType = 0
		sat1_configlist.mLowLNB = 9750
		sat1_configlist.mHighLNB = 10600
		sat1_configlist.mLNBThreshold = 11700
		sat1_configlist.mMotorizedData =0 
		sat1_configlist.mIsOneCable = 0
		sat1_configlist.mOneCablePin = 0
		sat1_configlist.mOneCableMDU = 0
		sat1_configlist.mOneCableLoFreq1 = 0
		sat1_configlist.mOneCableLoFreq2 = 0
		sat1_configlist.mOneCableUBSlot = 0
		sat1_configlist.mOneCableUBFreq = 0	
		configuredList.append(sat1_configlist)
		ret = self.mCommander.Satelliteconfig_SaveList( configuredList )
		print 'satelliteconfig save list = %s'%ret
		
	def testZappingMode_GetCurrent(self):
		zappingmode = []
		zappingmode = self.mCommander.Zappingmode_GetCurrent()
		zappingmode.printdebug()

	def testZappingMode_SetCurrent(self):
		ret = []
		inputz=[]
		zappingmode = ElisIZappingMode()
		zappingmode.printdebug()
		inputz.append(zappingmode)
		ret = self.mCommander.Zappingmode_SetCurrent(inputz)
		print 'ret = %s'%ret

	def testChannel_Get(self):
		print 'testchannel get'
		channel_info = []
		channel_number = 3
		channel_info=self.mCommander.Channel_Get(channel_number, ElisEnum.E_SERVICE_TYPE_TV)
		channel_info.printdebug()		

	def testChannel_SetCurrent(self):
		ret = []
		channel_number = 1
		ret=self.mCommander.Channel_SetCurrent(channel_number, ElisEnum.E_SERVICE_TYPE_TV)
		print 'ret = %s'%ret

	def testChannel_GetCurret(self):
		channel_info = []
		channel_info=self.mCommander.Channel_GetCurrent()
		channel_info.printdebug()

	def testChannel_GetPrev(self):		
		channel_info = []

		channel_info=self.mCommander.Channel_GetPrev()
		channel_info.printdebug()

	def testChannel_GetNext(self):		
		channel_info = []
		channel_info=self.mCommander.Channel_GetNext()
		channel_info.printdebug()

	def testChannel_GetList(self):
		channel_info = []

		start_time = time.time()
		print "Channel GetList start = %s"%start_time 		
		#print "time = ", time.asctime(time.localtime(time.time()))
		channel_info=self.mCommander.Channel_GetList(ElisEnum.E_SERVICE_TYPE_TV, ElisEnum.E_MODE_ALL, ElisEnum.E_SORT_BY_DEFAULT)
		#print "time = ", time.asctime(time.localtime(time.time()))
		print "Channel GetList end = %s"% (time.time() - start_time)
		'''
		count = 0
		if channel_info != None:			
			for ch in channel_info:
				if ch == None:
					print'data None'
				elif ch.mError < 0:
					print 'channel Get Error'
				else:
					ch.printdebug()
					count= count +1
					print "count = ",count
				
		elif channel_info == None:
			print 'channel None'
		'''
	def testChannel_GetListBySatellite(self):
		channel_info = []
		channel_info=self.mCommander.Channel_GetListBySatellite(ElisEnum.E_SERVICE_TYPE_TV, ElisEnum.E_MODE_ALL, ElisEnum.E_SORD_BY_DEFAULT, 192, ElisEnum.E_BAND_KU)
		for ch in channel_info:
			ch.printdebug()

	def testChannel_GetListByFavorite(self):
		channel_info = []
		channel_info=self.mCommander.Channel_GetListByFavorite(ElisEnum.E_SERVICE_TYPE_TV, ElisEnum.E_MODE_ALL, ElisEnum.E_SORD_BY_DEFAULT, '1.Free')
		for ch in channel_info:
			ch.printdebug()

	def testChannel_GetListByFTACas(self):
		channel_info = []
		channel_info=self.mCommander.Channel_GetListByFTACas(ElisEnum.E_SERVICE_TYPE_TV, ElisEnum.E_MODE_ALL, ElisEnum.E_SORD_BY_DEFAULT, ElisEnum.E_FTA_CHANNEL)
		for ch in channel_info:
			ch.printdebug()

	def testFavorite_GetList(self):
		favorite_info = []
		favorite_info = self.mCommander.Favorite_GetList(ElisEnum.E_SERVICE_TYPE_TV)
		for fav in favorite_info:
			fav.printdebug()

	def testFta_cas_GetList(self):
		cas_info = []
		cas_info = self.mCommander.Fta_cas_GetList(ElisEnum.E_SERVICE_TYPE_TV)
		for cas in cas_info:
			cas.printdebug()

	def testChannel_Delete(self):
		channel = []
		channel_info = self.mCommander.Channel_Get(3, ElisEnum.E_SERVICE_TYPE_TV)
		channel.append(channel_info)
		ret = self.mCommander.Channel_Delete(channel)
		print 'ret = %s'%ret		

	def testChannel_Lock(self, lock, Number):
		channel = []
		channel_info = self.mCommander.Channel_Get(Number, ElisEnum.E_SERVICE_TYPE_TV)
		if channel_info == None:			
			print'Channel None'
		elif channel_info.mError < 0:
			print 'Channel Get Error'
		else:
			channel.append(channel_info)			
		
		ret = self.mCommander.Channel_Lock(lock, channel)
		print 'ret = %s'%ret		

	def testChannel_Skip(self, skip, Number):
		channel = []
		channel_info = self.mCommander.Channel_Get(Number, ElisEnum.E_SERVICE_TYPE_TV)
		if channel_info == None:			
			print'Channel None'
		elif channel_info.mError < 0:
			print 'Channel Get Error'
		else:
			channel.append(channel_info)			
		
		ret = self.mCommander.Channel_Skip(skip, channel)
		print 'ret = %s'%ret		
	
	def testChannel_DeleteByNumber(self):
		channelNumber = []
		n0=ElisEInteger()     
		n0.mParam = 318
		n1=ElisEInteger()     
		n1.mParam = 320
		n2=ElisEInteger()     
		n2.mParam = 325
		n3=ElisEInteger()     
		n3.mParam = 333
		channelNumber.append(n0)
		channelNumber.append(n1)
		channelNumber.append(n2)
		channelNumber.append(n3)		
		ret = self.mCommander.Channel_DeleteByNumber(ElisEnum.E_SERVICE_TYPE_TV, channelNumber)
		print 'ret = %s'%ret
	
	def testChannel_Save(self):
		ret = []
		ret=self.mCommander.Channel_Save()
		print 'ret = %s'%ret		

	def testChannel_DeleteAll(self):
		ret = []
		ret=self.mCommander.Channel_DeleteAll()
		print 'ret = %s'%ret		

	def testChannel_Restore(self):
		ret = []
		ret=self.mCommander.Channel_Restore(1)
		print 'ret = %s'%ret		

	def testFavoritegroup_GetGroupCount(self):
		ret = []
		ret=self.mCommander.Favoritegroup_GetGroupCount(ElisEnum.E_SERVICE_TYPE_TV)
		print 'fav group count %d'%ret

	def testFavoritegroup_Create(self):
		ret = []
		ret=self.mCommander.Favoritegroup_Create('favtest', ElisEnum.E_SERVICE_TYPE_TV)
		print ret

		
	def testFavoritegroup_GetByIndex(self):
		fav_group = []
		fav_group=self.mCommander.Favoritegroup_GetByIndex(0 ,ElisEnum.E_SERVICE_TYPE_TV)
		fav_group.printdebug()	
		
	def testFavoritegroup_GetByGroupName(self):
		fav_group = []
		fav_group=self.mCommander.Favoritegroup_GetByGroupName('favtest', ElisEnum.E_SERVICE_TYPE_TV)
		fav_group.printdebug()	
		
	def testFavoritegroup_Remove(self):
		ret = []
		ret=self.mCommander.Favoritegroup_Remove('favtest', ElisEnum.E_SERVICE_TYPE_TV)
		print 'ret = %s'%ret	

	def testFavoritegroup_ChangeName(self):
		ret = []
		ret = self.mCommander.Favoritegroup_ChangeName('favtest', ElisEnum.E_SERVICE_TYPE_TV, 'netfav')
		print 'ret = %s'%ret	

	def testFavoritegroup_AddChannel(self):
		ret = []
		ret = self.mCommander.Favoritegroup_AddChannel('1.Free', 1, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_AddChannel('1.Free', 4, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_AddChannel('1.Free', 95, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_AddChannel('1.Free', 94, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_AddChannel('2.Free', 1, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_AddChannel('2.Free', 2, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_AddChannel('2.Free', 95, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_AddChannel('3.Free', 1, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_AddChannel('4.Free', 1, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_AddChannel('3.Free', 5, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_AddChannel('4.Free', 95, ElisEnum.E_SERVICE_TYPE_TV, )
		print 'ret = %s'%ret	
		

	def testFavoritegroup_RemoveChannel(self):
		ret = []
		ret = self.mCommander.Favoritegroup_RemoveChannel('4.Free', 10, ElisEnum.E_SERVICE_TYPE_TV, )
		ret = self.mCommander.Favoritegroup_RemoveChannel('1.Free', 95, ElisEnum.E_SERVICE_TYPE_TV, )		
		print 'ret = %s'%ret	
		
	def testEpgevnet_GetPresent(self):
		epg_info = []
		epg_info = self.mCommander.Epgevent_GetPresent()
		if epg_info == None:			
			print'data None'
		elif epg_info.mError < 0:
			print 'Epgevent Get Error'
		else:
			epg_info.printdebug()

		epglist = []
	

	def testEpgevnet_GetFollowing(self):
		epg_info = []
		epg_info = self.mCommander.Epgevent_GetFollowing()
		if epg_info != None:			
			print'data None'
		elif epg_info.mError < 0:
			print 'Epgevent Get Error'
		else:
			epg_info.printdebug()


	def testEpgevent_GetList(self):
		epg_info = []
		channel_info = []
		channel_number = 4
		channel_info=self.mCommander.Channel_GetCurrent()
		#channel_info.printdebug()

		
		#channel_info=self.mCommander.Channel_Get(4, ElisEnum.E_SERVICE_TYPE_TV)
		#channel_info.printdebug()
		epg_test = self.mCommander.Epgevent_GetPresent()
		count = 0
		if epg_test.mError != -1:
			print 'EPG Get Present'
			ret = self.mCommander.Datetime_GetGMTTime()
			#gmtFrom = epg_test.mStartTime
			gmtFrom = time.time()
			print "time = ", time.asctime(time.localtime(gmtFrom))
			gmtUntil = gmtFrom+(3600*24*8)
			print "time = ", time.asctime(time.localtime(gmtUntil))
			print "time = ", gmtFrom
			print "time = ", gmtUntil
			epg_info = self.mCommander.Epgevent_GetList(channel_info.mSid, channel_info.mTsid, channel_info.mOnid, gmtFrom, gmtUntil, 1024)
			print "end get time = %s"%(time.time() - gmtFrom)
			if epg_info != None:			
				for epg in epg_info:
					if epg == None:
						print'data None'
					elif epg.mError < 0:
						print 'Epgevent Get Error'
					else:
						'''
						epg.printdebug()
						'''
						count= count +1
						print "count = ",count
					
			elif epg_info == None:
				print 'EPG None'
		else:
			print 'EPG Get Present NULL'

	def testSatellite_GetByChannelNumber(self):
		sat_info = []
		sat_info = self.mCommander.Satellite_GetByChannelNumber(1, ElisEnum.E_SERVICE_TYPE_TV)
		sat_info.printdebug()

	def testSatellite_Get(self):
		sat_info = []
		sat_info = self.mCommander.Satellite_Get(192, ElisEnum.E_BAND_KU)
		sat_info.printdebug()

	def testSatellite_GetList(self):
		sat_info = []
		sat_info = self.mCommander.Satellite_GetList(ElisEnum.E_SORTING_ORBITAL)
		for sat in sat_info:
			sat.printdebug()

	def testSatellite_Add(self):
		ret = [] 
		ret = self.mCommander.Satellite_Add(192, ElisEnum.E_BAND_KU, 'ASIA3')
		print 'ret = %s'%ret

	def testSatellite_ChangeName(self):
		ret = [] 
		ret = self.mCommander.Satellite_ChangeName(192, ElisEnum.E_BAND_KU, 'NewName')
		print 'ret = %s'%ret

	def testSatellite_Delete(self):
		ret = [] 
		ret = self.mCommander.Satellite_Delete(192, ElisEnum.E_BAND_KU)
		print 'ret = %s'%ret

	def testSatellite_GetConfiguredList(self):
		sat_info = []
		sat_info = self.mCommander.Satellite_GetConfiguredList(ElisEnum.E_SORT_LONGITUDE)
		for sat in sat_info:
			sat.printdebug()

	def testTransponder_GetList(self):
		tp_info = []
		tp_info = self.mCommander.Transponder_GetList(192, ElisEnum.E_BAND_KU)
		for tp in tp_info:
			tp.printdebug()

	def testTransponder_HasCompatible(self):
		tp_info = ElisITransponderInfo()	
		ret = self.mCommander.Transponder_HasCompatible(192, ElisEnum.E_BAND_KU, tp_info)
		print 'ret = %s'%ret

	def testTransponder_Add(self):
		tp_info = ElisITransponderInfo()
		tp=[]
		tp.append(tp_info)
		ret = []
		ret = self.mCommander.Transponder_Add(192, ElisEnum.E_BAND_KU, tp)
		print 'ret =%s'%ret

	def testTransponder_Delete(self):
		tp_info = ElisITransponderInfo()
		tp=[]
		tp.append(tp_info)
		ret = []
		ret = self.mCommander.Transponder_Delete(192, ElisEnum.E_BAND_KU, tp)
		print 'ret =%s'%ret

	def testSatelliteconfig_GetList(self):
		sat_info =[]
		sat_info = self.mCommander.Satelliteconfig_GetList(0)
		if sat_info != None:			
			for sat in sat_info:
				if sat == None:
					print'data None'
				elif sat.mError < 0:
					print 'sat Get Error'
				else:
					sat.printdebug()
				
		elif sat_info == None:
			print 'sat None'		

		sat_info1 = self.mCommander.Satelliteconfig_GetList(1)
		if sat_info1 != None:			
			for sat1 in sat_info1:
				if sat1 == None:
					print'data None'
				elif sat1.mError < 0:
					print 'sat Get Error'
				else:
					sat1.printdebug()
				
		elif sat_info1 == None:
			print 'sat1 None'		
			

	def testSatelliteconfig_GetFirstAvailablePos(self):
		ret = []
		ret = self.mCommander.Satelliteconfig_GetFirstAvailablePos(0, 0)
		print 'First available pos %d'%ret

	def testSatelliteconfig_DeleteAll(self):
		ret = [] 
		ret = self.mCommander.Satelliteconfig_DeleteAll()
		print 'ret =%s'%ret

	def testDatetime_GetGMTTime(self):
		ret = []
		ret = self.mCommander.Datetime_GetGMTTime()
		print "time = ", time.asctime(time.localtime(ret))
		print 'ret = %d'%ret

	def testDatetime_GetLocalOffset(self):
		ret = []
		ret = self.mCommander.Datetime_GetLocalOffset()
		print 'ret = %d'%ret

	def testDatetime_GetLocalTime(self):
		ret = []
		ret = self.mCommander.Datetime_GetLocalTime()
		print 'ret = %d'%ret

	def testMotorized_Stop(self):
		ret = []
		ret = self.mCommander.Motorized_Stop(0)
		print 'ret = %s'%ret
		
	def testMotorized_GoWest(self):
		ret = []
		ret = self.mCommander.Motorized_GoWest(0)
		print 'ret = %s'%ret

	def testMotorized_GoEast(self):
		ret = []
		ret = self.mCommander.Motorized_GoEast(0)
		print 'ret = %s'%ret

	def testMotorized_StepWest(self):
		ret = []
		ret = self.mCommander.Motorized_StepWest(0)
		print 'ret = %s'%ret
		
	def testMotorized_StepEast(self):
		ret = []
		ret = self.mCommander.Motorized_StepEast(0)
		print 'ret = %s'%ret

	def testMotorized_SetEastLimit(self):
		ret = []
		ret = self.mCommander.Motorized_SetEastLimit(0)
		print 'ret = %s'%ret

	def testMotorized_SetWestLimit(self):
		ret = []
		ret = self.mCommander.Motorized_SetWestLimit(0)
		print 'ret = %s'%ret
		
	def testMotorized_ResetLimit(self):
		ret = []
		ret = self.mCommander.Motorized_ResetLimit(0)
		print 'ret = %s'%ret
		
	def testMotorized_GotoNull(self):
		ret = []
		ret = self.mCommander.Motorized_GotoNull(0)
		print 'ret = %s'%ret

	def testMotorized_SavePosition(self):
		ret = []
		ret = self.mCommander.Motorized_SavePosition(0,1)
		print 'ret = %s'%ret

	def testplayer_GetStatus(self):
		status=[]
		status=self.mCommander.Player_GetStatus()
		print 'player status = %s'%status
	
	def testPlayer_StartTimeshiftPlayback(self):
		ret = []
		ret = self.mCommander.Player_StartTimeshiftPlayback(ElisEnum.E_IPLAYER_TIMESHIFT, 0)
		print 'ret = %s'%ret

	def testPlayer_StartInternalRecordPlayback(self):
		ret = []
		ret = self.mCommander.Player_StartInternalRecordPlayback(1, ElisEnum.E_SERVICE_TYPE_TV, 0, 100)
		print 'ret = %s'%ret

	def testPlayer_Stop(self):
		ret = []
		ret = self.mCommander.Player_Stop()
		print 'ret = %s'%ret

	def testPlayer_SetSpeed(self):
		ret = []
		ret = self.mCommander.Player_SetSpeed(200)
		print 'ret = %s'%ret

	def testPlayer_JumpTo(self):
		ret = []
		ret = self.mCommander.Player_JumpTo(5000)
		print 'ret = %s'%ret

	def testPlayer_JumpToIFrame(self):
		ret = []
		ret = self.mCommander.Player_JumpToIFrame(5000)
		print 'ret = %s'%ret

	def testPlayer_Pause(self):
		ret = []
		ret = self.mCommander.Player_Pause()
		print 'ret = %s'%ret

	def testPlayer_Resume(self):
		ret = []
		ret = self.mCommander.Player_Resume()
		print 'ret = %s'%ret

	def testPlayer_SetVolume(self):
		ret = []
		ret = self.mCommander.Player_SetVolume(10)
		print 'ret = %s'%ret

	def testPlayer_GetVolume(self):
		ret = []
		ret = self.mCommander.Player_GetVolume()
		print 'ret = %d'%ret

	def testPlayer_SetMute(self):
		ret = []
		ret = self.mCommander.Player_SetMute(1)
		print 'ret = %s'%ret

	def testPlayer_GetMute(self):
		ret = []
		ret = self.mCommander.Player_GetMute()
		print 'ret = %d'%ret
		
	def testPlayer_AVBlank(self):
		ret = []
		ret = self.mCommander.Player_AVBlank(1, 0)
		print 'ret = %s'%ret

	def testPlayer_VideoBlank(self):
		ret = []
		ret = self.mCommander.Player_VideoBlank(1, 0)
		print 'ret = %s'%ret

	def testPlayer_AVMute(self):
		ret = []
		ret = self.mCommander.Player_AVMute(1, 0)
		print 'ret = %s'%ret

	def testPlayer_StopLivePlayer(self):
		ret = []
		ret = self.mCommander.Player_StopLivePlayer()
		print 'ret = %s'%ret

	def testPlayer_SetVIdeoSize(self):
		ret = []
		ret = self.mCommander.Player_SetVIdeoSize(0, 0, 1280,720)
		print 'ret = %s'%ret

	def testPlayer_IsVideoValid(self):
		ret = []
		ret = self.mCommander.Player_IsVideoValid()
		print 'ret = %s'%ret
		
	def testRecord_GetCount(self):
		ret = []
		ret = self.mCommander.Record_GetCount(ElisEnum.E_SERVICE_TYPE_TV)
		print 'ret = %d'%ret

	def testRecord_GetRecordInfo(self):
		rec_info = []
		rec_info = self.mCommander.Record_GetRecordInfo(0, ElisEnum.E_SERVICE_TYPE_TV)
		for rec in rec_info:
			rec.printdebug()

	def testRecord_GetRecordInfoByKey(self):
		rec_info = []
		rec_info = self.mCommander.Record_GetRecordInfoByKey(0)
		for rec in rec_info:
			rec.printdebug()

	def testRecord_StartRecord(self):
		ret = []
		ret = self.mCommander.Record_StartRecord(1 , ElisEnum.E_SERVICE_TYPE_TV, 60000, 'recname' )
		print 'ret = %s'%ret

	def testRecord_StopRecord(self):
		ret = []
		ret = self.mCommander.Record_StopRecord(1, ElisEnum.E_SERVICE_TYPE_TV, 0)
		print 'ret = %s'%ret

	def testRecord_GetRunningRecorderCount(self):
		ret = []
		ret = self.mCommander.Record_GetRunningRecorderCount()
		print 'ret = %d'%ret

	def testRecord_GetRunningRecordInfo(self):
		rec_info = []
		rec_info = self.mCommander.Record_GetRunningRecordInfo(0)
		for rec in rec_info:
			rec.printdebug()

	def testRecord_GetPartitionSize(self):
		ret = []
		ret = self.mCommander.Record_GetPartitionSize()
		print 'ret = %d'%ret

	def testRecord_GetFreeMBSize(self):
		ret = []
		ret = self.mCommander.Record_GetFreeMBSize()
		print 'ret = %d'%ret		
		
	def testRecord_DeleteRecord(self, key):
		ret = []
		ret = self.mCommander.Record_DeleteRecord(key, ElisEnum.E_SERVICE_TYPE_TV)
		print 'ret = %d'%ret

	def testRecord_SetLock(self, key, lock):
		ret = []
		ret = self.mCommander.Record_SetLock(key, ElisEnum.E_SERVICE_TYPE_TV, lock)
		print 'ret = %s'%ret

	def testRecord_Rename(self, key, name):
		ret = []
		ret = self.mCommander.Record_Rename(key, ElisEnum.E_SERVICE_TYPE_TV, name)
		print 'ret = %d'%ret

	def testRecord_IsRecording(self):
		ret = []
		ret = self.mCommander.Record_IsRecording(0, ElisEnum.E_SERVICE_TYPE_TV)
		print 'ret = %d'%ret
		
	def testSubtitle_Get(self):
		sub_info = []
		sub_info = self.mCommander.Subtitle_Get(0)
		for sub in sub_info:
			sub.printdebug()
		
	def testSubtitle_GetCount(self):
		ret = []
		ret = self.mCommander.Subtitle_GetCount()
		print 'ret = %d'%ret
		

	def testSubtitle_Select(self):
		ret = []
		ret = self.mCommander.Subtitle_Select(123, 5, 0)
		print 'ret = %d'%ret

	def testFrontdisplay_GetMaxStringLength(self):
		ret = []
		ret = self.mCommander.Subtitle_Select()
		print 'ret = %d'%ret
		
	def testFrontdisplay_SetMessage(self):
		ret = []
		ret = self.mCommander.Frontdisplay_SetMessage('test front')
		print 'ret = %s'%ret		
		
	def testFrontdisplay_SetIcon(self):
		ret = []
		ret = self.mCommander.Frontdisplay_SetIcon(1, 1)
		print 'ret = %s'%ret

	def testFrontdisplay_SetLEDMessage(self):
		ret = []
		ret = self.mCommander.Frontdisplay_SetLEDMessage('test front')
		print 'ret = %s'%ret		
		
	def testFrontdisplay_SetLedOnOff(self):
		ret = []
		ret = self.mCommander.Frontdisplay_SetLedOnOff(1, 1)
		print 'ret = %s'%ret			
		
	def testAudiotrack_GetCount(self):
		ret = []
		ret = self.mCommander.Audiotrack_GetCount(1, 1)
		print 'ret = %d'%ret	

	def testAudiotrack_Get(self):
		aud_info = []
		aud_info = self.mCommander.Audiotrack_Get(0)
		aud_info.printdebug()

	def testAudiotrack_GetSelectedIndex(self):
		ret = []
		ret = self.mCommander.Audiotrack_GetSelectedIndex()
		print 'ret = %d'%ret			

	def tesAudiotrack_select(self):
		ret = []
		ret = self.mCommander.Audiotrack_select(0)
		print 'ret = %s'%ret		

	def testCicam_GetSlotCount(self):
		ret = []
		ret = self.mCommander.Cicam_GetSlotCount()
		print 'ret = %d'%ret	

	def testCicam_IsInserted(self):
		ret = []
		ret = self.mCommander.Cicam_IsInserted(0)
		print 'ret = %d'%ret	

	def testCicam_GetInfo(self):
		cam_info = []
		cam_info = self.mCommander.Cicam_GetInfo(0)
		cam_info.printdebug

	def testCicam_EnterMMI(self):
		ret = []
		ret = self.mCommander.Cicam_EnterMMI(0)
		print 'ret = %s'%ret	

	def testCicam_SendMenuAnswer(self, answer):
		ret = []
		ret = self.mCommander.Cicam_SendMenuAnswer(0, answer)
		print 'ret = %s'%ret			

	def testDvbtuner_IsViewingTunerLocked(self):
		ret = []
		ret = self.mCommander.Dvbtuner_IsViewingTunerLocked(0)
		print 'ret = %d'%ret	

	def testUpdate_LoadChannelList(self):
		ret = []
		ret = self.mCommander.Update_LoadChannelList()
		print 'ret = %d'%ret	

	def testUpdate_SaveChannelList(self):
		ret = []
		ret = self.mCommander.Update_SaveChannelList()
		print 'ret = %d'%ret	

	def testUpdate_UpdateFimware(self):
		ret = []
		ret = self.mCommander.Update_UpdateFimware()
		print 'ret = %d'%ret	

	def testOtimodule_GetModuleConut(self):
		ret = []
		ret = self.mCommander.Otimodule_GetModuleConut()
		print 'ret = %d'%ret	

	def testOtimodule_GetModule(self):
		oti_info = []
		oti_info = self.mCommander.Otimodule_GetModule(0)
		oti_info.printdebug()		

	def testOtimodule_UpdateSW(self):
		ret = []
		ret = self.mCommander.Otimodule_UpdateSW()
		print 'ret = %s'%ret	

	def testOtimodule_UpdateCL(self):
		ret = []
		ret = self.mCommander.Otimodule_UpdateCL()
		print 'ret = %s'%ret	


	def testSystem_EnableUpdate(self):
		ret = []
		ret = self.mCommander.System_EnableUpdate()
		print 'ret = %s'%ret

	def testSystem_UpdateEnabled(self):
		ret = []
		ret = self.mCommander.System_UpdateEnabled()
		print 'ret = %s'%ret

	def testSystem_Shutdown(self):
		ret = []
		ret = self.mCommander.System_Shutdown()
		print 'ret = %s'%ret

	def testSystem_FactoryReset(self):
		ret = []
		ret = self.mCommander.System_FactoryReset()
		print 'ret = %s'%ret

	def testSystem_SetDefaultChannelList(self):
		ret = []
		ret = self.mCommander.System_SetDefaultChannelList()
		print 'ret = %s'%ret

	def testSystem_GetVersion(self):
		sys_ver = []
		sys_ver = self.mCommander.System_GetVersion()
		sys_ver.printdebug()

	def testSystem_GetHDMISinkInfo(self):
		hdmi_info = []
		hdmi_info = self.mCommander.System_GetHDMISinkInfo()
		hdmi_info.printdebug()

	def testSystem_SetAVSwitch(self):
		ret = []
		ret = self.mCommander.System_SetAVSwitch(0)
		print 'ret = %s'%ret

	def testRecordItem_GetCount(self):
		ret = []
		ret = self.mCommander.RecordItem_GetCount()
		print 'ret = %d'%ret

	def testRecordItem_GetAllCount(self):
		ret = []
		ret = self.mCommander.RecordItem_GetAllCount()
		print 'ret = %s'%ret		

	def testRecordItem_Refresh(self):
		ret = []
		ret = self.mCommander.RecordItem_Refresh()
		print 'ret = %s'%ret

	def testRecordItem_Get(self):
		rec_info = []
		rec_info = self.mCommander.RecordItem_Get(0)
		rec_info.printdebug()

	def testRecordItem_GetByKey(self):
		rec_info = []
		rec_info = self.mCommander.RecordItem_GetByKey(0)
		rec_info.printdebug()

	def testScanHelper_Start(self):
		ret = []
		ret = self.mCommander.ScanHelper_Start()
		print 'ret = %s'%ret

	def testScanHelper_Stop(self):
		ret = []
		ret = self.mCommander.ScanHelper_Stop()
		print 'ret = %s'%ret		


	def testScanHelper_ChangeContextByCarrier( self ):
		carriers = ElisITransponderInfo()
		carriers.reset()
		carriers.mFrequency = 11303
		carriers.mSymbolRate = 22000
		carriers.mPolarization=ElisEnum.E_LNB_HORIZONTAL
		carriers.mFECMode=ElisEnum.E_DVBS2_8PSK_2_3
		input_carriers = []
		input_carriers.append(carriers)
		ret = self.mCommander.ScanHelper_ChangeContextByCarrier( input_carriers )
		print 'ret = %s'%ret

	def testTimer_GetOTRInfo(self):
		ort_info = []
		ort_info = self.mCommander.Timer_GetOTRInfo(0)
		ort_info.printdebug()

	def testTimer_AddOTRTimer(self):
		ret  = []
		ret = self.mCommander.Timer_AddOTRTimer(0,4000,0, 'timer_name',0,0,0,0)
		print 'ret = %s'%ret

	def testTimer_AddManualTimer(self):
		ret  = []
		ret = self.mCommander.Timer_AddManualTimer(1,ElisEnum.E_SERVICE_TYPE_TV, 0, 5000, 'rec_name', 0)
		print 'ret = %s'%ret

	def testTimer_GetTimerCount(self):
		ret = []
		ret = self.mCommander.Timer_GetTimerCount()
		print 'ret = %d'%ret

	def testTimer_GetByIndex(self):
		timer_info = []
		timer_info = self.mCommander.Timer_GetByIndex(0)
		timer_info.printdebug()

	def testTimer_GetById(self):
		timer_info = []
		timer_info = self.mCommander.Timer_GetById(0)
		timer_info.printdebug()

	def testTimer_GetEPGOffset(self):
		timer_offset = []
		timer_offset = self.mCommander.Timer_GetEPGOffset()
		timer_offset.printdebug()

	def testTimer_SetEPGOffset(self):
		timer_offset = ElisITIMEREPGOffset()
		timer_offset.mStartOffset = 0
		timer_offset.mEndOffset = 0
		input_offset = []
		input_offset.append(timer_offset)
		ret = self.mCommander.Timer_SetEPGOffset(input_offset)
		print 'ret = %s'%ret

	def testTimer_DeleteTimer(self):
		ret = []
		ret = self.mCommander.Timer_DeleteTimer(0)
		print 'ret = %s'%ret		


	def testTimer_ChangePriority(self):
		ret = []
		ret = self.mCommander.Timer_ChangePriority(0, ElisEnum.E_ITMER_PRIORITY_NORMAL)
		print 'ret = %s'%ret

	def testTimer_ChangeName(self):
		ret = []
		ret = self.mCommander.Timer_ChangeName(0, 'NewName')
		print 'ret = %s'%ret

	def testRecordNavigation_Get(self):
		ret=[]
		ret = self.mCommander.RecordNavigation_Get()
		if ret ==None:
			print 'empty'
		elif ret.mError == -1:
			print 'Get Error'
		else:
			ret.printdebug()


	def testRecordNavigation_Set(self):
		ret=[]
		nav=[]
		rec_nav = ElisIRecordNavigation()
		rec_nav.mMode = ElisEnum.E_NAV_TYPE_FOLDER
		rec_nav.mSortType = ElisEnum.E_SORT_BY_TITLE
		rec_nav.mServiceType = ElisEnum.E_SERVICE_TYPE_TV
		rec_nav.mUserFolder =ElisUserFolder()
		rec_nav.mUserFolder.mFolderNumber = 0
		rec_nav.mUserFolder.mParenFolder = 0
		nav.append(rec_nav)
		
		ret = self.mCommander.RecordNavigation_Set(nav)
		print 'ret = %s'%ret		

	def testNetworkIpConfig(self):
		ret = self.mCommander.NetWork_SaveSetting(network)
		print 'ret = %s'%ret

	def testDHCP_Start(self):
		ret = self.mCommander.NetWork_DHCPStart()
		print 'ret = %s'%ret

	def testConax_GetInformation(self):
		ret = []
		ret = self.mCommander.Conax_GetInformation(0)
		if ret ==None:
			print 'empty'
		elif ret.mError == -1:
			print 'Get Error'
		else:
			ret.printdebug()		

	def testChannel_db(self):
		db = sqlite3.connect("/tmp/channel.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblChannel")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()

	def testEPG_db(self):
		db = sqlite3.connect("/tmp/epg.db")
		cursor = db.cursor()

		time1 = time.time()+7200
		print "time = %d"%time1
		cursor.execute("select * from tblEPG WHERE (StartTime + Duration + 3600) < %d"%time1)
		print "time2 = ", time.time()
		for row in cursor:
		    print row
		'''
		print "time = ", time.time()
		cursor.execute("select * from tblEPG where Onid=1")
		print "time2 = ", time.time()
		for row in cursor:
		    print row
		'''

		cursor.close()

		db.commit()
		db.close()

	def testProperty_db(self):
		db = sqlite3.connect("/tmp/property.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblPropertyEnum")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblPropertyInt")
		print "time2 = ", time.time()
		for row in cursor:
		    print row


		cursor.close()

		db.commit()
		db.close()		

	def testChannelUp(self):
		channel_info = []
		channel_info=self.mCommander.Channel_GetNext()
		ret = []
		channel_number = channel_info.mNumber
		ret=self.mCommander.Channel_SetCurrent(channel_number, ElisEnum.E_SERVICE_TYPE_TV)
		print 'ret = %s'%ret

	def testChannelDown(self):
		channel_info = []
		channel_info=self.mCommander.Channel_GetPrev()
		ret = []
		channel_number = channel_info.mNumber
		ret=self.mCommander.Channel_SetCurrent(channel_number, ElisEnum.E_SERVICE_TYPE_TV)
		print 'ret = %s'%ret		 
		
	def testChannelChange(self, number):
		ret = []
		channel_number = number
		ret=self.mCommander.Channel_SetCurrent(channel_number, ElisEnum.E_SERVICE_TYPE_TV)
		print 'ret = %s'%ret

	def testRecordInfoList(self):
		mRecordCount = self.mCommander.Record_GetCount( ElisEnum.E_SERVICE_TYPE_TV )
		
		if(mRecordCount > 0):		
			for i in range( mRecordCount ) :
				print'i=%d',i		
				recInfo = self.mCommander.Record_GetRecordInfo( i, ElisEnum.E_SERVICE_TYPE_TV )
				if recInfo ==None:
					print 'empty'
				elif recInfo.mError == -1:
					print 'Recordinfo Read Error'
				else:
					recInfo.printdebug()
		else:
			print'Not exist Record file'


	def testRecordPlayback(self, rec_index):
		ret = []
		reckey = rec_index
		ret = self.mCommander.Player_StartInternalRecordPlayback(reckey, ElisEnum.E_SERVICE_TYPE_TV, 0, 100)
		print 'ret = %s'%ret

	def testRecordStop(self, channel_no, rec_key):
		ret = []
		channelNo = channel_no
		recKey = rec_key
		ret = self.mCommander.Record_StopRecord(channelNo, ElisEnum.E_SERVICE_TYPE_TV, recKey)
		print 'ret = %s'%ret

	def testRecordStart(self, channel_no, rec_duration, record_name):
		channelNo = channel_no
		recDuration = rec_duration
		recordName = record_name
		ret = []
		ret = self.mCommander.Record_StartRecord(channelNo, ElisEnum.E_SERVICE_TYPE_TV, recDuration, recordName)
		print 'ret = %s'%ret

	def testRecordRunningList(self):
		mRecordCount = self.mCommander.Record_GetRunningRecorderCount()
		
		if(mRecordCount > 0):		
			for i in range( mRecordCount ) :
				print'i=%d',i		
				recInfo = self.mCommander.Record_GetRunningRecordInfo( i )
				if recInfo ==None:
					print 'empty'
				elif recInfo.mError == -1:
					print 'Recordinfo Read Error'
				else:
					recInfo.printdebug()
		else:
			print'Not exist Recording file'

	def testRecordInfo_db(self):
		db = sqlite3.connect("/tmp/recordinfo.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblRecordInfo")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()


	def testSatellite_db(self):
		db = sqlite3.connect("/tmp/channel.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblSatellite")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()

	def testTransponder_db(self):
		db = sqlite3.connect("/tmp/channel.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblSCarrier")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()
			
	def testSatelliteConfigured_db(self):
		db = sqlite3.connect("/tmp/channel.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblSatelliteConfig")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()
		

	def testConfiguredSatelliteInfo(self):
		db = sqlite3.connect("/tmp/channel.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblConfiguredSatelliteInfo")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()
	
	def testFavGroup(self):
		db = sqlite3.connect("/tmp/channel.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblFavoriteGroup")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()

	def testFavGroupChannel(self):
		db = sqlite3.connect("/tmp/channel.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblFavoriteChannel")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()
		
	def testZappingChannelList(self):
		ret = self.mCommander.Channel_GetZappingList(0)
		print 'ret = %s'%ret

	def testZappingChannel(self):
		start_time = time.time()	
		print "time = ", time.time()
		ret = self.mCommander.Channel_GetZappingList(0)
		print "zapping channel = %s"% (time.time() - start_time)
		db = sqlite3.connect("/tmp/channel.db")
		cursor = db.cursor()

		start_time = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblZappingChannel")
		print "query channel = %s"% (time.time() - start_time)
		#for row in cursor:
		    #print row

		cursor.close()

		db.commit()
		db.close()

	def testZappingModeDB(self):
		db = sqlite3.connect("/tmp/channel.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblZappingMode")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()

	def testTimer_AddEPG(self):
		epg_info = []
		epg_info = self.mCommander.Epgevent_GetPresent()
		if epg_info == None:			
			print'data None'
		elif epg_info.mError < 0:
			print 'Epgevent Get Error'
		else:
			epg_info.printdebug()
			epglist = []
			epglist.append(epg_info)
			ret = []
			ret = self.mCommander.Timer_AddEPGTimer(0, 0, epglist)
			if ret == None:			
				print'data None'
			else:
				for timerid in ret:
					if timerid == None:
						print'data None'
					elif timerid.mError < 0:
						print 'Add Timer Error'
					else:
						timerid.printdebug()
				
		
	def testTimer_GetCount(self):
		ret = []
		ret = self.mCommander.Timer_GetTimerCount()
		print "timer count = ",ret


	def testTimer_GetList(self):
		ret = []
		ret = self.mCommander.Timer_GetTimerCount()
		print "timer count = ",ret
		for i in range( ret) :
			timer = []
			timer = self.mCommander.Timer_GetByIndex(i)
			if timer == None:
				print 'no timer'
			elif timer.mError < 0:
				print 'get timer error'
			else:
				timer.printdebug()

	def testTimer_delete(self, aTimerId):
		ret = []
		ret = self.mCommander.Timer_DeleteTimer(aTimerId)
		print 'ret = %s'%ret

	def testTimer_AddManual(self):
		epg_info = []
		epg_test = self.mCommander.Epgevent_GetPresent()
		count = 0
		if epg_test.mError != -1:
			print 'EPG Get Present'
			ret = self.mCommander.Datetime_GetGMTTime()
			gmtFrom = epg_test.mStartTime
			print "time = ", time.asctime(time.localtime(gmtFrom))
			gmtUntil = gmtFrom+(3600*24*7)
			print "time = ", time.asctime(time.localtime(gmtUntil))
			print "time = ", gmtFrom
			print "time = ", gmtUntil
			ret = self.mCommander.Timer_AddManualTimer(1, ElisEnum.E_SERVICE_TYPE_TV, gmtFrom, 120, 'testmanualtimer', 0)
			if ret == None:			
				print'data None'
			else:
				for timerid in ret:
					if timerid == None:
						print'data None'
					elif timerid.mError < 0:
						print 'Epgevent Get Error'
					else:
						timerid.printdebug()
		else:
			print 'EPG Get Present NULL'

	def testTimer_AddWeekly(self):
		epg_info = []
		epg_test = self.mCommander.Epgevent_GetPresent()
		count = 0
		if epg_test.mError != -1:
			print 'EPG Get Present'
			ret = self.mCommander.Datetime_GetGMTTime()
			gmtFrom = epg_test.mStartTime
			print "time = ", time.asctime(time.localtime(gmtFrom))
			gmtUntil = gmtFrom+(3600*24*7)
			print "time = ", time.asctime(time.localtime(gmtUntil))
			print "time = ", gmtFrom
			print "time = ", gmtUntil

			weelkylist=[]
			weelky1 = ElisIWeeklyTimer()
			weelky1.mDate = 0
			weelky1.mStartTime = gmtFrom
			weelky1.mDuration = 120
			
			weelky2 = ElisIWeeklyTimer()
			weelky2.mDate = 1
			weelky2.mStartTime = gmtFrom+130
			weelky2.mDuration = 120
			
			weelky3 = ElisIWeeklyTimer()
			weelky3.mDate = 2
			weelky3.mStartTime = gmtFrom+260
			weelky3.mDuration = 120
			
			weelkylist.append(weelky1)
			weelkylist.append(weelky2)
			weelkylist.append(weelky3)

			
			ret = self.mCommander.Timer_AddWeeklyTimer(1, ElisEnum.E_SERVICE_TYPE_TV, 0, 0, 'testweelkytimer', 3, weelkylist)
			if ret == None:			
				print'data None'
			else:
				for timerid in ret:
					if timerid == None:
						print'data None'
					elif timerid.mError < 0:
						print 'Epgevent Get Error'
					else:
						timerid.printdebug()
		else:
			print 'EPG Get Present NULL'


	def testAppMediaPlayer_Control(self, aStart):
		ret = []
		ret = self.mCommander.AppMediaPlayer_Control(aStart)
		print 'ret = %s'%ret

	def testGetCurrentEventDB(self, aStart, aEnd):
		ret = []
		print "time1 = ", time.time()		
		ret = self.mCommander.Epgevnt_GetCurrentDB(ElisEnum.E_SERVICE_TYPE_TV, aStart, aEnd)
		print "time1 = ", time.time()		
		db = sqlite3.connect("/tmp/epgcf.db")
		cursor = db.cursor()

		time1 = time.time()		
		print "time = ", time.time()
		cursor.execute("select * from tblCurrentEPG")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()

	def testGetFollowingEventDB(self,  aStart, aEnd):
		ret = []
		print "time1 = ", time.time()		
		ret = self.mCommander.Epgevent_GetFollowingDB(ElisEnum.E_SERVICE_TYPE_TV, aStart, aEnd)
		print "time1 = ", time.time()
		db = sqlite3.connect("/tmp/epgcf.db")
		cursor = db.cursor()


		print "time1 = ", time.time()
		cursor.execute("select * from tblFollowingEPG")
		print "time2 = ", time.time()
		for row in cursor:
		    print row

		cursor.close()

		db.commit()
		db.close()

	def testGetChannelEventDB(self):
		channel_info = []
		channel_info=self.mCommander.Channel_GetCurrent()
		channel_info.printdebug()
	
		ret = []
		start_time = time.time()
		print "get epg = %s"%start_time 		
		ret = self.mCommander.Epgevent_GetChannelDB(channel_info.mSid, channel_info.mTsid, channel_info.mOnid)
		print "end get epg = %s"% (time.time() - start_time)
		db = sqlite3.connect("/tmp/epgcf.db")
		cursor = db.cursor()


		start_time = time.time()
		print "query start = %s"%start_time 		
		cursor.execute("select * from tblChannelEPG")
		print "query end = %s"% (time.time() - start_time)
		'''
		for row in cursor:
		    print row
		'''
		cursor.close()

		db.commit()
		db.close()
		
	def testTimer_GetRunningTimers(self):
		timer  = []
		timer = self.mCommander.Timer_GetRunningTimers()
		if timer == None:			
			print'data None'
		else:
			for timerid in timer:
				if timerid == None:
					print'data None'
				elif timerid.mError < 0:
					print 'timer Get Error'
				else:
					timerid.printdebug()
		
	def testZappingTest(self):
		global aLoop 
		aLoop = True
		count = 0
		while aLoop:
			print"Zapping Test Count = ",count
			ret=self.mCommander.Channel_SetCurrent(1, ElisEnum.E_SERVICE_TYPE_TV)
			count = count +1
			print"Zapping Test Count = ",count
			time.sleep(8)
			ret=self.mCommander.Channel_SetCurrent(156, ElisEnum.E_SERVICE_TYPE_TV)
			time.sleep(8)
			count = count +1

	def testRecordInfoGetEvt(self, key):
		recordevent = []
		recordevent = self.mCommander.RecordItem_GetEventInfo(key)
		if recordevent == None:
			print'epg data None'
		elif recordevent.mError < 0:
			print'epg get data error'
		else:
			recordevent.printdebug()
		
