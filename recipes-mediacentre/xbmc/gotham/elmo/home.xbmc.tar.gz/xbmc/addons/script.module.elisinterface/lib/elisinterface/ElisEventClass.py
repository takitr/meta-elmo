
from ElisEnum import ElisEnum
from ElisClass import * 
from ElisEventCustom import ElisEventCustom

class ElisEvent(object):
	@classmethod
	def getName(cls):
		return cls.__name__

	def ParseElisEvent( ret ):
		if ret[0] == 'Elis-ScanProgress':
			lElisEventScanProgress= ElisEventScanProgress()
			lElisEventScanProgress.parseReturnBuffer(ret, 1 )
			return lElisEventScanProgress
			
		elif ret[0] == 'Elis-ScanAddChannel':
			lElisEventScanAddChannel= ElisEventScanAddChannel()
			lElisEventScanAddChannel.parseReturnBuffer(ret, 1 )
			return lElisEventScanAddChannel
			
		elif ret[0] == 'Elis-PMTReceived':
			lElisPMTReceivedEvent= ElisPMTReceivedEvent()
			lElisPMTReceivedEvent.parseReturnBuffer(ret, 1 )
			return lElisPMTReceivedEvent
			
		elif ret[0] == 'Elis-VideoIdentified':
			lElisEventVideoIdentified= ElisEventVideoIdentified()
			lElisEventVideoIdentified.parseReturnBuffer(ret, 1 )
			return lElisEventVideoIdentified
			
		elif ret[0] == 'Elis-ChannelChangeResult':
			lElisEventChannelChangeResult= ElisEventChannelChangeResult()
			lElisEventChannelChangeResult.parseReturnBuffer(ret, 1 )
			return lElisEventChannelChangeResult
			
		elif ret[0] == 'Elis-CurrentEITReceived':
			lElisEventCurrentEITReceived= ElisEventCurrentEITReceived()
			lElisEventCurrentEITReceived.parseReturnBuffer(ret, 1 )
			return lElisEventCurrentEITReceived
			
		elif ret[0] == 'Elis-ChannelChangeStatus':
			lElisEventChannelChangeStatus= ElisEventChannelChangeStatus()
			lElisEventChannelChangeStatus.parseReturnBuffer(ret, 1 )
			return lElisEventChannelChangeStatus
			
		elif ret[0] == 'Elis-RecordingStarted':
			lElisEventRecordingStarted= ElisEventRecordingStarted()
			lElisEventRecordingStarted.parseReturnBuffer(ret, 1 )
			return lElisEventRecordingStarted
			
		elif ret[0] == 'Elis-RecordingStopped':
			lElisEventRecordingStopped= ElisEventRecordingStopped()
			lElisEventRecordingStopped.parseReturnBuffer(ret, 1 )
			return lElisEventRecordingStopped
			
		elif ret[0] == 'Elis-ChannelChangedByRecord':
			lElisEventChannelChangedByRecord= ElisEventChannelChangedByRecord()
			lElisEventChannelChangedByRecord.parseReturnBuffer(ret, 1 )
			return lElisEventChannelChangedByRecord
			
		elif ret[0] == 'Elis-PlaybackStarted':
			lElisEventPlaybackStarted= ElisEventPlaybackStarted()
			lElisEventPlaybackStarted.parseReturnBuffer(ret, 1 )
			return lElisEventPlaybackStarted
			
		elif ret[0] == 'Elis-PlaybackStopped':
			lElisEventPlaybackStopped= ElisEventPlaybackStopped()
			lElisEventPlaybackStopped.parseReturnBuffer(ret, 1 )
			return lElisEventPlaybackStopped
			
		elif ret[0] == 'Elis-TimeshiftEITReceived':
			lElisEventTimeshiftEITReceived= ElisEventTimeshiftEITReceived()
			lElisEventTimeshiftEITReceived.parseReturnBuffer(ret, 1 )
			return lElisEventTimeshiftEITReceived
			
		elif ret[0] == 'Elis-CAMInsertRemove':
			lElisEventCAMInsertRemove= ElisEventCAMInsertRemove()
			lElisEventCAMInsertRemove.parseReturnBuffer(ret, 1 )
			return lElisEventCAMInsertRemove
			
		elif ret[0] == 'Elis-ChannelChangeStarted':
			lElisEventChannelChangeStarted= ElisEventChannelChangeStarted()
			lElisEventChannelChangeStarted.parseReturnBuffer(ret, 1 )
			return lElisEventChannelChangeStarted
			
		elif ret[0] == 'Elis-CIMMIClosed':
			lElisEventCIMMIClosed= ElisEventCIMMIClosed()
			lElisEventCIMMIClosed.parseReturnBuffer(ret, 1 )
			return lElisEventCIMMIClosed
			
		elif ret[0] == 'Elis-CIMMIShowEnq':
			lElisEventCIMMIShowEnq= ElisEventCIMMIShowEnq()
			lElisEventCIMMIShowEnq.parseReturnBuffer(ret, 1 )
			return lElisEventCIMMIShowEnq
			
		elif ret[0] == 'Elis-CIMMIShowMenu':
			lElisEventCIMMIShowMenu= ElisEventCIMMIShowMenu()
			lElisEventCIMMIShowMenu.parseReturnBuffer(ret, 1 )
			return lElisEventCIMMIShowMenu
			
		elif ret[0] == 'Elis-CopyProgress':
			lElisEventCopyProgress= ElisEventCopyProgress()
			lElisEventCopyProgress.parseReturnBuffer(ret, 1 )
			return lElisEventCopyProgress
			
		elif ret[0] == 'Elis-DedicatedMakeStatus':
			lElisEventDedicatedMakeStatus= ElisEventDedicatedMakeStatus()
			lElisEventDedicatedMakeStatus.parseReturnBuffer(ret, 1 )
			return lElisEventDedicatedMakeStatus
			
		elif ret[0] == 'Elis-HDDForDedicatedFound':
			lElisEventHDDForDedicatedFound= ElisEventHDDForDedicatedFound()
			lElisEventHDDForDedicatedFound.parseReturnBuffer(ret, 1 )
			return lElisEventHDDForDedicatedFound
			
		elif ret[0] == 'Elis-HDDFormatStatus':
			lElisEventHDDFormatStatus= ElisEventHDDFormatStatus()
			lElisEventHDDFormatStatus.parseReturnBuffer(ret, 1 )
			return lElisEventHDDFormatStatus
			
		elif ret[0] == 'Elis-MediaPlayerBufferUnderflow':
			lElisEventMediaPlayerBufferUnderflow= ElisEventMediaPlayerBufferUnderflow()
			lElisEventMediaPlayerBufferUnderflow.parseReturnBuffer(ret, 1 )
			return lElisEventMediaPlayerBufferUnderflow
			
		elif ret[0] == 'Elis-OldRecordDeleted':
			lElisEventOldRecordDeleted= ElisEventOldRecordDeleted()
			lElisEventOldRecordDeleted.parseReturnBuffer(ret, 1 )
			return lElisEventOldRecordDeleted
			
		elif ret[0] == 'Elis-OTIDownloadStatus':
			lElisEventOTIDownloadStatus= ElisEventOTIDownloadStatus()
			lElisEventOTIDownloadStatus.parseReturnBuffer(ret, 1 )
			return lElisEventOTIDownloadStatus
			
		elif ret[0] == 'Elis-PlaybackEOF':
			lElisEventPlaybackEOF= ElisEventPlaybackEOF()
			lElisEventPlaybackEOF.parseReturnBuffer(ret, 1 )
			return lElisEventPlaybackEOF
			
		elif ret[0] == 'Elis-Shutdown':
			lElisEventShutdown= ElisEventShutdown()
			lElisEventShutdown.parseReturnBuffer(ret, 1 )
			return lElisEventShutdown
			
		elif ret[0] == 'Elis-Temperature':
			lElisEventTemperature= ElisEventTemperature()
			lElisEventTemperature.parseReturnBuffer(ret, 1 )
			return lElisEventTemperature
			
		elif ret[0] == 'Elis-EventTuningStatus':
			lElisEventTuningStatus= ElisEventTuningStatus()
			lElisEventTuningStatus.parseReturnBuffer(ret, 1 )
			return lElisEventTuningStatus
			
		elif ret[0] == 'Elis-UpdateProgress':
			lElisEventUpdateProgress= ElisEventUpdateProgress()
			lElisEventUpdateProgress.parseReturnBuffer(ret, 1 )
			return lElisEventUpdateProgress
			
		elif ret[0] == 'Elis-USBCopyMediaProgress':
			lElisEventUSBCopyMediaProgress= ElisEventUSBCopyMediaProgress()
			lElisEventUSBCopyMediaProgress.parseReturnBuffer(ret, 1 )
			return lElisEventUSBCopyMediaProgress
			
		elif ret[0] == 'Elis-USBCopyRecordProgress':
			lElisEventUSBCopyRecordProgress= ElisEventUSBCopyRecordProgress()
			lElisEventUSBCopyRecordProgress.parseReturnBuffer(ret, 1 )
			return lElisEventUSBCopyRecordProgress
			
		elif ret[0] == 'Elis-PowerSave':
			lElisEventPowerSave= ElisEventPowerSave()
			lElisEventPowerSave.parseReturnBuffer(ret, 1 )
			return lElisEventPowerSave
			
		elif ret[0] == 'Elis-TimeReceived':
			lElisEventTimeReceived= ElisEventTimeReceived()
			lElisEventTimeReceived.parseReturnBuffer(ret, 1 )
			return lElisEventTimeReceived
			
		elif ret[0] == 'Elis-ChannelScanFinish':
			lElisEventChannelScanFinish= ElisEventChannelScanFinish()
			lElisEventChannelScanFinish.parseReturnBuffer(ret, 1 )
			return lElisEventChannelScanFinish
			
		elif ret[0] == 'Elis-ChannelDBUpdate':
			lElisEventChannelDBUpdate= ElisEventChannelDBUpdate()
			lElisEventChannelDBUpdate.parseReturnBuffer(ret, 1 )
			return lElisEventChannelDBUpdate
			
		elif ret[0] == 'Elis-ZappingChannelDBUpdate':
			lElisEventZappingChannelDBUpdate= ElisEventZappingChannelDBUpdate()
			lElisEventZappingChannelDBUpdate.parseReturnBuffer(ret, 1 )
			return lElisEventZappingChannelDBUpdate
			
		elif ret[0] == 'Elis-EPGDBUpdate':
			lElisEventEPGDBUpdate= ElisEventEPGDBUpdate()
			lElisEventEPGDBUpdate.parseReturnBuffer(ret, 1 )
			return lElisEventEPGDBUpdate
			
		elif ret[0] == 'Elis-PropertyDBUpdate':
			lElisEventPropertyDBUpdate= ElisEventPropertyDBUpdate()
			lElisEventPropertyDBUpdate.parseReturnBuffer(ret, 1 )
			return lElisEventPropertyDBUpdate
			
		elif ret[0] == 'Elis-RecordInfoDBUpdate':
			lElisEventRecordInfoDBUpdate= ElisEventRecordInfoDBUpdate()
			lElisEventRecordInfoDBUpdate.parseReturnBuffer(ret, 1 )
			return lElisEventRecordInfoDBUpdate
			
		elif ret[0] == 'Elis-ExternalMediaPlayerStart':
			lElisEventExternalMediaPlayerStart= ElisEventExternalMediaPlayerStart()
			lElisEventExternalMediaPlayerStart.parseReturnBuffer(ret, 1 )
			return lElisEventExternalMediaPlayerStart
			
		elif ret[0] == 'Elis-ExternalMediaPlayerSetSpeed':
			lElisEventExternalMediaPlayerSetSpeed= ElisEventExternalMediaPlayerSetSpeed()
			lElisEventExternalMediaPlayerSetSpeed.parseReturnBuffer(ret, 1 )
			return lElisEventExternalMediaPlayerSetSpeed
			
		elif ret[0] == 'Elis-ExternalMediaPlayerSeekStream':
			lElisEventExternalMediaPlayerSeekStream= ElisEventExternalMediaPlayerSeekStream()
			lElisEventExternalMediaPlayerSeekStream.parseReturnBuffer(ret, 1 )
			return lElisEventExternalMediaPlayerSeekStream
			
		elif ret[0] == 'Elis-ExternalMediaPlayerStopPlay':
			lElisEventExternalMediaPlayerStopPlay= ElisEventExternalMediaPlayerStopPlay()
			lElisEventExternalMediaPlayerStopPlay.parseReturnBuffer(ret, 1 )
			return lElisEventExternalMediaPlayerStopPlay
			
		elif ret[0] == 'Elis-EventMediaPlayerSetVideoSize':
			lElisEventMediaPlayerSetVideoSize= ElisEventMediaPlayerSetVideoSize()
			lElisEventMediaPlayerSetVideoSize.parseReturnBuffer(ret, 1 )
			return lElisEventMediaPlayerSetVideoSize
			
		elif ret[0] == 'Elis-PowerSaveEnd':
			lElisEventPowerSaveEnd= ElisEventPowerSaveEnd()
			lElisEventPowerSaveEnd.parseReturnBuffer(ret, 1 )
			return lElisEventPowerSaveEnd
			
		elif ret[0] == 'Elis-USBNotifyAttach':
			lElisEventUSBNotifyAttach= ElisEventUSBNotifyAttach()
			lElisEventUSBNotifyAttach.parseReturnBuffer(ret, 1 )
			return lElisEventUSBNotifyAttach
			
		elif ret[0] == 'Elis-USBNotifyDetach':
			lElisEventUSBNotifyDetach= ElisEventUSBNotifyDetach()
			lElisEventUSBNotifyDetach.parseReturnBuffer(ret, 1 )
			return lElisEventUSBNotifyDetach
			

	ParseElisEvent = staticmethod(ParseElisEvent)
	

class ElisEventScanProgress( ElisEvent ):
	def __init__(self, amAllCount = 0 ,amCurrentIndex = 0 ,amFinished = 0 ,amCarrier = None):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, All Carrier Count
		###
		self.mAllCount= amAllCount

		### 
		# Type: Integer, Current Carrier Index
		###
		self.mCurrentIndex= amCurrentIndex

		### 
		# Type: Bool, Be Finished
		###
		self.mFinished= amFinished

		### 
		# Type: ElisICarrier, Current Carrier Information
		# @see ElisICarrier
		###
		self.mCarrier= amCarrier

	def parseReturnBuffer(self, ret ,offset=0):
		self.mAllCount= int(ret[offset])
		offset=offset+1
		self.mCurrentIndex= int(ret[offset])
		offset=offset+1
		self.mFinished= int(ret[offset])
		offset=offset+1
		self.mCarrier= ElisICarrier()
		offset = self.mCarrier.parseReturnBuffer( ret, offset )

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventScanProgress'
		print 'mAllCount= %d'%self.mAllCount
		print 'mCurrentIndex= %d'%self.mCurrentIndex
		print 'mFinished= %d'%self.mFinished
		print 'mCarrier=' 
		self.mCarrier.printdebug()

class ElisEventScanAddChannel( ElisEvent ):
	def __init__(self, amIChannel = None ,amIsNew = 1):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: ElisIChannel, Channel Information
		# @see ElisIChannel
		###
		self.mIChannel= amIChannel

		### 
		# Type: Bool, New Channel or not
		###
		self.mIsNew= amIsNew

	def parseReturnBuffer(self, ret ,offset=0):
		self.mIChannel= ElisIChannel()
		offset = self.mIChannel.parseReturnBuffer( ret, offset )
		self.mIsNew= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventScanAddChannel'
		print 'mIChannel=' 
		self.mIChannel.printdebug()
		print 'mIsNew= %d'%self.mIsNew

class ElisPMTReceivedEvent( ElisEvent ):

	def parseReturnBuffer(self, ret ,offset=0):

		ElisEventCustom.parseElisPMTReceivedEvent(self, ret, offset )

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisPMTReceivedEvent'

		ElisEventCustom.debugprintElisPMTReceivedEvent(self )

class ElisEventVideoIdentified( ElisEvent ):
	def __init__(self, amVideoWidth = 1920 ,amVideoHeight = 1080):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Source Video Width
		###
		self.mVideoWidth= amVideoWidth

		### 
		# Type: Integer, Source Video Height
		###
		self.mVideoHeight= amVideoHeight

	def parseReturnBuffer(self, ret ,offset=0):
		self.mVideoWidth= int(ret[offset])
		offset=offset+1
		self.mVideoHeight= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventVideoIdentified'
		print 'mVideoWidth= %d'%self.mVideoWidth
		print 'mVideoHeight= %d'%self.mVideoHeight

class ElisEventChannelChangeResult( ElisEvent ):
	def __init__(self, amChannelNo = 1 ,amServiceType = ElisEnum.E_SERVICE_TYPE_INVALID ,amSuccess = 1 ,amFailedReason = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Channel Number
		###
		self.mChannelNo= amChannelNo

		### 
		# Type: Integer, Service Type : 
		###
		self.mServiceType= amServiceType

		### 
		# Type: Integer, Success : ture or false
		###
		self.mSuccess= amSuccess

		### 
		# Type: Integer, Failed Reason
		###
		self.mFailedReason= amFailedReason

	def parseReturnBuffer(self, ret ,offset=0):
		self.mChannelNo= int(ret[offset])
		offset=offset+1
		self.mServiceType= int(ret[offset])
		offset=offset+1
		self.mSuccess= int(ret[offset])
		offset=offset+1
		self.mFailedReason= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventChannelChangeResult'
		print 'mChannelNo= %d'%self.mChannelNo
		print 'mServiceType= %d'%self.mServiceType
		print 'mSuccess= %d'%self.mSuccess
		print 'mFailedReason= %d'%self.mFailedReason

class ElisEventCurrentEITReceived( ElisEvent ):
	def __init__(self, amSid = 0 ,amTsid = 0 ,amOnid = 0 ,amEventId = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Service ID
		###
		self.mSid= amSid

		### 
		# Type: Integer, Transport Stream ID
		###
		self.mTsid= amTsid

		### 
		# Type: Integer, Original Network ID
		###
		self.mOnid= amOnid

		### 
		# Type: Integer, EPG Evnet ID
		###
		self.mEventId= amEventId

	def parseReturnBuffer(self, ret ,offset=0):
		self.mSid= int(ret[offset])
		offset=offset+1
		self.mTsid= int(ret[offset])
		offset=offset+1
		self.mOnid= int(ret[offset])
		offset=offset+1
		self.mEventId= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventCurrentEITReceived'
		print 'mSid= %d'%self.mSid
		print 'mTsid= %d'%self.mTsid
		print 'mOnid= %d'%self.mOnid
		print 'mEventId= %d'%self.mEventId

class ElisEventChannelChangeStatus( ElisEvent ):
	def __init__(self, amStatus = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Channel Change Status :E_CC_SUCCESS, E_CC_FAILED_NO_SIGNAL, E_CC_FAILED_SCRAMBLED_CHANNEL
		###
		self.mStatus= amStatus

	def parseReturnBuffer(self, ret ,offset=0):
		self.mStatus= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventChannelChangeStatus'
		print 'mStatus= %d'%self.mStatus

class ElisEventRecordingStarted( ElisEvent ):
	def __init__(self, amTimerId = 1 ,amRecordKey = 1 ,amName = "NoName" ,amChannelNo = 1 ,amServiceType = 1 ,amStartTime = 1 ,amDuration = 1):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Timer ID
		###
		self.mTimerId= amTimerId

		### 
		# Type: Integer, Record Key
		###
		self.mRecordKey= amRecordKey

		### 
		# Type: String, Recording Name
		###
		self.mName= amName

		### 
		# Type: Integer, Channel Number
		###
		self.mChannelNo= amChannelNo

		### 
		# Type: Integer, Service Type
		###
		self.mServiceType= amServiceType

		### 
		# Type: Integer, Start Time
		###
		self.mStartTime= amStartTime

		### 
		# Type: Integer, Duration
		###
		self.mDuration= amDuration

	def parseReturnBuffer(self, ret ,offset=0):
		self.mTimerId= int(ret[offset])
		offset=offset+1
		self.mRecordKey= int(ret[offset])
		offset=offset+1
		self.mName= ret[offset]
		offset=offset+1
		self.mChannelNo= int(ret[offset])
		offset=offset+1
		self.mServiceType= int(ret[offset])
		offset=offset+1
		self.mStartTime= int(ret[offset])
		offset=offset+1
		self.mDuration= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventRecordingStarted'
		print 'mTimerId= %d'%self.mTimerId
		print 'mRecordKey= %d'%self.mRecordKey
		print 'mName= %s'%self.mName
		print 'mChannelNo= %d'%self.mChannelNo
		print 'mServiceType= %d'%self.mServiceType
		print 'mStartTime= %d'%self.mStartTime
		print 'mDuration= %d'%self.mDuration

class ElisEventRecordingStopped( ElisEvent ):
	def __init__(self, amTimerId = 1 ,amRecordKey = 1 ,amName = "NoName" ,amChannelNo = 1 ,amServiceType = 1 ,amStartTime = 1 ,amDuration = 1 ,amHDDFull = 1):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Timer ID
		###
		self.mTimerId= amTimerId

		### 
		# Type: Integer, Record Key
		###
		self.mRecordKey= amRecordKey

		### 
		# Type: String, Recording Name
		###
		self.mName= amName

		### 
		# Type: Integer, Channel Number
		###
		self.mChannelNo= amChannelNo

		### 
		# Type: Integer, Service Type
		###
		self.mServiceType= amServiceType

		### 
		# Type: Integer, Start Time
		###
		self.mStartTime= amStartTime

		### 
		# Type: Integer, Duration
		###
		self.mDuration= amDuration

		### 
		# Type: Bool, Is Hdd Full
		###
		self.mHDDFull= amHDDFull

	def parseReturnBuffer(self, ret ,offset=0):
		self.mTimerId= int(ret[offset])
		offset=offset+1
		self.mRecordKey= int(ret[offset])
		offset=offset+1
		self.mName= ret[offset]
		offset=offset+1
		self.mChannelNo= int(ret[offset])
		offset=offset+1
		self.mServiceType= int(ret[offset])
		offset=offset+1
		self.mStartTime= int(ret[offset])
		offset=offset+1
		self.mDuration= int(ret[offset])
		offset=offset+1
		self.mHDDFull= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventRecordingStopped'
		print 'mTimerId= %d'%self.mTimerId
		print 'mRecordKey= %d'%self.mRecordKey
		print 'mName= %s'%self.mName
		print 'mChannelNo= %d'%self.mChannelNo
		print 'mServiceType= %d'%self.mServiceType
		print 'mStartTime= %d'%self.mStartTime
		print 'mDuration= %d'%self.mDuration
		print 'mHDDFull= %d'%self.mHDDFull

class ElisEventChannelChangedByRecord( ElisEvent ):
	def __init__(self, amChannelNo = 1 ,amServiceType = ElisEnum.E_SERVICE_TYPE_INVALID):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Channel Number
		###
		self.mChannelNo= amChannelNo

		### 
		# Type: Integer, Service Type : 
		###
		self.mServiceType= amServiceType

	def parseReturnBuffer(self, ret ,offset=0):
		self.mChannelNo= int(ret[offset])
		offset=offset+1
		self.mServiceType= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventChannelChangedByRecord'
		print 'mChannelNo= %d'%self.mChannelNo
		print 'mServiceType= %d'%self.mServiceType

class ElisEventPlaybackStarted( ElisEvent ):
	def __init__(self, amKey = 1):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Record Key
		###
		self.mKey= amKey

	def parseReturnBuffer(self, ret ,offset=0):
		self.mKey= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventPlaybackStarted'
		print 'mKey= %d'%self.mKey

class ElisEventPlaybackStopped( ElisEvent ):
	def __init__(self, amKey = 1):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Record Key
		###
		self.mKey= amKey

	def parseReturnBuffer(self, ret ,offset=0):
		self.mKey= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventPlaybackStopped'
		print 'mKey= %d'%self.mKey

class ElisEventTimeshiftEITReceived( ElisEvent ):
	def __init__(self, amSid = 0 ,amTsid = 0 ,amOnid = 0 ,amEventId = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Service ID
		###
		self.mSid= amSid

		### 
		# Type: Integer, Transport Stream ID
		###
		self.mTsid= amTsid

		### 
		# Type: Integer, Original Network ID
		###
		self.mOnid= amOnid

		### 
		# Type: Integer, EPG Evnet ID
		###
		self.mEventId= amEventId

	def parseReturnBuffer(self, ret ,offset=0):
		self.mSid= int(ret[offset])
		offset=offset+1
		self.mTsid= int(ret[offset])
		offset=offset+1
		self.mOnid= int(ret[offset])
		offset=offset+1
		self.mEventId= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventTimeshiftEITReceived'
		print 'mSid= %d'%self.mSid
		print 'mTsid= %d'%self.mTsid
		print 'mOnid= %d'%self.mOnid
		print 'mEventId= %d'%self.mEventId

class ElisEventCAMInsertRemove( ElisEvent ):
	def __init__(self, amSlotNo = 0 ,amInserted = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Slot Number
		###
		self.mSlotNo= amSlotNo

		### 
		# Type: Integer, Is Inserted
		###
		self.mInserted= amInserted

	def parseReturnBuffer(self, ret ,offset=0):
		self.mSlotNo= int(ret[offset])
		offset=offset+1
		self.mInserted= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventCAMInsertRemove'
		print 'mSlotNo= %d'%self.mSlotNo
		print 'mInserted= %d'%self.mInserted

class ElisEventChannelChangeStarted( ElisEvent ):
	def __init__(self, amChannelNo = 1 ,amServiceType = ElisEnum.E_SERVICE_TYPE_INVALID):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Channel Number
		###
		self.mChannelNo= amChannelNo

		### 
		# Type: Integer, Service Type
		###
		self.mServiceType= amServiceType

	def parseReturnBuffer(self, ret ,offset=0):
		self.mChannelNo= int(ret[offset])
		offset=offset+1
		self.mServiceType= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventChannelChangeStarted'
		print 'mChannelNo= %d'%self.mChannelNo
		print 'mServiceType= %d'%self.mServiceType

class ElisEventCIMMIClosed( ElisEvent ):
	def __init__(self, amSlotNo = 0 ,amSsnb = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Slot Number
		###
		self.mSlotNo= amSlotNo

		### 
		# Type: Integer, Is Ssnb
		###
		self.mSsnb= amSsnb

	def parseReturnBuffer(self, ret ,offset=0):
		self.mSlotNo= int(ret[offset])
		offset=offset+1
		self.mSsnb= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventCIMMIClosed'
		print 'mSlotNo= %d'%self.mSlotNo
		print 'mSsnb= %d'%self.mSsnb

class ElisEventCIMMIShowEnq( ElisEvent ):
	def __init__(self, amSlotNo = 0 ,amEnqData = None):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Slot Number
		###
		self.mSlotNo= amSlotNo

		### 
		# Type: ElisCIMMIEnqData, Enq Data
		# @see ElisCIMMIEnqData
		###
		self.mEnqData= amEnqData

	def parseReturnBuffer(self, ret ,offset=0):
		self.mSlotNo= int(ret[offset])
		offset=offset+1
		self.mEnqData= ElisCIMMIEnqData()
		offset = self.mEnqData.parseReturnBuffer( ret, offset )

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventCIMMIShowEnq'
		print 'mSlotNo= %d'%self.mSlotNo
		print 'mEnqData=' 
		self.mEnqData.printdebug()

class ElisEventCIMMIShowMenu( ElisEvent ):

	def parseReturnBuffer(self, ret ,offset=0):

		ElisEventCustom.parseElisEventCIMMIShowMenu(self, ret, offset )

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventCIMMIShowMenu'

		ElisEventCustom.debugprintElisEventCIMMIShowMenu(self )

class ElisEventCopyProgress( ElisEvent ):
	def __init__(self, amKey = 0 ,amProgress = 0 ,amFinished = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Key
		###
		self.mKey= amKey

		### 
		# Type: Integer, Progress
		###
		self.mProgress= amProgress

		### 
		# Type: Bool, Finished
		###
		self.mFinished= amFinished

	def parseReturnBuffer(self, ret ,offset=0):
		self.mKey= int(ret[offset])
		offset=offset+1
		self.mProgress= int(ret[offset])
		offset=offset+1
		self.mFinished= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventCopyProgress'
		print 'mKey= %d'%self.mKey
		print 'mProgress= %d'%self.mProgress
		print 'mFinished= %d'%self.mFinished

class ElisEventDedicatedMakeStatus( ElisEvent ):
	def __init__(self, amStatus = ElisEnum.E_STATUS_INVALID):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Status
		###
		self.mStatus= amStatus

	def parseReturnBuffer(self, ret ,offset=0):
		self.mStatus= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventDedicatedMakeStatus'
		print 'mStatus= %d'%self.mStatus

class ElisEventHDDForDedicatedFound( ElisEvent ):
	def __init__(self, amHDDSizeMB = 1):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Hdd Size
		###
		self.mHDDSizeMB= amHDDSizeMB

	def parseReturnBuffer(self, ret ,offset=0):
		self.mHDDSizeMB= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventHDDForDedicatedFound'
		print 'mHDDSizeMB= %d'%self.mHDDSizeMB

class ElisEventHDDFormatStatus( ElisEvent ):
	def __init__(self, amStatus = ElisEnum.E_STATUS_FORMATTING ,amProgress = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Hdd Format Status
		###
		self.mStatus= amStatus

		### 
		# Type: Integer, Hdd Size
		###
		self.mProgress= amProgress

	def parseReturnBuffer(self, ret ,offset=0):
		self.mStatus= int(ret[offset])
		offset=offset+1
		self.mProgress= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventHDDFormatStatus'
		print 'mStatus= %d'%self.mStatus
		print 'mProgress= %d'%self.mProgress

class ElisEventMediaPlayerBufferUnderflow( ElisEvent ):
	def __init__(self, amBufferUnderflowed = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Bool, Buffer Underflowed
		###
		self.mBufferUnderflowed= amBufferUnderflowed

	def parseReturnBuffer(self, ret ,offset=0):
		self.mBufferUnderflowed= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventMediaPlayerBufferUnderflow'
		print 'mBufferUnderflowed= %d'%self.mBufferUnderflowed

class ElisEventOldRecordDeleted( ElisEvent ):
	def __init__(self, amRecordKey = 1 ,amRecordName = "NoName" ,amChannelNumber = 1 ,amChannelName = "NoName"):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Record Key
		###
		self.mRecordKey= amRecordKey

		### 
		# Type: String, Recording Name
		###
		self.mRecordName= amRecordName

		### 
		# Type: Integer, Channel Number
		###
		self.mChannelNumber= amChannelNumber

		### 
		# Type: String, Channel Name
		###
		self.mChannelName= amChannelName

	def parseReturnBuffer(self, ret ,offset=0):
		self.mRecordKey= int(ret[offset])
		offset=offset+1
		self.mRecordName= ret[offset]
		offset=offset+1
		self.mChannelNumber= int(ret[offset])
		offset=offset+1
		self.mChannelName= ret[offset]
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventOldRecordDeleted'
		print 'mRecordKey= %d'%self.mRecordKey
		print 'mRecordName= %s'%self.mRecordName
		print 'mChannelNumber= %d'%self.mChannelNumber
		print 'mChannelName= %s'%self.mChannelName

class ElisEventOTIDownloadStatus( ElisEvent ):
	def __init__(self, amProgress = 0 ,amStatus = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, OTI Download Progress
		###
		self.mProgress= amProgress

		### 
		# Type: Integer, OTI Download Status
		###
		self.mStatus= amStatus

	def parseReturnBuffer(self, ret ,offset=0):
		self.mProgress= int(ret[offset])
		offset=offset+1
		self.mStatus= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventOTIDownloadStatus'
		print 'mProgress= %d'%self.mProgress
		print 'mStatus= %d'%self.mStatus

class ElisEventPlaybackEOF( ElisEvent ):
	def __init__(self, amType = ElisEnum.E_EOF_START):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Playback EOF Type
		###
		self.mType= amType

	def parseReturnBuffer(self, ret ,offset=0):
		self.mType= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventPlaybackEOF'
		print 'mType= %d'%self.mType

class ElisEventShutdown( ElisEvent ):
	def __init__(self, amType = ElisEnum.E_NORMAL_STANDBY):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Shutdown Type
		###
		self.mType= amType

	def parseReturnBuffer(self, ret ,offset=0):
		self.mType= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventShutdown'
		print 'mType= %d'%self.mType

class ElisEventTemperature( ElisEvent ):
	def __init__(self, amTemperature = 0 ,amCount = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Temperature
		###
		self.mTemperature= amTemperature

		### 
		# Type: Integer, Count
		###
		self.mCount= amCount

	def parseReturnBuffer(self, ret ,offset=0):
		self.mTemperature= int(ret[offset])
		offset=offset+1
		self.mCount= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventTemperature'
		print 'mTemperature= %d'%self.mTemperature
		print 'mCount= %d'%self.mCount

class ElisEventTuningStatus( ElisEvent ):
	def __init__(self, amTunerNo = 1 ,amIsLocked = 0 ,amSignalQuality = 0 ,amSignalStrength = 0 ,amFrequency = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Tuner Number
		###
		self.mTunerNo= amTunerNo

		### 
		# Type: Bool, Is Locked
		###
		self.mIsLocked= amIsLocked

		### 
		# Type: Integer, Signal Quality
		###
		self.mSignalQuality= amSignalQuality

		### 
		# Type: Integer, Signal Strength
		###
		self.mSignalStrength= amSignalStrength

		### 
		# Type: Integer, Frequency
		###
		self.mFrequency= amFrequency

	def parseReturnBuffer(self, ret ,offset=0):
		self.mTunerNo= int(ret[offset])
		offset=offset+1
		self.mIsLocked= int(ret[offset])
		offset=offset+1
		self.mSignalQuality= int(ret[offset])
		offset=offset+1
		self.mSignalStrength= int(ret[offset])
		offset=offset+1
		self.mFrequency= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventTuningStatus'
		print 'mTunerNo= %d'%self.mTunerNo
		print 'mIsLocked= %d'%self.mIsLocked
		print 'mSignalQuality= %d'%self.mSignalQuality
		print 'mSignalStrength= %d'%self.mSignalStrength
		print 'mFrequency= %d'%self.mFrequency

class ElisEventUpdateProgress( ElisEvent ):
	def __init__(self, amPercentage = 1 ,amStatus = ElisEnum.E_UPDATE_READY ,amTotal = 0 ,amIndex = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Update Percentage
		###
		self.mPercentage= amPercentage

		### 
		# Type: Integer, Update Status
		###
		self.mStatus= amStatus

		### 
		# Type: Integer, Total
		###
		self.mTotal= amTotal

		### 
		# Type: Integer, Index
		###
		self.mIndex= amIndex

	def parseReturnBuffer(self, ret ,offset=0):
		self.mPercentage= int(ret[offset])
		offset=offset+1
		self.mStatus= int(ret[offset])
		offset=offset+1
		self.mTotal= int(ret[offset])
		offset=offset+1
		self.mIndex= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventUpdateProgress'
		print 'mPercentage= %d'%self.mPercentage
		print 'mStatus= %d'%self.mStatus
		print 'mTotal= %d'%self.mTotal
		print 'mIndex= %d'%self.mIndex

class ElisEventUSBCopyMediaProgress( ElisEvent ):
	def __init__(self, amFileCount = 0 ,amCurrentIndex = 0 ,amProgress = 0 ,amCurrentCopiedFile = "NoFile" ,amAllFinished = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, File Count
		###
		self.mFileCount= amFileCount

		### 
		# Type: Bool, Currnet index
		###
		self.mCurrentIndex= amCurrentIndex

		### 
		# Type: Integer, Copy Progress
		###
		self.mProgress= amProgress

		### 
		# Type: String, Current Copied File
		###
		self.mCurrentCopiedFile= amCurrentCopiedFile

		### 
		# Type: Bool, All Finished
		###
		self.mAllFinished= amAllFinished

	def parseReturnBuffer(self, ret ,offset=0):
		self.mFileCount= int(ret[offset])
		offset=offset+1
		self.mCurrentIndex= int(ret[offset])
		offset=offset+1
		self.mProgress= int(ret[offset])
		offset=offset+1
		self.mCurrentCopiedFile= ret[offset]
		offset=offset+1
		self.mAllFinished= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventUSBCopyMediaProgress'
		print 'mFileCount= %d'%self.mFileCount
		print 'mCurrentIndex= %d'%self.mCurrentIndex
		print 'mProgress= %d'%self.mProgress
		print 'mCurrentCopiedFile= %s'%self.mCurrentCopiedFile
		print 'mAllFinished= %d'%self.mAllFinished

class ElisEventUSBCopyRecordProgress( ElisEvent ):
	def __init__(self, amProgress = 0 ,amCurrentRecordKey = 0 ,amCurrentIndex = 0 ,amCopyRecordCount = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Copy Progress
		###
		self.mProgress= amProgress

		### 
		# Type: Integer, Current Record Key
		###
		self.mCurrentRecordKey= amCurrentRecordKey

		### 
		# Type: Bool, Currnet index
		###
		self.mCurrentIndex= amCurrentIndex

		### 
		# Type: Bool, Copy Record Count
		###
		self.mCopyRecordCount= amCopyRecordCount

	def parseReturnBuffer(self, ret ,offset=0):
		self.mProgress= int(ret[offset])
		offset=offset+1
		self.mCurrentRecordKey= int(ret[offset])
		offset=offset+1
		self.mCurrentIndex= int(ret[offset])
		offset=offset+1
		self.mCopyRecordCount= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventUSBCopyRecordProgress'
		print 'mProgress= %d'%self.mProgress
		print 'mCurrentRecordKey= %d'%self.mCurrentRecordKey
		print 'mCurrentIndex= %d'%self.mCurrentIndex
		print 'mCopyRecordCount= %d'%self.mCopyRecordCount

class ElisEventPowerSave( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventPowerSave'

class ElisEventTimeReceived( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventTimeReceived'

class ElisEventChannelScanFinish( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventChannelScanFinish'

class ElisEventChannelDBUpdate( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventChannelDBUpdate'

class ElisEventZappingChannelDBUpdate( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventZappingChannelDBUpdate'

class ElisEventEPGDBUpdate( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventEPGDBUpdate'

class ElisEventPropertyDBUpdate( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventPropertyDBUpdate'

class ElisEventRecordInfoDBUpdate( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventRecordInfoDBUpdate'

class ElisEventExternalMediaPlayerStart( ElisEvent ):
	def __init__(self, amUrl = "No Url" ,amSpeed = 0 ,amStartPosition = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: String, Url
		###
		self.mUrl= amUrl

		### 
		# Type: Integer, Speed : 100 (normal)
		###
		self.mSpeed= amSpeed

		### 
		# Type: Integer, Start Position : Position in ms
		###
		self.mStartPosition= amStartPosition

	def parseReturnBuffer(self, ret ,offset=0):
		self.mUrl= ret[offset]
		offset=offset+1
		self.mSpeed= int(ret[offset])
		offset=offset+1
		self.mStartPosition= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventExternalMediaPlayerStart'
		print 'mUrl= %s'%self.mUrl
		print 'mSpeed= %d'%self.mSpeed
		print 'mStartPosition= %d'%self.mStartPosition

class ElisEventExternalMediaPlayerSetSpeed( ElisEvent ):
	def __init__(self, amSpeed = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Speed : 100 (normal)
		###
		self.mSpeed= amSpeed

	def parseReturnBuffer(self, ret ,offset=0):
		self.mSpeed= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventExternalMediaPlayerSetSpeed'
		print 'mSpeed= %d'%self.mSpeed

class ElisEventExternalMediaPlayerSeekStream( ElisEvent ):
	def __init__(self, amSeekPosition = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Seek Position : Position in ms
		###
		self.mSeekPosition= amSeekPosition

	def parseReturnBuffer(self, ret ,offset=0):
		self.mSeekPosition= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventExternalMediaPlayerSeekStream'
		print 'mSeekPosition= %d'%self.mSeekPosition

class ElisEventExternalMediaPlayerStopPlay( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventExternalMediaPlayerStopPlay'

class ElisEventMediaPlayerSetVideoSize( ElisEvent ):
	def __init__(self, amPosX = 0 ,amPosY = 0 ,amWidth = 0 ,amHeight = 0):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

		### 
		# Type: Integer, Position X
		###
		self.mPosX= amPosX

		### 
		# Type: Integer, Position Y
		###
		self.mPosY= amPosY

		### 
		# Type: Integer, Width
		###
		self.mWidth= amWidth

		### 
		# Type: Integer, Height
		###
		self.mHeight= amHeight

	def parseReturnBuffer(self, ret ,offset=0):
		self.mPosX= int(ret[offset])
		offset=offset+1
		self.mPosY= int(ret[offset])
		offset=offset+1
		self.mWidth= int(ret[offset])
		offset=offset+1
		self.mHeight= int(ret[offset])
		offset=offset+1

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventMediaPlayerSetVideoSize'
		print 'mPosX= %d'%self.mPosX
		print 'mPosY= %d'%self.mPosY
		print 'mWidth= %d'%self.mWidth
		print 'mHeight= %d'%self.mHeight

class ElisEventPowerSaveEnd( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventPowerSaveEnd'

class ElisEventUSBNotifyAttach( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventUSBNotifyAttach'

class ElisEventUSBNotifyDetach( ElisEvent ):
	def __init__(self, ):
		"""
			Constructor
		@param self : self
		@return NULL
		"""

	def parseReturnBuffer(self, ret ,offset=0):

		return offset
	def printdebug( self ):
		"""
			Print Debug.
		"""
		print 'Class  ElisEventUSBNotifyDetach'

