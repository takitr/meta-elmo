
from ElisEnum import ElisEnum
from ElisClassCustom import ElisClassCustom
from ElisClassSub import *

"""
# ElisInterface Classes for Python UI\n
# ElisCommand Interface Classes\n
# @package ElisCommander\n
# This Class describes all structure of Python UI.\n
# All functions of this class have it's equavalent functions in M/W on C++\n
# @author doliyu@marusys.com, jhshin@marusys.com\n
# @date	02.12.2011\n
# @file elisclass.py\n
"""

class ElisClass(object):
		mError  = 0


class ElisIDVBSCarrier( ElisClass ): 
		""" 
		ElisIDVBSCarrier DVBS Carrier Information\n
		\brief DVBS Carrier Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mSatelliteLongitude	Longitude : Satellite Longitude
		Integer	mSatelliteBand	Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
		Integer	mFrequency	Current Chanenl Frequency [MHz] 
		Integer	mSymbolRate	Current Channel SymbolRate [ KHz ]
		Integer	mFECValue	Current Channel FEC Mode : 
		Integer	mPolarization	Current Channel Polarization : E_LNB_HORIZONTAL, E_LNB_VERTICAL, E_LNB_LEFT, E_LNB_RIGHT

		"""

		def __init__(self, amSatelliteLongitude = 0 ,amSatelliteBand = ElisEnum.E_BAND_UNDEFINED ,amFrequency = 1553 ,amSymbolRate = 22000 ,amFECValue = ElisEnum.E_DVBS_3_4 ,amPolarization = ElisEnum.E_LNB_HORIZONTAL):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Longitude : Satellite Longitude
			###
			self.mSatelliteLongitude= amSatelliteLongitude

			### 
			# Type: Integer, Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			###
			self.mSatelliteBand= amSatelliteBand

			### 
			# Type: Integer, Current Chanenl Frequency [MHz] 
			###
			self.mFrequency= amFrequency

			### 
			# Type: Integer, Current Channel SymbolRate [ KHz ]
			###
			self.mSymbolRate= amSymbolRate

			### 
			# Type: Integer, Current Channel FEC Mode : 
			###
			self.mFECValue= amFECValue

			### 
			# Type: Integer, Current Channel Polarization : E_LNB_HORIZONTAL, E_LNB_VERTICAL, E_LNB_LEFT, E_LNB_RIGHT
			###
			self.mPolarization= amPolarization

		def reset(self):
			"""
				Reset to default value
			"""
			self.mSatelliteLongitude= 0
			self.mSatelliteBand= ElisEnum.E_BAND_UNDEFINED
			self.mFrequency= 1553
			self.mSymbolRate= 22000
			self.mFECValue= ElisEnum.E_DVBS_3_4
			self.mPolarization= ElisEnum.E_LNB_HORIZONTAL

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mSatelliteLongitude)
			req.append('%d' %self.mSatelliteBand)
			req.append('%d' %self.mFrequency)
			req.append('%d' %self.mSymbolRate)
			req.append('%d' %self.mFECValue)
			req.append('%d' %self.mPolarization)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mSatelliteLongitude= int(ret[offset])
			offset=offset+1
			self.mSatelliteBand= int(ret[offset])
			offset=offset+1
			self.mFrequency= int(ret[offset])
			offset=offset+1
			self.mSymbolRate= int(ret[offset])
			offset=offset+1
			self.mFECValue= int(ret[offset])
			offset=offset+1
			self.mPolarization= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IDVBSCarrier'
			print 'mSatelliteLongitude= %d'%self.mSatelliteLongitude
			print 'mSatelliteBand= %d'%self.mSatelliteBand
			print 'mFrequency= %d'%self.mFrequency
			print 'mSymbolRate= %d'%self.mSymbolRate
			print 'mFECValue= %d'%self.mFECValue
			print 'mPolarization= %d'%self.mPolarization

class ElisIDVBTCarrier( ElisClass ): 
		""" 
		ElisIDVBTCarrier DVBT Carrier Information\n
		\brief DVBT Carrier Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mFrequency	Current Chanenl Frequency [MHz] 
		Integer	mBand	Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C

		"""

		def __init__(self, amFrequency = 1553 ,amBand = ElisEnum.E_BAND_UNDEFINED):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Current Chanenl Frequency [MHz] 
			###
			self.mFrequency= amFrequency

			### 
			# Type: Integer, Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			###
			self.mBand= amBand

		def reset(self):
			"""
				Reset to default value
			"""
			self.mFrequency= 1553
			self.mBand= ElisEnum.E_BAND_UNDEFINED

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mFrequency)
			req.append('%d' %self.mBand)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mFrequency= int(ret[offset])
			offset=offset+1
			self.mBand= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IDVBTCarrier'
			print 'mFrequency= %d'%self.mFrequency
			print 'mBand= %d'%self.mBand

class ElisIDVBCCarrier( ElisClass ): 
		""" 
		ElisIDVBCCarrier DVBC Carrier Information\n
		\brief DVBC Carrier Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mFrequency	Current Chanenl Frequency [MHz] 
		Integer	mSymbolRate	Current Channel SymbolRate [ KHz ]
		Integer	mQAM	QAM: 64, 128,256

		"""

		def __init__(self, amFrequency = 1553 ,amSymbolRate = 22000 ,amQAM = 64):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Current Chanenl Frequency [MHz] 
			###
			self.mFrequency= amFrequency

			### 
			# Type: Integer, Current Channel SymbolRate [ KHz ]
			###
			self.mSymbolRate= amSymbolRate

			### 
			# Type: Integer, QAM: 64, 128,256
			###
			self.mQAM= amQAM

		def reset(self):
			"""
				Reset to default value
			"""
			self.mFrequency= 1553
			self.mSymbolRate= 22000
			self.mQAM= 64

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mFrequency)
			req.append('%d' %self.mSymbolRate)
			req.append('%d' %self.mQAM)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mFrequency= int(ret[offset])
			offset=offset+1
			self.mSymbolRate= int(ret[offset])
			offset=offset+1
			self.mQAM= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IDVBCCarrier'
			print 'mFrequency= %d'%self.mFrequency
			print 'mSymbolRate= %d'%self.mSymbolRate
			print 'mQAM= %d'%self.mQAM

class ElisICarrier( ElisClass ): 
		""" 
		ElisICarrier Carrier Information\n
		\brief Carrier Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mCarrierType	Carrier Type
		ElisIDVBCCarrier	mDVBC	DVBC carrier 
		ElisIDVBTCarrier	mDVBT	DVBT Carrier
		ElisIDVBSCarrier	mDVBS	DVBS Carrier

		"""

		def __init__(self, amCarrierType = 0 ,amDVBC = None ,amDVBT = None ,amDVBS = None):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Carrier Type
			###
			self.mCarrierType= amCarrierType

			### 
			# Type: ElisIDVBCCarrier, DVBC carrier 
			# @see ElisIDVBCCarrier
			###
			if amDVBC == None:
				self.mDVBC= ElisIDVBCCarrier()
			else:
				self.mDVBC= amDVBC

			### 
			# Type: ElisIDVBTCarrier, DVBT Carrier
			# @see ElisIDVBTCarrier
			###
			if amDVBT == None:
				self.mDVBT= ElisIDVBTCarrier()
			else:
				self.mDVBT= amDVBT

			### 
			# Type: ElisIDVBSCarrier, DVBS Carrier
			# @see ElisIDVBSCarrier
			###
			if amDVBS == None:
				self.mDVBS= ElisIDVBSCarrier()
			else:
				self.mDVBS= amDVBS

		def reset(self):
			"""
				Reset to default value
			"""
			self.mCarrierType= 0
			self.mDVBC= ElisIDVBCCarrier()
			self.mDVBT= ElisIDVBTCarrier()
			self.mDVBS= ElisIDVBSCarrier()

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mCarrierType)
			self.mDVBC.appendReqBuffer( req )
			self.mDVBT.appendReqBuffer( req )
			self.mDVBS.appendReqBuffer( req )

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mCarrierType= int(ret[offset])
			offset=offset+1
			self.mDVBC= ElisIDVBCCarrier()
			offset = self.mDVBC.parseReturnBuffer( ret, offset )
			self.mDVBT= ElisIDVBTCarrier()
			offset = self.mDVBT.parseReturnBuffer( ret, offset )
			self.mDVBS= ElisIDVBSCarrier()
			offset = self.mDVBS.parseReturnBuffer( ret, offset )

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ICarrier'
			print 'mCarrierType= %d'%self.mCarrierType
			print 'mDVBC=' 
			self.mDVBC.printdebug()
			print 'mDVBT=' 
			self.mDVBT.printdebug()
			print 'mDVBS=' 
			self.mDVBS.printdebug()

class ElisIChannel( ElisClass ): 
		""" 
		ElisIChannel Channel Information\n
		\brief Channel Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mNumber	Channel Number
		Integer	mPresentationNumber	Channel presentation number
		String	mName	Channel Name
		Integer	mServiceType	Service Type
		Integer	mLocked	Lock Status : LOCKED or UNLOCKED
		Integer	mIsCA	CAS Status : CA or notCA
		Integer	mIsHD	HD status
		Integer	mNid	Network ID
		Integer	mSid	Service ID
		Integer	mTsid	Transport Stream ID
		Integer	mOnid	Original Network ID
		Integer	mCarrierType	Carrier Type : DVBS, DVBT, DVBC
		Integer	mSkipped	Channel Skip Status : Skip or Not Skip
		Integer	mIsBlank	mIsBlank
		ElisICarrier	mCarrier	Carrier Information

		"""

		def __init__(self, amNumber = 1 ,amPresentationNumber = 1 ,amName = "No Channel" ,amServiceType = ElisEnum.E_SERVICE_TYPE_INVALID ,amLocked = 0 ,amIsCA = 0 ,amIsHD = 0 ,amNid = 0 ,amSid = 0 ,amTsid = 0 ,amOnid = 0 ,amCarrierType = 0 ,amSkipped = 0 ,amIsBlank = 0 ,amCarrier = None):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Channel Number
			###
			self.mNumber= amNumber

			### 
			# Type: Integer, Channel presentation number
			###
			self.mPresentationNumber= amPresentationNumber

			### 
			# Type: String, Channel Name
			###
			self.mName= amName

			### 
			# Type: Integer, Service Type
			###
			self.mServiceType= amServiceType

			### 
			# Type: Integer, Lock Status : LOCKED or UNLOCKED
			###
			self.mLocked= amLocked

			### 
			# Type: Integer, CAS Status : CA or notCA
			###
			self.mIsCA= amIsCA

			### 
			# Type: Integer, HD status
			###
			self.mIsHD= amIsHD

			### 
			# Type: Integer, Network ID
			###
			self.mNid= amNid

			### 
			# Type: Integer, Service ID
			###
			self.mSid= amSid

			### 
			# Type: Integer, Transport Stream ID
			###
			self.mTsid= amTsid

			### 
			# Type: Integer, Original Network ID
			###
			self.mOnid= amOnid

			### 
			# Type: Integer, Carrier Type : DVBS, DVBT, DVBC
			###
			self.mCarrierType= amCarrierType

			### 
			# Type: Integer, Channel Skip Status : Skip or Not Skip
			###
			self.mSkipped= amSkipped

			### 
			# Type: Integer, mIsBlank
			###
			self.mIsBlank= amIsBlank

			### 
			# Type: ElisICarrier, Carrier Information
			# @see ElisICarrier
			###
			if amCarrier == None:
				self.mCarrier= ElisICarrier()
			else:
				self.mCarrier= amCarrier

		def reset(self):
			"""
				Reset to default value
			"""
			self.mNumber= 1
			self.mPresentationNumber= 1
			self.mName= "No Channel"
			self.mServiceType= ElisEnum.E_SERVICE_TYPE_INVALID
			self.mLocked= 0
			self.mIsCA= 0
			self.mIsHD= 0
			self.mNid= 0
			self.mSid= 0
			self.mTsid= 0
			self.mOnid= 0
			self.mCarrierType= 0
			self.mSkipped= 0
			self.mIsBlank= 0
			self.mCarrier= ElisICarrier()

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mNumber)
			req.append('%d' %self.mPresentationNumber)
			req.append(self.mName)
			req.append('%d' %self.mServiceType)
			req.append('%d' %self.mLocked)
			req.append('%d' %self.mIsCA)
			req.append('%d' %self.mIsHD)
			req.append('%d' %self.mNid)
			req.append('%d' %self.mSid)
			req.append('%d' %self.mTsid)
			req.append('%d' %self.mOnid)
			req.append('%d' %self.mCarrierType)
			req.append('%d' %self.mSkipped)
			req.append('%d' %self.mIsBlank)
			self.mCarrier.appendReqBuffer( req )

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mNumber= int(ret[offset])
			offset=offset+1
			self.mPresentationNumber= int(ret[offset])
			offset=offset+1
			self.mName= ret[offset]
			offset=offset+1
			self.mServiceType= int(ret[offset])
			offset=offset+1
			self.mLocked= int(ret[offset])
			offset=offset+1
			self.mIsCA= int(ret[offset])
			offset=offset+1
			self.mIsHD= int(ret[offset])
			offset=offset+1
			self.mNid= int(ret[offset])
			offset=offset+1
			self.mSid= int(ret[offset])
			offset=offset+1
			self.mTsid= int(ret[offset])
			offset=offset+1
			self.mOnid= int(ret[offset])
			offset=offset+1
			self.mCarrierType= int(ret[offset])
			offset=offset+1
			self.mSkipped= int(ret[offset])
			offset=offset+1
			self.mIsBlank= int(ret[offset])
			offset=offset+1
			self.mCarrier= ElisICarrier()
			offset = self.mCarrier.parseReturnBuffer( ret, offset )

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IChannel'
			print 'mNumber= %d'%self.mNumber
			print 'mPresentationNumber= %d'%self.mPresentationNumber
			print 'mName= %s'%self.mName
			print 'mServiceType= %d'%self.mServiceType
			print 'mLocked= %d'%self.mLocked
			print 'mIsCA= %d'%self.mIsCA
			print 'mIsHD= %d'%self.mIsHD
			print 'mNid= %d'%self.mNid
			print 'mSid= %d'%self.mSid
			print 'mTsid= %d'%self.mTsid
			print 'mOnid= %d'%self.mOnid
			print 'mCarrierType= %d'%self.mCarrierType
			print 'mSkipped= %d'%self.mSkipped
			print 'mIsBlank= %d'%self.mIsBlank
			print 'mCarrier=' 
			self.mCarrier.printdebug()

class ElisIFavoriteGroup( ElisClass ): 
		""" 
		ElisIFavoriteGroup Favoirte Group Information\n
		\brief Favoirte Group Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		String	mGroupName	Favorite Group Name
		Integer	mServiceType	Service Type
		Integer	mFavoriteChannelCount	Total Count for Favorite

		"""

		def __init__(self, amGroupName = "No Name" ,amServiceType = ElisEnum.E_SERVICE_TYPE_INVALID ,amFavoriteChannelCount = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: String, Favorite Group Name
			###
			self.mGroupName= amGroupName

			### 
			# Type: Integer, Service Type
			###
			self.mServiceType= amServiceType

			### 
			# Type: Integer, Total Count for Favorite
			###
			self.mFavoriteChannelCount= amFavoriteChannelCount

		def reset(self):
			"""
				Reset to default value
			"""
			self.mGroupName= "No Name"
			self.mServiceType= ElisEnum.E_SERVICE_TYPE_INVALID
			self.mFavoriteChannelCount= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append(self.mGroupName)
			req.append('%d' %self.mServiceType)
			req.append('%d' %self.mFavoriteChannelCount)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mGroupName= ret[offset]
			offset=offset+1
			self.mServiceType= int(ret[offset])
			offset=offset+1
			self.mFavoriteChannelCount= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IFavoriteGroup'
			print 'mGroupName= %s'%self.mGroupName
			print 'mServiceType= %d'%self.mServiceType
			print 'mFavoriteChannelCount= %d'%self.mFavoriteChannelCount

class ElisIChannelCASInfo( ElisClass ): 
		""" 
		ElisIChannelCASInfo CAS Information\n
		\brief CAS Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		String	mName	CAS Name
		Integer	mChannelCount	
		Integer	mCAId	CAId : E_FTA_CHANNEL, E_MEDIAGUARD, E_VIACCESS, E_NAGRA, E_IRDETO, E_CONAX, E_CRYPTOWORKS, E_NDS, E_BETADIGITAL,  E_OTHERS

		"""

		def __init__(self, amName = "No Name" ,amChannelCount = 0 ,amCAId = ElisEnum.E_FTA_CHANNEL):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: String, CAS Name
			###
			self.mName= amName

			### 
			# Type: Integer, 
			###
			self.mChannelCount= amChannelCount

			### 
			# Type: Integer, CAId : E_FTA_CHANNEL, E_MEDIAGUARD, E_VIACCESS, E_NAGRA, E_IRDETO, E_CONAX, E_CRYPTOWORKS, E_NDS, E_BETADIGITAL,  E_OTHERS
			###
			self.mCAId= amCAId

		def reset(self):
			"""
				Reset to default value
			"""
			self.mName= "No Name"
			self.mChannelCount= 0
			self.mCAId= ElisEnum.E_FTA_CHANNEL

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append(self.mName)
			req.append('%d' %self.mChannelCount)
			req.append('%d' %self.mCAId)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mName= ret[offset]
			offset=offset+1
			self.mChannelCount= int(ret[offset])
			offset=offset+1
			self.mCAId= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IChannelCASInfo'
			print 'mName= %s'%self.mName
			print 'mChannelCount= %d'%self.mChannelCount
			print 'mCAId= %d'%self.mCAId

class ElisINetworkInfo( ElisClass ): 
		""" 
		ElisINetworkInfo Network Information\n
		\brief Network Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mNid	Network ID
		String	mName	Network Name

		"""

		def __init__(self, amNid = 0 ,amName = "No Name"):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Network ID
			###
			self.mNid= amNid

			### 
			# Type: String, Network Name
			###
			self.mName= amName

		def reset(self):
			"""
				Reset to default value
			"""
			self.mNid= 0
			self.mName= "No Name"

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mNid)
			req.append(self.mName)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mNid= int(ret[offset])
			offset=offset+1
			self.mName= ret[offset]
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  INetworkInfo'
			print 'mNid= %d'%self.mNid
			print 'mName= %s'%self.mName

class ElisIEPGEvent( ElisClass ): 
		""" 
		ElisIEPGEvent Elis EPG Event\n
		\brief Elis EPG Event\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mEventId	EPG Event ID 
		String	mEventName	EPG Event NAme
		String	mEventDescription	EPG Event Description
		Integer	mSid	Service ID
		Integer	mTsid	Transport Stream ID
		Integer	mOnid	Original Network ID
		Integer	mStartTime	EPG Event Start Time (ms)
		Integer	mDuration	EPG Event Duration Time (ms) 
		Integer	mContentTag	EPG Event Content Tag
		Integer	mHasHDVideo	HD Video : 1 or 0
		Integer	mHas16_9Video	16:9 video : 1 or 0
		Integer	mHasStereoAudio	Stereo Audio : 1 or 0 
		Integer	mHasMultichannelAudio	Multi Channel Audio : 1 or 0
		Integer	mHasDolbyDigital	Dolby Digital Audio : 1 or 0
		Integer	mHasSubtitles	Subtitle : 1 or 0
		Integer	mHasHardOfHearingAudio	Hard of Hearing Audio : 1 or 0
		Integer	mHasHardOfHearingSub	Hard of Hearing Sub : 1 or 0
		Integer	mHasVisuallyImpairedAudio	Visually Impaire Audio : 1 or 0
		Integer	mIsSeries	Series
		Integer	mHasTimer	Has Timer
		Integer	mTimerId	Timer ID
		Integer	mAgeRating	Age Rateing

		"""

		def __init__(self, amEventId = 0 ,amEventName = "No Name" ,amEventDescription = "No Description" ,amSid = 0 ,amTsid = 0 ,amOnid = 0 ,amStartTime = 0 ,amDuration = 0 ,amContentTag = 0 ,amHasHDVideo = 0 ,amHas16_9Video = 0 ,amHasStereoAudio = 0 ,amHasMultichannelAudio = 0 ,amHasDolbyDigital = 0 ,amHasSubtitles = 0 ,amHasHardOfHearingAudio = 0 ,amHasHardOfHearingSub = 0 ,amHasVisuallyImpairedAudio = 0 ,amIsSeries = 0 ,amHasTimer = 0 ,amTimerId = 0 ,amAgeRating = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, EPG Event ID 
			###
			self.mEventId= amEventId

			### 
			# Type: String, EPG Event NAme
			###
			self.mEventName= amEventName

			### 
			# Type: String, EPG Event Description
			###
			self.mEventDescription= amEventDescription

			### 
			# Type: Integer, Service ID
			###
			self.mSid= amSid

			### 
			# Type: Integer, Transport Stream ID
			###
			self.mTsid= amTsid

			### 
			# Type: Integer, Original Network ID
			###
			self.mOnid= amOnid

			### 
			# Type: Integer, EPG Event Start Time (ms)
			###
			self.mStartTime= amStartTime

			### 
			# Type: Integer, EPG Event Duration Time (ms) 
			###
			self.mDuration= amDuration

			### 
			# Type: Integer, EPG Event Content Tag
			###
			self.mContentTag= amContentTag

			### 
			# Type: Integer, HD Video : 1 or 0
			###
			self.mHasHDVideo= amHasHDVideo

			### 
			# Type: Integer, 16:9 video : 1 or 0
			###
			self.mHas16_9Video= amHas16_9Video

			### 
			# Type: Integer, Stereo Audio : 1 or 0 
			###
			self.mHasStereoAudio= amHasStereoAudio

			### 
			# Type: Integer, Multi Channel Audio : 1 or 0
			###
			self.mHasMultichannelAudio= amHasMultichannelAudio

			### 
			# Type: Integer, Dolby Digital Audio : 1 or 0
			###
			self.mHasDolbyDigital= amHasDolbyDigital

			### 
			# Type: Integer, Subtitle : 1 or 0
			###
			self.mHasSubtitles= amHasSubtitles

			### 
			# Type: Integer, Hard of Hearing Audio : 1 or 0
			###
			self.mHasHardOfHearingAudio= amHasHardOfHearingAudio

			### 
			# Type: Integer, Hard of Hearing Sub : 1 or 0
			###
			self.mHasHardOfHearingSub= amHasHardOfHearingSub

			### 
			# Type: Integer, Visually Impaire Audio : 1 or 0
			###
			self.mHasVisuallyImpairedAudio= amHasVisuallyImpairedAudio

			### 
			# Type: Integer, Series
			###
			self.mIsSeries= amIsSeries

			### 
			# Type: Integer, Has Timer
			###
			self.mHasTimer= amHasTimer

			### 
			# Type: Integer, Timer ID
			###
			self.mTimerId= amTimerId

			### 
			# Type: Integer, Age Rateing
			###
			self.mAgeRating= amAgeRating

		def reset(self):
			"""
				Reset to default value
			"""
			self.mEventId= 0
			self.mEventName= "No Name"
			self.mEventDescription= "No Description"
			self.mSid= 0
			self.mTsid= 0
			self.mOnid= 0
			self.mStartTime= 0
			self.mDuration= 0
			self.mContentTag= 0
			self.mHasHDVideo= 0
			self.mHas16_9Video= 0
			self.mHasStereoAudio= 0
			self.mHasMultichannelAudio= 0
			self.mHasDolbyDigital= 0
			self.mHasSubtitles= 0
			self.mHasHardOfHearingAudio= 0
			self.mHasHardOfHearingSub= 0
			self.mHasVisuallyImpairedAudio= 0
			self.mIsSeries= 0
			self.mHasTimer= 0
			self.mTimerId= 0
			self.mAgeRating= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mEventId)
			req.append(self.mEventName)
			req.append(self.mEventDescription)
			req.append('%d' %self.mSid)
			req.append('%d' %self.mTsid)
			req.append('%d' %self.mOnid)
			req.append('%d' %self.mStartTime)
			req.append('%d' %self.mDuration)
			req.append('%d' %self.mContentTag)
			req.append('%d' %self.mHasHDVideo)
			req.append('%d' %self.mHas16_9Video)
			req.append('%d' %self.mHasStereoAudio)
			req.append('%d' %self.mHasMultichannelAudio)
			req.append('%d' %self.mHasDolbyDigital)
			req.append('%d' %self.mHasSubtitles)
			req.append('%d' %self.mHasHardOfHearingAudio)
			req.append('%d' %self.mHasHardOfHearingSub)
			req.append('%d' %self.mHasVisuallyImpairedAudio)
			req.append('%d' %self.mIsSeries)
			req.append('%d' %self.mHasTimer)
			req.append('%d' %self.mTimerId)
			req.append('%d' %self.mAgeRating)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mEventId= int(ret[offset])
			offset=offset+1
			self.mEventName= ret[offset]
			offset=offset+1
			self.mEventDescription= ret[offset]
			offset=offset+1
			self.mSid= int(ret[offset])
			offset=offset+1
			self.mTsid= int(ret[offset])
			offset=offset+1
			self.mOnid= int(ret[offset])
			offset=offset+1
			self.mStartTime= int(ret[offset])
			offset=offset+1
			self.mDuration= int(ret[offset])
			offset=offset+1
			self.mContentTag= int(ret[offset])
			offset=offset+1
			self.mHasHDVideo= int(ret[offset])
			offset=offset+1
			self.mHas16_9Video= int(ret[offset])
			offset=offset+1
			self.mHasStereoAudio= int(ret[offset])
			offset=offset+1
			self.mHasMultichannelAudio= int(ret[offset])
			offset=offset+1
			self.mHasDolbyDigital= int(ret[offset])
			offset=offset+1
			self.mHasSubtitles= int(ret[offset])
			offset=offset+1
			self.mHasHardOfHearingAudio= int(ret[offset])
			offset=offset+1
			self.mHasHardOfHearingSub= int(ret[offset])
			offset=offset+1
			self.mHasVisuallyImpairedAudio= int(ret[offset])
			offset=offset+1
			self.mIsSeries= int(ret[offset])
			offset=offset+1
			self.mHasTimer= int(ret[offset])
			offset=offset+1
			self.mTimerId= int(ret[offset])
			offset=offset+1
			self.mAgeRating= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IEPGEvent'
			print 'mEventId= %d'%self.mEventId
			print 'mEventName= %s'%self.mEventName
			print 'mEventDescription= %s'%self.mEventDescription
			print 'mSid= %d'%self.mSid
			print 'mTsid= %d'%self.mTsid
			print 'mOnid= %d'%self.mOnid
			print 'mStartTime= %d'%self.mStartTime
			print 'mDuration= %d'%self.mDuration
			print 'mContentTag= %d'%self.mContentTag
			print 'mHasHDVideo= %d'%self.mHasHDVideo
			print 'mHas16_9Video= %d'%self.mHas16_9Video
			print 'mHasStereoAudio= %d'%self.mHasStereoAudio
			print 'mHasMultichannelAudio= %d'%self.mHasMultichannelAudio
			print 'mHasDolbyDigital= %d'%self.mHasDolbyDigital
			print 'mHasSubtitles= %d'%self.mHasSubtitles
			print 'mHasHardOfHearingAudio= %d'%self.mHasHardOfHearingAudio
			print 'mHasHardOfHearingSub= %d'%self.mHasHardOfHearingSub
			print 'mHasVisuallyImpairedAudio= %d'%self.mHasVisuallyImpairedAudio
			print 'mIsSeries= %d'%self.mIsSeries
			print 'mHasTimer= %d'%self.mHasTimer
			print 'mTimerId= %d'%self.mTimerId
			print 'mAgeRating= %d'%self.mAgeRating

class ElisISatelliteInfo( ElisClass ): 
		""" 
		ElisISatelliteInfo Satellite Information\n
		\brief Satellite Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mLongitude	Satellite Longitude
		Integer	mBand	Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
		String	mName	Satellite Name

		"""

		def __init__(self, amLongitude = 0 ,amBand = ElisEnum.E_BAND_KU ,amName = "No Name"):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Satellite Longitude
			###
			self.mLongitude= amLongitude

			### 
			# Type: Integer, Band:Satellite Band E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			###
			self.mBand= amBand

			### 
			# Type: String, Satellite Name
			###
			self.mName= amName

		def reset(self):
			"""
				Reset to default value
			"""
			self.mLongitude= 0
			self.mBand= ElisEnum.E_BAND_KU
			self.mName= "No Name"

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mLongitude)
			req.append('%d' %self.mBand)
			req.append(self.mName)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mLongitude= int(ret[offset])
			offset=offset+1
			self.mBand= int(ret[offset])
			offset=offset+1
			self.mName= ret[offset]
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ISatelliteInfo'
			print 'mLongitude= %d'%self.mLongitude
			print 'mBand= %d'%self.mBand
			print 'mName= %s'%self.mName

class ElisITransponderInfo( ElisClass ): 
		""" 
		ElisITransponderInfo Transponder Information\n
		\brief Transponder Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mFrequency	Frequency [MHz]
		Integer	mSymbolRate	Symbolrate [ KHz ]
		Integer	mPolarization	Polarizationi:
		Integer	mFECMode	Fec Mode : 
		Integer	mTsid	Transport Stream ID
		Integer	mOnid	Original Network ID
		Integer	mNid	Network ID

		"""

		def __init__(self, amFrequency = 0 ,amSymbolRate = 0 ,amPolarization = 0 ,amFECMode = 0 ,amTsid = 0 ,amOnid = 0 ,amNid = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Frequency [MHz]
			###
			self.mFrequency= amFrequency

			### 
			# Type: Integer, Symbolrate [ KHz ]
			###
			self.mSymbolRate= amSymbolRate

			### 
			# Type: Integer, Polarizationi:
			###
			self.mPolarization= amPolarization

			### 
			# Type: Integer, Fec Mode : 
			###
			self.mFECMode= amFECMode

			### 
			# Type: Integer, Transport Stream ID
			###
			self.mTsid= amTsid

			### 
			# Type: Integer, Original Network ID
			###
			self.mOnid= amOnid

			### 
			# Type: Integer, Network ID
			###
			self.mNid= amNid

		def reset(self):
			"""
				Reset to default value
			"""
			self.mFrequency= 0
			self.mSymbolRate= 0
			self.mPolarization= 0
			self.mFECMode= 0
			self.mTsid= 0
			self.mOnid= 0
			self.mNid= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mFrequency)
			req.append('%d' %self.mSymbolRate)
			req.append('%d' %self.mPolarization)
			req.append('%d' %self.mFECMode)
			req.append('%d' %self.mTsid)
			req.append('%d' %self.mOnid)
			req.append('%d' %self.mNid)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mFrequency= int(ret[offset])
			offset=offset+1
			self.mSymbolRate= int(ret[offset])
			offset=offset+1
			self.mPolarization= int(ret[offset])
			offset=offset+1
			self.mFECMode= int(ret[offset])
			offset=offset+1
			self.mTsid= int(ret[offset])
			offset=offset+1
			self.mOnid= int(ret[offset])
			offset=offset+1
			self.mNid= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ITransponderInfo'
			print 'mFrequency= %d'%self.mFrequency
			print 'mSymbolRate= %d'%self.mSymbolRate
			print 'mPolarization= %d'%self.mPolarization
			print 'mFECMode= %d'%self.mFECMode
			print 'mTsid= %d'%self.mTsid
			print 'mOnid= %d'%self.mOnid
			print 'mNid= %d'%self.mNid

class ElisISatelliteConfig( ElisClass ): 
		""" 
		ElisISatelliteConfig Satellite Configure Information\n
		\brief Satellite Configure Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mTunerIndex	Tuenr Index
		Integer	mSlotNumber	Slot Number
		Integer	mSatelliteLongitude	Satellite Longitude
		Integer	mBandType	Band Type : E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
		Integer	mFrequencyLevel	Frequency Level : E_SAT_22KHZ_OFF, E_SAT_22KHZ_ON
		Integer	mDisEqc11	Diseqc11 used ?: 
		Integer	mDisEqcMode	Diseqc Mode : E_SWITC_DISABLED, E_SWITCH_1OF4, E_SWITCH_2OF4, E_SWITCH_3OF4, E_SWITCH_4OF4, E_SWITCH_MINI_A, E_SWITCH_MINI_B
		Integer	mDisEqcRepeat	Diseqc Repeat : true or false 
		Integer	mIsConfigUsed	Configure used : true or false
		Integer	mLnbType	Lnb Type : E_LNB_UNIVERSAL, E_LNB_SINGLE, E_LNB_DUAL
		Integer	mMotorizedType	Diseqc Motorized Type : E_MOTORIZED_OFF, E_MOTORIZED_ON, E_MOTORIZED_USALS
		Integer	mLowLNB	Low LNB Value
		Integer	mHighLNB	High LNB Value
		Integer	mLNBThreshold	LNB Threadhold Value
		Integer	mMotorizedData	Motorized Data 
		Integer	mIsOneCable	One Cable : true or false
		Integer	mOneCablePin	One Cable Pin
		Integer	mOneCableMDU	One Cable MDU : true or false
		Integer	mOneCableLoFreq1	One Cable Lo Frequency1
		Integer	mOneCableLoFreq2	One Cable Lo Frequency1
		Integer	mOneCableUBSlot	One Cable UB Slot 
		Integer	mOneCableUBFreq	One Cable UB Frequency

		"""

		def __init__(self, amTunerIndex = 0 ,amSlotNumber = 0 ,amSatelliteLongitude = 0 ,amBandType = 0 ,amFrequencyLevel = 0 ,amDisEqc11 = 0 ,amDisEqcMode = 0 ,amDisEqcRepeat = 0 ,amIsConfigUsed = 0 ,amLnbType = 0 ,amMotorizedType = 0 ,amLowLNB = 0 ,amHighLNB = 0 ,amLNBThreshold = 0 ,amMotorizedData = 0 ,amIsOneCable = 0 ,amOneCablePin = 0 ,amOneCableMDU = 0 ,amOneCableLoFreq1 = 0 ,amOneCableLoFreq2 = 0 ,amOneCableUBSlot = 0 ,amOneCableUBFreq = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Tuenr Index
			###
			self.mTunerIndex= amTunerIndex

			### 
			# Type: Integer, Slot Number
			###
			self.mSlotNumber= amSlotNumber

			### 
			# Type: Integer, Satellite Longitude
			###
			self.mSatelliteLongitude= amSatelliteLongitude

			### 
			# Type: Integer, Band Type : E_BAND_UNDEFINED, E_BAND_KU, E_BAND_C
			###
			self.mBandType= amBandType

			### 
			# Type: Integer, Frequency Level : E_SAT_22KHZ_OFF, E_SAT_22KHZ_ON
			###
			self.mFrequencyLevel= amFrequencyLevel

			### 
			# Type: Integer, Diseqc11 used ?: 
			###
			self.mDisEqc11= amDisEqc11

			### 
			# Type: Integer, Diseqc Mode : E_SWITC_DISABLED, E_SWITCH_1OF4, E_SWITCH_2OF4, E_SWITCH_3OF4, E_SWITCH_4OF4, E_SWITCH_MINI_A, E_SWITCH_MINI_B
			###
			self.mDisEqcMode= amDisEqcMode

			### 
			# Type: Integer, Diseqc Repeat : true or false 
			###
			self.mDisEqcRepeat= amDisEqcRepeat

			### 
			# Type: Integer, Configure used : true or false
			###
			self.mIsConfigUsed= amIsConfigUsed

			### 
			# Type: Integer, Lnb Type : E_LNB_UNIVERSAL, E_LNB_SINGLE, E_LNB_DUAL
			###
			self.mLnbType= amLnbType

			### 
			# Type: Integer, Diseqc Motorized Type : E_MOTORIZED_OFF, E_MOTORIZED_ON, E_MOTORIZED_USALS
			###
			self.mMotorizedType= amMotorizedType

			### 
			# Type: Integer, Low LNB Value
			###
			self.mLowLNB= amLowLNB

			### 
			# Type: Integer, High LNB Value
			###
			self.mHighLNB= amHighLNB

			### 
			# Type: Integer, LNB Threadhold Value
			###
			self.mLNBThreshold= amLNBThreshold

			### 
			# Type: Integer, Motorized Data 
			###
			self.mMotorizedData= amMotorizedData

			### 
			# Type: Integer, One Cable : true or false
			###
			self.mIsOneCable= amIsOneCable

			### 
			# Type: Integer, One Cable Pin
			###
			self.mOneCablePin= amOneCablePin

			### 
			# Type: Integer, One Cable MDU : true or false
			###
			self.mOneCableMDU= amOneCableMDU

			### 
			# Type: Integer, One Cable Lo Frequency1
			###
			self.mOneCableLoFreq1= amOneCableLoFreq1

			### 
			# Type: Integer, One Cable Lo Frequency1
			###
			self.mOneCableLoFreq2= amOneCableLoFreq2

			### 
			# Type: Integer, One Cable UB Slot 
			###
			self.mOneCableUBSlot= amOneCableUBSlot

			### 
			# Type: Integer, One Cable UB Frequency
			###
			self.mOneCableUBFreq= amOneCableUBFreq

		def reset(self):
			"""
				Reset to default value
			"""
			self.mTunerIndex= 0
			self.mSlotNumber= 0
			self.mSatelliteLongitude= 0
			self.mBandType= 0
			self.mFrequencyLevel= 0
			self.mDisEqc11= 0
			self.mDisEqcMode= 0
			self.mDisEqcRepeat= 0
			self.mIsConfigUsed= 0
			self.mLnbType= 0
			self.mMotorizedType= 0
			self.mLowLNB= 0
			self.mHighLNB= 0
			self.mLNBThreshold= 0
			self.mMotorizedData= 0
			self.mIsOneCable= 0
			self.mOneCablePin= 0
			self.mOneCableMDU= 0
			self.mOneCableLoFreq1= 0
			self.mOneCableLoFreq2= 0
			self.mOneCableUBSlot= 0
			self.mOneCableUBFreq= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mTunerIndex)
			req.append('%d' %self.mSlotNumber)
			req.append('%d' %self.mSatelliteLongitude)
			req.append('%d' %self.mBandType)
			req.append('%d' %self.mFrequencyLevel)
			req.append('%d' %self.mDisEqc11)
			req.append('%d' %self.mDisEqcMode)
			req.append('%d' %self.mDisEqcRepeat)
			req.append('%d' %self.mIsConfigUsed)
			req.append('%d' %self.mLnbType)
			req.append('%d' %self.mMotorizedType)
			req.append('%d' %self.mLowLNB)
			req.append('%d' %self.mHighLNB)
			req.append('%d' %self.mLNBThreshold)
			req.append('%d' %self.mMotorizedData)
			req.append('%d' %self.mIsOneCable)
			req.append('%d' %self.mOneCablePin)
			req.append('%d' %self.mOneCableMDU)
			req.append('%d' %self.mOneCableLoFreq1)
			req.append('%d' %self.mOneCableLoFreq2)
			req.append('%d' %self.mOneCableUBSlot)
			req.append('%d' %self.mOneCableUBFreq)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mTunerIndex= int(ret[offset])
			offset=offset+1
			self.mSlotNumber= int(ret[offset])
			offset=offset+1
			self.mSatelliteLongitude= int(ret[offset])
			offset=offset+1
			self.mBandType= int(ret[offset])
			offset=offset+1
			self.mFrequencyLevel= int(ret[offset])
			offset=offset+1
			self.mDisEqc11= int(ret[offset])
			offset=offset+1
			self.mDisEqcMode= int(ret[offset])
			offset=offset+1
			self.mDisEqcRepeat= int(ret[offset])
			offset=offset+1
			self.mIsConfigUsed= int(ret[offset])
			offset=offset+1
			self.mLnbType= int(ret[offset])
			offset=offset+1
			self.mMotorizedType= int(ret[offset])
			offset=offset+1
			self.mLowLNB= int(ret[offset])
			offset=offset+1
			self.mHighLNB= int(ret[offset])
			offset=offset+1
			self.mLNBThreshold= int(ret[offset])
			offset=offset+1
			self.mMotorizedData= int(ret[offset])
			offset=offset+1
			self.mIsOneCable= int(ret[offset])
			offset=offset+1
			self.mOneCablePin= int(ret[offset])
			offset=offset+1
			self.mOneCableMDU= int(ret[offset])
			offset=offset+1
			self.mOneCableLoFreq1= int(ret[offset])
			offset=offset+1
			self.mOneCableLoFreq2= int(ret[offset])
			offset=offset+1
			self.mOneCableUBSlot= int(ret[offset])
			offset=offset+1
			self.mOneCableUBFreq= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ISatelliteConfig'
			print 'mTunerIndex= %d'%self.mTunerIndex
			print 'mSlotNumber= %d'%self.mSlotNumber
			print 'mSatelliteLongitude= %d'%self.mSatelliteLongitude
			print 'mBandType= %d'%self.mBandType
			print 'mFrequencyLevel= %d'%self.mFrequencyLevel
			print 'mDisEqc11= %d'%self.mDisEqc11
			print 'mDisEqcMode= %d'%self.mDisEqcMode
			print 'mDisEqcRepeat= %d'%self.mDisEqcRepeat
			print 'mIsConfigUsed= %d'%self.mIsConfigUsed
			print 'mLnbType= %d'%self.mLnbType
			print 'mMotorizedType= %d'%self.mMotorizedType
			print 'mLowLNB= %d'%self.mLowLNB
			print 'mHighLNB= %d'%self.mHighLNB
			print 'mLNBThreshold= %d'%self.mLNBThreshold
			print 'mMotorizedData= %d'%self.mMotorizedData
			print 'mIsOneCable= %d'%self.mIsOneCable
			print 'mOneCablePin= %d'%self.mOneCablePin
			print 'mOneCableMDU= %d'%self.mOneCableMDU
			print 'mOneCableLoFreq1= %d'%self.mOneCableLoFreq1
			print 'mOneCableLoFreq2= %d'%self.mOneCableLoFreq2
			print 'mOneCableUBSlot= %d'%self.mOneCableUBSlot
			print 'mOneCableUBFreq= %d'%self.mOneCableUBFreq

class ElisIZappingMode( ElisClass ): 
		""" 
		ElisIZappingMode Zapping Mode Information\n
		\brief Zapping Mode Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mMode	Zapping Mode : E_MODE_ALL, E_MODE_FAVORITE, E_MODE_NETWORK, E_MODE_SATELLITE, E_MODE_CAS
		Integer	mSortingMode	Sorting Mode : E_SORT_BY_DEFAULT, E_SORT_BY_ALPHABET, E_SORT_BY_CARRIER, E_SORT_BY_NUMBER, E_SORT_BY_HD
		Integer	mServiceType	Service Type : E_SERVICE_TYPE_TV, E_TYPE_RADIO
		ElisIFavoriteGroup	mFavoriteGroup	Favorite Information
		ElisINetworkInfo	mINetworkInfo	Network Information
		ElisISatelliteInfo	mSatelliteInfo	Satellite Information
		ElisIChannelCASInfo	mCasInfo	CAS Information

		"""

		def __init__(self, amMode = ElisEnum.E_MODE_ALL ,amSortingMode = ElisEnum.E_SORT_BY_DEFAULT ,amServiceType = ElisEnum.E_SERVICE_TYPE_TV ,amFavoriteGroup = None ,amINetworkInfo = None ,amSatelliteInfo = None ,amCasInfo = None):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Zapping Mode : E_MODE_ALL, E_MODE_FAVORITE, E_MODE_NETWORK, E_MODE_SATELLITE, E_MODE_CAS
			###
			self.mMode= amMode

			### 
			# Type: Integer, Sorting Mode : E_SORT_BY_DEFAULT, E_SORT_BY_ALPHABET, E_SORT_BY_CARRIER, E_SORT_BY_NUMBER, E_SORT_BY_HD
			###
			self.mSortingMode= amSortingMode

			### 
			# Type: Integer, Service Type : E_SERVICE_TYPE_TV, E_TYPE_RADIO
			###
			self.mServiceType= amServiceType

			### 
			# Type: ElisIFavoriteGroup, Favorite Information
			# @see ElisIFavoriteGroup
			###
			if amFavoriteGroup == None:
				self.mFavoriteGroup= ElisIFavoriteGroup()
			else:
				self.mFavoriteGroup= amFavoriteGroup

			### 
			# Type: ElisINetworkInfo, Network Information
			# @see ElisINetworkInfo
			###
			if amINetworkInfo == None:
				self.mINetworkInfo= ElisINetworkInfo()
			else:
				self.mINetworkInfo= amINetworkInfo

			### 
			# Type: ElisISatelliteInfo, Satellite Information
			# @see ElisISatelliteInfo
			###
			if amSatelliteInfo == None:
				self.mSatelliteInfo= ElisISatelliteInfo()
			else:
				self.mSatelliteInfo= amSatelliteInfo

			### 
			# Type: ElisIChannelCASInfo, CAS Information
			# @see ElisIChannelCASInfo
			###
			if amCasInfo == None:
				self.mCasInfo= ElisIChannelCASInfo()
			else:
				self.mCasInfo= amCasInfo

		def reset(self):
			"""
				Reset to default value
			"""
			self.mMode= ElisEnum.E_MODE_ALL
			self.mSortingMode= ElisEnum.E_SORT_BY_DEFAULT
			self.mServiceType= ElisEnum.E_SERVICE_TYPE_TV
			self.mFavoriteGroup= ElisIFavoriteGroup()
			self.mINetworkInfo= ElisINetworkInfo()
			self.mSatelliteInfo= ElisISatelliteInfo()
			self.mCasInfo= ElisIChannelCASInfo()

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mMode)
			req.append('%d' %self.mSortingMode)
			req.append('%d' %self.mServiceType)
			self.mFavoriteGroup.appendReqBuffer( req )
			self.mINetworkInfo.appendReqBuffer( req )
			self.mSatelliteInfo.appendReqBuffer( req )
			self.mCasInfo.appendReqBuffer( req )

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mMode= int(ret[offset])
			offset=offset+1
			self.mSortingMode= int(ret[offset])
			offset=offset+1
			self.mServiceType= int(ret[offset])
			offset=offset+1
			self.mFavoriteGroup= ElisIFavoriteGroup()
			offset = self.mFavoriteGroup.parseReturnBuffer( ret, offset )
			self.mINetworkInfo= ElisINetworkInfo()
			offset = self.mINetworkInfo.parseReturnBuffer( ret, offset )
			self.mSatelliteInfo= ElisISatelliteInfo()
			offset = self.mSatelliteInfo.parseReturnBuffer( ret, offset )
			self.mCasInfo= ElisIChannelCASInfo()
			offset = self.mCasInfo.parseReturnBuffer( ret, offset )

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IZappingMode'
			print 'mMode= %d'%self.mMode
			print 'mSortingMode= %d'%self.mSortingMode
			print 'mServiceType= %d'%self.mServiceType
			print 'mFavoriteGroup=' 
			self.mFavoriteGroup.printdebug()
			print 'mINetworkInfo=' 
			self.mINetworkInfo.printdebug()
			print 'mSatelliteInfo=' 
			self.mSatelliteInfo.printdebug()
			print 'mCasInfo=' 
			self.mCasInfo.printdebug()

class ElisIPlayerStatus( ElisClass ): 
		""" 
		ElisIPlayerStatus Player Status Information\n
		\brief Player Status Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mMode	Player Mode : E_MODE_LIVE, E_MODE_TIMESHIFT, E_MODE_PVR, E_MODE_EXTERNAL_PVR, E_MODE_MULTIMEDIA
		Integer	mMediaType	Media Type : E_MEDIA_TYPE_INVALID, E_MEDIA_TYPE_MP3, E_MEDIA_TYPE_JPEG, E_MEDIA_TYPE_AVIMPG
		Integer	mKey	Live Channel number
		Integer	mServiceType	Service Type
		Integer	mStartTimeInMs	Start Time ms
		Integer	mPlayTimeInMs	Play Time ms
		Integer	mEndTimeInMs	End Time ms
		Integer	mSpeed	Play Speed Value
		Integer	mIsTimeshiftPending	Timeshift Pending Status : true or false
		Integer	mTotalFileCount	Total File Conut
		Integer	mCurrentIndex	Current playing Index
		Integer	mAbsoluteCurrentIndex	Absolute Current Index

		"""

		def __init__(self, amMode = 0 ,amMediaType = 0 ,amKey = 0 ,amServiceType = 0 ,amStartTimeInMs = 0 ,amPlayTimeInMs = 1000 ,amEndTimeInMs = 2000 ,amSpeed = 100 ,amIsTimeshiftPending = 0 ,amTotalFileCount = 0 ,amCurrentIndex = 0 ,amAbsoluteCurrentIndex = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Player Mode : E_MODE_LIVE, E_MODE_TIMESHIFT, E_MODE_PVR, E_MODE_EXTERNAL_PVR, E_MODE_MULTIMEDIA
			###
			self.mMode= amMode

			### 
			# Type: Integer, Media Type : E_MEDIA_TYPE_INVALID, E_MEDIA_TYPE_MP3, E_MEDIA_TYPE_JPEG, E_MEDIA_TYPE_AVIMPG
			###
			self.mMediaType= amMediaType

			### 
			# Type: Integer, Live Channel number
			###
			self.mKey= amKey

			### 
			# Type: Integer, Service Type
			###
			self.mServiceType= amServiceType

			### 
			# Type: Integer, Start Time ms
			###
			self.mStartTimeInMs= amStartTimeInMs

			### 
			# Type: Integer, Play Time ms
			###
			self.mPlayTimeInMs= amPlayTimeInMs

			### 
			# Type: Integer, End Time ms
			###
			self.mEndTimeInMs= amEndTimeInMs

			### 
			# Type: Integer, Play Speed Value
			###
			self.mSpeed= amSpeed

			### 
			# Type: Integer, Timeshift Pending Status : true or false
			###
			self.mIsTimeshiftPending= amIsTimeshiftPending

			### 
			# Type: Integer, Total File Conut
			###
			self.mTotalFileCount= amTotalFileCount

			### 
			# Type: Integer, Current playing Index
			###
			self.mCurrentIndex= amCurrentIndex

			### 
			# Type: Integer, Absolute Current Index
			###
			self.mAbsoluteCurrentIndex= amAbsoluteCurrentIndex

		def reset(self):
			"""
				Reset to default value
			"""
			self.mMode= 0
			self.mMediaType= 0
			self.mKey= 0
			self.mServiceType= 0
			self.mStartTimeInMs= 0
			self.mPlayTimeInMs= 1000
			self.mEndTimeInMs= 2000
			self.mSpeed= 100
			self.mIsTimeshiftPending= 0
			self.mTotalFileCount= 0
			self.mCurrentIndex= 0
			self.mAbsoluteCurrentIndex= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mMode)
			req.append('%d' %self.mMediaType)
			req.append('%d' %self.mKey)
			req.append('%d' %self.mServiceType)
			req.append('%d' %self.mStartTimeInMs)
			req.append('%d' %self.mPlayTimeInMs)
			req.append('%d' %self.mEndTimeInMs)
			req.append('%d' %self.mSpeed)
			req.append('%d' %self.mIsTimeshiftPending)
			req.append('%d' %self.mTotalFileCount)
			req.append('%d' %self.mCurrentIndex)
			req.append('%d' %self.mAbsoluteCurrentIndex)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mMode= int(ret[offset])
			offset=offset+1
			self.mMediaType= int(ret[offset])
			offset=offset+1
			self.mKey= int(ret[offset])
			offset=offset+1
			self.mServiceType= int(ret[offset])
			offset=offset+1
			self.mStartTimeInMs= int(ret[offset])
			offset=offset+1
			self.mPlayTimeInMs= int(ret[offset])
			offset=offset+1
			self.mEndTimeInMs= int(ret[offset])
			offset=offset+1
			self.mSpeed= int(ret[offset])
			offset=offset+1
			self.mIsTimeshiftPending= int(ret[offset])
			offset=offset+1
			self.mTotalFileCount= int(ret[offset])
			offset=offset+1
			self.mCurrentIndex= int(ret[offset])
			offset=offset+1
			self.mAbsoluteCurrentIndex= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IPlayerStatus'
			print 'mMode= %d'%self.mMode
			print 'mMediaType= %d'%self.mMediaType
			print 'mKey= %d'%self.mKey
			print 'mServiceType= %d'%self.mServiceType
			print 'mStartTimeInMs= %d'%self.mStartTimeInMs
			print 'mPlayTimeInMs= %d'%self.mPlayTimeInMs
			print 'mEndTimeInMs= %d'%self.mEndTimeInMs
			print 'mSpeed= %d'%self.mSpeed
			print 'mIsTimeshiftPending= %d'%self.mIsTimeshiftPending
			print 'mTotalFileCount= %d'%self.mTotalFileCount
			print 'mCurrentIndex= %d'%self.mCurrentIndex
			print 'mAbsoluteCurrentIndex= %d'%self.mAbsoluteCurrentIndex

class ElisERecordInfo( ElisClass ): 
		""" 
		ElisERecordInfo Record Information\n
		\brief Record Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mRecordKey	Channel Number
		Integer	mFolderNumber	Channel presentation number
		Integer	mStartTime	Record Start Time
		Integer	mDuration	Record Duration Time
		Integer	mPlayedOffset	Played Offset
		Integer	mChannelNo	Record Channel Number
		Integer	mServiceType	Service Type
		String	mChannelName	Record Channel Name
		String	mRecordName	Record Name
		Integer	mServiceId	Service Id
		Integer	mVpid	Video Pid
		Integer	mApid	Audio Pid
		Integer	mLocked	Is Locked

		"""

		def __init__(self, amRecordKey = 0 ,amFolderNumber = 0 ,amStartTime = 0 ,amDuration = 1000 ,amPlayedOffset = 0 ,amChannelNo = 0 ,amServiceType = ElisEnum.E_SERVICE_TYPE_INVALID ,amChannelName = "No Channel" ,amRecordName = "No Name" ,amServiceId = 0 ,amVpid = 0 ,amApid = 0 ,amLocked = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Channel Number
			###
			self.mRecordKey= amRecordKey

			### 
			# Type: Integer, Channel presentation number
			###
			self.mFolderNumber= amFolderNumber

			### 
			# Type: Integer, Record Start Time
			###
			self.mStartTime= amStartTime

			### 
			# Type: Integer, Record Duration Time
			###
			self.mDuration= amDuration

			### 
			# Type: Integer, Played Offset
			###
			self.mPlayedOffset= amPlayedOffset

			### 
			# Type: Integer, Record Channel Number
			###
			self.mChannelNo= amChannelNo

			### 
			# Type: Integer, Service Type
			###
			self.mServiceType= amServiceType

			### 
			# Type: String, Record Channel Name
			###
			self.mChannelName= amChannelName

			### 
			# Type: String, Record Name
			###
			self.mRecordName= amRecordName

			### 
			# Type: Integer, Service Id
			###
			self.mServiceId= amServiceId

			### 
			# Type: Integer, Video Pid
			###
			self.mVpid= amVpid

			### 
			# Type: Integer, Audio Pid
			###
			self.mApid= amApid

			### 
			# Type: Integer, Is Locked
			###
			self.mLocked= amLocked

		def reset(self):
			"""
				Reset to default value
			"""
			self.mRecordKey= 0
			self.mFolderNumber= 0
			self.mStartTime= 0
			self.mDuration= 1000
			self.mPlayedOffset= 0
			self.mChannelNo= 0
			self.mServiceType= ElisEnum.E_SERVICE_TYPE_INVALID
			self.mChannelName= "No Channel"
			self.mRecordName= "No Name"
			self.mServiceId= 0
			self.mVpid= 0
			self.mApid= 0
			self.mLocked= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mRecordKey)
			req.append('%d' %self.mFolderNumber)
			req.append('%d' %self.mStartTime)
			req.append('%d' %self.mDuration)
			req.append('%d' %self.mPlayedOffset)
			req.append('%d' %self.mChannelNo)
			req.append('%d' %self.mServiceType)
			req.append(self.mChannelName)
			req.append(self.mRecordName)
			req.append('%d' %self.mServiceId)
			req.append('%d' %self.mVpid)
			req.append('%d' %self.mApid)
			req.append('%d' %self.mLocked)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mRecordKey= int(ret[offset])
			offset=offset+1
			self.mFolderNumber= int(ret[offset])
			offset=offset+1
			self.mStartTime= int(ret[offset])
			offset=offset+1
			self.mDuration= int(ret[offset])
			offset=offset+1
			self.mPlayedOffset= int(ret[offset])
			offset=offset+1
			self.mChannelNo= int(ret[offset])
			offset=offset+1
			self.mServiceType= int(ret[offset])
			offset=offset+1
			self.mChannelName= ret[offset]
			offset=offset+1
			self.mRecordName= ret[offset]
			offset=offset+1
			self.mServiceId= int(ret[offset])
			offset=offset+1
			self.mVpid= int(ret[offset])
			offset=offset+1
			self.mApid= int(ret[offset])
			offset=offset+1
			self.mLocked= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ERecordInfo'
			print 'mRecordKey= %d'%self.mRecordKey
			print 'mFolderNumber= %d'%self.mFolderNumber
			print 'mStartTime= %d'%self.mStartTime
			print 'mDuration= %d'%self.mDuration
			print 'mPlayedOffset= %d'%self.mPlayedOffset
			print 'mChannelNo= %d'%self.mChannelNo
			print 'mServiceType= %d'%self.mServiceType
			print 'mChannelName= %s'%self.mChannelName
			print 'mRecordName= %s'%self.mRecordName
			print 'mServiceId= %d'%self.mServiceId
			print 'mVpid= %d'%self.mVpid
			print 'mApid= %d'%self.mApid
			print 'mLocked= %d'%self.mLocked

class ElisISubtitle( ElisClass ): 
		""" 
		ElisISubtitle Subtitle information\n
		\brief Subtitle information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mSubtitleType	Subtitle Type : E_SUB_DVB, E_SUB_TTX
		Integer	mHardOfHearing	Hard of Hearig : true or false
		String	mLanguage	Subtitle Language
		Integer	mPid	PId
		Integer	mPageId	Subtitle Page ID
		Integer	mSubId	Subtitle ID

		"""

		def __init__(self, amSubtitleType = 0 ,amHardOfHearing = 0 ,amLanguage = "ElisEnum.E_ENGLISH" ,amPid = 0 ,amPageId = 0 ,amSubId = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Subtitle Type : E_SUB_DVB, E_SUB_TTX
			###
			self.mSubtitleType= amSubtitleType

			### 
			# Type: Integer, Hard of Hearig : true or false
			###
			self.mHardOfHearing= amHardOfHearing

			### 
			# Type: String, Subtitle Language
			###
			self.mLanguage= amLanguage

			### 
			# Type: Integer, PId
			###
			self.mPid= amPid

			### 
			# Type: Integer, Subtitle Page ID
			###
			self.mPageId= amPageId

			### 
			# Type: Integer, Subtitle ID
			###
			self.mSubId= amSubId

		def reset(self):
			"""
				Reset to default value
			"""
			self.mSubtitleType= 0
			self.mHardOfHearing= 0
			self.mLanguage= "ElisEnum.E_ENGLISH"
			self.mPid= 0
			self.mPageId= 0
			self.mSubId= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mSubtitleType)
			req.append('%d' %self.mHardOfHearing)
			req.append(self.mLanguage)
			req.append('%d' %self.mPid)
			req.append('%d' %self.mPageId)
			req.append('%d' %self.mSubId)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mSubtitleType= int(ret[offset])
			offset=offset+1
			self.mHardOfHearing= int(ret[offset])
			offset=offset+1
			self.mLanguage= ret[offset]
			offset=offset+1
			self.mPid= int(ret[offset])
			offset=offset+1
			self.mPageId= int(ret[offset])
			offset=offset+1
			self.mSubId= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ISubtitle'
			print 'mSubtitleType= %d'%self.mSubtitleType
			print 'mHardOfHearing= %d'%self.mHardOfHearing
			print 'mLanguage= %s'%self.mLanguage
			print 'mPid= %d'%self.mPid
			print 'mPageId= %d'%self.mPageId
			print 'mSubId= %d'%self.mSubId

class ElisIAudioTrack( ElisClass ): 
		""" 
		ElisIAudioTrack Audio Track information\n
		\brief Audio Track information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mAudioType	Audio Type : 0 ~ 14 (E_AUD_STREAM_INVALID, E_AUD_STREAM_MP1A, E_AUD_STREAM_MP2A, E_AUD_STREAM_AAC, E_AUD_STREAM_AC3, E_AUD_STREAM_MP3, E_AUD_STREAM_DTS, E_AUD_STREAM_MP4A, E_AUD_STREAM_DDPLUS, E_AUD_STREAM_HEAAC,E_AUD_STREAM_HEAAC_V4, E_AUD_STREAM_WMA, E_AUD_STREAM_BEEP_TONE, E_AUD_STREAM_PCM )
		Integer	mAudioChannel	Audio Channel : 0~3 (E_AUDIO_CHANNEL_STEREO, E_AUDIO_CHANNEL_LEFT, E_AUDIO_CHANNEL_RIGHT, E_AUDIO_CHANNEL_MULTI)
		String	mName	Audio Track Name
		String	mLang	Audio Language
		Integer	mPid	Audio PID

		"""

		def __init__(self, amAudioType = 0 ,amAudioChannel = 0 ,amName = "No Name" ,amLang = "ElisEnum.E_ENGLISH" ,amPid = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Audio Type : 0 ~ 14 (E_AUD_STREAM_INVALID, E_AUD_STREAM_MP1A, E_AUD_STREAM_MP2A, E_AUD_STREAM_AAC, E_AUD_STREAM_AC3, E_AUD_STREAM_MP3, E_AUD_STREAM_DTS, E_AUD_STREAM_MP4A, E_AUD_STREAM_DDPLUS, E_AUD_STREAM_HEAAC,E_AUD_STREAM_HEAAC_V4, E_AUD_STREAM_WMA, E_AUD_STREAM_BEEP_TONE, E_AUD_STREAM_PCM )
			###
			self.mAudioType= amAudioType

			### 
			# Type: Integer, Audio Channel : 0~3 (E_AUDIO_CHANNEL_STEREO, E_AUDIO_CHANNEL_LEFT, E_AUDIO_CHANNEL_RIGHT, E_AUDIO_CHANNEL_MULTI)
			###
			self.mAudioChannel= amAudioChannel

			### 
			# Type: String, Audio Track Name
			###
			self.mName= amName

			### 
			# Type: String, Audio Language
			###
			self.mLang= amLang

			### 
			# Type: Integer, Audio PID
			###
			self.mPid= amPid

		def reset(self):
			"""
				Reset to default value
			"""
			self.mAudioType= 0
			self.mAudioChannel= 0
			self.mName= "No Name"
			self.mLang= "ElisEnum.E_ENGLISH"
			self.mPid= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mAudioType)
			req.append('%d' %self.mAudioChannel)
			req.append(self.mName)
			req.append(self.mLang)
			req.append('%d' %self.mPid)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mAudioType= int(ret[offset])
			offset=offset+1
			self.mAudioChannel= int(ret[offset])
			offset=offset+1
			self.mName= ret[offset]
			offset=offset+1
			self.mLang= ret[offset]
			offset=offset+1
			self.mPid= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IAudioTrack'
			print 'mAudioType= %d'%self.mAudioType
			print 'mAudioChannel= %d'%self.mAudioChannel
			print 'mName= %s'%self.mName
			print 'mLang= %s'%self.mLang
			print 'mPid= %d'%self.mPid

class ElisIOTIModule( ElisClass ): 
		""" 
		ElisIOTIModule OTIModule Information\n
		\brief OTIModule Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mType	Module Type : E_MODULE_INVALID, E_MODULE_SW, E_MODULE_CHLIST, E_MODULE_DELTA_CHLIST, E_MODULE_EXTERNAL_PROGRAM
		Integer	mFileType	File Type : E_FILE_INVALID, E_FILE_BINARY, E_FILE_GZIPPED_BINARY, E_FILE_TEXT, E_FILE_GZIPPED_TEXT
		String	mPath	File Path
		String	mFileName	File Name
		String	mInfo	Module Information
		Integer	mVersion	Module Version
		Integer	mReleaseDate	Module Release Date
		Integer	mCountryCode	Country Code

		"""

		def __init__(self, amType = 0 ,amFileType = 0 ,amPath = "No Path" ,amFileName = "No FileName" ,amInfo = "No Info" ,amVersion = 0 ,amReleaseDate = 0 ,amCountryCode = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Module Type : E_MODULE_INVALID, E_MODULE_SW, E_MODULE_CHLIST, E_MODULE_DELTA_CHLIST, E_MODULE_EXTERNAL_PROGRAM
			###
			self.mType= amType

			### 
			# Type: Integer, File Type : E_FILE_INVALID, E_FILE_BINARY, E_FILE_GZIPPED_BINARY, E_FILE_TEXT, E_FILE_GZIPPED_TEXT
			###
			self.mFileType= amFileType

			### 
			# Type: String, File Path
			###
			self.mPath= amPath

			### 
			# Type: String, File Name
			###
			self.mFileName= amFileName

			### 
			# Type: String, Module Information
			###
			self.mInfo= amInfo

			### 
			# Type: Integer, Module Version
			###
			self.mVersion= amVersion

			### 
			# Type: Integer, Module Release Date
			###
			self.mReleaseDate= amReleaseDate

			### 
			# Type: Integer, Country Code
			###
			self.mCountryCode= amCountryCode

		def reset(self):
			"""
				Reset to default value
			"""
			self.mType= 0
			self.mFileType= 0
			self.mPath= "No Path"
			self.mFileName= "No FileName"
			self.mInfo= "No Info"
			self.mVersion= 0
			self.mReleaseDate= 0
			self.mCountryCode= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mType)
			req.append('%d' %self.mFileType)
			req.append(self.mPath)
			req.append(self.mFileName)
			req.append(self.mInfo)
			req.append('%d' %self.mVersion)
			req.append('%d' %self.mReleaseDate)
			req.append('%d' %self.mCountryCode)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mType= int(ret[offset])
			offset=offset+1
			self.mFileType= int(ret[offset])
			offset=offset+1
			self.mPath= ret[offset]
			offset=offset+1
			self.mFileName= ret[offset]
			offset=offset+1
			self.mInfo= ret[offset]
			offset=offset+1
			self.mVersion= int(ret[offset])
			offset=offset+1
			self.mReleaseDate= int(ret[offset])
			offset=offset+1
			self.mCountryCode= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IOTIModule'
			print 'mType= %d'%self.mType
			print 'mFileType= %d'%self.mFileType
			print 'mPath= %s'%self.mPath
			print 'mFileName= %s'%self.mFileName
			print 'mInfo= %s'%self.mInfo
			print 'mVersion= %d'%self.mVersion
			print 'mReleaseDate= %d'%self.mReleaseDate
			print 'mCountryCode= %d'%self.mCountryCode

class ElisIHDMIVideoFormat( ElisClass ): 
		""" 
		ElisIHDMIVideoFormat  HDMISink Information\n
		\brief  HDMISink Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mWidth	Width
		Integer	mHeight	Height
		Integer	mFrameRate	FrameRate
		Integer	mInterlaced	Interlaced

		"""

		def __init__(self, amWidth = 0 ,amHeight = 0 ,amFrameRate = 0 ,amInterlaced = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Width
			###
			self.mWidth= amWidth

			### 
			# Type: Integer, Height
			###
			self.mHeight= amHeight

			### 
			# Type: Integer, FrameRate
			###
			self.mFrameRate= amFrameRate

			### 
			# Type: Integer, Interlaced
			###
			self.mInterlaced= amInterlaced

		def reset(self):
			"""
				Reset to default value
			"""
			self.mWidth= 0
			self.mHeight= 0
			self.mFrameRate= 0
			self.mInterlaced= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mWidth)
			req.append('%d' %self.mHeight)
			req.append('%d' %self.mFrameRate)
			req.append('%d' %self.mInterlaced)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mWidth= int(ret[offset])
			offset=offset+1
			self.mHeight= int(ret[offset])
			offset=offset+1
			self.mFrameRate= int(ret[offset])
			offset=offset+1
			self.mInterlaced= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IHDMIVideoFormat'
			print 'mWidth= %d'%self.mWidth
			print 'mHeight= %d'%self.mHeight
			print 'mFrameRate= %d'%self.mFrameRate
			print 'mInterlaced= %d'%self.mInterlaced

class ElisIRecordItem( ElisClass ): 
		""" 
		ElisIRecordItem  Record Item Information\n
		\brief  Record Item Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mType	E_TYPE_RECORD, E_TYPE_FOLDER, E_TYPE_PSEUDO_FOLDER, E_TYPE_PRIORITY_FOLDER
		Integer	mIsLocked	 Is Locked : true or false
		Integer	mKey	Record key
		Integer	mParentFolder	 ParentFolder : E_ROOT_FOLDER
		String	mName	Record Name
		Integer	mStartTime	Record Start Time
		Integer	mDuration	Record Duration
		Integer	mChannelNumber	Record Channel Number
		Integer	mServiceType	Service Type
		String	mChannelName	Record Channel Name
		Integer	mGenre	Genre
		Integer	mPlayedCount	Played Count
		Integer	mLastWatchedTime	Last Watched Time
		Integer	mUserPriority	User Priority
		Integer	mTimerId	Timer ID
		Integer	mFromSeries	Is Series : true or false
		Integer	mIsToParent	Is To Parent : true or false
		Integer	mChildCount	Child Count
		Integer	mHasDecryptTimer	Has Decrypt Timer : true or false
		Integer	mScrambled	Scrambled : true or false
		Integer	mAgeLimit	Age Limit

		"""

		def __init__(self, amType = 0 ,amIsLocked = 0 ,amKey = 0 ,amParentFolder = 0 ,amName = "No Name" ,amStartTime = 0 ,amDuration = 0 ,amChannelNumber = 0 ,amServiceType = 0 ,amChannelName = "No ChannelName" ,amGenre = 0 ,amPlayedCount = 0 ,amLastWatchedTime = 0 ,amUserPriority = 0 ,amTimerId = 0 ,amFromSeries = 0 ,amIsToParent = 0 ,amChildCount = 0 ,amHasDecryptTimer = 0 ,amScrambled = 0 ,amAgeLimit = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, E_TYPE_RECORD, E_TYPE_FOLDER, E_TYPE_PSEUDO_FOLDER, E_TYPE_PRIORITY_FOLDER
			###
			self.mType= amType

			### 
			# Type: Integer,  Is Locked : true or false
			###
			self.mIsLocked= amIsLocked

			### 
			# Type: Integer, Record key
			###
			self.mKey= amKey

			### 
			# Type: Integer,  ParentFolder : E_ROOT_FOLDER
			###
			self.mParentFolder= amParentFolder

			### 
			# Type: String, Record Name
			###
			self.mName= amName

			### 
			# Type: Integer, Record Start Time
			###
			self.mStartTime= amStartTime

			### 
			# Type: Integer, Record Duration
			###
			self.mDuration= amDuration

			### 
			# Type: Integer, Record Channel Number
			###
			self.mChannelNumber= amChannelNumber

			### 
			# Type: Integer, Service Type
			###
			self.mServiceType= amServiceType

			### 
			# Type: String, Record Channel Name
			###
			self.mChannelName= amChannelName

			### 
			# Type: Integer, Genre
			###
			self.mGenre= amGenre

			### 
			# Type: Integer, Played Count
			###
			self.mPlayedCount= amPlayedCount

			### 
			# Type: Integer, Last Watched Time
			###
			self.mLastWatchedTime= amLastWatchedTime

			### 
			# Type: Integer, User Priority
			###
			self.mUserPriority= amUserPriority

			### 
			# Type: Integer, Timer ID
			###
			self.mTimerId= amTimerId

			### 
			# Type: Integer, Is Series : true or false
			###
			self.mFromSeries= amFromSeries

			### 
			# Type: Integer, Is To Parent : true or false
			###
			self.mIsToParent= amIsToParent

			### 
			# Type: Integer, Child Count
			###
			self.mChildCount= amChildCount

			### 
			# Type: Integer, Has Decrypt Timer : true or false
			###
			self.mHasDecryptTimer= amHasDecryptTimer

			### 
			# Type: Integer, Scrambled : true or false
			###
			self.mScrambled= amScrambled

			### 
			# Type: Integer, Age Limit
			###
			self.mAgeLimit= amAgeLimit

		def reset(self):
			"""
				Reset to default value
			"""
			self.mType= 0
			self.mIsLocked= 0
			self.mKey= 0
			self.mParentFolder= 0
			self.mName= "No Name"
			self.mStartTime= 0
			self.mDuration= 0
			self.mChannelNumber= 0
			self.mServiceType= 0
			self.mChannelName= "No ChannelName"
			self.mGenre= 0
			self.mPlayedCount= 0
			self.mLastWatchedTime= 0
			self.mUserPriority= 0
			self.mTimerId= 0
			self.mFromSeries= 0
			self.mIsToParent= 0
			self.mChildCount= 0
			self.mHasDecryptTimer= 0
			self.mScrambled= 0
			self.mAgeLimit= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mType)
			req.append('%d' %self.mIsLocked)
			req.append('%d' %self.mKey)
			req.append('%d' %self.mParentFolder)
			req.append(self.mName)
			req.append('%d' %self.mStartTime)
			req.append('%d' %self.mDuration)
			req.append('%d' %self.mChannelNumber)
			req.append('%d' %self.mServiceType)
			req.append(self.mChannelName)
			req.append('%d' %self.mGenre)
			req.append('%d' %self.mPlayedCount)
			req.append('%d' %self.mLastWatchedTime)
			req.append('%d' %self.mUserPriority)
			req.append('%d' %self.mTimerId)
			req.append('%d' %self.mFromSeries)
			req.append('%d' %self.mIsToParent)
			req.append('%d' %self.mChildCount)
			req.append('%d' %self.mHasDecryptTimer)
			req.append('%d' %self.mScrambled)
			req.append('%d' %self.mAgeLimit)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mType= int(ret[offset])
			offset=offset+1
			self.mIsLocked= int(ret[offset])
			offset=offset+1
			self.mKey= int(ret[offset])
			offset=offset+1
			self.mParentFolder= int(ret[offset])
			offset=offset+1
			self.mName= ret[offset]
			offset=offset+1
			self.mStartTime= int(ret[offset])
			offset=offset+1
			self.mDuration= int(ret[offset])
			offset=offset+1
			self.mChannelNumber= int(ret[offset])
			offset=offset+1
			self.mServiceType= int(ret[offset])
			offset=offset+1
			self.mChannelName= ret[offset]
			offset=offset+1
			self.mGenre= int(ret[offset])
			offset=offset+1
			self.mPlayedCount= int(ret[offset])
			offset=offset+1
			self.mLastWatchedTime= int(ret[offset])
			offset=offset+1
			self.mUserPriority= int(ret[offset])
			offset=offset+1
			self.mTimerId= int(ret[offset])
			offset=offset+1
			self.mFromSeries= int(ret[offset])
			offset=offset+1
			self.mIsToParent= int(ret[offset])
			offset=offset+1
			self.mChildCount= int(ret[offset])
			offset=offset+1
			self.mHasDecryptTimer= int(ret[offset])
			offset=offset+1
			self.mScrambled= int(ret[offset])
			offset=offset+1
			self.mAgeLimit= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IRecordItem'
			print 'mType= %d'%self.mType
			print 'mIsLocked= %d'%self.mIsLocked
			print 'mKey= %d'%self.mKey
			print 'mParentFolder= %d'%self.mParentFolder
			print 'mName= %s'%self.mName
			print 'mStartTime= %d'%self.mStartTime
			print 'mDuration= %d'%self.mDuration
			print 'mChannelNumber= %d'%self.mChannelNumber
			print 'mServiceType= %d'%self.mServiceType
			print 'mChannelName= %s'%self.mChannelName
			print 'mGenre= %d'%self.mGenre
			print 'mPlayedCount= %d'%self.mPlayedCount
			print 'mLastWatchedTime= %d'%self.mLastWatchedTime
			print 'mUserPriority= %d'%self.mUserPriority
			print 'mTimerId= %d'%self.mTimerId
			print 'mFromSeries= %d'%self.mFromSeries
			print 'mIsToParent= %d'%self.mIsToParent
			print 'mChildCount= %d'%self.mChildCount
			print 'mHasDecryptTimer= %d'%self.mHasDecryptTimer
			print 'mScrambled= %d'%self.mScrambled
			print 'mAgeLimit= %d'%self.mAgeLimit

class ElisIOTRInfo( ElisClass ): 
		""" 
		ElisIOTRInfo On Time Record Information\n
		\brief On Time Record Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mHasEPG	Timer ID
		Integer	mEventStartTime	Event Start Time
		Integer	mEventEndTime	Event End Time
		Integer	mEventPassedSeconds	Event Passed Second
		Integer	mExpectedRecordDuration	Expected Record Duration
		String	mEventName	Event Name
		Integer	mSid	Service ID
		Integer	mTsid	Transport Stream ID
		Integer	mOnid	Original Network ID
		Integer	mEventId	Event ID
		Integer	mTimeshiftAvailable	Timeshift Avalable : true or false
		Integer	mTimeshiftRecordMs	Timeshift Record Time : (ms)

		"""

		def __init__(self, amHasEPG = 0 ,amEventStartTime = 0 ,amEventEndTime = 0 ,amEventPassedSeconds = 0 ,amExpectedRecordDuration = 0 ,amEventName = "No EventName" ,amSid = 0 ,amTsid = 0 ,amOnid = 0 ,amEventId = 0 ,amTimeshiftAvailable = 0 ,amTimeshiftRecordMs = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Timer ID
			###
			self.mHasEPG= amHasEPG

			### 
			# Type: Integer, Event Start Time
			###
			self.mEventStartTime= amEventStartTime

			### 
			# Type: Integer, Event End Time
			###
			self.mEventEndTime= amEventEndTime

			### 
			# Type: Integer, Event Passed Second
			###
			self.mEventPassedSeconds= amEventPassedSeconds

			### 
			# Type: Integer, Expected Record Duration
			###
			self.mExpectedRecordDuration= amExpectedRecordDuration

			### 
			# Type: String, Event Name
			###
			self.mEventName= amEventName

			### 
			# Type: Integer, Service ID
			###
			self.mSid= amSid

			### 
			# Type: Integer, Transport Stream ID
			###
			self.mTsid= amTsid

			### 
			# Type: Integer, Original Network ID
			###
			self.mOnid= amOnid

			### 
			# Type: Integer, Event ID
			###
			self.mEventId= amEventId

			### 
			# Type: Integer, Timeshift Avalable : true or false
			###
			self.mTimeshiftAvailable= amTimeshiftAvailable

			### 
			# Type: Integer, Timeshift Record Time : (ms)
			###
			self.mTimeshiftRecordMs= amTimeshiftRecordMs

		def reset(self):
			"""
				Reset to default value
			"""
			self.mHasEPG= 0
			self.mEventStartTime= 0
			self.mEventEndTime= 0
			self.mEventPassedSeconds= 0
			self.mExpectedRecordDuration= 0
			self.mEventName= "No EventName"
			self.mSid= 0
			self.mTsid= 0
			self.mOnid= 0
			self.mEventId= 0
			self.mTimeshiftAvailable= 0
			self.mTimeshiftRecordMs= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mHasEPG)
			req.append('%d' %self.mEventStartTime)
			req.append('%d' %self.mEventEndTime)
			req.append('%d' %self.mEventPassedSeconds)
			req.append('%d' %self.mExpectedRecordDuration)
			req.append(self.mEventName)
			req.append('%d' %self.mSid)
			req.append('%d' %self.mTsid)
			req.append('%d' %self.mOnid)
			req.append('%d' %self.mEventId)
			req.append('%d' %self.mTimeshiftAvailable)
			req.append('%d' %self.mTimeshiftRecordMs)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mHasEPG= int(ret[offset])
			offset=offset+1
			self.mEventStartTime= int(ret[offset])
			offset=offset+1
			self.mEventEndTime= int(ret[offset])
			offset=offset+1
			self.mEventPassedSeconds= int(ret[offset])
			offset=offset+1
			self.mExpectedRecordDuration= int(ret[offset])
			offset=offset+1
			self.mEventName= ret[offset]
			offset=offset+1
			self.mSid= int(ret[offset])
			offset=offset+1
			self.mTsid= int(ret[offset])
			offset=offset+1
			self.mOnid= int(ret[offset])
			offset=offset+1
			self.mEventId= int(ret[offset])
			offset=offset+1
			self.mTimeshiftAvailable= int(ret[offset])
			offset=offset+1
			self.mTimeshiftRecordMs= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IOTRInfo'
			print 'mHasEPG= %d'%self.mHasEPG
			print 'mEventStartTime= %d'%self.mEventStartTime
			print 'mEventEndTime= %d'%self.mEventEndTime
			print 'mEventPassedSeconds= %d'%self.mEventPassedSeconds
			print 'mExpectedRecordDuration= %d'%self.mExpectedRecordDuration
			print 'mEventName= %s'%self.mEventName
			print 'mSid= %d'%self.mSid
			print 'mTsid= %d'%self.mTsid
			print 'mOnid= %d'%self.mOnid
			print 'mEventId= %d'%self.mEventId
			print 'mTimeshiftAvailable= %d'%self.mTimeshiftAvailable
			print 'mTimeshiftRecordMs= %d'%self.mTimeshiftRecordMs

class ElisITimer( ElisClass ): 
		""" 
		ElisITimer Timer Information\n
		\brief Timer Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mTimerId	Timer ID
		Integer	mTimerType	Timer Type : E_ITIMER_INVLID, E_TIMER_MANUAL, E_TIMER_WEEKLY, E_TIMER_EPG, E_TIMER_CRID, E_TIMER_CRID_SERIES, E_TIMER_KEYWORD
		Integer	mChannelNo	Channel Number for Timer
		Integer	mServiceType	Service Type:E_SERVICE_TYPE_TV, E_SERVICE_TYPE_RADIO
		Integer	mSid	Service ID
		Integer	mTsid	Transport Stream ID
		Integer	mOnid	Original Network ID
		Integer	mEventId	Event ID
		Integer	mFromEPG	From EPG
		Integer	mStartTime	Start Time
		Integer	mDuration	Duration
		Integer	mIsRepeated	Is Repeated ?
		Integer	mRepeatInterval	Repeat Interval
		Integer	mForceDecrypt	ForceDecrypt
		String	mName	Name
		Integer	mRecordKey	Record Key
		Integer	mRecordStartedTime	Record Started Time
		Integer	mPriority	Priority
		Integer	mWeeklyTimerCount	Weekly Timer Count
		ElisIWeeklyTimer	mWeeklyTimer	

		"""

		def __init__(self): 
			print 'init'
	
		def reset(self):
			print 'reset'
	
		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			ElisClassCustom.appendITimer(self, req)
	
		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			ElisClassCustom.parseITimer(self, ret, offset)
	
			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ITimer'
			ElisClassCustom.debugprintITimer(self)
	
class ElisESystemVersion( ElisClass ): 
		""" 
		ElisESystemVersion System Version\n
		\brief System Version\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mHwVersion	HW Version
		Integer	mSwVersion	SW Version
		String	mBeta_code	Beta Code

		"""

		def __init__(self, amHwVersion = 0 ,amSwVersion = 0 ,amBeta_code = "NO Code"):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, HW Version
			###
			self.mHwVersion= amHwVersion

			### 
			# Type: Integer, SW Version
			###
			self.mSwVersion= amSwVersion

			### 
			# Type: String, Beta Code
			###
			self.mBeta_code= amBeta_code

		def reset(self):
			"""
				Reset to default value
			"""
			self.mHwVersion= 0
			self.mSwVersion= 0
			self.mBeta_code= "NO Code"

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mHwVersion)
			req.append('%d' %self.mSwVersion)
			req.append(self.mBeta_code)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mHwVersion= int(ret[offset])
			offset=offset+1
			self.mSwVersion= int(ret[offset])
			offset=offset+1
			self.mBeta_code= ret[offset]
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ESystemVersion'
			print 'mHwVersion= %d'%self.mHwVersion
			print 'mSwVersion= %d'%self.mSwVersion
			print 'mBeta_code= %s'%self.mBeta_code

class ElisITIMEREPGOffset( ElisClass ): 
		""" 
		ElisITIMEREPGOffset Timer EPG Offset\n
		\brief Timer EPG Offset\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mStartOffset	Start Offset
		Integer	mEndOffset	End Offset

		"""

		def __init__(self, amStartOffset = 0 ,amEndOffset = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Start Offset
			###
			self.mStartOffset= amStartOffset

			### 
			# Type: Integer, End Offset
			###
			self.mEndOffset= amEndOffset

		def reset(self):
			"""
				Reset to default value
			"""
			self.mStartOffset= 0
			self.mEndOffset= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mStartOffset)
			req.append('%d' %self.mEndOffset)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mStartOffset= int(ret[offset])
			offset=offset+1
			self.mEndOffset= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ITIMEREPGOffset'
			print 'mStartOffset= %d'%self.mStartOffset
			print 'mEndOffset= %d'%self.mEndOffset

class ElisICICAM( ElisClass ): 
		""" 
		ElisICICAM CICAM Name\n
		\brief CICAM Name\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		String	mName	CICAM Name

		"""

		def __init__(self, amName = "No Name"):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: String, CICAM Name
			###
			self.mName= amName

		def reset(self):
			"""
				Reset to default value
			"""
			self.mName= "No Name"

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append(self.mName)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mName= ret[offset]
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ICICAM'
			print 'mName= %s'%self.mName

class ElisCIMMIEnqData( ElisClass ): 
		""" 
		ElisCIMMIEnqData CI MMI Enq Data\n
		\brief CI MMI Enq Data\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mSlotNo	Slot Number
		Integer	mBlindAnswer	Blind Answer
		Integer	mAnswerTextLen	Answer Text Len
		String	mText	Text

		"""

		def __init__(self, amSlotNo = 0 ,amBlindAnswer = 0 ,amAnswerTextLen = 0 ,amText = "No Test"):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Slot Number
			###
			self.mSlotNo= amSlotNo

			### 
			# Type: Integer, Blind Answer
			###
			self.mBlindAnswer= amBlindAnswer

			### 
			# Type: Integer, Answer Text Len
			###
			self.mAnswerTextLen= amAnswerTextLen

			### 
			# Type: String, Text
			###
			self.mText= amText

		def reset(self):
			"""
				Reset to default value
			"""
			self.mSlotNo= 0
			self.mBlindAnswer= 0
			self.mAnswerTextLen= 0
			self.mText= "No Test"

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mSlotNo)
			req.append('%d' %self.mBlindAnswer)
			req.append('%d' %self.mAnswerTextLen)
			req.append(self.mText)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mSlotNo= int(ret[offset])
			offset=offset+1
			self.mBlindAnswer= int(ret[offset])
			offset=offset+1
			self.mAnswerTextLen= int(ret[offset])
			offset=offset+1
			self.mText= ret[offset]
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  CIMMIEnqData'
			print 'mSlotNo= %d'%self.mSlotNo
			print 'mBlindAnswer= %d'%self.mBlindAnswer
			print 'mAnswerTextLen= %d'%self.mAnswerTextLen
			print 'mText= %s'%self.mText

class ElisCIMMIMenuData( ElisClass ): 
		""" 
		ElisCIMMIMenuData CI MMI Menu Data\n
		\brief CI MMI Menu Data\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mSlotNo	Slot Number
		String	mTitle	Title
		String	mSubtitle	Subtitle
		String	mBottom	Bottom
		Integer	mItemCount	CIMMIMenuDataItem Count
		ElisCIMMIMenuDataItem	mItems	CIMMIMenuDataItem

		"""

		def __init__(self): 
			print 'init'
	
		def reset(self):
			print 'reset'
	
		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			ElisClassCustom.appendCIMMIMenuData(self, req)
	
		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			ElisClassCustom.parseCIMMIMenuData(self, ret, offset)
	
			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  CIMMIMenuData'
			ElisClassCustom.debugprintCIMMIMenuData(self)
	
class ElisIRecordNavigation( ElisClass ): 
		""" 
		ElisIRecordNavigation Record Navigation\n
		\brief Record Navigation\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mMode	Mode : E_NAV_TYPE_ALL, E_NAV_TYPE_FOLDER, E_NAV_TYPE_PSEUDO_FOLDER, E_NAV_TYPE_PRIORITY
		Integer	mSortType	SortType : E_SORT_BY_TITLE, E_SORT_BY_DATE, E_SORT_BY_CHANNEL, E_SORT_BY_DURATION, E_SORT_BY_TIMER
		Integer	mServiceType	Service Type
		ElisPseudoFolder	mPFolder	Pseudo Folder Information
		ElisPriority	mPriority	Priority Folder Information
		ElisUserFolder	mUserFolder	User Folder Information

		"""

		def __init__(self): 
			print 'init'
	
		def reset(self):
			print 'reset'
	
		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			ElisClassCustom.appendIRecordNavigation(self, req)
	
		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			ElisClassCustom.parseIRecordNavigation(self, ret, offset)
	
			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IRecordNavigation'
			ElisClassCustom.debugprintIRecordNavigation(self)
	
class ElisESubtitle( ElisClass ): 
		""" 
		ElisESubtitle Subtitle Id\n
		\brief Subtitle Id\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mPid	Program ID
		Integer	mPageId	Page ID
		Integer	mSubId	Subtitle ID

		"""

		def __init__(self, amPid = 0 ,amPageId = 0 ,amSubId = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Program ID
			###
			self.mPid= amPid

			### 
			# Type: Integer, Page ID
			###
			self.mPageId= amPageId

			### 
			# Type: Integer, Subtitle ID
			###
			self.mSubId= amSubId

		def reset(self):
			"""
				Reset to default value
			"""
			self.mPid= 0
			self.mPageId= 0
			self.mSubId= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mPid)
			req.append('%d' %self.mPageId)
			req.append('%d' %self.mSubId)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mPid= int(ret[offset])
			offset=offset+1
			self.mPageId= int(ret[offset])
			offset=offset+1
			self.mSubId= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ESubtitle'
			print 'mPid= %d'%self.mPid
			print 'mPageId= %d'%self.mPageId
			print 'mSubId= %d'%self.mSubId

class ElisIRecordPartitionInfo( ElisClass ): 
		""" 
		ElisIRecordPartitionInfo Record Partition Inof\n
		\brief Record Partition Inof\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mIndex	Index
		String	mName	Partition Name/
		String	mMountPoint	Mount Point
		String	mDeviceName	Device Name
		Integer	mTotalSizeInMB	Total Size In MB
		Integer	mFreeSizeInMB	Free Size in MB
		Integer	mReadOnly	Read Only Flag
		String	mFileSystemName	FileSystem Name
		String	mUuid	Uuid
		Integer	mIsDedicatedHDD	Is Dedicated HDD
		Integer	mDedicatedPartitionType	Dedicated Partition Type
		Integer	mIsRecordable	Is Recordable

		"""

		def __init__(self, amIndex = 0 ,amName = "No Name" ,amMountPoint = "root" ,amDeviceName = "HDD" ,amTotalSizeInMB = 0 ,amFreeSizeInMB = 0 ,amReadOnly = 0 ,amFileSystemName = "EXT3" ,amUuid = "Uuid" ,amIsDedicatedHDD = 0 ,amDedicatedPartitionType = 0 ,amIsRecordable = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Index
			###
			self.mIndex= amIndex

			### 
			# Type: String, Partition Name/
			###
			self.mName= amName

			### 
			# Type: String, Mount Point
			###
			self.mMountPoint= amMountPoint

			### 
			# Type: String, Device Name
			###
			self.mDeviceName= amDeviceName

			### 
			# Type: Integer, Total Size In MB
			###
			self.mTotalSizeInMB= amTotalSizeInMB

			### 
			# Type: Integer, Free Size in MB
			###
			self.mFreeSizeInMB= amFreeSizeInMB

			### 
			# Type: Integer, Read Only Flag
			###
			self.mReadOnly= amReadOnly

			### 
			# Type: String, FileSystem Name
			###
			self.mFileSystemName= amFileSystemName

			### 
			# Type: String, Uuid
			###
			self.mUuid= amUuid

			### 
			# Type: Integer, Is Dedicated HDD
			###
			self.mIsDedicatedHDD= amIsDedicatedHDD

			### 
			# Type: Integer, Dedicated Partition Type
			###
			self.mDedicatedPartitionType= amDedicatedPartitionType

			### 
			# Type: Integer, Is Recordable
			###
			self.mIsRecordable= amIsRecordable

		def reset(self):
			"""
				Reset to default value
			"""
			self.mIndex= 0
			self.mName= "No Name"
			self.mMountPoint= "root"
			self.mDeviceName= "HDD"
			self.mTotalSizeInMB= 0
			self.mFreeSizeInMB= 0
			self.mReadOnly= 0
			self.mFileSystemName= "EXT3"
			self.mUuid= "Uuid"
			self.mIsDedicatedHDD= 0
			self.mDedicatedPartitionType= 0
			self.mIsRecordable= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mIndex)
			req.append(self.mName)
			req.append(self.mMountPoint)
			req.append(self.mDeviceName)
			req.append('%d' %self.mTotalSizeInMB)
			req.append('%d' %self.mFreeSizeInMB)
			req.append('%d' %self.mReadOnly)
			req.append(self.mFileSystemName)
			req.append(self.mUuid)
			req.append('%d' %self.mIsDedicatedHDD)
			req.append('%d' %self.mDedicatedPartitionType)
			req.append('%d' %self.mIsRecordable)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mIndex= int(ret[offset])
			offset=offset+1
			self.mName= ret[offset]
			offset=offset+1
			self.mMountPoint= ret[offset]
			offset=offset+1
			self.mDeviceName= ret[offset]
			offset=offset+1
			self.mTotalSizeInMB= int(ret[offset])
			offset=offset+1
			self.mFreeSizeInMB= int(ret[offset])
			offset=offset+1
			self.mReadOnly= int(ret[offset])
			offset=offset+1
			self.mFileSystemName= ret[offset]
			offset=offset+1
			self.mUuid= ret[offset]
			offset=offset+1
			self.mIsDedicatedHDD= int(ret[offset])
			offset=offset+1
			self.mDedicatedPartitionType= int(ret[offset])
			offset=offset+1
			self.mIsRecordable= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  IRecordPartitionInfo'
			print 'mIndex= %d'%self.mIndex
			print 'mName= %s'%self.mName
			print 'mMountPoint= %s'%self.mMountPoint
			print 'mDeviceName= %s'%self.mDeviceName
			print 'mTotalSizeInMB= %d'%self.mTotalSizeInMB
			print 'mFreeSizeInMB= %d'%self.mFreeSizeInMB
			print 'mReadOnly= %d'%self.mReadOnly
			print 'mFileSystemName= %s'%self.mFileSystemName
			print 'mUuid= %s'%self.mUuid
			print 'mIsDedicatedHDD= %d'%self.mIsDedicatedHDD
			print 'mDedicatedPartitionType= %d'%self.mDedicatedPartitionType
			print 'mIsRecordable= %d'%self.mIsRecordable

class ElisCAInfo( ElisClass ): 
		""" 
		ElisCAInfo CAS Information\n
		\brief CAS Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mCASystemId	CAS ID

		"""

		def __init__(self, amCASystemId = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, CAS ID
			###
			self.mCASystemId= amCASystemId

		def reset(self):
			"""
				Reset to default value
			"""
			self.mCASystemId= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mCASystemId)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mCASystemId= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  CAInfo'
			print 'mCASystemId= %d'%self.mCASystemId

class ElisESInfo( ElisClass ): 
		""" 
		ElisESInfo Elementary Stream Information\n
		\brief Elementary Stream Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mIndex	Index
		Integer	mPid	Pid
		Integer	mStreamType	Stream Type
		Integer	mComponentTag	Component Tag
		Integer	mSubtitleType	Subtitle Type
		Integer	mAudioStreamType	Audio Stream Type
		Integer	mLanguageCount	Language Count
		ElisElisISO639Lang	mISO639Lang	Language Information

		"""

		def __init__(self): 
			print 'init'
	
		def reset(self):
			print 'reset'
	
		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			ElisClassCustom.appendESInfo(self, req)
	
		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			ElisClassCustom.parseESInfo(self, ret, offset)
	
			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  ESInfo'
			ElisClassCustom.debugprintESInfo(self)
	
class ElisEConaxInfo( ElisClass ): 
		""" 
		ElisEConaxInfo Elementary Stream Information\n
		\brief Elementary Stream Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		String	sw_version	SW Version
		String	if_version	IF Version
		String	card_number	Card Number
		String	recv_number	Recv Number
		Integer	number_session	Number Seeion
		Integer	lang	Language Information
		String	ca_sys_id	CA SYS ID

		"""

		def __init__(self, asw_version = "No Version" ,aif_version = "No Version" ,acard_number = "No Number" ,arecv_number = "No Number" ,anumber_session = 0 ,alang = 0 ,aca_sys_id = "No Number"):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: String, SW Version
			###
			self.sw_version= asw_version

			### 
			# Type: String, IF Version
			###
			self.if_version= aif_version

			### 
			# Type: String, Card Number
			###
			self.card_number= acard_number

			### 
			# Type: String, Recv Number
			###
			self.recv_number= arecv_number

			### 
			# Type: Integer, Number Seeion
			###
			self.number_session= anumber_session

			### 
			# Type: Integer, Language Information
			###
			self.lang= alang

			### 
			# Type: String, CA SYS ID
			###
			self.ca_sys_id= aca_sys_id

		def reset(self):
			"""
				Reset to default value
			"""
			self.sw_version= "No Version"
			self.if_version= "No Version"
			self.card_number= "No Number"
			self.recv_number= "No Number"
			self.number_session= 0
			self.lang= 0
			self.ca_sys_id= "No Number"

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append(self.sw_version)
			req.append(self.if_version)
			req.append(self.card_number)
			req.append(self.recv_number)
			req.append('%d' %self.number_session)
			req.append('%d' %self.lang)
			req.append(self.ca_sys_id)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.sw_version= ret[offset]
			offset=offset+1
			self.if_version= ret[offset]
			offset=offset+1
			self.card_number= ret[offset]
			offset=offset+1
			self.recv_number= ret[offset]
			offset=offset+1
			self.number_session= int(ret[offset])
			offset=offset+1
			self.lang= int(ret[offset])
			offset=offset+1
			self.ca_sys_id= ret[offset]
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  EConaxInfo'
			print 'sw_version= %s'%self.sw_version
			print 'if_version= %s'%self.if_version
			print 'card_number= %s'%self.card_number
			print 'recv_number= %s'%self.recv_number
			print 'number_session= %d'%self.number_session
			print 'lang= %d'%self.lang
			print 'ca_sys_id= %s'%self.ca_sys_id

class ElisEInteger( ElisClass ): 
		""" 
		ElisEInteger Integer Value\n
		\brief Integer Value\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mParam	Integer Value

		"""

		def __init__(self, amParam = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Integer Value
			###
			self.mParam= amParam

		def reset(self):
			"""
				Reset to default value
			"""
			self.mParam= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mParam)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mParam= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  EInteger'
			print 'mParam= %d'%self.mParam

class ElisEChar( ElisClass ): 
		""" 
		ElisEChar Char Value\n
		\brief Char Value\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		String	mParam	Char Value

		"""

		def __init__(self, amParam = "None"):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: String, Char Value
			###
			self.mParam= amParam

		def reset(self):
			"""
				Reset to default value
			"""
			self.mParam= "None"

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append(self.mParam)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mParam= ret[offset]
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  EChar'
			print 'mParam= %s'%self.mParam

class ElisEBookmark( ElisClass ): 
		""" 
		ElisEBookmark BookMark Information\n
		\brief BookMark Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mTimeMs	Position Time(MS)
		Integer	mOffset	Position Offset

		"""

		def __init__(self, amTimeMs = 0 ,amOffset = 0):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Position Time(MS)
			###
			self.mTimeMs= amTimeMs

			### 
			# Type: Integer, Position Offset
			###
			self.mOffset= amOffset

		def reset(self):
			"""
				Reset to default value
			"""
			self.mTimeMs= 0
			self.mOffset= 0

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mTimeMs)
			req.append('%d' %self.mOffset)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mTimeMs= int(ret[offset])
			offset=offset+1
			self.mOffset= int(ret[offset])
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  EBookmark'
			print 'mTimeMs= %d'%self.mTimeMs
			print 'mOffset= %d'%self.mOffset

class ElisPropertyEnumValue( ElisClass ): 
		""" 
		ElisPropertyEnumValue PropertyValue Information\n
		\brief PropertyValue Information\n
		ElisInterface Classes for Python UI\n
		ElisCommand Interface Classes\n
		This Class describes all structure of Python UI.\n
		All functions of this class have it's equavalent functions in M/W on C++\n

		"""	

		"""
		Integer	mValue	Property Value
		String	mString	Property String

		"""

		def __init__(self, amValue = 0 ,amString = "0"):
			"""
				Constructor
			@param self : self
			@return NULL
			"""

			### 
			# Type: Integer, Property Value
			###
			self.mValue= amValue

			### 
			# Type: String, Property String
			###
			self.mString= amString

		def reset(self):
			"""
				Reset to default value
			"""
			self.mValue= 0
			self.mString= "0"

		def appendReqBuffer(self, req ):
			"""
				Append Data to request buffer.
			"""
			req.append('%d' %self.mValue)
			req.append(self.mString)

		def parseReturnBuffer(self, ret, offset=0):
			"""
				Parse Returned Buffer to Class Data to request buffer.
			@param ret	return array.
			@param offset Integer offset value of ret buffer
			@return Integer return curretn buffer offset to use resusive class in class
			"""
			self.mValue= int(ret[offset])
			offset=offset+1
			self.mString= ret[offset]
			offset=offset+1

			return offset

		def printdebug( self ):
			"""
				Print Debug.
			"""
			print 'Class  PropertyEnumValue'
			print 'mValue= %d'%self.mValue
			print 'mString= %s'%self.mString
