from ElisClassSub import *
from ElisEnum import ElisEnum

class ElisClassCustom(object):
	def appendIRecordNavigation(self, req ):
		req.append('%d' %self.mMode)
		req.append('%d' %self.mSortType)
		req.append('%d' %self.mServiceType)
		if self.mMode == ElisEnum.E_NAV_TYPE_FOLDER:
			self.mUserFolder.appendReqBuffer(req)
		elif self.mMode == ElisEnum.E_NAV_TYPE_PRIORITY:
			self.mPriority.appendReqBuffer(req)
		elif self.mMode == ElisEnum.E_NAV_TYPE_PSEUDO_FOLDER:
			self.mPFolder.appendReqBuffer(req)
		else:
			print 'E_NAV_TYPE_ALL'
	
		print 'appendIRecordNavigation'

	def parseIRecordNavigation(self, ret, offset ):
		self.mMode= int(ret[offset])
		offset=offset+1
		self.mSortType= int(ret[offset])
		offset=offset+1
		self.mServiceType= int(ret[offset])
		offset=offset+1
		if self.mMode == ElisEnum.E_NAV_TYPE_FOLDER:
			self.mUserFolder = ElisUserFolder()
			offset = self.mUserFolder.parseReturnBuffer( ret, offset )
		elif self.mMode == ElisEnum.E_NAV_TYPE_PRIORITY:
			self.mPriority = ElisPriority()
			offset = self.mPriority.parseReturnBuffer( ret, offset )
		elif self.mMode == ElisEnum.E_NAV_TYPE_PSEUDO_FOLDER:
			self.mPFolder =ElisPseudoFolder()
			offset = self.mPFolder.parseReturnBuffer( ret, offset )
		else:
			print 'E_NAV_TYPE_ALL'

		print 'parseIRecordNavigation'
		return offset

	def debugprintIRecordNavigation(self):
		print 'debugprintIRecordNavigation'
		print 'Class  RecordNavigation'
		print 'mMode= %d'%self.mMode
		print 'mSortType= %d'%self.mSortType
		print 'mServiceType= %d'%self.mServiceType		
		if self.mMode == ElisEnum.E_NAV_TYPE_FOLDER:
			print 'mUserFolder=' 
			#self.mUserFolder = ElisUserFolder()
			self.mUserFolder.printdebug()
		elif self.mMode == ElisEnum.E_NAV_TYPE_PRIORITY:
			print 'mPriority=' 
			#self.mPriority = ElisPriority()
			self.mPriority.printdebug()
		elif self.mMode == ElisEnum.E_NAV_TYPE_PSEUDO_FOLDER:
			print 'mPFolder=' 
			#self.mPFolder =ElisPseudoFolder()
			self.mPFolder.printdebug()
		else:
			print 'E_NAV_TYPE_ALL'

	appendIRecordNavigation = staticmethod(appendIRecordNavigation)	
	parseIRecordNavigation = staticmethod(parseIRecordNavigation)	
	debugprintIRecordNavigation = staticmethod(debugprintIRecordNavigation)	

	def appendITimer(self, req):
		"""
			Append Data to request buffer.
		"""
		req.append('%d' %self.mTimerId)
		req.append('%d' %self.mTimerType)
		req.append('%d' %self.mChannelNo)
		req.append('%d' %self.mServiceType)
		req.append('%d' %self.mSid)
		req.append('%d' %self.mTsid)
		req.append('%d' %self.mOnid)
		req.append('%d' %self.mEventId)
		req.append('%d' %self.mFromEPG)
		req.append('%d' %self.mStartTime)
		req.append('%d' %self.mDuration)
		req.append('%d' %self.mIsRepeated)
		req.append('%d' %self.mRepeatInterval)
		req.append('%d' %self.mForceDecrypt)
		req.append(self.mName)
		req.append('%d' %self.mRecordKey)
		req.append('%d' %self.mRecordStartedTime)
		req.append('%d' %self.mPriority)
		req.append('%d' %self.mWeeklyTimerCount)
		self.mWeeklyTimer = []		
		for i in range( self.mWeeklyTimerCount) :
			self.mWeeklyTimer.append( ElisIWeeklyTimer())
			self.mWeeklyTimer[i].appendReqBuffer( req )
			mWeeklyTimer.append(mWeekly[i])

	def parseITimer(self, ret, offset):
		"""
			Parse Returned Buffer to Class Data to request buffer.
		@param ret	return array.
		@param offset Integer offset value of ret buffer
		@return Integer return curretn buffer offset to use resusive class in class
		"""
		self.mTimerId= int(ret[offset])
		offset=offset+1
		self.mTimerType= int(ret[offset])
		offset=offset+1
		self.mChannelNo= int(ret[offset])
		offset=offset+1
		self.mServiceType= int(ret[offset])
		offset=offset+1
		self.mSid= int(ret[offset])
		offset=offset+1
		self.mTsid= int(ret[offset])
		offset=offset+1
		self.mOnid= int(ret[offset])
		offset=offset+1
		self.mEventId= int(ret[offset])
		offset=offset+1
		self.mFromEPG= int(ret[offset])
		offset=offset+1
		self.mStartTime= int(ret[offset])
		offset=offset+1
		self.mDuration= int(ret[offset])
		offset=offset+1
		self.mIsRepeated= int(ret[offset])
		offset=offset+1
		self.mRepeatInterval= int(ret[offset])
		offset=offset+1
		self.mForceDecrypt= int(ret[offset])
		offset=offset+1
		self.mName= ret[offset]
		offset=offset+1
		self.mRecordKey= int(ret[offset])
		offset=offset+1
		self.mRecordStartedTime= int(ret[offset])
		offset=offset+1
		self.mPriority= int(ret[offset])
		offset=offset+1
		self.mWeeklyTimerCount= int(ret[offset])
		offset=offset+1
		self.mWeeklyTimer= []
		for i in range( self.mWeeklyTimerCount) :
			self.mWeeklyTimer.append( ElisIWeeklyTimer())
			self.mWeeklyTimer[i].parseReturnBuffer( ret, offset )		
			offset = offset +3


		return offset		

	def debugprintITimer(self):
		"""
			Print Debug.
		"""
		print 'Class  ITimer'
		print 'mTimerId= %d'%self.mTimerId
		print 'mTimerType= %d'%self.mTimerType
		print 'mChannelNo= %d'%self.mChannelNo
		print 'mServiceType= %d'%self.mServiceType
		print 'mSid= %d'%self.mSid
		print 'mTsid= %d'%self.mTsid
		print 'mOnid= %d'%self.mOnid
		print 'mEventId= %d'%self.mEventId
		print 'mFromEPG= %d'%self.mFromEPG
		print 'mStartTime= %d'%self.mStartTime
		print 'mDuration= %d'%self.mDuration
		print 'mIsRepeated= %d'%self.mIsRepeated
		print 'mRepeatInterval= %d'%self.mRepeatInterval
		print 'mForceDecrypt= %d'%self.mForceDecrypt
		print 'mName= %s'%self.mName
		print 'mRecordKey= %d'%self.mRecordKey
		print 'mRecordStartedTime= %d'%self.mRecordStartedTime
		print 'mPriority= %d'%self.mPriority
		print 'mWeeklyTimerCount= %d'%self.mWeeklyTimerCount
		print 'mWeeklyTimer=' 
		for mWeekly in self.mWeeklyTimer :
			mWeekly.printdebug()


	appendITimer = staticmethod(appendITimer)	
	parseITimer = staticmethod(parseITimer)	
	debugprintITimer = staticmethod(debugprintITimer)	


	def appendCIMMIMenuData(self, req):
		print 'appendCIMMIMenuData'

	def parseCIMMIMenuData(self, ret, offset):
		self.mSlotNo= int(ret[offset])
		offset=offset+1		
		self.mTitle= ret[offset]
		offset=offset+1
		self.mSubtitle= ret[offset]
		offset=offset+1
		self.mBottom= ret[offset]
		offset=offset+1
		self.mItemCount= int(ret[offset])
		offset=offset+1
		self.mItems = []
		for i in range( self.mItemCount) :
			self.mItems.append( ElisCIMMIMenuDataItem())
			self.mItems[i].parseReturnBuffer( ret, offset )		
			offset = offset +1

	def debugprintCIMMIMenuData(self):	
		"""
			Print Debug.
		"""
		print 'Class  ITimer'
		print 'mSlotNo= %d'%self.mSlotNo
		print 'mTitle= %s'%self.mTitle
		print 'mSubtitle= %s'%self.mSubtitle
		print 'mBottom= %s'%self.mBottom
		print 'mItemCount= %d'%self.mItemCount
		print 'mItems=' 
		for mText in self.mItems :
			mText.printdebug()


	appendCIMMIMenuData = staticmethod(appendCIMMIMenuData)	
	parseCIMMIMenuData = staticmethod(parseCIMMIMenuData)	
	debugprintCIMMIMenuData = staticmethod(debugprintCIMMIMenuData)	

			
