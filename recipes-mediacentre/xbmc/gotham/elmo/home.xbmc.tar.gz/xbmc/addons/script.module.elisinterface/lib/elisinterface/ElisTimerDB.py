import xbmc
import xbmcgui
import sys
import time
import os
import shutil


from database.Database  import Database
from util.Logger import LOG_TRACE, LOG_WARN, LOG_ERR
from ElisClass import *


DEFAULT_TIMER_DB_PATH = '/tmp/timer.db'


class ElisTimerDB( Database ) :
	def __init__( self, aPath = None ) :
		Database.__init__( self )
		self.mResult = None
		ret = True
		
		if aPath == None :
			ret = self.Open( DEFAULT_TIMER_DB_PATH )
		else :
			ret = self.Open( aPath )

		if ret == False :
			return

		self.Connect( )

	def Timer_GetTimerCount( self ) :
		self.Timer_GetTimerList()

		if self.mResult == None :
			return 0
		else :
			return len(self.mResult)
			

	def Timer_GetById( self, aTimerId ) :
		self.Timer_GetTimerList()
		
		if self.mResult == None :
			return None

		for i in range( len( self.mResult ) ) :
			if self.mResult[i].mTimerId == aTimerId :
				return self.mResult[i]

		return None

		"""
		req = 'SELECT * FROM tblTimer'
		req +=' WHERE TimerId=%d' % aTimerId
		req +=' LIMIT 1'

		reply = self.Execute( req )

		self.mResult = []

		for timer in reply :
			self.Timer_Parse( timer )

		count = len( self.mResult )
		LOG_TRACE( 'count = %d' %count )
		if count <= 0 :
			return None

		return self.mResult[0]
		"""


	def Timer_GetByIndex( self, aIndex ) :
		self.Timer_GetTimerList()
		
		if self.mResult == None :
			return None
		if aIndex >= 0 and aIndex < len( self.mResult ) :
			return self.mResult[aIndex]


	def Timer_GetTimerList( self ) :
		req = 'SELECT * FROM tblTimer'
		reply = self.Execute( req )

		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		self.mResult = []

		for timer in reply :
			self.Timer_Parse( timer )

		count = len( self.mResult )
		if count <= 0 :
			return None

		for timer in self.mResult:
			if timer.mWeeklyTimerCount > 0 :
				timer.mWeeklyTimer = self.Timer_GetWeeklyTimerList( timer.mTimerId )

		"""
		# DEBUG CODE
		for timer in self.mResult:
			timer.printdebug()
			if timer.mWeeklyTimerCount > 0 :
				for weeklyTimer in timer.mWeeklyTimer:
					weeklyTimer.printdebug()
		"""

		return self.mResult


	def Timer_Parse( self, aTimer ) :
		elisTimer = ElisITimer( )
		elisTimer.reset( )
		key										= aTimer[0]
		elisTimer.mTimerId						= aTimer[1]
		elisTimer.mTimerType					= aTimer[2]
		elisTimer.mName							= aTimer[3].encode('utf-8')
		elisTimer.mChannelNo					= aTimer[4]						
		elisTimer.mServiceType					= aTimer[5]
		elisTimer.mSid							= aTimer[6]
		elisTimer.mTsid							= aTimer[7]
		elisTimer.mOnid							= aTimer[8]
		elisTimer.mEventId						= aTimer[9]
		elisTimer.mFromEPG						= aTimer[10]
		elisTimer.mStartTime					= aTimer[11]
		elisTimer.mDuration						= aTimer[12]
		elisTimer.mIsRepeated					= aTimer[13]
		elisTimer.mRepeatInterval				= aTimer[14]
		elisTimer.mForceDecrypt					= aTimer[15]
		elisTimer.mWeeklyTimerCount				= aTimer[16]
		elisTimer.mRecordKey					= aTimer[17]
		elisTimer.mRecordStartedTime			= aTimer[18]
		elisTimer.mPriority						= aTimer[19]
		offset = 20
		elisTimer.mWeeklyTimer= []

		#LOG_TRACE('elisTimer.mWeeklyTimerCount=%d' %elisTimer.mWeeklyTimerCount)
		
		elisTimer.printdebug()
		self.mResult.append( elisTimer )


	def Timer_GetWeeklyTimerList( self, aTimerId ) :
		req = 'SELECT * FROM tblWeeklyTimer'
		req +=' WHERE TimerId=%d' % aTimerId
		reply = self.Execute( req )

		if reply == None :
			LOG_WARN( 'Has no result' )
			return None

		weeklyTimerList = []

		for weeklyTimer in reply :
			weeklyTimerList.append( self.Timer_WeeklyParse( weeklyTimer ) )

		count = len( weeklyTimerList )
		if count <= 0 :
			return None

		return weeklyTimerList


	def Timer_WeeklyParse( self, aWeeklyTimer ) :
		elisWeelyTimer = ElisIWeeklyTimer( )
		key											= aWeeklyTimer[0]
		timerId										= aWeeklyTimer[1]		
		elisWeelyTimer.mDate						= aWeeklyTimer[2]
		elisWeelyTimer.mStartTime					= aWeeklyTimer[3]
		elisWeelyTimer.mDuration					= aWeeklyTimer[4]

		return elisWeelyTimer
