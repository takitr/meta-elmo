from ElisClass import * 


class ElisEventCustom(object):
	def parseElisPMTReceivedEvent(self, ret, offset ):
		'''	
		self.mVersion= int(ret[offset])
		offset=offset+1
		self.mAudioSelectedIndex= int(ret[offset])
		offset=offset+1
		self.mSubtitleSelectedIndex= int(ret[offset])
		offset=offset+1
		self.mPMTSource= int(ret[offset])
		offset=offset+1
		self.mChannelNumber= int(ret[offset])
		offset=offset+1
		self.mServiceType= int(ret[offset])
		offset=offset+1

		self.mVideoCount= int(ret[offset])
		offset=offset+1
		count = 0
		mVS=[]
		self.mVideoStream=[]
		while count < self.mVideoCount
			mVS[count] = ElisESInfo()
			offset = mVS[count].parseReturnBuffer(ret, offset)
			self.mVideoStream.appand(mVS[count])
			count = count+1

		self.mAudioCount= int(ret[offset])
		offset=offset+1
		count = 0
		mAS=[]		
		self.mAudioStream=[]		
		while count < self.mAudioCount
			mAS[count] = ElisESInfo()
			offset = mAS[count].parseReturnBuffer(ret, offset)
			self.mAudioStream.appand(mAS[count])
			count = count+1

		self.mTTXCount= int(ret[offset])
		offset=offset+1
		count = 0
		mTT=[]		
		self.mTTXStream=[]
		while count < self.mTTXCount
			mTT[count] = ElisESInfo()
			offset = mTT[count].parseReturnBuffer(ret, offset)
			self.mTTXStream.appand(mTT[count])
			count = count+1

		self.mSubCount= int(ret[offset])
		offset=offset+1
		count = 0
		mSS=[]		
		self.mSubtitleStream=[]
		while count < self.mSubCount
			mSS[count] = ElisESInfo()
			offset = mSS[count].parseReturnBuffer(ret, offset)
			self.mSubtitleStream.appand(mSS[count])
			count = count+1
		'''			

		
		
		'''		
		for mVStram in ret(self.mVideoCount)
			

		
		
		
		if self.mMode == ElisEnum.E_NAV_TYPE_FOLDER:
			self.mUserFolder = ElisUserFolder()
			offset = self.mUserFolder.parseReturnBuffer( ret, offset )
		elif self.mMode == ElisEnum.E_NAV_TYPE_PRIORITY:
			self.mPriority = ElisPriority()
			offset = self.mPriority.parseReturnBuffer( ret, offset )
		elif self.mMode == ElisEnum.E_NAV_TYPE_PSEUDO_FOLDER:
			self.mPFolder =ElisPseudoFolder()
			offset = self.mPFolder.parseReturnBuffer( ret, offset )
		else:
			print 'E_NAV_TYPE_ALL'




	mMaker.AddSeparator( event->mVersion );
	mMaker.AddSeparator( event->mAudioSelectedIndex );
	mMaker.AddSeparator( event->mSubtitleSelectedIndex );
	mMaker.AddSeparator( event->mPMTSource );
	mMaker.AddSeparator( event->mChannelNumber );
	mMaker.AddSeparator( event->mServiceType );

	mMaker.AddSeparator( event->mVideoCount );
	for(i=0; i < event->mVideoCount; i++)
	{
		mMaker.AddSeparator( event->mVideoStream[i].mIndex );
		mMaker.AddSeparator( event->mVideoStream[i].mPid );
		mMaker.AddSeparator( event->mVideoStream[i].mStreamType );
		mMaker.AddSeparator( event->mVideoStream[i].mComponentTag );

		mMaker.AddSeparator( event->mVideoStream[i].mSubtitleType );
		mMaker.AddSeparator( event->mVideoStream[i].mAudioStreamType );

		mMaker.AddSeparator( event->mVideoStream[i].mLanguageCount );
		for(j=0; j < event->mVideoStream[i].mLanguageCount; j++)
		{
			mMaker.AddSeparator( event->mVideoStream[i].mISO639Lang[j].mLanguageCode );
		}
	}
	
	mMaker.AddSeparator( event->mAudioCount );
	for(i=0; i < event->mAudioCount; i++)
	{
		mMaker.AddSeparator( event->mAudioStream[i].mIndex );
		mMaker.AddSeparator( event->mAudioStream[i].mPid );
		mMaker.AddSeparator( event->mAudioStream[i].mStreamType );
		mMaker.AddSeparator( event->mAudioStream[i].mComponentTag );

		mMaker.AddSeparator( event->mAudioStream[i].mSubtitleType );
		mMaker.AddSeparator( event->mAudioStream[i].mAudioStreamType );

		mMaker.AddSeparator( event->mAudioStream[i].mLanguageCount );
		for(j=0; j < event->mAudioStream[i].mLanguageCount; j++)
		{
			mMaker.AddSeparator( event->mAudioStream[i].mISO639Lang[j].mLanguageCode );
		}
	}

	mMaker.AddSeparator( event->mTTXCount );
	for(i=0; i < event->mTTXCount; i++)
	{
		mMaker.AddSeparator( event->mTTXStream[i].mIndex );
		mMaker.AddSeparator( event->mTTXStream[i].mPid );
		mMaker.AddSeparator( event->mTTXStream[i].mStreamType );
		mMaker.AddSeparator( event->mTTXStream[i].mComponentTag );

		mMaker.AddSeparator( event->mTTXStream[i].mSubtitleType );
		mMaker.AddSeparator( event->mTTXStream[i].mAudioStreamType );

		mMaker.AddSeparator( event->mTTXStream[i].mLanguageCount );
		for(j=0; j < event->mTTXStream[i].mLanguageCount; j++)
		{
			mMaker.AddSeparator( event->mTTXStream[i].mISO639Lang[j].mLanguageCode );
		}
	}

	mMaker.AddSeparator( event->mSubCount );
	for(i=0; i < event->mSubCount; i++)
	{
		mMaker.AddSeparator( event->mSubtitleStream[i].mIndex );
		mMaker.AddSeparator( event->mSubtitleStream[i].mPid );
		mMaker.AddSeparator( event->mSubtitleStream[i].mStreamType );
		mMaker.AddSeparator( event->mSubtitleStream[i].mComponentTag );

		mMaker.AddSeparator( event->mSubtitleStream[i].mSubtitleType );
		mMaker.AddSeparator( event->mSubtitleStream[i].mAudioStreamType );

		mMaker.AddSeparator( event->mSubtitleStream[i].mLanguageCount );
		for(j=0; j < event->mSubtitleStream[i].mLanguageCount; j++)
		{
			mMaker.AddSeparator( event->mSubtitleStream[i].mISO639Lang[j].mLanguageCode );
		}
	}

	mMaker.AddSeparator( event->mCACount );
	for(i=0; i < event->mCACount; i++)
	{
		mMaker.AddSeparator( event->mCAInfo[i].mCASystemId );
	}
		'''	
		print 'ParseElisPMTReceivedEvent'
		return offset

	def debugprintElisPMTReceivedEvent(self):
		print 'debugprintElisPMTReceivedEvent'

	def parseElisEventCIMMIShowMenu(self, ret, offset ):
		self.mSlotNo= int(ret[offset])
		offset=offset+1
		self.mMenuData = ElisCIMMIMenuData()
		offset=self.mMenuData.parseReturnBuffer( ret, offset )

		print 'ParseElisEventCIMMIShowMenu'
		return offset

	def debugprintElisEventCIMMIShowMenu(self):
		print 'mSlotNo = %d'%self.mSlotNo
		self.mMenuData.printdebug()
		print 'debugprintElisEventCIMMIShowMenu'

	parseElisPMTReceivedEvent = staticmethod(parseElisPMTReceivedEvent)	
	debugprintElisPMTReceivedEvent = staticmethod(debugprintElisPMTReceivedEvent)	

	parseElisEventCIMMIShowMenu = staticmethod(parseElisEventCIMMIShowMenu)
	debugprintElisEventCIMMIShowMenu = staticmethod(debugprintElisEventCIMMIShowMenu)

