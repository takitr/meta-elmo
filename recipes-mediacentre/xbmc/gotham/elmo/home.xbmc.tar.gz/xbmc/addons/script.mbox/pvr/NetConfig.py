targetIp			= '127.0.0.1'
myIp				= '127.0.0.1'

receiverPort 		= 54321
commanderPort		= 12345

