/******************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                    */
/*                        SOFTWARE FILE/MODULE HEADER                         */
/*                    Copyright Conexant Systems Inc. 2006                    */
/*                                 Austin, TX                                 */
/*                            All Rights Reserved                             */
/******************************************************************************/
/*
 * Filename:        msr_firmware_pecos.h
 *
 *
 * Description:     Public header file defining firware-specific values (such
 *                  as soft register addresses, bit definitions, etc.) for the
 *                  MPEG Shared RAM (MSR).
 *
 *
 * Author:          Billy Jackman
 *
 ******************************************************************************/
/* $Id: msr.h 180719 2010-11-24 09:46:01Z guduruj $
 ******************************************************************************/

#ifndef _MSR_H_
#define _MSR_H_

/*************************************/
/* MPEG Shared RAM Definitions (MSR) */
/*************************************/

#ifndef __ASSEMBLY__
typedef struct
{
   LPREG  pWrite;
   LPREG  pRead;
   LPREG  pStart;
   LPREG  pEnd;
} TEMPEST_BUF_DESC;
#endif


#define    MPEG_SHARED_RAM_1W     (TEMPEST_COMMON_MAP + 0xC000)
#define    MPEG_SHARED_RAM_2W     (TEMPEST_COMMON_MAP + 0xD000)
#define    MPEG_SHARED_RAM_3W     (TEMPEST_COMMON_MAP + 0xE000)
#define    MPEG_SHARED_RAM_4W     (TEMPEST_COMMON_MAP + 0xF000)
#define    MSR_BASE               MPEG_SHARED_RAM_1W
#define    MSR_SIZE               0x800

#include "hwIpheaders/tmmodIpTsp.h"

/* Table Descriptor offset from the start of ... */
#if (ISAPOLLO)
/* In Kronos, table descriptors offset is from TEMPEST_BASE BASE */
#define SHARED_RAM_START_ADDR     TEMPEST_BASE
#else
/* In Kronos, table descriptors offset is from TSP RAM BASE */
#define SHARED_RAM_START_ADDR     TSP_RAM(0)
#endif



#define MSR_SIGNATURE_REG                                      (MSR_BASE + 0x00)
#define    MSR_SIGNATURE_MASK                                      0xFFFFFFFF
#define    MSR_SIGNATURE_SHIFT                                            0
#define       MSR_SIGNATURE_VALUE                                  0x12EBECCA

#if (ISAPOLLO)
#define IS_TSP_SHARED_RAM_READY()    \
            (CNXT_GET_VAL(MSR_SIGNATURE_REG, MSR_SIGNATURE_MASK) == MSR_SIGNATURE_VALUE)
#else
/* No MSR in Kronos. ES buffer,PTS buffer, audio data buffers are moved to TSP RAM. 
 * TSP unit is always 0 */
#define IS_TSP_SHARED_RAM_READY()    \
            (CNXT_GET_VAL(TSP_PARSER_STATUS_REG(0), TSP_PARSER_STATUS_READY_MASK))
#endif

#define MSR_VERSION_REG                                        (MSR_BASE + 0x04)
#define    MSR_REV_MASK                                            0x0000000F
#define    MSR_REV_SHIFT                                                  0
#define    MSR_MINOR_REV_MASK                                      0x000000F0
#define    MSR_MINOR_REV_SHIFT                                            4
#define    MSR_MAJOR_REV_MASK                                      0x0000FF00
#define    MSR_MAJOR_REV_SHIFT                                            8
#define    MSR_CHIP_VER_REQ_MASK                                   0x00FF0000
#define    MSR_CHIP_VER_REQ_SHIFT                                         16
#define    MSR_UCODE_TYPE_MASK                                     0xFF000000
#define    MSR_UCODE_TYPE_SHIFT                                           24

#define MSR_CAPABILITIES_REG                                   (MSR_BASE + 0x08)
#define    MSR_PCR_TBL_VALID_MASK                                  0x00000001
#define    MSR_PCR_TBL_VALID_SHIFT                                        0
#define       MSR_PCR_TBL_VALID_VALUE                                (1UL<<0)
#define    MSR_PTS_TBL_VALID_MASK                                  0x00000002
#define    MSR_PTS_TBL_VALID_SHIFT                                        1
#define       MSR_PTS_TBL_VALID_VALUE                                (1UL<<1)
#define    MSR_ES_TBL_VALID_MASK                                   0x00000004
#define    MSR_ES_TBL_VALID_SHIFT                                         2
#define       MSR_ES_TBL_VALID_VALUE                                 (1UL<<2)
#define    MSR_USER_DATA_TBL_VALID_MASK                            0x00000008
#define    MSR_USER_DATA_TBL_VALID_SHIFT                                  3
#define       MSR_USER_DATA_TBL_VALID_VALUE                          (1UL<<3)
#define    MSR_ANCILL_DATA_TBL_VALID_MASK                          0x00000010
#define    MSR_ANCILL_DATA_TBL_VALID_SHIFT                                4
#define       MSR_ANCILL_DATA_TBL_VALID_VALUE                        (1UL<<4)

#if (ISAPOLLO)
#define MSR_PCR_TBL_DESC_REG                                   (MSR_BASE + 0x10)
#else
#define MSR_PCR_TBL_DESC_REG                                   (TSP_PCR_TABLE_DESCRIPTOR_REG(0))
#endif
#define    MSR_PCR_TBL_OFFSET_MASK                                  0x0000FFFF
#define    MSR_PCR_TBL_OFFSET_SHIFT                                        0
#define    MSR_PCR_DESC_SIZE_MASK                                   0x00FF0000
#define    MSR_PCR_DESC_SIZE_SHIFT                                        16
#define    MSR_PCR_NO_DESCRIPTORS_MASK                              0xFF000000
#define    MSR_PCR_NO_DESCRIPTORS_SHIFT                                   24

#if (ISAPOLLO)
#define MSR_PTS_TBL_DESC_REG                                   (MSR_BASE + 0x14)
#else
#define MSR_PTS_TBL_DESC_REG                                   (TSP_PTS_BUFFER_TABLE_DESCRIPTOR_REG(0))
#endif
#define    MSR_PTS_TBL_OFFSET_MASK                                  0x0000FFFF
#define    MSR_PTS_TBL_OFFSET_SHIFT                                        0
#define    MSR_PTS_DESC_SIZE_MASK                                   0x00FF0000
#define    MSR_PTS_DESC_SIZE_SHIFT                                        16
#define    MSR_PTS_NO_DESCRIPTORS_MASK                              0xFF000000
#define    MSR_PTS_NO_DESCRIPTORS_SHIFT                                   24

#if (ISAPOLLO)
#define MSR_ES_TBL_DESC_REG                                    (MSR_BASE + 0x18)
#else
#define MSR_ES_TBL_DESC_REG                                    (TSP_ES_BUFFER_TABLE_DESCRIPTOR_REG(0))
#endif
#define    MSR_ES_TBL_OFFSET_MASK                                   0x0000FFFF
#define    MSR_ES_TBL_OFFSET_SHIFT                                         0
#define    MSR_ES_DESC_SIZE_MASK                                    0x00FF0000
#define    MSR_ES_DESC_SIZE_SHIFT                                         16
#define    MSR_ES_NO_DESCRIPTORS_MASK                               0xFF000000
#define    MSR_ES_NO_DESCRIPTORS_SHIFT                                    24

/* AUDIO_DATA_TABLE_DESCRIPTOR */
#if (ISAPOLLO)
#define MSR_USER_DATA_TBL_DESC_REG                             (MSR_BASE + 0x1C)
#else
#define MSR_USER_DATA_TBL_DESC_REG                             (TSP_AUDIO_DATA_TABLE_DESCRIPTOR_REG(0))
#endif
#define    MSR_USER_DATA_TBL_OFFSET_MASK                           0x0000FFFF
#define    MSR_USER_DATA_TBL_OFFSET_SHIFT                                 0
#define    MSR_USER_DATA_DESC_SIZE_MASK                            0x00FF0000
#define    MSR_USER_DATA_DESC_SIZE_SHIFT                                 16
#define    MSR_USER_DATA_NO_DESCRIPTORS_MASK                       0xFF000000
#define    MSR_USER_DATA_NO_DESCRIPTORS_SHIFT                            24

#define MSR_ANCILL_DATA_TBL_DESC_REG                           (MSR_BASE + 0x20)
#define    MSR_ANCILL_DATA_TBL_OFFSET_MASK                         0x0000FFFF
#define    MSR_ANCILL_DATA_TBL_OFFSET_SHIFT                               0
#define    MSR_ANCILL_DATA_DESC_SIZE_MASK                          0x00FF0000
#define    MSR_ANCILL_DATA_DESC_SIZE_SHIFT                               16
#define    MSR_ANCILL_DATA_NO_DESCRIPTORS_MASK                     0xFF000000
#define    MSR_ANCILL_DATA_NO_DESCRIPTORS_SHIFT                          24

/************************************************
 * MSR Buffer Descriptor Definitions and Macros *
 ************************************************/

/* Macro to get Descriptor address of index */
#if (ISAPOLLO)
/* Pass index as 0 to get Table Descriptor Start Address */
#define CNXT_MSR_GET_DESCRIPTOR(table_desc_reg, index)      \
            ((u_int32) (TEMPEST_BASE +                      \
                        CNXT_GET_VAL(table_desc_reg, MSR_ES_TBL_OFFSET_MASK)) +  \
                        (u_int32) (CNXT_GET_VAL(table_desc_reg, MSR_ES_DESC_SIZE_MASK) * index))
#else
/* Pass index as 0 to get Table Descriptor Start Address */
#define CNXT_MSR_GET_DESCRIPTOR(table_desc_reg, index)      \
            ((u_int32) (TSP_RAM(0) +                        \
                        CNXT_GET_VAL(table_desc_reg, MSR_ES_TBL_OFFSET_MASK)) +  \
                        (u_int32) (CNXT_GET_VAL(table_desc_reg, MSR_ES_DESC_SIZE_MASK) * index))
#endif

/* Macro to get Descriptor size */
#define CNXT_MSR_GET_DESCRIPTOR_SIZE(table_desc_reg)        \
            (CNXT_GET_VAL(table_desc_reg, MSR_ES_DESC_SIZE_MASK))

/* Macro to get number of descriptors */
#define CNXT_MSR_GET_NUM_DESCRIPTORS(table_desc_reg)        \
            (CNXT_GET_VAL(table_desc_reg, MSR_ES_NO_DESCRIPTORS_MASK))



#define MSR_BUFF_DESC_WRITE_OFFSET                  (0)          /* The number of words offset this address is from the base of the buffer descriptor */
#define MSR_BUFF_DESC_WRITE_4_BIT_WRAP_MASK         (0x0FFFFFFF) /* Mask for the valid data */
#define MSR_BUFF_DESC_WRITE_2_BIT_WRAP_MASK         (0x3FFFFFFF) /* Mask for the valid data */
#define MSR_BUFF_DESC_READ_OFFSET                   (1)          /* The number of words offset this address is from the base of the buffer descriptor */
#define MSR_BUFF_DESC_READ_4_BIT_WRAP_MASK          (0x0FFFFFFF) /* Mask for the valid data */
#define MSR_BUFF_DESC_READ_2_BIT_WRAP_MASK          (0x3FFFFFFF) /* Mask for the valid data */
#define MSR_BUFF_DESC_START_OFFSET                  (2)          /* The number of words offset this address is from the base of the buffer descriptor */
#define MSR_BUFF_DESC_START_4_BIT_WRAP_MASK         (0x0FFFFFFF) /* Mask for the valid data */
#define MSR_BUFF_DESC_START_2_BIT_WRAP_MASK         (0x3FFFFFFF) /* Mask for the valid data */
#define MSR_BUFF_DESC_END_OFFSET                    (3)          /* The number of words offset this address is from the base of the buffer descriptor */
#define MSR_BUFF_DESC_END_4_BIT_WRAP_MASK           (0x0FFFFFFF) /* Mask for the valid data */
#define MSR_BUFF_DESC_END_2_BIT_WRAP_MASK           (0x3FFFFFFF) /* Mask for the valid data */
#define MSR_BUFF_DESC_WRITE_WRAP_CNT_OFFSET         (0)          /* The number of words offset this address is from the base of the buffer descriptor */
#define MSR_BUFF_DESC_WRITE_4_BIT_WRAP_CNT_MASK     (0xF0000000) /* Mask for the valid data */
#define MSR_BUFF_DESC_WRITE_2_BIT_WRAP_CNT_MASK     (0xC0000000) /* Mask for the valid data */
#define MSR_BUFF_DESC_READ_WRAP_CNT_OFFSET          (1)          /* The number of words offset this address is from the base of the buffer descriptor */
#define MSR_BUFF_DESC_READ_4_BIT_WRAP_CNT_MASK      (0xF0000000) /* Mask for the valid data */
#define MSR_BUFF_DESC_READ_2_BIT_WRAP_CNT_MASK      (0xC0000000) /* Mask for the valid data */
#define MSR_BUFF_DESC_LOW_WATERMARK_OFFSET          (4)          /* The number of words offset this address is from the base of the buffer descriptor */
#define MSR_BUFF_DESC_LOW_WATERMARK_4_BIT_WRAP_MASK (0x0FFFFFFF) /* Mask for the valid data */
#define MSR_BUFF_DESC_LOW_WATERMARK_2_BIT_WRAP_MASK (0x3FFFFFFF) /* Mask for the valid data */
#define MSR_BUFF_DESC_WORD_MASK                     (0xFFFFFFFF) /* Mask for the entire word */
/* Macro:      CNXT_MSR_BUFF_GET_WRITE_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write address of the buffer.                                         */
#define CNXT_MSR_BUFF_GET_4_BIT_WRAP_WRITE_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_OFFSET,MSR_BUFF_DESC_WRITE_4_BIT_WRAP_MASK))
#define CNXT_MSR_BUFF_GET_2_BIT_WRAP_WRITE_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_OFFSET,MSR_BUFF_DESC_WRITE_2_BIT_WRAP_MASK))

/* Macro:      CNXT_MSR_BUFF_SET_WRITE_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write address of this buffer.     */
/* Returns:    Nothing.                                                                 */
#define CNXT_MSR_BUFF_SET_4_BIT_WRAP_WRITE_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_OFFSET,MSR_BUFF_DESC_WRITE_4_BIT_WRAP_MASK,(value)))
#define CNXT_MSR_BUFF_SET_2_BIT_WRAP_WRITE_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_OFFSET,MSR_BUFF_DESC_WRITE_2_BIT_WRAP_MASK,(value)))

/* Macro:      CNXT_MSR_BUFF_SET_WRAP_WRITE_ADDR_AND_WRAP_CNT                           */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write address of this buffer.     */
/*                      wrap_cnt - the new wrap cnt value                               */      
/* Returns:    Nothing.                                                                 */
#define CNXT_MSR_BUFF_SET_4_BIT_WRAP_WRITE_ADDR_AND_WRAP_CNT(buff_desc_addr,value,wrap_cnt) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_OFFSET,(MSR_BUFF_DESC_WORD_MASK),((value) + ((wrap_cnt)<<28))))
#define CNXT_MSR_BUFF_SET_2_BIT_WRAP_WRITE_ADDR_AND_WRAP_CNT(buff_desc_addr,value,wrap_cnt) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_OFFSET,(MSR_BUFF_DESC_WORD_MASK),((value) + ((wrap_cnt)<<30))))

/* Macro:      CNXT_MSR_BUFF_GET_WRITE_ADDR_AND_WRAP_CNT                                */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write address of the buffer including wrap count.                    */
#define CNXT_MSR_BUFF_GET_WRITE_ADDR_AND_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_OFFSET,(MSR_BUFF_DESC_WORD_MASK)))

/* Macro:      CNXT_MSR_BUFF_GET_READ_ADDRESS                                           */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The read address of the buffer.                                          */
#define CNXT_MSR_BUFF_GET_4_BIT_WRAP_READ_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_OFFSET,MSR_BUFF_DESC_READ_4_BIT_WRAP_MASK))
#define CNXT_MSR_BUFF_GET_2_BIT_WRAP_READ_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_OFFSET,MSR_BUFF_DESC_READ_2_BIT_WRAP_MASK))

/* Macro:      CNXT_MSR_BUFF_SET_READ_ADDRESS                                           */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the read address of this buffer.      */
/* Returns:    Nothing.                                                                 */
#define CNXT_MSR_BUFF_SET_4_BIT_WRAP_READ_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_OFFSET,MSR_BUFF_DESC_READ_4_BIT_WRAP_MASK,(value)))
#define CNXT_MSR_BUFF_SET_2_BIT_WRAP_READ_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_OFFSET,MSR_BUFF_DESC_READ_2_BIT_WRAP_MASK,(value)))

/* Macro:      CNXT_MSR_BUFF_GET_START_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The start address of the buffer.                                         */
#define CNXT_MSR_BUFF_GET_4_BIT_WRAP_START_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_START_OFFSET,MSR_BUFF_DESC_START_4_BIT_WRAP_MASK))
#define CNXT_MSR_BUFF_GET_2_BIT_WRAP_START_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_START_OFFSET,MSR_BUFF_DESC_START_2_BIT_WRAP_MASK))

/* Macro:      CNXT_MSR_BUFF_SET_WRAP_READ_ADDR_AND_WRAP_CNT                            */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the read address of this buffer.      */
/*                      wrap_cnt - the new wrap cnt value                               */      
/* Returns:    Nothing.                                                                 */
#define CNXT_MSR_BUFF_SET_4_BIT_WRAP_READ_ADDR_AND_WRAP_CNT(buff_desc_addr,value,wrap_cnt) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_OFFSET,(MSR_BUFF_DESC_WORD_MASK),((value) + ((wrap_cnt)<<28))))
#define CNXT_MSR_BUFF_SET_2_BIT_WRAP_READ_ADDR_AND_WRAP_CNT(buff_desc_addr,value,wrap_cnt) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_OFFSET,(MSR_BUFF_DESC_WORD_MASK),((value) + ((wrap_cnt)<<30))))

/* Macro:      CNXT_MSR_BUFF_GET_READ_ADDR_AND_WRAP_CNT                                */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The read address of the buffer including wrap count.                    */
#define CNXT_MSR_BUFF_GET_READ_ADDR_AND_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_OFFSET,(MSR_BUFF_DESC_WORD_MASK)))

/* Macro:      CNXT_MSR_BUFF_SET_START_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the start address of this buffer.     */
/* Returns:    Nothing.                                                                 */
#define CNXT_MSR_BUFF_SET_4_BIT_WRAP_START_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_START_OFFSET,MSR_BUFF_DESC_START_4_BIT_WRAP_MASK,(value)))
#define CNXT_MSR_BUFF_SET_2_BIT_WRAP_START_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_START_OFFSET,MSR_BUFF_DESC_START_2_BIT_WRAP_MASK,(value)))

/* Macro:      CNXT_MSR_BUFF_GET_END_ADDRESS                                            */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The end address of the buffer.                                           */
#define CNXT_MSR_BUFF_GET_4_BIT_WRAP_END_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_END_OFFSET,MSR_BUFF_DESC_END_4_BIT_WRAP_MASK))
#define CNXT_MSR_BUFF_GET_2_BIT_WRAP_END_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_END_OFFSET,MSR_BUFF_DESC_END_2_BIT_WRAP_MASK))

/* Macro:      CNXT_MSR_BUFF_SET_END_ADDRESS                                            */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the end address of this buffer.       */
/* Returns:    Nothing.                                                                 */
#define CNXT_MSR_BUFF_SET_4_BIT_WRAP_END_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_END_OFFSET,MSR_BUFF_DESC_END_4_BIT_WRAP_MASK,(value)))
#define CNXT_MSR_BUFF_SET_2_BIT_WRAP_END_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_END_OFFSET,MSR_BUFF_DESC_END_2_BIT_WRAP_MASK,(value)))

/* Macro:      CNXT_MSR_BUFF_GET_WRITE_WRAP_CNT                                         */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write wrap count of the buffer.                                      */
#define CNXT_MSR_BUFF_GET_WRITE_4_BIT_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_WRAP_CNT_OFFSET,MSR_BUFF_DESC_WRITE_4_BIT_WRAP_CNT_MASK))
#define CNXT_MSR_BUFF_GET_WRITE_2_BIT_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_WRAP_CNT_OFFSET,MSR_BUFF_DESC_WRITE_2_BIT_WRAP_CNT_MASK))

/* Macro:      CNXT_MSR_BUFF_SET_WRITE_WRAP_CNT                                         */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write wrap count of this buffer.  */
/* Returns:    Nothing.                                                                 */
#define CNXT_MSR_BUFF_SET_WRITE_4_BIT_WRAP_CNT(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_WRAP_CNT_OFFSET,MSR_BUFF_DESC_WRITE_4_BIT_WRAP_CNT_MASK,(value)))
#define CNXT_MSR_BUFF_SET_WRITE_2_BIT_WRAP_CNT(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_WRITE_WRAP_CNT_OFFSET,MSR_BUFF_DESC_WRITE_2_BIT_WRAP_CNT_MASK,(value)))

/* Macro:      CNXT_MSR_BUFF_GET_READ_WRAP_CNT                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The read wrap count of the buffer.                                       */
#define CNXT_MSR_BUFF_GET_READ_4_BIT_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_WRAP_CNT_OFFSET,MSR_BUFF_DESC_READ_4_BIT_WRAP_CNT_MASK))
#define CNXT_MSR_BUFF_GET_READ_2_BIT_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_WRAP_CNT_OFFSET,MSR_BUFF_DESC_READ_2_BIT_WRAP_CNT_MASK))

/* Macro:      CNXT_MSR_BUFF_SET_READ_WRAP_CNT                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the read wrap count of this buffer.   */
/* Returns:    Nothing.                                                                 */
#define CNXT_MSR_BUFF_SET_READ_4_BIT_WRAP_CNT(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_WRAP_CNT_OFFSET,MSR_BUFF_DESC_READ_4_BIT_WRAP_CNT_MASK,(value)))
#define CNXT_MSR_BUFF_SET_READ_2_BIT_WRAP_CNT(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_READ_WRAP_CNT_OFFSET,MSR_BUFF_DESC_READ_2_BIT_WRAP_CNT_MASK,(value)))

/* Macro:      CNXT_MSR_BUFF_GET_LOW_WATERMARK                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The low watermark threshold of the buffer.                               */
#define CNXT_MSR_BUFF_GET_4_BIT_WRAP_LOW_WATERMARK(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_LOW_WATERMARK_OFFSET,MSR_BUFF_DESC_LOW_WATERMARK_4_BIT_WRAP_MASK))
#define CNXT_MSR_BUFF_GET_2_BIT_WRAP_LOW_WATERMARK(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+MSR_BUFF_DESC_LOW_WATERMARK_OFFSET,MSR_BUFF_DESC_LOW_WATERMARK_2_BIT_WRAP_MASK))

/* Macro:      CNXT_MSR_BUFF_SET_LOW_WATERMARK                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the low watermark of this buffer.     */
/* Returns:    Nothing.                                                                 */
#define CNXT_MSR_BUFF_SET_4_BIT_WRAP_LOW_WATERMARK(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_LOW_WATERMARK_OFFSET,MSR_BUFF_DESC_LOW_WATERMARK_4_BIT_WRAP_MASK,(value)))
#define CNXT_MSR_BUFF_SET_2_BIT_WRAP_LOW_WATERMARK(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+MSR_BUFF_DESC_LOW_WATERMARK_OFFSET,MSR_BUFF_DESC_LOW_WATERMARK_2_BIT_WRAP_MASK,(value)))

/* Microcode Offset Defination for PTS. They are soft registers */
#define MSR_PTS_DESCRIPTOR_PTS_OFFSET                     0x00
#define    MSR_PTS_DESCRIPTOR_PTS_MASK                    0xFFFFFFFF
#define    MSR_PTS_DESCRIPTOR_PTS_SHIFT                          0

#define MSR_PTS_DESCRIPTOR_DTS_OFFSET                     0x04
#define    MSR_PTS_DESCRIPTOR_DTS_MASK                    0xFFFFFFFF
#define    MSR_PTS_DESCRIPTOR_DTS_SHIFT                          0

#define MSR_PTS_DESCRIPTOR_FLAGS_PTS_HIGHBIT_OFFSET       0x08
#define    MSR_PTS_DESCRIPTOR_FLAGS_PTS_HIGHBIT_MASK      0x00000001
#define    MSR_PTS_DESCRIPTOR_FLAGS_PTS_HIGHBIT_SHIFT            0
#define    MSR_PTS_DESCRIPTOR_FLAGS_DTS_HIGHBIT_MASK      0x00000002
#define    MSR_PTS_DESCRIPTOR_FLAGS_DTS_HIGHBIT_SHIFT            1
#define    MSR_PTS_DESCRIPTOR_FLAGS_STC_PARITY_MASK       0x00000004
#define    MSR_PTS_DESCRIPTOR_FLAGS_STC_PARITY_SHIFT             2
#define       MSR_PTS_DESCRIPTOR_FLAGS_STC_PARITY_A         (0UL<<2)
#define       MSR_PTS_DESCRIPTOR_FLAGS_STC_PARITY_B         (1UL<<2)
#define    MSR_PTS_DESCRIPTOR_FLAGS_PTS_STATUS_MASK       0x00000008
#define    MSR_PTS_DESCRIPTOR_FLAGS_PTS_STATUS_SHIFT             3
#define       MSR_PTS_DESCRIPTOR_FLAGS_PTS_STATUS_MATURE    (0UL<<3)
#define       MSR_PTS_DESCRIPTOR_FLAGS_PTS_STATUS_PENDING   (1UL<<3)
#define    MSR_PTS_DESCRIPTOR_FLAGS_MATADDR_WRAPCNT_MASK  0x00000F00
#define    MSR_PTS_DESCRIPTOR_FLAGS_MATADDR_WRAPCNT_SHIFT        8
#define    MSR_PTS_DESCRIPTOR_FLAGS_STC_TIMEBASEID_MASK   0x000F0000
#define    MSR_PTS_DESCRIPTOR_FLAGS_STC_TIMEBASEID_SHIFT        16
#define    MSR_PTS_DESCRIPTOR_FLAGS_AVC_TAG_MASK          0xFF000000
#define    MSR_PTS_DESCRIPTOR_FLAGS_AVC_TAG_SHIFT               24

#define MSR_PTS_DESCRIPTOR_MATURITY_ADDR_OFFSET           0x0C
#define    MSR_PTS_DESCRIPTOR_MATURITY_ADDR_MASK          0x0FFFFFFF
#define    MSR_PTS_DESCRIPTOR_MATURITY_ADDR_SHIFT                0

#define MSR_PTS_DESCRIPTOR_SYNC_CHECK_PTS_OFFSET          0x10
#define    MSR_PTS_DESCRIPTOR_SYNC_CHECK_PTS_MASK         0xFFFFFFFF
#define    MSR_PTS_DESCRIPTOR_SYNC_CHECK_PTS_SHIFT               0

#define MSR_PTS_DESCRIPTOR_SYNC_CHECK_STC_OFFSET          0x14

#define MSR_PTS_DESCRIPTOR_DIFFERENCE_OFFSET              0x18

#define MSR_PTS_DESCRIPTOR_SYNC_FLAGS_OFFSET              0x1C
#define    MSR_PTS_DESCRIPTOR_SYNC_FLAGS_PTS_HIGHBIT_MASK 0x00000001
#define    MSR_PTS_DESCRIPTOR_SYNC_FLAGS_PTS_HIGHBIT_SHIFT       0


#endif   /* _MSR_H_ */

/****************************************************************************
* Modifications:
* $Log$
*
****************************************************************************/

