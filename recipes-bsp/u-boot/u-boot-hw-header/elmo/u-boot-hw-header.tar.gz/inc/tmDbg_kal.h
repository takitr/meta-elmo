/*=========================================================================*/
/*        COPYRIGHT (c) NXP B.V. <year>                                    */
/*       All rights are reserved. Reproduction in whole or in part is      */
/*       prohibited without the written consent of the copyright owner.    */
/*-------------------------------------------------------------------------*/
#ifndef TMDBG_H
#define TMDBG_H

/*
* -----------------------------------------------------------------------------
*  Project include files:
* -----------------------------------------------------------------------------
* 
*/

#include "kal.h"

#if defined(__cplusplus)
extern "C" 
{
#endif

#define DBG_ISR_PRINT(param) 			cnxt_trace_test(param);
#define DBG_ISR_PRINT0(uid, flags, message) 	cnxt_trace_test(message);


#define DBG_ASSERT(assertion)             \
    if (!(assertion))                     \
    {                                     \
        cnxt_kal_error_log(CNXT_ERROR_FATAL);   \
    }

#define DBG_ASSERT2(assertion, message)   \
    if (!(assertion))                     \
    {                                     \
        cnxt_kal_error_log(CNXT_ERROR_FATAL);   \
	cnxt_trace_test(message); \
    }

#if defined(__cplusplus)
}
#endif

#endif /* TMDBG_H */
