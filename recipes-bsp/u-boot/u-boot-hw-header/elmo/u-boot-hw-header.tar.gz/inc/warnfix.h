/****************************************************************************/ 
 /*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
 /*                       SOFTWARE FILE/MODULE HEADER                        */
 /*                      Conexant Systems Inc. (c) 2004                      */
 /*                         All Rights Reserved                              */
 /****************************************************************************/
 /*
  * Filename: WARNFIX.H
  *
  * Description:        Public header file containing various items to
  *                     fix up otherwise bothersome warnings from the
  *                     compiler. It is preferable to have this in a
  *                     separate header to avoid making changes to
  *                     'delivered' source code, such as pSOS header files
  *                     or OpenTV delivered files which generate benign
  *                     warnings.
  *
  * Author:             Steve Glennon
  *
  ****************************************************************************/
 /* $Id: warnfix.h 99754 2009-06-25 22:40:42Z gargn $
  ****************************************************************************/ 

#ifndef _WARNFIX_H_
#define _WARNFIX_H_

#ifndef __GNUC__
#define __GNUC__ 0
#endif

/* to fix undefined __CADUL__ in stddef.h */
#ifndef __CADUL__
#define __CADUL__ 0
#endif


#endif


/****************************************************************************
 * Modifications:
 * $Log$
 *
 ****************************************************************************/ 

