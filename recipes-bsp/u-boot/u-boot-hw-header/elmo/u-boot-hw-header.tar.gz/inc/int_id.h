/*============================================================================*/
/*     COPYRIGHT (c) NXP B.V. 2009                                            */
/*     All rights are reserved. Reproduction in whole or in part is           */
/*     prohibited without the written consent of the copyright owner.         */
/*----------------------------------------------------------------------------*/
/*
 * Filename:       int_id.h
 *
 * Description:    Interrupt Identifier definitions and associated macros.
 *
 ****************************************************************************/
/* $Id: int_id.h 149842 2010-03-04 06:54:09Z asethi $
 ******************************************************************************/

#ifndef _INT_ID_H_
#define _INT_ID_H_

/**********************************************************************/
/* Use this macro to generate the dwIntID parameter to any of the     */
/* KAL interrupt service functions. Parameter x is either 0 or 1 and  */
/* indicates the PIC in use, parameter y is the bit number associated */
/* with the requested interrupt.                                      */
/**********************************************************************/
#define PIC_FROM_INT_ID(x) (x >> 16)
#define INT_FROM_INT_ID(x) (x & 0xFF)
#define LINUX_INT_ID(x, y) ((x) * 32 + y)
#define CALC_INT_ID(x, y) ((x << 16) | (y))
#define IPC_BIT_FROM_INT_ID(x) ((x>>8) & 0x7)
#define IPC_CALC_INT_ID(int_id, ipc_int_pos) (int_id | (ipc_int_pos << 8))

//#define IPC_INT_FROM_INT_ID(x) ((x >> 8) & 0xFF)

/*
 * Interrupt  0 - 31 is internal Cortex A9 (local per core),
 *           32 - 223 are external interrupts (via Distributor).
 */

/*******************************/
/*       PIC numbers           */
/*******************************/
#define PIC_SGIPPI           0x00 /* Cortex A9 internal interrupts */
#define PIC_SPI_1            0x01 /* Shared Peripheral Interrupts */
#define PIC_SPI_2            0x02 /* Shared Peripheral Interrupts */
#define PIC_SPI_3            0x03 /* Shared Peripheral Interrupts */
#define PIC_SPI_4            0x04 /* Shared Peripheral Interrupts */
#define PIC_SPI_5            0x05 /* Shared Peripheral Interrupts */
#define PIC_SPI_6            0x06 /* Shared Peripheral Interrupts */
#define PIC_SPI_7            0x07 /* Shared Peripheral Interrupts */
#define PIC_GPIO             0x08 /* GPIO Controller interrupts*/

/*******************************/
/* INTERRUP POSITION           */
/*******************************/
#define INT_POS0       0
#define INT_POS1       1
#define INT_POS2       2
#define INT_POS3       3
#define INT_POS4       4
#define INT_POS5       5
#define INT_POS6       6
#define INT_POS7       7
#define INT_POS8       8
#define INT_POS9       9
#define INT_POS10      10
#define INT_POS11      11
#define INT_POS12      12
#define INT_POS13      13
#define INT_POS14      14
#define INT_POS15      15
#define INT_POS16      16
#define INT_POS17      17
#define INT_POS18      18
#define INT_POS19      19
#define INT_POS20      20
#define INT_POS21      21
#define INT_POS22      22
#define INT_POS23      23
#define INT_POS24      24
#define INT_POS25      25
#define INT_POS26      26
#define INT_POS27      27
#define INT_POS28      28
#define INT_POS29      29
#define INT_POS30      30
#define INT_POS31      31

/*******************************************************************/
/* KAL INTERRUP ID - This will be used for interrup registration   */
/*******************************************************************/
#define INT_ID0    CALC_INT_ID(PIC_SGIPPI, INT_POS0)
#define INT_ID1    CALC_INT_ID(PIC_SGIPPI, INT_POS1)
#define INT_ID2    CALC_INT_ID(PIC_SGIPPI, INT_POS2)
#define INT_ID3    CALC_INT_ID(PIC_SGIPPI, INT_POS3)
#define INT_ID4    CALC_INT_ID(PIC_SGIPPI, INT_POS4)
#define INT_ID5    CALC_INT_ID(PIC_SGIPPI, INT_POS5)
#define INT_ID6    CALC_INT_ID(PIC_SGIPPI, INT_POS6)
#define INT_ID7    CALC_INT_ID(PIC_SGIPPI, INT_POS7)
#define INT_ID8    CALC_INT_ID(PIC_SGIPPI, INT_POS8)
#define INT_ID9    CALC_INT_ID(PIC_SGIPPI, INT_POS9)
#define INT_ID10    CALC_INT_ID(PIC_SGIPPI, INT_POS10)
#define INT_ID11    CALC_INT_ID(PIC_SGIPPI, INT_POS11)
#define INT_ID12    CALC_INT_ID(PIC_SGIPPI, INT_POS12)
#define INT_ID13    CALC_INT_ID(PIC_SGIPPI, INT_POS13)
#define INT_ID14    CALC_INT_ID(PIC_SGIPPI, INT_POS14)
#define INT_ID15    CALC_INT_ID(PIC_SGIPPI, INT_POS15)
#define INT_ID16    CALC_INT_ID(PIC_SGIPPI, INT_POS16)
#define INT_ID17    CALC_INT_ID(PIC_SGIPPI, INT_POS17)
#define INT_ID18    CALC_INT_ID(PIC_SGIPPI, INT_POS18)
#define INT_ID19    CALC_INT_ID(PIC_SGIPPI, INT_POS19)
#define INT_ID20    CALC_INT_ID(PIC_SGIPPI, INT_POS20)
#define INT_ID21    CALC_INT_ID(PIC_SGIPPI, INT_POS21)
#define INT_ID22    CALC_INT_ID(PIC_SGIPPI, INT_POS22)
#define INT_ID23    CALC_INT_ID(PIC_SGIPPI, INT_POS23)
#define INT_ID24    CALC_INT_ID(PIC_SGIPPI, INT_POS24)
#define INT_ID25    CALC_INT_ID(PIC_SGIPPI, INT_POS25)
#define INT_ID26    CALC_INT_ID(PIC_SGIPPI, INT_POS26)
#define INT_ID27    CALC_INT_ID(PIC_SGIPPI, INT_POS27)
#define INT_ID28    CALC_INT_ID(PIC_SGIPPI, INT_POS28)
#define INT_ID29    CALC_INT_ID(PIC_SGIPPI, INT_POS29)
#define INT_ID30    CALC_INT_ID(PIC_SGIPPI, INT_POS30)
#define INT_ID31    CALC_INT_ID(PIC_SGIPPI, INT_POS31)
#define INT_ID32    CALC_INT_ID(PIC_SPI_1, INT_POS0)
#define INT_ID33    CALC_INT_ID(PIC_SPI_1, INT_POS1)
#define INT_ID34    CALC_INT_ID(PIC_SPI_1, INT_POS2)
#define INT_ID35    CALC_INT_ID(PIC_SPI_1, INT_POS3)
#define INT_ID36    CALC_INT_ID(PIC_SPI_1, INT_POS4)
#define INT_ID37    CALC_INT_ID(PIC_SPI_1, INT_POS5)
#define INT_ID38    CALC_INT_ID(PIC_SPI_1, INT_POS6)
#define INT_ID39    CALC_INT_ID(PIC_SPI_1, INT_POS7)
#define INT_ID40    CALC_INT_ID(PIC_SPI_1, INT_POS8)
#define INT_ID41    CALC_INT_ID(PIC_SPI_1, INT_POS9)
#define INT_ID42    CALC_INT_ID(PIC_SPI_1, INT_POS10)
#define INT_ID43    CALC_INT_ID(PIC_SPI_1, INT_POS11)
#define INT_ID44    CALC_INT_ID(PIC_SPI_1, INT_POS12)
#define INT_ID45    CALC_INT_ID(PIC_SPI_1, INT_POS13)
#define INT_ID46    CALC_INT_ID(PIC_SPI_1, INT_POS14)
#define INT_ID47    CALC_INT_ID(PIC_SPI_1, INT_POS15)
#define INT_ID48    CALC_INT_ID(PIC_SPI_1, INT_POS16)
#define INT_ID49    CALC_INT_ID(PIC_SPI_1, INT_POS17)
#define INT_ID50    CALC_INT_ID(PIC_SPI_1, INT_POS18)
#define INT_ID51    CALC_INT_ID(PIC_SPI_1, INT_POS19)
#define INT_ID52    CALC_INT_ID(PIC_SPI_1, INT_POS20)
#define INT_ID53    CALC_INT_ID(PIC_SPI_1, INT_POS21)
#define INT_ID54    CALC_INT_ID(PIC_SPI_1, INT_POS22)
#define INT_ID55    CALC_INT_ID(PIC_SPI_1, INT_POS23)
#define INT_ID56    CALC_INT_ID(PIC_SPI_1, INT_POS24)
#define INT_ID57    CALC_INT_ID(PIC_SPI_1, INT_POS25)
#define INT_ID58    CALC_INT_ID(PIC_SPI_1, INT_POS26)
#define INT_ID59    CALC_INT_ID(PIC_SPI_1, INT_POS27)
#define INT_ID60    CALC_INT_ID(PIC_SPI_1, INT_POS28)
#define INT_ID61    CALC_INT_ID(PIC_SPI_1, INT_POS29)
#define INT_ID62    CALC_INT_ID(PIC_SPI_1, INT_POS30)
#define INT_ID63    CALC_INT_ID(PIC_SPI_1, INT_POS31)
#define INT_ID64    CALC_INT_ID(PIC_SPI_2, INT_POS0)
#define INT_ID65    CALC_INT_ID(PIC_SPI_2, INT_POS1)
#define INT_ID66    CALC_INT_ID(PIC_SPI_2, INT_POS2)
#define INT_ID67    CALC_INT_ID(PIC_SPI_2, INT_POS3)
#define INT_ID68    CALC_INT_ID(PIC_SPI_2, INT_POS4)
#define INT_ID69    CALC_INT_ID(PIC_SPI_2, INT_POS5)
#define INT_ID70    CALC_INT_ID(PIC_SPI_2, INT_POS6)
#define INT_ID71    CALC_INT_ID(PIC_SPI_2, INT_POS7)
#define INT_ID72    CALC_INT_ID(PIC_SPI_2, INT_POS8)
#define INT_ID73    CALC_INT_ID(PIC_SPI_2, INT_POS9)
#define INT_ID74    CALC_INT_ID(PIC_SPI_2, INT_POS10)
#define INT_ID75    CALC_INT_ID(PIC_SPI_2, INT_POS11)
#define INT_ID76    CALC_INT_ID(PIC_SPI_2, INT_POS12)
#define INT_ID77    CALC_INT_ID(PIC_SPI_2, INT_POS13)
#define INT_ID78    CALC_INT_ID(PIC_SPI_2, INT_POS14)
#define INT_ID79    CALC_INT_ID(PIC_SPI_2, INT_POS15)
#define INT_ID80    CALC_INT_ID(PIC_SPI_2, INT_POS16)
#define INT_ID81    CALC_INT_ID(PIC_SPI_2, INT_POS17)
#define INT_ID82    CALC_INT_ID(PIC_SPI_2, INT_POS18)
#define INT_ID83    CALC_INT_ID(PIC_SPI_2, INT_POS19)
#define INT_ID84    CALC_INT_ID(PIC_SPI_2, INT_POS20)
#define INT_ID85    CALC_INT_ID(PIC_SPI_2, INT_POS21)
#define INT_ID86    CALC_INT_ID(PIC_SPI_2, INT_POS22)
#define INT_ID87    CALC_INT_ID(PIC_SPI_2, INT_POS23)
#define INT_ID88    CALC_INT_ID(PIC_SPI_2, INT_POS24)
#define INT_ID89    CALC_INT_ID(PIC_SPI_2, INT_POS25)
#define INT_ID90    CALC_INT_ID(PIC_SPI_2, INT_POS26)
#define INT_ID91    CALC_INT_ID(PIC_SPI_2, INT_POS27)
#define INT_ID92    CALC_INT_ID(PIC_SPI_2, INT_POS28)
#define INT_ID93    CALC_INT_ID(PIC_SPI_2, INT_POS29)
#define INT_ID94    CALC_INT_ID(PIC_SPI_2, INT_POS30)
#define INT_ID95    CALC_INT_ID(PIC_SPI_2, INT_POS31)
#define INT_ID96    CALC_INT_ID(PIC_SPI_3, INT_POS0)
#define INT_ID97    CALC_INT_ID(PIC_SPI_3, INT_POS1)
#define INT_ID98    CALC_INT_ID(PIC_SPI_3, INT_POS2)
#define INT_ID99    CALC_INT_ID(PIC_SPI_3, INT_POS3)
#define INT_ID100    CALC_INT_ID(PIC_SPI_3, INT_POS4)
#define INT_ID101    CALC_INT_ID(PIC_SPI_3, INT_POS5)
#define INT_ID102    CALC_INT_ID(PIC_SPI_3, INT_POS6)
#define INT_ID103    CALC_INT_ID(PIC_SPI_3, INT_POS7)
#define INT_ID104    CALC_INT_ID(PIC_SPI_3, INT_POS8)
#define INT_ID105    CALC_INT_ID(PIC_SPI_3, INT_POS9)
#define INT_ID106    CALC_INT_ID(PIC_SPI_3, INT_POS10)
#define INT_ID107    CALC_INT_ID(PIC_SPI_3, INT_POS11)
#define INT_ID108    CALC_INT_ID(PIC_SPI_3, INT_POS12)
#define INT_ID109    CALC_INT_ID(PIC_SPI_3, INT_POS13)
#define INT_ID110    CALC_INT_ID(PIC_SPI_3, INT_POS14)
#define INT_ID111    CALC_INT_ID(PIC_SPI_3, INT_POS15)
#define INT_ID112    CALC_INT_ID(PIC_SPI_3, INT_POS16)
#define INT_ID113    CALC_INT_ID(PIC_SPI_3, INT_POS17)
#define INT_ID114    CALC_INT_ID(PIC_SPI_3, INT_POS18)
#define INT_ID115    CALC_INT_ID(PIC_SPI_3, INT_POS19)
#define INT_ID116    CALC_INT_ID(PIC_SPI_3, INT_POS20)
#define INT_ID117    CALC_INT_ID(PIC_SPI_3, INT_POS21)
#define INT_ID118    CALC_INT_ID(PIC_SPI_3, INT_POS22)
#define INT_ID119    CALC_INT_ID(PIC_SPI_3, INT_POS23)
#define INT_ID120    CALC_INT_ID(PIC_SPI_3, INT_POS24)
#define INT_ID121    CALC_INT_ID(PIC_SPI_3, INT_POS25)
#define INT_ID122    CALC_INT_ID(PIC_SPI_3, INT_POS26)
#define INT_ID123    CALC_INT_ID(PIC_SPI_3, INT_POS27)
#define INT_ID124    CALC_INT_ID(PIC_SPI_3, INT_POS28)
#define INT_ID125    CALC_INT_ID(PIC_SPI_3, INT_POS29)
#define INT_ID126    CALC_INT_ID(PIC_SPI_3, INT_POS30)
#define INT_ID127    CALC_INT_ID(PIC_SPI_3, INT_POS31)
#define INT_ID128    CALC_INT_ID(PIC_SPI_4, INT_POS0)
#define INT_ID129    CALC_INT_ID(PIC_SPI_4, INT_POS1)
#define INT_ID130    CALC_INT_ID(PIC_SPI_4, INT_POS2)
#define INT_ID131    CALC_INT_ID(PIC_SPI_4, INT_POS3)
#define INT_ID132    CALC_INT_ID(PIC_SPI_4, INT_POS4)
#define INT_ID133    CALC_INT_ID(PIC_SPI_4, INT_POS5)
#define INT_ID134    CALC_INT_ID(PIC_SPI_4, INT_POS6)
#define INT_ID135    CALC_INT_ID(PIC_SPI_4, INT_POS7)
#define INT_ID136    CALC_INT_ID(PIC_SPI_4, INT_POS8)
#define INT_ID137    CALC_INT_ID(PIC_SPI_4, INT_POS9)
#define INT_ID138    CALC_INT_ID(PIC_SPI_4, INT_POS10)
#define INT_ID139    CALC_INT_ID(PIC_SPI_4, INT_POS11)
#define INT_ID140    CALC_INT_ID(PIC_SPI_4, INT_POS12)
#define INT_ID141    CALC_INT_ID(PIC_SPI_4, INT_POS13)
#define INT_ID142    CALC_INT_ID(PIC_SPI_4, INT_POS14)
#define INT_ID143    CALC_INT_ID(PIC_SPI_4, INT_POS15)
#define INT_ID144    CALC_INT_ID(PIC_SPI_4, INT_POS16)
#define INT_ID145    CALC_INT_ID(PIC_SPI_4, INT_POS17)
#define INT_ID146    CALC_INT_ID(PIC_SPI_4, INT_POS18)
#define INT_ID147    CALC_INT_ID(PIC_SPI_4, INT_POS19)
#define INT_ID148    CALC_INT_ID(PIC_SPI_4, INT_POS20)
#define INT_ID149    CALC_INT_ID(PIC_SPI_4, INT_POS21)
#define INT_ID150    CALC_INT_ID(PIC_SPI_4, INT_POS22)
#define INT_ID151    CALC_INT_ID(PIC_SPI_4, INT_POS23)
#define INT_ID152    CALC_INT_ID(PIC_SPI_4, INT_POS24)
#define INT_ID153    CALC_INT_ID(PIC_SPI_4, INT_POS25)
#define INT_ID154    CALC_INT_ID(PIC_SPI_4, INT_POS26)
#define INT_ID155    CALC_INT_ID(PIC_SPI_4, INT_POS27)
#define INT_ID156    CALC_INT_ID(PIC_SPI_4, INT_POS28)
#define INT_ID157    CALC_INT_ID(PIC_SPI_4, INT_POS29)
#define INT_ID158    CALC_INT_ID(PIC_SPI_4, INT_POS30)
#define INT_ID159    CALC_INT_ID(PIC_SPI_4, INT_POS31)
#define INT_ID160    CALC_INT_ID(PIC_SPI_5, INT_POS0)
#define INT_ID161    CALC_INT_ID(PIC_SPI_5, INT_POS1)
#define INT_ID162    CALC_INT_ID(PIC_SPI_5, INT_POS2)
#define INT_ID163    CALC_INT_ID(PIC_SPI_5, INT_POS3)

/************************/
/* Useful Interrupt IDs */
/************************/

#define INT_GPIO_LEFT   INT_ID32
#define INT_IPC0        INT_ID33
#define INT_IPC1        INT_ID34
#define INT_IPC2        INT_ID35
#define INT_IPC3        INT_ID36
#define INT_IPC4        INT_ID37
#define INT_CGU         INT_ID38
#define INT_SATA        INT_ID39
#define INT_GMAC0_MAC   INT_ID40
#define INT_GMAC0_PWR   INT_ID41
#define INT_NS          INT_ID42
#define INT_PT0         INT_ID43
#define INT_PT1         INT_ID44
#define INT_CEC         INT_ID45
#define INT_UART0       INT_ID46
#define INT_UART1       INT_ID47
#define INT_UART2       INT_ID48
#define INT_UART3       INT_ID49
#define INT_SPI_COMB    INT_ID50
#define INT_SPI_DMA     INT_ID51
#define INT_SMARTCARD0  INT_ID52
#define INT_SMARTCARD1  INT_ID53
#define INT_IR0         INT_ID54
#define INT_IIC2        INT_ID55
#define INT_IIC3        INT_ID56
#define INT_IIC4        INT_ID57
#define INT_TIMER0      INT_ID58
#define INT_TIMER1      INT_ID59
#define INT_TIMER2      INT_ID60
#define INT_TIMER3      INT_ID61
#define INT_TIMER4      INT_ID62
#define INT_TIMER5      INT_ID63
#define INT_TIMER6      INT_ID64
#define INT_TIMER7      INT_ID65
#define INT_TIMER8      INT_ID66
#define INT_TIMER9      INT_ID67
#define INT_TIMER10     INT_ID68
#define INT_TIMER11     INT_ID69
#define INT_TIMER12     INT_ID70
#define INT_TIMER13     INT_ID71
#define INT_TIMER14     INT_ID72
#define INT_TIMER15     INT_ID73
#define INT_TIMER16     INT_ID74
#define INT_TIMER17     INT_ID75
#define INT_TIMER18     INT_ID76
#define INT_TIMER19     INT_ID77
#define INT_TIMER20     INT_ID78
#define INT_TIMER21     INT_ID79
#define INT_TIMER22     INT_ID80
#define INT_TIMER23     INT_ID81
#define INT_SDCN        INT_ID82
#define INT_TSA         INT_ID83
#define INT_MCX         INT_ID84
#define INT_TSP0        INT_ID85
#define INT_TSR0        INT_ID86
#define INT_TSX         INT_ID87
#define INT_VSMDMA0     INT_ID88
#define INT_VSMDMA1     INT_ID89
#define INT_VSMDMA2     INT_ID90
#define INT_VSMDMA3     INT_ID91
#define INT_ICAM        INT_ID92
#define INT_USB0        INT_ID93
#define INT_USB1        INT_ID94
#define INT_USB2        INT_ID95
#define INT_MTLMON0     INT_ID96
#define INT_MTLMON1     INT_ID97
#define INT_MTLMON2     INT_ID98
#define INT_MTLMON3     INT_ID99
#define INT_DMA_H0      INT_ID100
#define INT_DMA_H1      INT_ID101
#define INT_GPIO_RIGHT  INT_ID102
#define INT_DRAW2D      INT_ID103
#define INT_GPPM        INT_ID104
#define INT_PCI_DMA     INT_ID105
#define INT_PCI         INT_ID106
#define INT_PCI_INTA    INT_ID107
#define INT_NAND_DMAC   INT_ID108
#define INT_CKL         INT_ID109
#define INT_CRYPTO      INT_ID110
#define INT_NEWTON      INT_ID111
#define INT_SSP_HOST0   INT_ID112
#define INT_SSP_HOST1   INT_ID113
#define INT_MCARD       INT_ID114
#define INT_DMAC_1902   INT_ID115
#define INT_THALIA      INT_ID116
#define INT_VDEC0       INT_ID117
#define INT_VDEC1       INT_ID118
#define INT_VDEC2       INT_ID119
#define INT_VPIPE0      INT_ID120
#define INT_VPIPE1      INT_ID121
#define INT_VPIPE2      INT_ID122
#define INT_VPIPE3      INT_ID123
#define INT_VPIPE4      INT_ID124
#define INT_VPIPE5      INT_ID125
#define INT_VPIPE6      INT_ID126
#define INT_SPDO        INT_ID127
#define INT_IPC5        INT_ID128
#define INT_IPC6        INT_ID129
#define INT_IPC7        INT_ID130
#define INT_AO_HDMI     INT_ID131
#define INT_AO_BTSC     INT_ID132
#define INT_AO_ADAC     INT_ID133
#define INT_DENC        INT_ID134
#define INT_ADCN        INT_ID135
#define INT_AVDSN       INT_ID136
#define INT_HDMI_TX     INT_ID137
#define INT_GMAC1_MAC   INT_ID138
#define INT_GMAC1_PWR   INT_ID139
#define INT_VIP         INT_ID140
#define INT_NAND        INT_ID141
#define INT_SFC         INT_ID142
#define INT_MTLMON4     INT_ID143
#define INT_MTLMON5     INT_ID144
#define INT_MTLMON6     INT_ID145
#define INT_MTLMON7     INT_ID146
#define INT_TYPHOON     INT_ID147
#define INT_AI          INT_ID148
#define INT_IIC5        INT_ID149
#define INT_AUX_CTI7    INT_ID150
#define INT_AUX_CTI6    INT_ID151
#define INT_PWM1        INT_ID152
#define INT_PWM2        INT_ID153
#define INT_PWM3        INT_ID154
#define INT_GMAC_PHY    INT_ID155
#define INT_SDCARD      INT_ID156
#define INT_PMU         INT_ID157
#define INT_A3CRC       INT_ID158
#define INT_RESERVED    INT_ID159
#define INT_L2_CACHE    INT_ID160
#define INT_COMMRX      INT_ID161
#define INT_COMMTX      INT_ID162
#define INT_A9_CTI      INT_ID163

/* Timer number 15 is reserved to be used as watchdog on A9 */
#define INT_WATCHDOG    INT_TIMER15

/* IPC Interrupt IDs */

/* IPC0 (A9) Source bit assignments */
#define IPC0_SRC_BIT_A9         0
#define IPC0_SRC_BIT_ADSP       1
#define IPC0_SRC_BIT_A926       2
#define IPC0_SRC_BIT_VDSP       3
#define IPC0_SRC_BIT_M3         4
#define IPC0_SRC_BIT_UNUSED1    5
#define IPC0_SRC_BIT_UNUSED2    6
#define IPC0_SRC_BIT_UNUSED3    7

/* IPC1 (ADSP) Source bit assignments */
#define IPC1_SRC_BIT_A9         0
#define IPC1_SRC_BIT_ARM926     1
#define IPC1_SRC_BIT_VDSP       2

/* IPC2 (ARM926) Source bit assignments */
#define IPC2_SRC_BIT_A9         0
#define IPC2_SRC_BIT_ADSP       1
#define IPC2_SRC_BIT_VDSP       2

/* IPC3 (VDSP) Source bit assignments */
#define IPC3_SRC_BIT_A9         0
#define IPC3_SRC_BIT_ADSP       1
#define IPC3_SRC_BIT_A926       2

/* IPC4 (M3) Source bit assignments */
#define IPC4_SRC_BIT_A9         0

/* IPC5 (ADSP) Source bit assignments */
#define IPC5_SRC_BIT_A9         0
#define IPC5_SRC_BIT_ARM926     1
#define IPC5_SRC_BIT_VDSP       2

/* IPC0 INT_IDs for A9 - Used for interrupt registeration & assert */
#define IPC0_INT_A9_TO_A9       IPC_CALC_INT_ID(INT_IPC0, IPC0_SRC_BIT_A9)
#define IPC0_INT_ADSP_TO_A9     IPC_CALC_INT_ID(INT_IPC0, IPC0_SRC_BIT_ADSP)
#define IPC0_INT_A926_TO_A9     IPC_CALC_INT_ID(INT_IPC0, IPC0_SRC_BIT_A926)
#define IPC0_INT_VDSP_TO_A9     IPC_CALC_INT_ID(INT_IPC0, IPC0_SRC_BIT_VDSP)
#define IPC0_INT_M3_TO_A9       IPC_CALC_INT_ID(INT_IPC0, IPC0_SRC_BIT_M3)

/* 
 * Following are the IPC1 to IPC5 INT_IDs for  
 * asserting interrupts from A9 to respective processors  
 */

/* IPC INT_ID for asserting interrupt A9->ADSP1 */
#define IPC1_INT_A9_TO_ADSP     IPC_CALC_INT_ID(INT_IPC1, IPC1_SRC_BIT_A9)

/* IPC INT_ID for asserting interrupt A9->A926 */
#define IPC2_INT_A9_TO_A926     IPC_CALC_INT_ID(INT_IPC2, IPC2_SRC_BIT_A9)

/* IPC INT_ID for asserting interrupt A9->VDSP */
#define IPC3_INT_A9_TO_VDSP     IPC_CALC_INT_ID(INT_IPC3, IPC3_SRC_BIT_A9)

/* IPC INT_ID for asserting interrupt A9->M3 */
#define IPC4_INT_A9_TO_M3       IPC_CALC_INT_ID(INT_IPC4, IPC4_SRC_BIT_A9)

/* IPC INT_ID for asserting interrupt A9->ADSP2 */
#define IPC5_INT_A9_TO_ADSP     IPC_CALC_INT_ID(INT_IPC5, IPC5_SRC_BIT_A9)

#endif /* INT_ID_H_ */

/*******************************************************************************
 * Modifications:
 * $Log: $
 *
 ******************************************************************************/


