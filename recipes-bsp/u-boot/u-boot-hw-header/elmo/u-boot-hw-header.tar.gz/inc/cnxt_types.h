/******************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                    */
/*                        SOFTWARE FILE/MODULE HEADER                         */
/*                 Copyright Conexant Systems Inc. 2004-2005                  */
/*                                 Austin, TX                                 */
/*                            All Rights Reserved                             */
/******************************************************************************/
/*
 * Filename:        cnxt_types.h
 *
 *
 * Description:     Common type definitions used by Conexant driver software.
 *
 *
 * Author:          Dave Wilson
 *
 ******************************************************************************/
/* $Id: cnxt_types.h 214431 2011-07-06 12:26:11Z rathd $
 ******************************************************************************/

#ifndef _CNXT_TYPES_H_
#define _CNXT_TYPES_H_

#include "basetype.h"
#include "status_codes.h"

#define CNXT_SCALE_MULT      (0x1000)
#define INVALID_UNIT_NUMBER  (0xFFFFFFFF)
#define CNXT_PAGE_AUTO       (0xFF)

/******************************************************************************/
/* Return Code Checks                                                         */
/*                                                                            */
/* Error checking macros used in cases where we want to ensure that we always */
/* record failures even if we don't back out changes and exit the function    */
/* immediately. Note that these are NOT intended for use with ALL calls. Code */
/* must still perform normal error checking and recovery for any function     */
/* call where a failure would materially and immediately affect the operation */
/* of the software. Examples of calls which may be error checked using these  */
/* macros would be critical section calls, sleep calls, etc.                  */
/******************************************************************************/

#define ERROR_FLAG bool __bErrorSeen = FALSE

#define ERROR_CHECK(seen, expected)    \
   do                                  \
   {                                   \
      if((seen) != (expected))         \
      {                                \
         __bErrorSeen = TRUE;          \
      }                                \
   } while( 0 )

#define ERROR_OCCURRED __bErrorSeen

/************************************/
/* General time and date structures */
/************************************/
typedef enum
{
   JANUARY = 1,
   FEBRUARY,
   MARCH,
   APRIL,
   MAY,
   JUNE,
   JULY,
   AUGUST,
   SEPTEMBER,
   OCTOBER,
   NOVEMBER,
   DECEMBER,
   NUMBER_OF_MONTHS = DECEMBER
} CNXT_MONTH;

typedef enum
{
   SUNDAY = 1,
   MONDAY,
   TUESDAY,
   WEDNESDAY,
   THURSDAY,
   FRIDAY,
   SATURDAY,
   NUMBER_OF_DAYS = SATURDAY
} CNXT_DAY;

typedef struct
{
   u_int16     uYear;
   CNXT_MONTH  Month;
   u_int8      uDay;
   CNXT_DAY    DayOfWeek;
   u_int8      uHour;
   u_int8      uMinute;
   u_int8      uSecond;
} CNXT_UTC_TIME;

typedef struct
{
   int16  nX;
   int16  nY;
} CNXT_XY;

typedef struct
{
   u_int16  uWidth;
   u_int16  uHeight;
} CNXT_SIZE;

typedef struct
{
  int16 nLeft;
  int16 nTop;
  int16 nRight;
  int16 nBottom;
} CNXT_RECT;

typedef struct
{
   u_int8  uRed;
   u_int8  uGreen;
   u_int8  uBlue;
   u_int8  uAlpha;
} CNXT_RGB_COLOR;

typedef struct
{
   u_int8  uY;
   u_int8  uCb;
   u_int8  uCr;
   u_int8  uAlpha;
} CNXT_YCC_COLOR;

typedef enum
{
   RGB = 0,         /* RGB format */
   YCC,             /* YCC format */
   PAL_INDEX,       /* Palette index or u_int32 representation of color*/
   CNXT_COLOR_TYPE_LAST = PAL_INDEX
} CNXT_COLOR_TYPE;

typedef union
{
   u_int32         uValue; /* Palette index or u_int32 representation of color */
   CNXT_RGB_COLOR  RGB;
   CNXT_YCC_COLOR  YCC;
} CNXT_COLOR_ENTRY;

typedef struct
{
   CNXT_COLOR_TYPE   ColorType;
   CNXT_COLOR_ENTRY  Color;
} CNXT_COLOR;

/* color space */
typedef enum
{
   CNXT_YCC_BASIC = 0,   /* Pure YCbCr for MPEG-1 decodes */
   CNXT_YCC_SD_BT470,    /* ITU-R BT470-2 System M   */
   CNXT_YCC_SD_BT470_BG, /* ITU-R BT470-2 System B/G */
   CNXT_YCC_SMPTE_170M,  /* SMPTE 170M */
   CNXT_YCC_SMPTE_240M,  /* SMPTE 240M */
   CNXT_YCC_GEN_FILM,    /* Generic Film(Color filters using Illuminant C) */
   CNXT_YCC_HD_BT709,
   CNXT_RGB,
   CNXT_COLOR_SPACE_LAST = CNXT_RGB
} CNXT_COLOR_SPACE;

typedef struct
{
   CNXT_COLOR_TYPE   ColorType;
   u_int16           uNumPalEntries;
   CNXT_COLOR_ENTRY  *pPalEntry;
} CNXT_PALETTE;

typedef struct
{
   CNXT_COLOR_SPACE     ColorSpace;
   CNXT_COLOR_ENTRY     Color;
} CNXT_COLOR_SPEC;

/* aspect ratio */
typedef enum
{
   CNXT_AR_INVALID = -1,
   CNXT_AR_1_1,
   CNXT_AR_4_3,
   CNXT_AR_14_9,
   CNXT_AR_16_9,
   CNXT_AR_20_9,
   CNXT_AR_RAW,
   CNXT_AR_LAST = CNXT_AR_RAW
} CNXT_AR;

typedef enum
{
   CNXT_VIDEO_SD = 0,
   CNXT_VIDEO_HD,
   CNXT_VIDEO_120x60i,
   CNXT_VIDEO_320x240i,
   CNXT_VIDEO_1440x800i,
   CNXT_VIDEO_360x288i
} CNXT_VIDEO_DEFINITION;

/* pixel formats */
typedef enum
{
   PIXEL_FORMAT_MONO_PATTERN = 0,
   PIXEL_FORMAT_2YCC,   /* primarily intended for cursor use */
   PIXEL_FORMAT_4ARGB,
   PIXEL_FORMAT_4AYCC,
   PIXEL_FORMAT_8ARGB,
   PIXEL_FORMAT_8AYCC,
   PIXEL_FORMAT_16ARGB_4444,
   PIXEL_FORMAT_16ABGR_4444,
   PIXEL_FORMAT_16AYCC_4444,
   PIXEL_FORMAT_16RGB_565,
   PIXEL_FORMAT_16BGR_565,
   PIXEL_FORMAT_16YCC_655,
   PIXEL_FORMAT_16ARGB_1555,
   PIXEL_FORMAT_16ABGR_1555,
   PIXEL_FORMAT_16AYCC_2644,
   PIXEL_FORMAT_32ARGB,
   PIXEL_FORMAT_32ABGR,
   PIXEL_FORMAT_32AYCC,
   PIXEL_FORMAT_NV12,     /* a planar YCC 4:2:0 format */
   PIXEL_FORMAT_UYVY,     /* a packed YCC 4:2:2 format */
   PIXEL_FORMAT_CXY1,     /* a planar YCC 4:2:2 format */
   PIXEL_FORMAT_CXY2,     /* a planar YCC 4:4:4 format */
   PIXEL_FORMAT_LAST = PIXEL_FORMAT_CXY2
} CNXT_PIXEL_MODE;

/* the Y and Cr, Cb values are all in full range [0-255] because that's */
/* what DRM supports */
typedef enum
{
   YCC_BASIC = 0,   /* Pure YCbCr for MPEG-1 decodes */
   YCC_SD_BT470,    /* ITU-R BT470-2 System M   */
   YCC_SD_BT470_BG, /* ITU-R BT470-2 System B/G */
   YCC_SMPTE_170M,  /* SMPTE 170M */
   YCC_SMPTE_240M,  /* SMPTE 240M */
   YCC_GEN_FILM,    /* Generic Film(Color filters using Illuminant C) */
   YCC_HD_BT709,
   CNXT_YCC_COLOR_TYPE_LAST = YCC_HD_BT709
} CNXT_YCC_COLOR_TYPE;

/* scaling factor structure */
typedef struct
{
   CNXT_XY  Pos; /* X an Y origin */
   u_int32  uHScale; /* explicit horizontal scale factor */
   u_int32  uVScale; /* explicit vertical scale factor */
}  CNXT_SCALE_FACTOR;

typedef struct
{
   bool bRect; /* TRUE when Rect is used, FALSE when ScaleFactor is used */
   union
   {
      CNXT_RECT          Rect;
      CNXT_SCALE_FACTOR  ScaleFactor;
   } RectOrScale;
} CNXT_RECT_SCALE;

/* enum for closed captioning data types */
typedef enum
{
   CNXT_CCDATA_CC = 0,                      /* closed captioning data */
   CNXT_CCDATA_XDS,                         /* extended data services */
   CNXT_CCDATA_708_PKT_DATA,                    /* EIA 708 Packet Data */
   CNXT_CCDATA_708_PKT_HEADER,                  /* EIA 708 Packet Header */   
   CNXT_CCDATA_LAST = CNXT_CCDATA_708_PKT_HEADER
} CNXT_CCDATA_TYPE;

/***********************************************************************/
/* Note: CNXT_VIDEO_STANDARD_XXXXs are defined in software config file */
/***********************************************************************/

/* Video Format */
typedef enum
{
   CNXT_VIDEO_FORMAT_MPEG2 = 0,
   CNXT_VIDEO_FORMAT_MPEG4, /* H264 */
   CNXT_VIDEO_FORMAT_VC1,
   CNXT_VIDEO_FORMAT_JPEG,
   CNXT_VIDEO_FORMAT_GIF,
   CNXT_VIDEO_FORMAT_PNG,
   CNXT_VIDEO_FORMAT_DIVX,/* DIVX 3.11 */
   CNXT_VIDEO_FORMAT_MPEG4PART2,/* MPEG4 SVH, MPEG4 SP, MPEG4 ASP, DIVX4,5,6 */
   CNXT_VIDEO_FORMAT_REALVIDEO8,
   CNXT_VIDEO_FORMAT_REALVIDEO9,
   CNXT_VIDEO_FORMAT_ON2_VP6,
   CNXT_VIDEO_FORMAT_ON2_VP8,
   CNXT_VIDEO_FORMAT_SORENSON_SPARK,
   CNXT_VIDEO_FORMAT_H263,
   CNXT_VIDEO_FORMAT_H263_ENCODER,
   CNXT_VIDEO_FORMAT_H264_ENCODER,
   CNXT_VIDEO_FORMAT_MPEG4PART2_ENCODER,
   CNXT_VIDEO_FORMAT_AVS,  
   CNXT_VIDEO_FORMAT_VIP656,
   CNXT_VIDEO_FORMAT_UNSUPPORTED
} CNXT_VIDEO_FORMAT;

/* Audio Format */
typedef enum
{
   CNXT_AUDIO_FMT_AUTO = 0,          /* auto-detect the audio format */
   CNXT_AUDIO_FMT_MPEG,              /* MPEG-1 Layers I and II */
   CNXT_AUDIO_FMT_MP3,               /* MPEG-1 Layer III */
   CNXT_AUDIO_FMT_DOLBY_DIGITAL,     /* Dolby Digital, i.e. AC-3 */
   CNXT_AUDIO_FMT_BASIC = CNXT_AUDIO_FMT_DOLBY_DIGITAL,
   CNXT_AUDIO_FMT_AAC,               /* AAC using Low Complexity Profile */
   CNXT_AUDIO_FMT_AAC_PLUS,          /* MPEG-4 High Efficiency (aacPlus), i.e. AAC with SBR */
   CNXT_AUDIO_FMT_DD_PLUS,           /* Dolby Digital Plus. */
   CNXT_AUDIO_FMT_DTS,               /* Digital Theater Systems */
   CNXT_AUDIO_FMT_AVS,               /* AVS Format*/
   CNXT_AUDIO_FMT_MLP,               /* Meridian Lossless Packing (DVD-Audio) */
   CNXT_AUDIO_FMT_WMA,               /* WMA Format */
   CNXT_AUDIO_FMT_WMAPRO,               /* WMAPRO Format */
   CNXT_AUDIO_FMT_REALAUDIO,         /* Real Audio Cook Format */
   CNXT_AUDIO_FMT_SILK,              /* Silk speech codec format*/
   CNXT_AUDIO_FMT_G729,              /* G.729 speech codec format*/
   CNXT_AUDIO_FMT_PCM,               /* PCM audio for playback with avsync*/
   CNXT_AUDIO_FMT_ADVANCED = CNXT_AUDIO_FMT_MLP
} CNXT_AUDIO_FORMAT;

#endif /* _CNXT_TYPES_H_ */

/*******************************************************************************
 * Modifications:
 * $Log$
 *
 ******************************************************************************/

