/****************************************************************************/ 
 /*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
 /*                       SOFTWARE FILE/MODULE HEADER                        */
 /*                    Conexant Systems Inc. (c) 2004-2007                   */
 /*                         All Rights Reserved                              */
 /****************************************************************************/
 /*
  * Filename:     HWLIB.H
  *
  * Description:  Public header file for low level function library.
  *               This can be used by the KAL or BSP only.
  *
  * Author:       Dave Wilson
  *
  ****************************************************************************/
 /* $Id: hwlib.h 99754 2009-06-25 22:40:42Z gargn $
  ****************************************************************************/ 

#ifndef _HWLIB_H_
#define _HWLIB_H_

/*******************************************************************************/
/* Note: Functions in this module do not make use of any RTOS services. Some   */
/* should be semaphore-protected to prevent potential problems caused by       */
/* global data areas being accessed from different tasks simultaneously but    */
/* this synchronisation is left to the caller. Functions which may be affected */
/* in this way are marked below.                                               */
/*******************************************************************************/

/******************************************/
/* Type definitions required within HWLIB */
/******************************************/
#include "stbcfg.h"
#include "basetype.h"
#include "kal_types.h"
#include "cnxt_types.h"
#include "board.h"
#include "hwfuncs.h"

/****************************/
/* Initialisation Functions */
/****************************/
bool hwlib_int_initialise(void);
#define hwlib_int_initialize hwlib_int_initialise
bool hwlib_timer_initialise(u_int32 period_us, bool bStart);
#define hwlib_timer_initialize hwlib_timer_initialise
CNXT_STATUS hwlib_watchdog_set(u_int32 uPeriodMs, bool bUserClear);
void hwlib_watchdog_enable(void);
void hwlib_watchdog_disable(void);
void hwlib_watchdog_clear(void);

/******************************/
/* Critical Section Functions */
/******************************/
CNXT_STATUS hwlib_critsec_begin( CNXT_CRIT_STATE *pState );
CNXT_STATUS hwlib_critsec_end( CNXT_CRIT_STATE PreviousState);
void hwlib_only_at_interrupt_safe( void );
void hwlib_not_interrupt_safe( void );

#if (!defined DEBUG)
  #define hwlib_not_from_critical_section  if (0) ((int (*)(void)) 0)
#else
  void hwlib_not_from_critical_section(void);
#endif

/**********************************/
/**********************************/
/* Interrupt Service Routine APIs */
/**********************************/
/**********************************/

CNXT_STATUS hwlib_int_register(u_int32 dwIntID,
                                   PFNISR  pfnHandler,
                                   bool    bFIQ);
CNXT_STATUS hwlib_int_deregister(u_int32 dwIntID,
                                   PFNISR  pfnHandler);
CNXT_STATUS hwlib_int_complete(u_int32 dwIntID,
                                   PFNISR  pfnHandler);
CNXT_STATUS hwlib_int_enable(u_int32 dwIntID);
CNXT_STATUS hwlib_int_disable(u_int32 dwIntID);
void            hwlib_disable_all_hw_ints(void);

void hwlib_enable_interrupts(void);
bool hwlib_disable_interrupts(void);
bool hwlib_interrupts_disabled(void);

/* Debug query function */

typedef struct
{
   u_int32 uSpuriousTimerInts;
   u_int32 uSpuriousGPIOInts;
   u_int32 uFastestTimerTurnaround;
   u_int32 uSlowestTimerTurnaround;
   u_int32 uFastestGPIOTurnaround;
   u_int32 uSlowestGPIOTurnaround;
} CNXT_HWLIB_INTERRUPT_DIAGNOSTICS;

CNXT_STATUS hwlib_get_interrupt_diag_info(
               CNXT_HWLIB_INTERRUPT_DIAGNOSTICS *pInfo);

/**********************/
/**********************/
/** Helper Functions **/
/**********************/
/**********************/
u_int32 *hwlib_get_stack_ptr(void);

/**********************/
/* Timer Service APIs */
/**********************/

CNXT_STATUS hwlib_hwtimer_create(PFNTIMERFUNC pfnCallback, void * pUserData, const char *name, CNXT_TIMER_ID *pTimer);
CNXT_STATUS hwlib_hwtimer_destroy(CNXT_TIMER_ID timer);
CNXT_STATUS hwlib_hwtimer_set(CNXT_TIMER_ID timer, u_int32 period_us, bool bOneShot);
CNXT_STATUS hwlib_hwtimer_start(CNXT_TIMER_ID);
CNXT_STATUS hwlib_hwtimer_stop(CNXT_TIMER_ID);

CNXT_STATUS hwlib_hwtimer_sys_set(u_int32 period_us);
CNXT_STATUS hwlib_hwtimer_sys_start(void);
CNXT_STATUS hwlib_hwtimer_sys_stop(void);
u_int32         hwlib_hwtimer_sys_get_rate(void);
CNXT_STATUS hwlib_hwtimer_sys_register_client(PFNTIMERFUNC pfnSysFunc, int iIndex, void *pArg);
CNXT_STATUS hwlib_hwtimer_sys_remove_client(int iIndex);
CNXT_STATUS hwlib_get_system_time( u_int32 *pTimeMs );
CNXT_STATUS hwlib_get_system_time_us( u_int32 *pTimeUs );

#define MAX_SYSTIMER_CLIENTS 4
#define SYSTIMER_CLIENT_RTOS 3
#define SYSTIMER_CLIENT_KAL  2
#define SYSTIMER_CLIENT_APP1 1
#define SYSTIMER_CLIENT_APP2 0

/*********************/
/* Tick Counter APIs */
/*********************/

CNXT_STATUS hwlib_tick_create(PFNTICKFUNC pfnCallback, void * pUserData, const char *name, CNXT_TICK_ID *pTick);
CNXT_STATUS hwlib_tick_destroy(CNXT_TICK_ID timer);
CNXT_STATUS hwlib_tick_set(CNXT_TICK_ID timer, u_int32 period_ms, bool bOneShot);
CNXT_STATUS hwlib_tick_start(CNXT_TICK_ID timer);
CNXT_STATUS hwlib_tick_stop(CNXT_TICK_ID timer);
CNXT_STATUS hwlib_tick_get_info(CNXT_TICK_ID timer, CNXT_TICK_INFO *info);
CNXT_STATUS hwlib_tick_from_name(const char *name, CNXT_TICK_ID *timer);
CNXT_STATUS hwlib_tick_get_max_period( u_int32 *pTime );

/**************************************************/
/* Miscellaneous Shared resource access functions */
/**************************************************/
CNXT_STATUS hwlib_get_board_and_vendor_codes(u_int8 *pBoard, u_int8 *pVendor);
CNXT_STATUS hwlib_get_chip_id_and_revision(u_int32 *pChip, u_int8 *pRev);

/* ToDo: This will disappear shortly - use the GPIO library */
/* instead for all GPIO control!                            */
void   hwlib_set_gpio_int_edge(unsigned int  GPIO_bit, int  polarity);   
#define RISING  0xaa
#define FALLING 0x55

/*****************************/
/* Caching Control Functions */
/*****************************/
#define     hwlib_cache_flush_i       hwlib_FlushICache
void hwlib_FlushICache(void);

#define     hwlib_cache_disable_i     hwlib_DisableICache
void hwlib_DisableICache(void);

#define     hwlib_cache_enable_i      hwlib_EnableICache
void hwlib_EnableICache(void);

#define     hwlib_cache_disable_d     hwlib_DisableDCache
void hwlib_DisableDCache(void);

/* WARNING -- this will not commit dirty lines to memory! -- WARNING */
#define     hwlib_cache_flush_d       hwlib_FlushDCache
void hwlib_FlushDCache(void);

#define     hwlib_cache_clean_d       hwlib_CleanDCache
void hwlib_CleanDCache(void);

#define     hwlib_cache_enable_d      hwlib_EnableDCache
void hwlib_EnableDCache(void);

#define     hwlib_cache_drain_d       hwlib_DrainWriteBuffer
void hwlib_DrainWriteBuffer(void);

void hwlib_CleanDCacheMVA(u_int32 MVA);
void hwlib_CleanAndInvalDCacheMVA(u_int32 MVA);
void hwlib_FlushAndInvalDCacheRegion(u_int8 *addr, u_int32 size); /*old name*/
void hwlib_CleanAndInvalDCacheRegion(u_int8 *addr, u_int32 size);
void hwlib_InvalDCacheRegion(u_int8 *addr, u_int32 size);
void hwlib_CleanInvalidateDCache(void);
void hwlib_reboot_IRD(void);

CNXT_STATUS hwlib_program_descriptor( ISA_DEVICE *Device );
int hwlib_pci_get_bar( unsigned int dev_ven, unsigned int bar_no, u_int32 *bar );

/************************************/
/* Debug and Diagnostic information */
/************************************/
#ifdef DEBUG

#define NUM_LATENCY_SAMPLES   1000
#define NUM_LONGEST_CRITSECS    10
#define NUM_LONGEST_LATENCY     10
#define LONGESTISRDURATION_SIZE 10

typedef struct
{
   u_int32 caller_add;
   u_int32 duration;
   u_int32 end;
   u_int32 id;
} ISR_TIMING_T;

#endif

#endif /* _HWLIB_H_ */
/****************************************************************************
 * Modifications:
 * $Log:
 *  21   mpeg       1.20        2/8/2007 8:12:04 AM    LinLin Gao      CR(s)
 *       23998 : Changed HW_BUFFER functions back to macro's. Moved macro's
 *       from hwlib to hwconfig.h since hwlib is not designed to be used by
 *       the driver.
 *  20   mpeg       1.19        2/6/2007 1:28:56 PM    LinLin Gao      CR(s)
 *       23998 : Added definitions of HW_BUFFER_SPACE_AVAILABLE,
 *       HW_BUFFER_DATA_AVAILABLE, HW_BUFFER_WRITE_WORD and
 *       HW_BUFFER_READ_WORD. Fixed race conditions caused by reading a buffer
 *        pointer twice which may potentially result in different values.
 *  19   mpeg       1.18        12/29/2006 11:05:17 AM RadhaKumar Pulyala CR(s)
 *        22882 : CleanInvalidateDCache api is removed from compile time
 *       macro.
 *  18   mpeg       1.17        11/15/2006 5:23:44 AM  RadhaKumar Pulyala CR(s)
 *        21650 : Pecos specific changes for ITC, L1 and L2 Caches and MMU
 *
 *       
 *  17   mpeg       1.16        11/14/2006 1:41:09 PM  Dave Wilson     CR(s)
 *       19614 : Added function hwlib_watchdog_disable.
 *  16   mpeg       1.15        6/19/2006 12:31:33 PM  Dave Wilson     CR(s)
 *       19716 19715 : Updated GPIO interrupt handling to use the same
 *       approach to spurious interrupts as timers. The code now counts any
 *       spurious interrupts detected and measures the time between the last
 *       good GPIO interrupt and the spurious one. This should determine if
 *       the (very, very occasional) problem is due to the interrupt not being
 *        cleared properly when the ISR exits and should also prevent the
 *       system from hanging if a spurious interrupt is detected (as it did
 *       with the previous version).
 *  15   mpeg       1.14        6/16/2006 1:15:22 PM   Dave Wilson     CR(s)
 *       19702 19701 : Added code to track the maximum time between a good
 *       timer interrupt and a spurious one. Previously, we just tracked the
 *       minimum time but, given that timer interrupts are not necessarily in
 *       phase, this doesn't tell us much about whether or not all spurious
 *       interrupts immediately follow good ones.
 *  14   mpeg       1.13        6/15/2006 1:56:11 PM   Dave Wilson     CR(s)
 *       19436 19434 : Added prototype for hwlib_get_timer_interrupt_info
 *       function.
 *  13   mpeg       1.12        5/11/2006 1:14:07 PM   Dave Wilson     CR(s)
 *       19149 19148 : Interrupt latency and critical section length
 *       monitoring is now enabled by default in debug builds.
 *  12   mpeg       1.11        2/23/2006 2:21:30 PM   Billy Jackman   CR(s)
 *       17984 17985 : Added prototype for existing hwlib API
 *       hwlib_InvalDCacheRegion.
 *  11   mpeg       1.10        1/28/2005 1:32:36 PM   Billy Jackman   CR(s)
 *       11817 : Added reference for new API hwlib_program_descriptor.
 *  10   mpeg       1.9         12/15/2004 3:03:09 PM  Kenneth Smeltzer CR(s)
 *       12158 12159 : Ported watchdog manual restart functionality from rio
 *       code base.
 *  9    mpeg       1.8         10/15/2004 7:22:18 AM  Lucy Allevato   CR(s)
 *       11118 : Replaced legacy code.
 *
 *       Cosmetic changes
 *  8    mpeg       1.7         10/11/2004 5:29:02 PM  Billy Jackman   CR(s)
 *       10245 : Use new model of int_register/int_deregister and centralized
 *       chaining.
 *  7    mpeg       1.6         8/11/2004 3:20:01 PM   Dave Wilson     CR(s)
 *       10060 : Removed assembler veneers over hwlib_not_interrupt_safe and
 *       hwlib_not_from_critical_section. These were of dubious use now that
 *       the functions are only ever called from the KAL (the assembler veneer
 *        was used to retrieve the original caller's address to dump in a
 *       trace message) and prevent ADW from showing the backtrace from inside
 *        the HWLIB function, thus making is extremely difficult to find the
 *       code making the offending call.
 *  6    mpeg       1.5         8/2/2004 8:23:03 AM    Dave Wilson     CR(s)
 *       9921 : Changed to use new common return code type CNXT_STATUS.
 *  5    mpeg       1.4         6/8/2004 9:55:05 AM    Regina Joiner   CR(s)
 *       9367 : Added hwlib_tick_get_max_period to return MAX_TICK_PERIOD.
 *       This function was necessary to get test_kal working.
 *  4    mpeg       1.3         6/4/2004 10:11:18 AM   Dave Wilson     CR(s)
 *       9354 : Renamed public functions which did not conform to the
 *       lower_case_with_underscores convention.
 *  3    mpeg       1.2         5/28/2004 9:30:45 AM   Billy Jackman   CR(s)
 *       9284 : Remove usage of CPU_TYPE definition.
 *  2    mpeg       1.1         4/12/2004 2:53:45 PM   Dave Wilson     CR(s)
 *       8835 : Miscellaneous changes to get a small app to build and link in
 *       the Edwards source tree.
 *  1    mpeg       1.0         4/9/2004 2:42:00 PM    Dave Wilson     CR(s)
 *       8821 : Part of hardware independent RTOS-like function layer for
 *       Edwards architecture.
 * $
 * 
 ****************************************************************************/

