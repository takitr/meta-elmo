/******************************************************************************/
/*                     NXP PROPRIETARY AND CONFIDENTIAL                       */
/*                        SOFTWARE FILE/MODULE HEADER                         */
/*                  Copyright NXP Semiconductors Inc. 2009                    */
/*                                 Austin, TX                                 */
/*                            All Rights Reserved                             */
/******************************************************************************/
/*
 * Filename:       kal.h
 *
 * Description:    Public header file for the Conexant Kernel Adaptation Layer
 *                 (version 3.0).
 *
 * Author:         
 *
 ******************************************************************************/
/* $Id: kal.h 173774 2010-09-29 22:43:13Z gargn $
 ******************************************************************************/

#ifndef _KAL_H_
#define _KAL_H_

/********************/
/* Type definitions */
/********************/
#include <stddef.h>
#include "basetype.h"
#include "kal_types.h"

//##******************************
//##** Initialisation Functions **
//##******************************

CNXT_STATUS cnxt_kal_initialize(void);

CNXT_STATUS cnxt_kal_terminate(void);

  /* DESCRIPTION:  STUB on Linux.                           */
CNXT_STATUS cnxt_kal_early_initialize(void);

  /* DESCRIPTION:  
   * STUB on Linux. 
   * Application entry point called by the KAL after the IRD has booted  */
CNXT_STATUS cnxt_kal_application_entry(void);

//##*******************************************
//##** Thread Creation/Destruction functions **
//##*******************************************

CNXT_STATUS cnxt_kal_thread_create(
               PFNTHREAD       pfnEntryPoint,
               int             nArgC,
               void           **ppArgV,
               u_int32         uStackSize,
               u_int8          uPrio,
               const char      *pszName,
               CNXT_THREAD_ID  *pId);

CNXT_STATUS cnxt_kal_thread_terminate(void);
CNXT_STATUS cnxt_kal_thread_id(CNXT_THREAD_ID *pId);

CNXT_STATUS cnxt_kal_thread_time_sleep(u_int32 uMs);
CNXT_STATUS cnxt_kal_thread_wakeup(CNXT_THREAD_ID Id);
CNXT_STATUS cnxt_kal_thread_mask(bool bOnOff);
CNXT_STATUS cnxt_kal_thread_get_mask( bool *pbMask );

CNXT_STATUS cnxt_kal_thread_priority(
               CNXT_THREAD_ID Id, 
               int16 nDelta, 
               u_int8 *puPriority);

CNXT_STATUS cnxt_kal_thread_set_pointer(
               CNXT_THREAD_ID Id, 
               void *pPtr, 
               void **ppOldPtr);

CNXT_STATUS cnxt_kal_thread_get_pointer(
               CNXT_THREAD_ID Id, 
               void **pPtr);

CNXT_STATUS cnxt_kal_thread_from_name(
               char *pszName, 
               CNXT_THREAD_ID *pId);

CNXT_STATUS cnxt_kal_make_async_thread_callback(
               PFNTHREADCALLBACK pfnCallback, 
               CNXT_KAL_CB_PRIORITY Priority, 
               u_int32 uParam1, 
               u_int32 uParam2, 
               void *pData);

CNXT_STATUS cnxt_kal_request_firmware(CNXT_FIRMWARE_INFO *pFirmware);
CNXT_STATUS cnxt_kal_release_firmware(CNXT_FIRMWARE_INFO *pFirmware);

#if (RTOS_PROFILING==YES)
CNXT_STATUS cnxt_kal_capture_thread_info(
                  CNXT_THREAD_ID        ThreadID,
                  CNXT_THREAD_INFO_SORT SortBy,
                  u_int32               uThreshold,
                  CNXT_THREAD_INFO     *pInfo,
                  u_int32               uLenInfo,
                  u_int32              *pNumInfoEntries);
                  
#if (defined DEBUG) || (ENABLE_TRACE_IN_RELEASE == YES)
void cnxt_kal_show_thread_info(
                  CNXT_THREAD_ID        ThreadID,
                  u_int32               uTraceFlags,
                  CNXT_THREAD_INFO_SORT SortBy,
                  u_int32               uThreshold);
#endif
#endif  /* RTOS_PROFILING */

//##*************************
//##** Semaphore Functions **
//##*************************

CNXT_STATUS cnxt_kal_sem_create(
               u_int32 uInitialValue, 
               const char *pszName, 
               CNXT_SEM_ID *pSem);

CNXT_STATUS cnxt_kal_sem_delete(CNXT_SEM_ID SemId);

CNXT_STATUS cnxt_kal_sem_get (
               CNXT_SEM_ID SemId, 
               u_int32 uTimeoutMs);
               
CNXT_STATUS cnxt_kal_sem_put( CNXT_SEM_ID SemId);


CNXT_STATUS cnxt_kal_sem_from_name(
               char *pszName, 
               CNXT_SEM_ID *pSem);

//##*******************************
//##** Hardware Semaphore Functions **
//##*******************************

CNXT_STATUS cnxt_kal_internal_hw_sems_init(void);

CNXT_STATUS cnxt_kal_hw_sem_from_name(char *pszName, CNXT_SEM_ID *pSemId);

CNXT_STATUS cnxt_kal_hw_sem_create (CNXT_KAL_HWSEM_CPU_ACCESS access, 
                                    CNXT_KAL_HWSEM_RESOURCE resource, 
                                    const char *pszName, 
                                    CNXT_SEM_ID *pSemId);

CNXT_STATUS cnxt_kal_hw_sem_get (CNXT_SEM_ID SemId, u_int32 uTimeoutMs);

CNXT_STATUS cnxt_kal_hw_sem_put( CNXT_SEM_ID SemId);

CNXT_STATUS cnxt_kal_hw_sem_delete(CNXT_SEM_ID SemId);

CNXT_STATUS cnxt_kal_hw_sem_print_all(void);

//##********************************
//##** Fall over and die horribly **
//##********************************

void cnxt_kal_fatal_exit_internal(
               u_int32 uCosmicConstant, 
               char *pszFilename, 
               int iLineNum);
               
#define cnxt_kal_fatal_exit(uError) cnxt_kal_fatal_exit_internal( \
               (uError),                                          \
                __FILE__,                                         \
                __LINE__)

//##**************
//##* Queue APIs *
//##**************

CNXT_STATUS cnxt_kal_qu_create(
               unsigned int nMaxElements, 
               const char *pszName, 
               CNXT_QUEUE_ID *pQuId);  

CNXT_STATUS cnxt_kal_qu_destroy(CNXT_QUEUE_ID QuId);

/* A queue message is generally represented as an array of 4 u_int32s. 
   Void pointers are, however, used to allow clients to easily cast this
   structure to another 16-byte structure if required. */
   
CNXT_STATUS cnxt_kal_qu_send(
               CNXT_QUEUE_ID QuId, 
               void          *pMessage);
               
CNXT_STATUS cnxt_kal_qu_receive(
               CNXT_QUEUE_ID QuId, 
               u_int32       uTimeoutMs, 
               void          *pMessage);

CNXT_STATUS cnxt_kal_qu_from_name(
               char          *pszName, 
               CNXT_QUEUE_ID *pQuId);

//##**********************************
//##* Dynamic Memory Allocation APIs *
//##**********************************

CNXT_STATUS cnxt_kal_mem_pool_create(
               u_int32 uSize, 
               u_int32 uPoolFlags, 
               const char *pszName, 
               CNXT_POOL_ID *pPool);

CNXT_STATUS cnxt_kal_mem_tile_pool(
               u_int32       uRgnWidth,
               u_int32       uTileWidth,
               u_int32       uTileHeight,
               CNXT_POOL_ID  poolId
                );

CNXT_STATUS cnxt_kal_mem_untile_pool(CNXT_POOL_ID  poolId);

CNXT_STATUS cnxt_kal_mem_pool_destroy(CNXT_POOL_ID Pool);

CNXT_STATUS cnxt_kal_mem_pool_from_name(
               char *pszName, 
               CNXT_POOL_ID *pPoolId);

CNXT_STATUS cnxt_kal_mem_get_info(
               void         *pPtr, 
               u_int32      *puSize,
               u_int32      *puPoolFlags, 
               CNXT_POOL_ID *pPoolID);


CNXT_STATUS cnxt_kal_mem_get_pool(
               void         *pPtr, 
               CNXT_POOL_ID *pPoolID);

CNXT_STATUS cnxt_kal_mem_malloc(
               CNXT_POOL_ID Pool, 
               u_int32 uSize, 
               u_int32 uFlags, 
               void **ppMem);
               
CNXT_STATUS cnxt_kal_mem_free(void *pMem);

   /* DESCRIPTION: Only available on linux (not on RTOS). */ 
CNXT_STATUS cnxt_kal_get_mem_pool_status(CNXT_POOL_ID poolId, CNXT_KAL_POOL_STATUS *poolStatus);

CNXT_STATUS cnxt_kal_mem_pool_get_free_size( CNXT_POOL_ID Pool, u_int32 *puFree);

#ifdef __KERNEL__
CNXT_STATUS cnxt_kal_flash_read(int mtd, void *buffer, loff_t offset, size_t count);
#endif
//##************************
//##* Pointer Manipulation *
//##************************

  /***************************************************************************
   * Note:
   * Historically, there has been an easy way to obtain a non-cached
   * view of a piece of memory.  Since the memory controller will
   * wrap memory when addressing past the end of physical memory,
   * we take advantage of the fact that upper addresses contain
   * a mirror image of lower addresses.  Alternatively, you can
   * accomplish the same thing with the MMU and virtual addresses.
   * Indeed, with our latter 920 based processors, we do just that
   * but maintain the simple "noncached bit" from older generations of chips.
   *
   * With linux, however, the story changes a bit.  Since the virtual address
   * map is quite different than a traditional RTOS, you can't simply OR in
   * the "noncached bit".    You must now use the UNCACHED_ADDR macro.
   *
   * Also note that there are three discrete memory pools:  cached, noncached,
   * and tiled (which is also noncached).  These macros can only convert a  
   * cached address into a non-cached address and perform the inverse function.
   * Nothing you can do, short of messing with page tables, will ever turn a
   * non-cached address into a cached address.
   *
   * CACHED_ADDR(uncached_ptr) will still leave you with an uncached ptr
   * but
   * CACHED_ADDR(UNCACHED_ADDR(cached_ptr)) == cached_ptr
   * get it?
   *
   * Lastly, note that these functions will not guaruntee cache coherency for
   * you.  If you operate on cached memory and switched to a noncached view
   * (or vice versa) you'll have to flush/invalidate your caches on your own.
   *
   *
  ***************************************************************************/

#if (RTOS==LINUX) 
   /* DESCRIPTION: Only available on linux as RTOS has a flat memory (no virtual). */ 
   CNXT_STATUS cnxt_kal_mem_virt_to_phys(u_int32 uVirt, 
                                         u_int32 *puPhys
   #ifdef DEBUG
                                         ,char *pszFile,
                                         u_int32 uLine
   #endif
                                         );

   /* this macro will only return the KLA of given physical address.  Note    */
   /* that the KLA is most likely cached.                                     */
   #define VIRTUAL_ADDRESS(ptr)  phys_to_virt((u_int32)ptr)
   #define PHYSICAL_ADDRESS(ptr) LINUX_PHYSICAL_ADDRESS(ptr, __FILE__, __LINE__)
   static inline u_int32 LINUX_PHYSICAL_ADDRESS(void * ptr,
                                                __attribute__((unused)) char *pszFile,
                                                __attribute__((unused)) u_int32 uLine)
   {
       u_int32 uPhys = 0;
   
       /* Return is ignored since this function will generate its own failure warnings. */
       cnxt_kal_mem_virt_to_phys((u_int32)ptr, &uPhys
   #ifdef DEBUG
                                 ,pszFile,
                                 uLine
   #endif
                                  );
      return uPhys;
   }
   #define PHYSICALLY_CONTIGUOUS __attribute__((__section__("__archdata")))

#else /* (RTOS!=LINUX) */

  
   #define PHYSICALLY_CONTIGUOUS 
   #define PHYSICAL_ADDRESS( ptr ) (((u_int32)(ptr)) & 0x3fffffff)
   #define VIRTUAL_ADDRESS( ptr )  ( ptr )

#endif

 CNXT_STATUS cnxt_kal_create_contiguous_block(
                void *pSrc,
                u_int32 uLength,
                void **ppDst);
               
 CNXT_STATUS cnxt_kal_free_contiguous_block(
                void *pBlock);

//##*******************
//##* Event functions *
//##*******************

/*  DESCRIPTION: STUB on Linux.  */
CNXT_STATUS cnxt_kal_event_create(CNXT_EVENTS *pEvents);

/*  DESCRIPTION: STUB on Linux.  */
CNXT_STATUS cnxt_kal_event_destroy(CNXT_EVENTS Events);

/*  DESCRIPTION: STUB on Linux.  */
CNXT_STATUS cnxt_kal_event_receive(
               CNXT_EVENTS Events, 
               CNXT_EVENTS *pReceived, 
               u_int32     uTimeoutMs, 
               bool        bWaitAll);
               
/*  DESCRIPTION: STUB on Linux.  */
CNXT_STATUS cnxt_kal_event_send(
               CNXT_THREAD_ID TargetThread, 
               CNXT_EVENTS    Events);

//##********************************
//##** Critical Section Functions **
//##********************************

CNXT_STATUS cnxt_kal_critsec_begin(CNXT_CRIT_STATE *pState );

CNXT_STATUS cnxt_kal_critsec_end(CNXT_CRIT_STATE PreviousState);

//##*****************************************************
//##** Time query functions (time since system booted) **
//##*****************************************************

CNXT_STATUS cnxt_kal_get_system_time( u_int32 *puTimeMs );
CNXT_STATUS cnxt_kal_get_system_time_us( u_int32 *puTimeUs );
#define CNXT_KAL_MEASURE_TIME_BEGIN();          \
   {                                            \
      u_int32 uTmpTime0, uTmpTime1, uTmpLine ;  \
      uTmpLine = __LINE__;                      \
      cnxt_kal_get_system_time_us(&uTmpTime0);

#define CNXT_KAL_MEASURE_TIME_END()                   \
      cnxt_kal_get_system_time_us(&uTmpTime1);         \
      cnxt_kal_trace(                                 \
            CNXT_TRACE_ANY | CNXT_TRACE_LEVEL_ALWAYS, \
            "%s: Line %d to %d: dT = %d\n",           \
            __FILE__, uTmpLine, __LINE__,             \
            uTmpTime1 - uTmpTime0);                     \
   }
 

//##***********************
//##** Tick Counter APIs **
//##***********************

CNXT_STATUS cnxt_kal_tick_create(
               PFNTICKFUNC  pfnCallback, 
               void         *pUserData, 
               const char   *pszName, 
               CNXT_TICK_ID *pTick);
               
CNXT_STATUS cnxt_kal_tick_destroy(CNXT_TICK_ID Timer);

CNXT_STATUS cnxt_kal_tick_set(
               CNXT_TICK_ID Timer, 
               u_int32      uPeriodMs, 
               bool         bOneShot);
               
CNXT_STATUS cnxt_kal_tick_start(CNXT_TICK_ID Timer);

CNXT_STATUS cnxt_kal_tick_stop(CNXT_TICK_ID Timer);

CNXT_STATUS cnxt_kal_tick_get_info(
               CNXT_TICK_ID    Timer, 
               CNXT_TICK_INFO *pInfo);

CNXT_STATUS cnxt_kal_tick_from_name(
               const char   *pszName, 
               CNXT_TICK_ID *pTimer);

CNXT_STATUS cnxt_kal_tick_get_max_period(
                u_int32 *pPeriodMs);

//##*********************************
//##** Hardware Timer Service APIs **
//##*********************************

typedef void (*PFNTIMER)(CNXT_TIMER_ID, void *);

/*  DESCRIPTION: STUB on Linux.  */
CNXT_STATUS cnxt_kal_timer_create(
               PFNTIMERFUNC  pfnCallback, 
               void          *pUserData, 
               const char    *pszName, 
               CNXT_TIMER_ID *pTimer);
               
/*  DESCRIPTION: STUB on Linux.  */
CNXT_STATUS cnxt_kal_timer_destroy(CNXT_TIMER_ID Timer);

/*  DESCRIPTION: STUB on Linux.  */
CNXT_STATUS cnxt_kal_timer_set(
               CNXT_TIMER_ID Timer, 
               u_int32       uPeriodUs, 
               bool          bOneShot);
               
/*  DESCRIPTION: STUB on Linux.  */
CNXT_STATUS cnxt_kal_timer_start(CNXT_TIMER_ID);

/*  DESCRIPTION: STUB on Linux.  */
CNXT_STATUS cnxt_kal_timer_stop(CNXT_TIMER_ID);

//##********************************
//##** System Watchdog Timer APIs **
//##********************************

CNXT_STATUS cnxt_kal_system_watchdog_running(bool *pbRunning);

CNXT_STATUS cnxt_kal_system_watchdog_set(u_int32 uPeriodMs, bool bUserClear);

CNXT_STATUS cnxt_kal_system_watchdog_enable(bool bEnable);

CNXT_STATUS cnxt_kal_system_watchdog_clear(void);

//##****************************************************
//##** Miscellaneous Shared resource access functions **
//##****************************************************

CNXT_STATUS cnxt_kal_get_board_and_vendor_codes(
               u_int8 *puBoard, 
               u_int8 *puVendor);
               
CNXT_STATUS cnxt_kal_get_chip_id_and_revision(
               u_int32 *puChip, 
               u_int8  *puRev);
               
void            cnxt_kal_reboot_IRD(void);

//##*****************************************
//##** Interrupt Service Routine functions **
//##*****************************************

CNXT_STATUS cnxt_kal_int_register(
               u_int32 dwIntID,
               PFNISR  pfnHandler,
               bool    bFIQ);
               
CNXT_STATUS cnxt_kal_int_deregister(
               u_int32 dwIntID,
               PFNISR  pfnHandler);
               
CNXT_STATUS cnxt_kal_int_complete(
               u_int32 dwIntID,
               PFNISR  pfnHandler);
               
CNXT_STATUS cnxt_kal_int_enable(u_int32 dwIntID);

CNXT_STATUS cnxt_kal_int_disable(u_int32 dwIntID);

CNXT_STATUS cnxt_kal_ipc_int_assert (u_int32 dwIntID);
CNXT_STATUS cnxt_kal_ipc_int_clear (u_int32 dwIntID);
CNXT_STATUS cnxt_kal_ipc_int_register(u_int32 dwIntID, PFNISR pfnHandler, bool bFIQ);
CNXT_STATUS cnxt_kal_ipc_int_deregister(u_int32 dwIntID, PFNISR pfnHandler);
CNXT_STATUS cnxt_kal_ipc_int_complete(u_int32 dwIntID, PFNISR pfnHandler);
CNXT_STATUS cnxt_kal_ipc_int_enable(u_int32 dwIntID);
CNXT_STATUS cnxt_kal_ipc_int_disable(u_int32 dwIntID);


//##*********************
//##** Debug Functions **
//##*********************

//##**************************************************************************
//##* Context checking functions - these hang if called in the wrong context *
//##**************************************************************************

CNXT_STATUS cnxt_kal_only_interrupt_safe( void );

void        cnxt_kal_not_interrupt_safe( void );
                                                     
//##*************************************
//##* Trace and Error Logging Functions *
//##*************************************

/* Max number of chars in a trace msg */
#define CNXT_MAX_TRACEMSG_CHARS 161
/* Max number of trace msgs in trace queue */
#define CNXT_MAX_TRACEMSGS       200
#define CNXT_MAX_ISR_DEBUG_QUEUE 50

/* Error logging */
#if !(defined DEBUG) && (ENABLE_TRACE_IN_RELEASE == NO)

/* Non-debug case */
CNXT_STATUS cnxt_kal_error_log(u_int32 uError);
#define cnxt_kal_isr_error_log cnxt_kal_error_log

#else

/* Debug case - wrap in macros so that we can add file and line number automatically */
CNXT_STATUS cnxt_kal_debug_error_log(
               u_int32 uError, 
               char    *pszFile, 
               int     nLineNum);
               
#define cnxt_kal_error_log(x) cnxt_kal_debug_error_log((x), __FILE__, __LINE__)

CNXT_STATUS cnxt_kal_debug_isr_error_log(
               u_int32 uError, 
               char    *pszFile, 
               int     nLineNum);
               
#define cnxt_kal_isr_error_log(x) cnxt_kal_debug_isr_error_log((x), __FILE__, __LINE__)

#endif

#if (defined DEBUG) || (ENABLE_TRACE_IN_RELEASE == YES)

CNXT_STATUS cnxt_kal_trace_set_module_flag(
               u_int32          uModuleID, 
               bool             bEnable, 
               CNXT_TRACE_FLAGS *pFlags);

CNXT_STATUS cnxt_kal_trace_get_module_flag(
               u_int32          uModuleID, 
               bool             *pbEnabled, 
               CNXT_TRACE_FLAGS *pFlags);

void cnxt_kal_trace(
               u_int32 uFlags, 
               char *pszString, 
               ...);
               
void cnxt_kal_isr_trace(
               u_int32 uFlags, 
               char    *pszString, 
               u_int32 uValue1, 
               u_int32 uValue2);
               
CNXT_STATUS cnxt_kal_flush_trace_on_abort(void);

CNXT_STATUS cnxt_kal_trace_set_level(
               u_int32          uLevel, 
               bool             bTimestamp,
               CNXT_TRACE_FLAGS *pFlags);
               
CNXT_STATUS cnxt_kal_trace_get_level(
               u_int32          *puLevel, 
               bool             *pbTimestamp,
               CNXT_TRACE_FLAGS *pFlags);
               
CNXT_STATUS cnxt_kal_trace_module(
               u_int32 uModuleID, 
               bool    bEnable);
               
CNXT_STATUS cnxt_kal_trace_is_module_enabled(
               u_int32 uModuleID, 
               bool    *pbEnabled);

CNXT_STATUS cnxt_kal_checkpoint(int nCheckpointNum);

#else

/* In non-Debug builds, trace calls are compiled to nothing */
#define cnxt_kal_trace         while (0) ((int (*)(u_int32,char *, ...)) 0)
#define cnxt_kal_isr_trace     while (0) ((int (*)(u_int32,char *, ...)) 0)

#endif

//##********************************
//##* Timestamped Message Function *
//##********************************
#if (defined DEBUG) || (ENABLE_TRACE_IN_RELEASE == YES)
/* When trace is enabled, this aliases to the basic trace function */
#define cnxt_kal_timestamp_message(str) \
      cnxt_kal_trace(CNXT_TRACE_LEVEL_ALWAYS|CNXT_TRACE_ANY, (str))
#else
/* When trace is disabled, we have a special function for timestamp messages */
CNXT_STATUS cnxt_kal_timestamp_message(char *pszStr);
#endif

//##*****************************
//##** Cache Control Functions **
//##*****************************

CNXT_STATUS cnxt_kal_flush_i_cache(void);

CNXT_STATUS cnxt_kal_disable_i_cache(void);

CNXT_STATUS cnxt_kal_enable_i_cache(void);

CNXT_STATUS cnxt_kal_clean_d_cache(void);

CNXT_STATUS cnxt_kal_flush_d_cache(void);

CNXT_STATUS cnxt_kal_disable_d_cache(void);

CNXT_STATUS cnxt_kal_enable_d_cache(void);

CNXT_STATUS cnxt_kal_drain_write_buffer(void);

CNXT_STATUS cnxt_kal_clean_and_inval_d_cache_range(
               void    *pBase, 
               u_int32 uSize);

CNXT_STATUS cnxt_kal_inval_d_cache_range(
               void    *pBase, 
               u_int32 uSize);

CNXT_STATUS cnxt_kal_clean_invalidate_d_cache(void);

/*  DESCRIPTION: STUB on Linux.  */
CNXT_STATUS cnxt_kal_disable_all_hw_ints(void);


//##************************
//##** C Runtime Wrappers **
//##************************

CNXT_STATUS cnxt_kal_memcpy(
               void       *p1, 
               const void *p2, 
               u_int32    uSize); 
               
CNXT_STATUS cnxt_kal_memcmp(
               const void *p1, 
               const void *p2, 
               u_int32    uSize, 
               int32      *pComparison );
                                 
CNXT_STATUS cnxt_kal_memset(
               void    *p1, 
               u_int8  uVal, 
               u_int32 uSize);
               
CNXT_STATUS cnxt_kal_strlen(
               const char *pszString, 
               u_int32    *pSize);
               
CNXT_STATUS cnxt_kal_strcpy(
               char       *pszDest, 
               const char *pszSrc);
               
CNXT_STATUS cnxt_kal_strncpy(
               char       *pszDest, 
               const char *pszSrc, 
               u_int32    uSize);
               
CNXT_STATUS cnxt_kal_strcmp(
               const char *pszStr1, 
               const char *pszStr2, 
               int32      *pComparison );
               
CNXT_STATUS cnxt_kal_strncmp(
               const char *pszStr1, 
               const char *pszStr2, 
               u_int32    uSize, 
               int32      *pComparison );
               
CNXT_STATUS cnxt_kal_sprintf(
               char       *pBuffer, 
               const char *pszFormat,
               ...);

CNXT_STATUS cnxt_kal_snprintf(
               u_int8 *src, 
               u_int32 size, 
               u_int32 *output, 
               const char *format,
               ...);

char *cnxt_kal_strtok(char *pBuffer, const char *pDelimiters);

//##*****************************
//##** RTOS-specific functions **
//##*****************************

/******************************************************************************/
/* WARNING:                                                                   */
/*                                                                            */
/* The following functions have been added to cater for specific middleware   */
/* and are only implemented in particular RTOS versions of the KAL. These are */
/* NOT part of the "official" KAL API. No Conexant software apart from the    */
/* KAL testcase may use these functions!!!!                                   */
/******************************************************************************/

#if (RTOS == NUP)

/* CNXT_THREAD_STATUS values will match the task status values returned by
   function NU_Task_Information. */
#define CNXT_THREAD_STATUS unsigned char

CNXT_STATUS cnxt_kal_thread_suspend(
               CNXT_THREAD_ID      Id);
               
CNXT_STATUS cnxt_kal_thread_resume(
               CNXT_THREAD_ID      Id);
               
CNXT_STATUS cnxt_kal_thread_get_status(
               CNXT_THREAD_ID      Id, 
               CNXT_THREAD_STATUS *pStatus);
               
CNXT_STATUS cnxt_kal_thread_destroy(
               CNXT_THREAD_ID      Id);

#endif /* RTOS == NUP */
#endif

/******************************************************************************
 * Modifications:
 * $Log:
 *  41   mpeg       1.40        5/17/07 2:37:00 AM CDT Amarinder Singh Sethi
 *       CR(s) 27705 27706 : Added a new KAL API to return the poolID and
 *       flags for a given memory pointer
 *  40   mpeg       1.39        5/6/07 9:55:39 PM CDT  Miles Bintz     CR(s)
 *       27071 27072 : readjusted pre-processor logic on inclusion of
 *       linux/kernel.h
 *  39   mpeg       1.38        5/5/07 5:41:05 PM CDT  Miles Bintz     CR(s)
 *       26337 26336 : in the UBS include paths on the command line are
 *       different.  The UBS doesn't need linux/config.h  Wrap it in a flag so
 *        the files can be common between LBS and UBS
 *  38   mpeg       1.37        1/5/07 1:06:36 PM CST  Har Yash Bahadur CR(s)
 *       23063 : Defined the macro KAL_UNCACHED_ADDR for supporting Malone
 *       shared memory access in Linux.
 *  37   mpeg       1.36        12/29/06 12:50:20 PM CSTRadhaKumar Pulyala
 *       CR(s) 22882 : ISPECOS flag removed for clean_invalidat_d_cache API
 *       including.
 *  36   mpeg       1.35        12/14/06 2:42:58 PM CSTMiles Bintz     CR(s)
 *       22540 : added a KAL macro to return the equivalent uncached version
 *       of a pointer
 *  35   mpeg       1.34        11/15/06 7:10:41 AM CSTRadhaKumar Pulyala CR(s)
 *        21650 : Pecos specific changes for ITC, L1 and L2 Caches and MMU
 *
 *       
 *  34   mpeg       1.33        11/14/06 3:42:27 PM CSTDave Wilson     CR(s)
 *       19614 : Added new functions cnxt_kal_system_watchdog_enable and
 *       cnxt_kal_system_watchdog_clear.
 *  33   mpeg       1.32        11/13/06 3:09:54 PM CSTDave Wilson     CR(s)
 *       21455 : Added prototypes for new functions
 *       cnxt_kal_create/free_contiguous_block.
 *  32   mpeg       1.31        2/23/06 4:12:00 PM CST Billy Jackman   CR(s)
 *       17984 17985 : Added prototype for new KAL API
 *       cnxt_kal_inval_d_cache_range.
 *  31   mpeg       1.30        2/8/06 3:48:04 AM CST  Ofer Senderovitz CR(s)
 *       17804 17996 : remove the vxWorks functions from KAL
 *  30   mpeg       1.29        12/28/05 1:14:29 PM CSTDave Wilson     CR(s)
 *       15296 17995 : Added prototypes for cnxt_kal_show_thread_info and
 *       cnxt_kal_capture_thread_info which allow thread state and CPU
 *       utilisation values to be displayed in the trace log or captured into
 *       a structure. These calls are only implemented when RTOS_PROFILING is
 *       defined as YES in the software config file. Note that, as of
 *       12/28/05, only Nucleus+ KAL has support for this feature. It is being
 *        added to the other KALs, however.
 *  29   mpeg       1.28        12/16/05 8:59:30 PM CSTMiles Bintz     CR(s)
 *       17159 17994 : added time measurement macros
 *  28   mpeg       1.27        10/7/05 7:30:35 AM CDT Dave Wilson     CR(s)
 *       15992 : Added functions cnxt_kal_thread_suspend,
 *       cnxt_kal_thread_resume, cnxt_kal_thread_destroy and
 *       cnxt_kal_thread_get_status. This function is required by some
 *       middleware.
 *
 *       NOTE: These functions are not part of the published KAL API and will
 *       not be implemented on other KAL versions for different RTOSs. No
 *       Conexant code should used these functions!
 *  27   mpeg       1.26        8/31/05 5:55:49 AM CDT Ofer Senderovitz CR(s)
 *       15475 : Add functions to free a network data buffer/data buffer
 *       structure
 *  26   mpeg       1.25        5/3/05 5:58:59 PM CDT  Miles Bintz     CR(s)
 *       13956 : added correct definitinos for physically_contiguous and added
 *        linux support to kal 
 *  25   mpeg       1.24        1/25/05 10:49:09 AM CSTMiles Bintz     CR(s)
 *       12800 : added the physically contiguous modifier to declarations
 *  24   mpeg       1.23        1/24/05 12:24:28 PM CSTMiles Bintz     CR(s)
 *       12776 12777 : back out change to physical address macro
 *  23   mpeg       1.22        1/21/05 5:00:40 PM CST Miles Bintz     CR(s)
 *       12760 12761 : added definitions for PHYSICAL_ADDRESS and
 *       PHYSICALLY_CONTIGUOUS to linux portion of rtos kal header
 *  22   mpeg       1.21        11/16/04 1:50:38 PM CSTBilly Jackman   CR(s)
 *       11701 11702 : Change the definition of cnxt_kal_isr_trace in release
 *       mode to match the definition of cnxt_kal_trace to avoid compiler
 *       warnings about statement with no effect.
 *  21   mpeg       1.20        10/11/04 8:06:41 PM CDTBilly Jackman   CR(s)
 *       10245 : Use new model of int_register/int_deregister and centralized
 *       chaining.
 *  20   mpeg       1.19        8/16/04 6:11:29 PM CDT Dave Wilson     CR(s)
 *       10090 : Added prototype for new function
 *       cnxt_kal_mem_tiled_pool_create.
 *  19   mpeg       1.18        8/12/04 10:51:54 AM CDTBilly Jackman   CR(s)
 *       10067 : Add macro PHYSICAL_ADDRESS(ptr) to convert an ARM pointer to
 *       a physical address. All other components in the system except the ARM
 *        processor must be given addresses as physical addresses.
 *  18   mpeg       1.17        8/2/04 10:01:41 AM CDT Dave Wilson     CR(s)
 *       9921 : Changed to use new common return code type CNXT_STATUS.
 *  17   mpeg       1.16        6/17/04 5:22:38 PM CDT Billy Jackman   CR(s)
 *       9501 : Fix compiler warnings/errors.
 *  16   mpeg       1.15        6/16/04 12:13:28 PM CDTBilly Jackman   CR(s)
 *       9485 : Parenthesize the defined value for trce functions to avoid
 *       warning message.
 *  15   mpeg       1.14        6/8/04 11:50:18 AM CDT Regina Joiner   CR(s)
 *       9367 : Modified cnxt_kal_thread_get_pointer to have a void** as a
 *       parameter instead of void*
 *  14   mpeg       1.13        5/18/04 2:30:47 PM CDT Dave Wilson     CR(s)
 *       9181 : Updated trace flags to match new definitions.
 *  13   mpeg       1.12        5/10/04 4:35:07 PM CDT Dave Wilson     CR(s)
 *       8942 : Removed redundant pool ID parameter from cnxt_kal_mem_free.
 *  12   mpeg       1.11        4/22/04 6:19:37 PM CDT Dave Wilson     CR(s)
 *       8931 : Added prototypes for C runtime wrapper functions.
 *  11   mpeg       1.10        4/12/04 4:51:25 PM CDT Dave Wilson     CR(s)
 *       8835 : Miscellaneous changes to get a small app to build and link in
 *       the Edwards tree
 *  10   mpeg       1.9         4/9/04 4:44:31 PM CDT  Dave Wilson     CR(s)
 *       8821 : Changes made in porting of HWLIB to Edwards. Added
 *       CNXT_KAL_BAD_HANDLE return code and removed offlevel ISR function
 *       prototypes.
 *  9    mpeg       1.8         4/8/04 2:31:33 PM CDT  Dave Wilson     CR(s)
 *       8810 : Added definitions of maximum trace string length and number of
 *        queued trace messages. These are needed by the test harness.
 *  8    mpeg       1.7         4/7/04 4:50:37 PM CDT  Joe Kroesche    CR(s)
 *       8697 : updated prototypes needed for KAL
 *  7    mpeg       1.6         3/29/04 6:58:35 PM CST Joe Kroesche    CR(s)
 *       8697 : added prototypes for hw timers, removed include of kal_rtos
 *       header file
 *  6    mpeg       1.5         2/20/04 5:00:19 PM CST Xin Golden      CR(s)
 *       8290 : added API cnxt_kal_clean_and_inval_d_cache_range in user kal.
 *  5    mpeg       1.4         2/16/04 5:35:06 PM CST Xin Golden      CR(s)
 *       8290 : removed parameter pStack from cnxt_kal_thread_create because
 *       user shouldn't have control on it.
 *  4    mpeg       1.3         2/12/04 3:30:30 PM CST Billy Jackman   CR(s)
 *       8405 : Modified to allow compile to succeed.  Altered names and
 *       format to match coding standards.
 *  3    mpeg       1.2         1/23/04 11:36:15 AM CSTDave Wilson     CR(s)
 *       8260 : Added definition of UNIT_DONT_CARE
 *  2    mpeg       1.1         1/22/04 5:16:08 PM CST Dave Wilson     CR(s)
 *       8260 : Modifications as a result of writing VM Driver Design
 *       Guidelines document.
 *       
 *  1    mpeg       1.0         1/21/04 3:26:44 PM CST Dave Wilson     CR(s)
 *       8260 : User-space Kernel Adaptation Layer public header.
 * $ 
 ******************************************************************************/


