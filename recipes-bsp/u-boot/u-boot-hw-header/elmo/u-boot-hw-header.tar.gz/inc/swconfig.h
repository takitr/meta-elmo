/****************************************************************************/ 
 /*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
 /*                       SOFTWARE FILE/MODULE HEADER                        */
 /*                      Conexant Systems Inc. (c) 2004                      */
 /*                         All Rights Reserved                              */
 /****************************************************************************/
 /*
  * Filename: swconfig.h
  *
  * Description: Top Level Software Defintions for C Files
  *
  * Author: Bobby Bradford
  *
  ****************************************************************************/
 /* $Id: swconfig.h 99754 2009-06-25 22:40:42Z gargn $
  ****************************************************************************/ 

#ifndef __STBCFG_H__
   /* Should generate a "warning" here, but don't recall how */
   #include "stbcfg.h"
#endif   /*#ifndef __STBCFG_H__*/

#ifndef  __SWCONFIG_H__
#define  __SWCONFIG_H__

/****************************************************************************
 * Basic Structure of this file is as follows ...
 *
 * SECTION 1 - Definition of SOFTWARE CONFIG parameter values.  This section
 *    will define all of the possible values that a software configuration
 *    parameter can take.
 *
 * SECTION 2 - Optional inclusion of translated SWCONFIG file.  To allow for
 *    the transition to using software configuration files, if no software
 *    config file is specified on the command line, a default value of NONE
 *    will be assumed for directory tree purposes, no translation will take
 *    place, no translated file will be included, and the default values
 *    that are defined in SECTION 3 will be used.
 *
 * SECTION 3 - Defintion of DEFAULT value for all SOFTWARE configuration
 *    features.  These values will be used if a SWCONFIG file does not
 *    specify a feature, or if the SWCONFIG option is not specified on the
 *    make command line.
 *
 ****************************************************************************/

/****************************************************************************
 * SECTION 1 - Defintion of Software Config Parameter Values
 *
 * These values are now generated dynamically during the build from the 
 * file CONFIGS/SWCONFIG.CFG using the CFGTOH tool.
 ****************************************************************************/
#include "swopts.h"

/********************************************/
/* Generic Driver Task Priorities and Names */
/********************************************/
#include "taskprio.h"

/****************************************************************************
 * SECTION 2 - Optional inclusion of translated SWCONFIG file
 ****************************************************************************/
   #if (SWCONFIG_INCL == 1)
      #include "swboxcfg.h"
   #endif   /* #if (SWCONFIG_INCL == 1) */

/****************************************************************************
 * SECTION 3 - Definition of Default Values
 *
 * These values are now generated dynamically during the build from the 
 * file CONFIGS/SWCONFIG.CFG using the CFGTOH tool.
 ****************************************************************************/
#include "swdefault.h"

/*
 * Define IMAGE_TYPE variations which must be defined for 'C' files
 */
#define GENERIC       1111
#define BOOT          2222
#define BOOTEXT       4444

/*
 * Define CLX_ENTRY_POINT variations which must be defined for 'C' files
 */
#define MIN_INIT      1
#define PARTIAL_INIT  2
#define FULL_INIT     3

#endif   /* #ifndef  __SWCONFIG_H__ */


/****************************************************************************
 * Modifications:
 * $Log$
 *
 ****************************************************************************/ 

