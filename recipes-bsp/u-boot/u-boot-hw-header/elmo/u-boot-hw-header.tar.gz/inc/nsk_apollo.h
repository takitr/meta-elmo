/****************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
/*                       SOFTWARE FILE/MODULE HEADER                        */
/*                      Conexant Systems Inc. (c) 2009                      */
/*                               Austin, TX                                 */
/*                            All Rights Reserved                           */
/****************************************************************************/
/*
* Filename: nsk_apollo.h
*
* Description: Public header file defining hardware-specific values
* (such as register addresses, bit definitions, etc.) for SVP module 
*
* Author:   G V Lakshmi Narayana 
*
****************************************************************************/
/* $Id $
****************************************************************************/

#ifndef _NSK_APOLLO_H_
#define _NSK_APOLLO_H_


/* NSK Module Internal Registers */
#define NSK_ERROR1_COMMAND_REG(x)       (NSK_BASE_INSTANCE(x) + 0x0000)
#define NSK_ERROR2_REG(x)               (NSK_BASE_INSTANCE(x) + 0x0004)
#define NSK_WARNING_REG(x)              (NSK_BASE_INSTANCE(x) + 0x0008)
#define NSK_INTERRUPT_REG(x)            (NSK_BASE_INSTANCE(x) + 0x000c)
#define NSK_STATUS_REG0(x)              (NSK_BASE_INSTANCE(x) + 0x0010)
#define NSK_STATUS_REG1(x)              (NSK_BASE_INSTANCE(x) + 0x0014)
#define NSK_STATUS_REG2(x)              (NSK_BASE_INSTANCE(x) + 0x0018)
#define NSK_STATUS_REG3(x)              (NSK_BASE_INSTANCE(x) + 0x001c)
#define NSK_STATUS_REG4(x)              (NSK_BASE_INSTANCE(x) + 0x0020)
#define NSK_STATUS_REG5(x)              (NSK_BASE_INSTANCE(x) + 0x0024)
#define NSK_STATUS_REG6(x)              (NSK_BASE_INSTANCE(x) + 0x0028)
#define NSK_CONTROL_BLOCK_REG(x)        (NSK_BASE_INSTANCE(x) + 0x01fc)
#define NSK_IO_REGISTER_BASE(x)         (NSK_BASE_INSTANCE(x) + 0x0200)
#define NSK_IO_REGISTER_END(x)          (NSK_BASE_INSTANCE(x) + 0x02fc)

/* Newton Registers */
#define NSK_CW0_WORD0_REG(x)            (NSK_BASE_INSTANCE(x) + 0x0400)
#define NSK_CW0_WORD1_REG(x)            (NSK_BASE_INSTANCE(x) + 0x0404)
#define NSK_CW0_WORD2_REG(x)            (NSK_BASE_INSTANCE(x) + 0x0408)
#define NSK_CW0_WORD3_REG(x)            (NSK_BASE_INSTANCE(x) + 0x040c)
#define NSK_CW1_WORD0_REG(x)            (NSK_BASE_INSTANCE(x) + 0x0410)
#define NSK_CW1_WORD1_REG(x)            (NSK_BASE_INSTANCE(x) + 0x0414)
#define NSK_CW1_WORD2_REG(x)            (NSK_BASE_INSTANCE(x) + 0x0418)
#define NSK_CW1_WORD3_REG(x)            (NSK_BASE_INSTANCE(x) + 0x041c)

#define NSK_ACPU_COMMAND_REG(x)         (NSK_BASE_INSTANCE(x) + 0x0500)
#define     NSK_ACPU_ESASUB_MASK             0xe0000000
#define     NSK_ACPU_ESASUB_SHIFT            29
#define     NSK_ACPU_CDMA_DESCRAM_MASK       0x10000000
#define     NSK_ACPU_CDMA_DESCRAM_SHIFT      28
#define     NSK_ACPU_CDMA_SCRAM_MASK         0x08000000
#define     NSK_ACPU_CDMA_SCRAM_SHIFT        27
#define     NSK_ACPU_LEG_DESCRAM_MASK        0x04000000
#define     NSK_ACPU_LEG_DESCRAM_SHIFT       26  
#define     NSK_ACPU_LEG_SCRAM_MASK          0x02000000
#define     NSK_ACPU_LEG_SCRAM_SHIFT         25
#define     NSK_ACPU_AV_FLAGS_MASK           0x01c00000
#define     NSK_ACPU_AV_FLAGS_SHIFT          22
#define     NSK_ACPU_SETKTE_MASK             0x00200000
#define     NSK_ACPU_SETKTE_SHIFT            21
#define     NSK_ACPU_WRITEKTE_MASK           0x00100000
#define     NSK_ACPU_WRITEKTE_SHIFT          20
#define     NSK_ACPU_TSP_MASK                0x000c0000
#define     NSK_ACPU_TSP_SHIFT               18
#define     NSK_ACPU_KSI_MASK                0x0000ff00
#define     NSK_ACPU_KSI_SHIFT               8
#define     NSK_ACPU_SCB_MASK                0x000000c0
#define     NSK_ACPU_SCB_SHIFT               6
#define     NSK_ACPU_CRYPT_DESCRAM_MASK      0x00000038
#define     NSK_ACPU_CRYPT_DESCRAM_SHIFT     3
#define     NSK_ACPU_CRYPT_SCRAM_MASK        0x00000007
#define     NSK_ACPU_CRYPT_SCRAM_SHIFT       0

#define NSK_KTE_FI_FXI_SWITCHES_REG(x)  (NSK_BASE_INSTANCE(x) + 0x0504)
#define NSK_KTE_CONTROL_SWITCHES_REG(x) (NSK_BASE_INSTANCE(x) + 0x0508)
#define NSK_INTERRUPT_ENABLE_REG(x)     (NSK_BASE_INSTANCE(x) + 0x0FE4)
#define NSK_ACPU_STATUS_REG(x)          (NSK_BASE_INSTANCE(x) + 0x0510)
#define     NSK_ACPU_GVPONLY_MASK               0x80000000
#define     NSK_ACPU_GVPONLY_SHIFT              31
#define     NSK_ACPU_UPDATE_DONE_MASK           0x40000000
#define     NSK_ACPU_UPDATE_DONE_SHIFT          30
#define     NSK_ACPU_BUSY_MASK                  0x20000000
#define     NSK_ACPU_BUSY_SHIFT                 29
#define     NSK_ACPU_NSA_AS_ESA_MASK            0x00020000
#define     NSK_ACPU_NSA_AS_ESA_SHIFT           17
#define     NSK_ACPU_CRYPTO_DMA_MASK            0x00010000
#define     NSK_ACPU_CRYPTO_DMA_SHIFT           16
#define     NSK_ACPU_AVPERMITTED_MASK           0x00000040
#define     NSK_ACPU_AVPERMITTED_SHIFT          6
#define     NSK_ACPU_DISABLE_CPCW_MASK          0x00000020
#define     NSK_ACPU_DISABLE_CPCW_SHIFT         5
#define     NSK_ACPU_NOT_SVP_MODE_MASK          0x00000010
#define     NSK_ACPU_NOT_SVP_MODE_SHIFT         4
#define     NSK_ACPU_WR_WHILE_BUSY_MASK         0x00000008
#define     NSK_ACPU_WR_WHILE_BUSY_SHIFT        3
#define     NSK_ACPU_ILLEGAL_WRITE_SET_KTE_MASK 0x00000004
#define     NSK_ACPU_ILLEGAL_WRITE_SET_KTE_SHIFT 2
#define     NSK_ACPU_NOT_LCC_PERMITTED_MASK     0x00000002
#define     NSK_ACPU_NOT_LCC_PERMITTED_SHIFT    1
#define     NSK_ACPU_ASM_DISABLE_MASK           0x00000001 
#define     NSK_ACPU_ASM_DISABLE_SHIFT          0
#define     NSK_ACPU_ERROR_MASK                 0x800001ff
#define     NSK_ACPU_WARNING_MASK               0x00030000

#define NSK_INTR_ENAB_CLR(x)  (NSK_BASE_INSTANCE(x) + 0x0FD8)
#define NSK_INTR_ENAB_SET(x)  (NSK_BASE_INSTANCE(x) + 0x0FDC)
#define NSK_INTR_STAT(x)      (NSK_BASE_INSTANCE(x) + 0x0FE0)
#define NSK_INTR_ENAB(x)      (NSK_BASE_INSTANCE(x) + 0x0FE4)
#define NSK_INTR_STAT_CLR(x)  (NSK_BASE_INSTANCE(x) + 0x0FE8)
#define NSK_INTR_STAT_SET(x)  (NSK_BASE_INSTANCE(x) + 0x0FEC)

#define NSK_INTR_NSKIRQ_MASK           0x00000001
#define NSK_INTR_NSKIRQ_SHIFT          0
#define NSK_INTR_ACPU_CMD_CMPLT_MASK   0x00000002
#define NSK_INTR_ACPU_CMD_CMPLT_SHIFT  1

#endif

/**************************************************************************** 
 * Modifications:
 * $Log$
 *
 ****************************************************************************/


