/****************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
/*                       SOFTWARE FILE/MODULE HEADER                        */
/*                    Conexant Systems Inc. (c) 2007                        */
/*                         All Rights Reserved                              */
/****************************************************************************/
/*
 * Filename:        CONEXANT.H
 *
 *
 * Description:     Public header file containing Conexant Internal
 *                  board specific hardware configuration values
 *
 *
 * Author:          Tim White
 *
 ****************************************************************************/
/* $Id: conexant.h 99754 2009-06-25 22:40:42Z gargn $
 ****************************************************************************/

#include "warnfix.h"

#ifndef _CONEXANT_H_
#define _CONEXANT_H_

/***************************************/
/* Conexant Config Bit Definitions for */
/* accessing register as a DWORD       */
/***************************************/
#define RSO_BOARD_ID            0x0000007f
#define RSO_FLASH_DESC          0x00007800
#define RSO_RAM_CFG             0x00180000

#define RSO_RAM_SHIFT           19

#define VIDFORMAT_NTSC      0
#define VIDFORMAT_PAL       1
#define VIDFORMAT_SECAM     2

/******************************************************/
/* Conexant Internal configuration definitions        */
/******************************************************/
#define     PLL_CONFIG0_MEMORY_BUS_WIDTH_MASK                      0x00000010
#define     PLL_CONFIG0_MEMORY_BUS_WIDTH_SHIFT                            4
#define         PLL_CONFIG0_MEMORY_BUS_16BITS_WIDE                   (0UL<<4)
#define         PLL_CONFIG0_MEMORY_BUS_32BITS_WIDE                   (1UL<<4)


/****************************************************************/
/* Generic Board Configuration definitions(found in EEPROM)     */
/****************************************************************/
#define    BOARD_CONFIG_VERSION_CODE_OFFSET            0x00000000
#define    BOARD_CONFIG_VERSION_CODE_SIZE                     1
#define    BOARD_CONFIG_LENGTH_OFFSET                  0x00000001
#define    BOARD_CONFIG_LENGTH_SIZE                           3
#define    BOARD_CONFIG_CHECKSUM_OFFSET                0x00000004
#define    BOARD_CONFIG_CHECKSUM_SIZE                         2
#define    BOARD_CONFIG_INV_CHECKSUM_OFFSET            0x00000006
#define    BOARD_CONFIG_INV_CHECKSUM_SIZE                     2
#define    BOARD_CONFIG_XTAL_SPEED_OFFSET              0x00000008
#define    BOARD_CONFIG_XTAL_SPEED_SIZE                       4
#define    BOARD_CONFIG_CUSTOMER_ID_OFFSET             0x0000000C
#define    BOARD_CONFIG_CUSTOMER_ID_SIZE                      1
#define    BOARD_CONFIG_BOARD_TYPE_OFFSET              0x0000000D
#define    BOARD_CONFIG_BOARD_TYPE_SIZE                       1
#define    BOARD_CONFIG_BOARD_REV_OFFSET               0x0000000E
#define    BOARD_CONFIG_BOARD_REV_SIZE                        1
#define    BOARD_CONFIG_DAC_MUX_OUT_OFFSET             0x0000000F
#define    BOARD_CONFIG_DAC_MUX_OUT_SIZE                      1
#define    BOARD_CONFIG_MODEM_CONFIG_OFFSET            0x00000010
#define    BOARD_CONFIG_MODEM_CONFIG_SIZE                     1
#define    BOARD_CONFIG_SPUR_SC1_OPTION_OFFSET         0x00000011
#define    BOARD_CONFIG_SPUR_SC1_OPTION_SIZE                  1
#define    BOARD_CONFIG_CHIP_TYPE_OFFSET                      0x00000012
#define    BOARD_CONFIG_CHIP_TYPE_SIZE                              1
#define    BOARD_CONFIG_CHIP_REV_OFFSET                        0x00000013
#define    BOARD_CONFIG_CHIP_REV_SIZE                                1
#define    BOARD_CONFIG_MEMORY_VENDOR_OFFSET            0x00000014
#define    BOARD_CONFIG_MEMORY_VENDOR_SIZE                    1
#define    BOARD_CONFIG_MAC_ADDR_OFFSET                       0x00000015
#define    BOARD_CONFIG_MAC_ADDR_SIZE                              6
#define    BOARD_CONFIG_BOARD_BUILD_OFFSET                  0x0000001B
#define    BOARD_CONFIG_BOARD_BUILD_SIZE                         6

#define EEPROM_VERSION_1                                                        1
#define EEPROM_VERSION_2                                                        2

typedef struct _CONFIG_TABLE
{
   unsigned long  xtal_speed;
   unsigned long  length;
   unsigned short checksum;
   unsigned short inv_checksum;
   unsigned char  version_code;
   unsigned char  customer_id;
   unsigned char  board_type;
   unsigned char  board_rev;
   unsigned char  dac_mux_out;
   unsigned char  modem_config;
   unsigned char  spur_sc1_option;
   unsigned char  chip_type;
   unsigned char  chip_rev;
   unsigned char  memory_vendor;
   unsigned char  mac_addr[6];
   unsigned long   board_build[6];
   
} CONFIG_TABLE;
typedef CONFIG_TABLE *LPCONFIG_TABLE;

/*******************************************************/
/* Generic Conexant Internal configuration definitions */
/*******************************************************/
#define     PLL_CONFIG0_CNXT_GENERIC_BOARD_ID_MASK                 0x0000007F
#define     PLL_CONFIG0_CNXT_GENERIC_BOARD_ID_SHIFT                       0
#define     PLL_CONFIG0_CNXT_GENERIC_VENDOR_ID_MASK                0x00000780
#define     PLL_CONFIG0_CNXT_GENERIC_VENDOR_ID_SHIFT                      7
#define     PLL_CONFIG0_CNXT_GENERIC_FLASH_DESC_MASK               0x00007800
#define     PLL_CONFIG0_CNXT_GENERIC_FLASH_DESC_SHIFT                    11
#define     PLL_CONFIG0_CNXT_GENERIC_BOARD_SPECIFIC1_MASK          0x00078000
#define     PLL_CONFIG0_CNXT_GENERIC_BOARD_SPECIFIC1_SHIFT               15
#define     PLL_CONFIG0_CNXT_GENERIC_RAM_TYPE_MASK                 0x00180000
#define     PLL_CONFIG0_CNXT_GENERIC_RAM_TYPE_SHIFT                      19
#define     PLL_CONFIG0_CNXT_GENERIC_BOARD_SPECIFIC2_MASK          0x00600000
#define     PLL_CONFIG0_CNXT_GENERIC_BOARD_SPECIFIC2_SHIFT               21
#define     PLL_CONFIG0_CNXT_GENERIC_PLL_BYPASS_CLK_SEL_MASK       0x00800000
#define     PLL_CONFIG0_CNXT_GENERIC_PLL_BYPASS_CLK_SEL_SHIFT            23
#define     PLL_CONFIG0_CNXT_GENERIC_ROM0_XOE_MASK                 0x01000000
#define     PLL_CONFIG0_CNXT_GENERIC_ROM0_XOE_SHIFT                      24
#define     PLL_CONFIG0_CNXT_GENERIC_BOARD_SPECIFIC3_MASK          0x06000000
#define     PLL_CONFIG0_CNXT_GENERIC_BOARD_SPECIFIC3_SHIFT               25
#define     PLL_CONFIG0_CNXT_GENERIC_ROM_BANK0_WIDTH_MASK          0x18000000
#define     PLL_CONFIG0_CNXT_GENERIC_ROM_BANK0_WIDTH_SHIFT               27
#define     PLL_CONFIG0_CNXT_GENERIC_DBG_REQ_DBG_ACK_MASK          0x20000000
#define     PLL_CONFIG0_CNXT_GENERIC_DBG_REQ_DBG_ACK_SHIFT               29
#define     PLL_CONFIG0_CNXT_GENERIC_SIX_CHAN_AUDIO_MASK           0x40000000
#define     PLL_CONFIG0_CNXT_GENERIC_SIX_CHAN_AUDIO_SHIFT                30
#define     PLL_CONFIG0_CNXT_GENERIC_PLL_BYPASS_MASK               0x80000000
#define     PLL_CONFIG0_CNXT_GENERIC_PLL_BYPASS_SHIFT                    31

#define     PLL_CONFIG0_CNXT_GENERIC_IO_PCI_MODE_MASK              0x00010000
#define     PLL_CONFIG0_CNXT_GENERIC_IO_PCI_MODE_SHIFT                   16

#define     PLL_CONFIG0_CNXT_GENERIC_AUD_DOUT_LR_MASK              0x40000000
#define     PLL_CONFIG0_CNXT_GENERIC_AUD_DOUT_LR_SHIFT                   30
#define     PLL_CONFIG0_CNXT_GENERIC_8004_MASK                     0x40000000
#define     PLL_CONFIG0_CNXT_GENERIC_8004_SHIFT                          30


/***********************/
/* Vendor & Board ID's */
/***********************/
extern unsigned char VendorID;
extern unsigned char BoardID;


/* Settings for audio deemphasis */
/* TODO: why is this stuff here, shouldnt it go in a config file? */
#define AUD_DEEMP_ON_GPIO             TRUE  /* Set GPIO/Demp to Deemp */
#define AUD_DEEMP_ENABLE_DEFAULT      0     /* 0=do not get from stream */
                                            /* if 0, ignore active low bit and mode */
#define AUD_DEEMP_ACTIVE_LOW_DEFAULT  1     /* 1=Active Low Deemp */
#define AUD_DEEMP_VALUE_DEFAULT       1     /* Default value if enable=0 */
                                            /* Ignores active low bit */
#define AUD_DEEMP_MODE_DEFAULT        AUD_DEEMP_STANDARD_NONE

/* Internal development-only default PID's for Dish Network free-to-air feeds */
#define CNXT_DISHNW_USA_100_VIDEO_PID           0x1722
#define CNXT_DISHNW_USA_100_AUDIO_PID           0x1723
#define CNXT_DISHNW_USA_101_VIDEO_PID           0x1122
#define CNXT_DISHNW_USA_101_AUDIO_PID           0x1123
#define CNXT_DISHNW_USA_500_VIDEO_PID           0x1B22
#define CNXT_DISHNW_USA_500_AUDIO_PID           0x1B23

#endif

/****************************************************************************
 * Modifications:
 * $Log$
 ****************************************************************************/


