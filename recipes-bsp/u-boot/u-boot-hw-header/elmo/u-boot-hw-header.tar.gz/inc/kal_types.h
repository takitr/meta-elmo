/******************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                    */
/*                        SOFTWARE FILE/MODULE HEADER                         */
/*                    Copyright Conexant Systems Inc. 2004                    */
/*                                 Austin, TX                                 */
/*                            All Rights Reserved                             */
/******************************************************************************/
/*
 * Filename:        kal_types.h
 *
 *
 * Description:     Public header file containing type definitions and labels
 *                  shared between the user- and privileged KAL modules.
 *
 *
 * Author:          Dave Wilson
 *
 ******************************************************************************/
/* $Id: kal_types.h 172240 2010-09-13 21:49:54Z gargn $
 ******************************************************************************/
 
#ifndef _KAL_TYPES_H_
#define _KAL_TYPES_H_

#include "stbcfg.h"

#ifndef TRUE
#define TRUE   1
#endif

#ifndef FALSE
#define FALSE  0
#endif

/********************/
/* Type definitions */
/********************/
#include "basetype.h"
#include "status_codes.h"

/*************************/
/* Interrupt identifiers */
/*************************/
#include "int_id.h"

/*****************************/
/* Trace-related definitions */
/*****************************/
#include "trace_types.h"

/*******************/
/* Resource Limits */
/*******************/

/* Maximum length of an OS object name string */
#define CNXT_KAL_MAX_OBJ_NAME_LENGTH   16

#define CNXT_KAL_NO_WAIT               0
#define CNXT_KAL_WAIT_FOREVER          ((u_int32)-1)

/* Macro to assign task priority based on RTOS (since UCOS doesn't allow two 
   tasks to have the same priority). */
#define CNXT_KAL_THREAD_PRIO(Prio, UCOS_Prio)                                 \
                                       (((RTOS != UCOS) && (RTOS != UCOS2)) ? \
                                        (Prio) : (UCOS_Prio))

/* Task Priority Limits. The min. value has been set to 1 for uniformity
 * across various RTOS's. Since the uCOS kernel creates an internal idle task 
 * with priority 255 (equivalent to 0 in KAL), and no two threads in uCOS can
 * have the same priority, KAL priority of 0 has been excluded from the valid
 * range of available priorities. All RTOS's that are currently supported
 * theoretically allow thread priorities in the range 0-255 (inclusive).
 */
#define CNXT_KAL_DEFAULT_PRIORITY      64
#define CNXT_KAL_MAX_THREAD_PRIORITY   255
#define CNXT_KAL_MIN_THREAD_PRIORITY   1

/* The Minimum and Maximum Stack size for KAL User threads */
#define CNXT_KAL_MAX_STACK_SIZE  ( 1024 * 1024 * 3)
#define CNXT_KAL_MIN_STACK_SIZE  ( 16 * 1024 )

/* Note: Default stack size is defined in the software config file */

#define CNXT_POOL_LOGICAL_MAGIC         0xF0020000

/* The pool IDs */
/* Note: RVDS assembler can not assign a symbol to another symbol if the other*/
/* symbol is not already defined (its not a two-pass pre-processor).          */
/* Thus the master values for these are set in swconfig.cfg  file and are     */
/* assigned here for user-friendliness.                                       */
typedef enum {
    CNXT_POOL_ID_DEFAULT_BANK0_CACHED   = CNXT_POOL_ID_CONFIG_BANK0_CACHED,
    CNXT_POOL_ID_DEFAULT_BANK0_UNCACHED = CNXT_POOL_ID_CONFIG_BANK0_UNCACHED,
    CNXT_POOL_ID_DEFAULT_BANK1_CACHED   = CNXT_POOL_ID_CONFIG_BANK1_CACHED,
    CNXT_POOL_ID_DEFAULT_BANK1_UNCACHED = CNXT_POOL_ID_CONFIG_BANK1_UNCACHED,
    CNXT_POOL_ID_KALCSSGEN = CNXT_POOL_ID_CONFIG_KALCSSGEN,
    CNXT_POOL_ID_KALCSSCON = CNXT_POOL_ID_CONFIG_KALCSSCON,

    /* When users nest pools, their newly created pool indices    */
    /* will start at 6                                            */
    CNXT_POOL_ID_USER_START             = (6),
    CNXT_POOL_ID_ARM926,
    CNXT_POOL_ID_BIS,
    CNXT_POOL_ID_ADSP,
    CNXT_POOL_ID_VDSP,
    CNXT_POOL_ID_MALONE,
    CNXT_POOL_ID_VRAMHD,
    CNXT_POOL_ID_VRAMSD,
    CNXT_POOL_ID_MBVPHD,
    CNXT_POOL_ID_MBVPSD,
    CNXT_POOL_ID_A9_ARM926,
    CNXT_POOL_ID_ARM926_TM,
    CNXT_POOL_ID_MBVP_STDI,

    /* the following defines are deprecated but left  for         */
    /* backwards compatibility                                    */
    CNXT_POOL_ID_DEFAULT_CACHED         =  (CNXT_KAL_BANK0_CACHED_POOL_SIZE?CNXT_POOL_ID_DEFAULT_BANK0_CACHED:CNXT_POOL_ID_DEFAULT_BANK1_CACHED),
    CNXT_POOL_ID_DEFAULT_UNCACHED       =  (CNXT_KAL_BANK0_UNCACHED_POOL_SIZE?CNXT_POOL_ID_DEFAULT_BANK0_UNCACHED:CNXT_POOL_ID_DEFAULT_BANK1_UNCACHED),
     //by doliyu
    CNXT_POOL_ID_USER_CACHED = 0xFFFFFFFE,
    CNXT_POOL_ID_UNSPECIFIED            =  (0xFFFFFFFF)
} CNXT_POOL_ID;


/* Flags indicating memory pool properties */
#define CNXT_POOL_CSS        0x01
#define CNXT_POOL_CONTIGUOUS 0x02
#define CNXT_POOL_UNCACHED   0x04

/* Flags used in memory allocation */
#define CNXT_MEM_ALIGN_4    0x00000002
#define CNXT_MEM_ALIGN_8    0x00000003
#define CNXT_MEM_ALIGN_16   0x00000004
#define CNXT_MEM_ALIGN_32   0x00000005
#define CNXT_MEM_ALIGN_64   0x00000006
#define CNXT_MEM_ALIGN_128  0x00000007
#define CNXT_MEM_ALIGN_256  0x00000008
#define CNXT_MEM_ALIGN_512  0x00000009
#define CNXT_MEM_ALIGN_1024 0x0000000A
#define CNXT_MEM_ALIGN_4096 0x0000000C

/* Default memory allocation alignment */
#define CNXT_MEM_ALIGN_DEFAULT CNXT_MEM_ALIGN_4

/* Default memory allocation flags */
#define CNXT_MEM_DEFAULT CNXT_MEM_ALIGN_DEFAULT

/* Mask used to extract alignment from flags. */
#define CNXT_MEM_ALIGN_MASK 0x0000000F

/****************************************/
/* Assorted object and type definitions */
/****************************************/

/* Object identifiers */
typedef u_int32        CNXT_QUEUE_ID;
typedef u_int32        CNXT_THREAD_ID;
typedef u_int32        CNXT_SEM_ID;
typedef u_int16        CNXT_EVENTS;
typedef u_int32        CNXT_TICK_ID;
typedef u_int32        CNXT_TIMER_ID;
typedef bool           CNXT_CRIT_STATE;

typedef enum
{
  CNXT_CB_LOW_PRIORITY,
  CNXT_CB_LOW_PRIORITY_NO_BLOCK,
  CNXT_CB_HIGH_PRIORITY,
  CNXT_CB_HIGH_PRIORITY_NO_BLOCK,
  CNXT_CB_PRIORITY_LAST = CNXT_CB_HIGH_PRIORITY_NO_BLOCK
} CNXT_KAL_CB_PRIORITY;

/* Function pointer types */
typedef void        (*PFNTHREAD)(int, void **);
typedef CNXT_STATUS (*PFNISR)(u_int32, bool);
typedef void        (*PFNTICKFUNC)(CNXT_TICK_ID, void *);
typedef void        (*PFNTIMERFUNC)(CNXT_TIMER_ID, void *);
typedef void        (*PFNTHREADCALLBACK)(u_int32, u_int32, void *);

typedef struct
{
   bool          bRunning; 
   u_int32       uFlags;
   PFNTICKFUNC   pfnCallback;
   void          *pUserData;
   char          szName[CNXT_KAL_MAX_OBJ_NAME_LENGTH];
} CNXT_TICK_INFO;

typedef struct
{
    void            *pPoolStart;
    u_int32         uTotalPoolSize;
    u_int32         uFreePoolSize;
    u_int32         uLargestFreeBlock;
}CNXT_KAL_POOL_STATUS;

typedef struct
{
    char        *devName; /* Max len of 20 */
    const char  *firmware_file_name;
    u_int32     uFWSize;
    u_int32     uFWAddr;
    void        *pFirmware_image;
}CNXT_FIRMWARE_INFO;

/*****************/
/* Useful Macros */
/*****************/
#ifndef __KERNEL__
#ifndef max
#define max(a, b) (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a, b) (((a) < (b)) ? (a) : (b))
#endif
#endif


/*********************************************/
/* Hardware semaphore accessed from the CPUs */
/*********************************************/
typedef enum 
{
   CNXT_KAL_HWSEM_CPU_ACCESS_UNSPEC        = 0,
   CNXT_KAL_HWSEM_CPU_ACCESS_A90_CORE0     = (1<<0),
   CNXT_KAL_HWSEM_CPU_ACCESS_A90_CORE1     = (1<<1),
   CNXT_KAL_HWSEM_CPU_ACCESS_A90_CORE2     = (1<<2),
   CNXT_KAL_HWSEM_CPU_ACCESS_A90_CORE3     = (1<<3),
   CNXT_KAL_HWSEM_CPU_ACCESS_ARM926        = (1<<4),
   CNXT_KAL_HWSEM_CPU_ACCESS_TM_ADSP       = (1<<5),
   CNXT_KAL_HWSEM_CPU_ACCESS_TM_VDSP       = (1<<6),
   CNXT_KAL_HWSEM_CPU_ACCESS_STANDBY_CTRLR = (1<<7),
} CNXT_KAL_HWSEM_CPU_ACCESS;

/*********************************************/
/* Hardware semaphore shared                 */
/* resources accessed                        */ 
/*********************************************/
typedef enum 
{
   CNXT_KAL_HWSEM_RESOURCE_UNSPEC     = 0,
   CNXT_KAL_HWSEM_RESOURCE_BIS_STRUCT = (1<<0),
   CNXT_KAL_HWSEM_RESOURCE_VSS_MEM    = (1<<1),
} CNXT_KAL_HWSEM_RESOURCE;

/*****************************************/
/*****************************************/
/** Optional RTOS profiling definitions **/
/*****************************************/
/*****************************************/
#if (RTOS_PROFILING == YES)

/* The sorting criterion to use when displaying thread state information 
   using the cnxt_kal_show_thread_info API */
typedef enum 
{
   CNXT_SORT_BY_CPU,       /* Sort by CPU utilisation, highest first */
   CNXT_SORT_BY_PRIORITY,  /* Sort by thread priority, highest first */
   CNXT_SORT_BY_INDEX      /* Sort by thread index                   */
} CNXT_THREAD_INFO_SORT;

/* Thread states as returned from cnxt_kal_capture_thread_info. Note that this 
   is a general list of states. Not all RTOSs may be able to provide this level 
   of detail and may, for example, merely report CNXT_THREAD_SUSPENDED for all
   cases where a thread is blocked. */
typedef enum
{
     CNXT_THREAD_UNKNOWN = -1,      /* State is unknown                             */
     CNXT_THREAD_SUSPENDED,         /* Suspended (general case)                     */
     CNXT_THREAD_BLOCKED_EVENT,     /* Blocked waiting for an event                 */
     CNXT_THREAD_BLOCKED_QUEUE,     /* Blocked reading from a queue                 */
     CNXT_THREAD_BLOCKED_SEMAPHORE, /* Blocked waiting for a semaphore              */
     CNXT_THREAD_BLOCKED_SLEEPING,  /* Blocked after being put to sleep             */
     CNXT_THREAD_TERMINATED,        /* Thread has been terminated                   */
     CNXT_THREAD_ENDING,            /* Thread is in the process of being terminated */
     CNXT_THREAD_READY,             /* Thread is ready to run                       */
     CNXT_THREAD_RUNNING            /* Thread is running                            */
} CNXT_THREAD_STATE;

/* This structure is populated by the function cnxt_kal_capture_thread_info.
   Note that not all RTOSs will allow all information in this structure to
   be queried. Unsupported fields will be indicated by the value -1 (cast to 
   the appropriate type) */
   
typedef struct
{
  u_int32           uIndex;         /* Index of this thread in the internal KAL thread table         */
  char              szName[CNXT_KAL_MAX_OBJ_NAME_LENGTH]; /* The name of the thread                  */
  void             *pControlBlock;  /* A pointer to the RTOS-specific control block for this thread  */
  u_int32           uTicksConsumed; /* Number of system ticks this thread has run for.               */
  u_int8            uPriority;      /* The thread priority as defined by the KAL                     */
  u_int8            uCPUPercent;    /* The percentage of the CPU used by this thread.                */
  u_int32           uScheduleCount; /* The number of times this thread has been scheduled to run.    */
  u_int32           uMinStack;      /* The minimum available stack space for this thread.            */
  CNXT_THREAD_STATE State;          /* The current state of the thread                               */
  PFNTHREAD         pfnEntry;       /* Thread entry point                                            */
} CNXT_THREAD_INFO;

#endif /* RTOS_PROFILING */

#endif /* _KAL_TYPES_H_ */

/******************************************************************************
 * Modifications:
 * $Log$ 
 ******************************************************************************/


