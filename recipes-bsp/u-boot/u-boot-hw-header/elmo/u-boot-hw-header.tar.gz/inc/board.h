/****************************************************************************/ 
 /*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
 /*                       SOFTWARE FILE/MODULE HEADER                        */
 /*                    Conexant Systems Inc. (c) 2004-2005                   */
 /*                         All Rights Reserved                              */
 /****************************************************************************/
 /*
  * Filename: board.h
  *
  * Description: Board hardware definition.
  *
  * Author: Tim Ross
  *
  ****************************************************************************/
 /* $Id: board.h 141504 2010-01-19 01:44:13Z murthyk $
  ****************************************************************************/ 

#ifndef _BOARD_H
#define _BOARD_H

/*****************/
/* Include Files */
/*****************/

/***********************/
/* Function Prototypes */
/***********************/

/**********************/
/* Local Definitions  */
/**********************/
typedef volatile u_int8 *LPREGB;
typedef volatile u_int16 *LPREGH;

/******************/
/* Register Bases */
/******************/
#define ROM_BASE     0xC0000000
#define PCI_IO_BASE  0xE1000000
#define PCI_MEM_BASE 0x80000000
#define UNIFORM_SECTOR_SIZE      0x20000; //128kb

/***********************************/
/* Board Type Specific Definitions */
/***********************************/

typedef struct _BOARD_TYPES
{
  u_int8        BoardID;            /* Board Identifier                      */
  u_int8        DeviceConfigIndex;  /* Index into ISA_DEVICE internal arrays */
} BOARD_TYPES, *LPBOARD_TYPES;

#define MAX_DEVICE_CONFIGS  4

/* Definitions of actual board and vendor IDs are to be */
/* found in HWCONFIG.H                                  */

/***************/
/* ISA Devices */
/***************/
typedef struct _ISA_DEVICE  {
    bool        bClocked;
    bool        XOEMask;
    u_int8      ChipSelect;
    u_int8      DescNum;
    u_int8      ExtWait;
    u_int8      IOMemory;
    u_int8      IORegMode;
    u_int16     WriteAccessTime;
    u_int16     ReadAccessTime;
    u_int16     IORegSetupTime;
    u_int16     IORegAccessTime;
    u_int16     CSSetupTime;
    u_int16     CSHoldTime;
    u_int16     CtrlSetupTime;
    u_int16     CtrlHoldTime;
    u_int8      ISAIncr;
    u_int8      Width;
} ISA_DEVICE, *LPISA_DEVICE;

/***************/
/* PCI Devices */
/***************/
#define PCCARD_PCI_DEVICE_NUM   1
#define PCI_ID_TI_1210          0xac1a104c
#define PCI_ID_TI_1211          0xac1e104c
#define PCI_ID_ACCES_COM2S      0x10d0494f

/* PCI - PCCard Bridge configuration.  */
#define PCCARD_BRIDGE_REG_BASE  0x40000000
#define PCCARD_BRIDGE_IO_BASE   0xfeec
#define PCCARD_LATENCY          0x20
#define CARDBUS_BUS_NUM         1
#define CARDBUS_SUB_BUS_NUM     0
#define CARDBUS_LATENCY         0x40

/*****************/
/* PCCard Bridge */
/*****************/
#define PCCARD_EXCA_BASE        (PCCARD_BRIDGE_REG_BASE + 0x800)
#define PCCARD_EXCA_IO_BASE     (PIO_BASE + PCCARD_BRIDGE_IO_BASE)

#endif

/****************************************************************************
 * Modifications:
 * $Log$
 *
 ****************************************************************************/ 

