/****************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
/*                       SOFTWARE FILE/MODULE HEADER                        */
/*                    Conexant Systems Inc. (c) 2007                        */
/*                              Austin, TX                                  */
/*                         All Rights Reserved                              */
/****************************************************************************/
/*
 * Filename:        hwconfig.h
 *
 *
 * Description:     Public header file containing labels for all the
 *                  hardware configuration values passed into code
 *                  during compilation using the config file mechanism
 *
 *
 * Author:          Dave Wilson
 *
 ****************************************************************************/
/* $Id: hwconfig.h 194989 2011-02-25 12:26:57Z guduruj $
 ****************************************************************************/

#ifndef __STBCFG_H__
   /* Should generate a "warning" here*/
   #include "stbcfg.h"
#endif   /*#ifndef __STBCFG_H__*/

#ifndef  __HWCONFIG_H__
#define  __HWCONFIG_H__

/********************************************************************************/
/********************************************************************************/
/**                                                                            **/
/** It is ABSOLUTELY VITAL that definitions in this file match definitions of  **/
/** the same label in HWCONFIG.VXA and HWCONFIG.A!!!!!! If this is not the     **/
/** case, build inconsistencies will occur.                                    **/
/**                                                                            **/
/********************************************************************************/
/********************************************************************************/


/****************************************************************************/
/*                                                                          */
/* This file contains definitions for all the strings that may be passed in */
/* Conexant build process configuration files. Labels are passed to source  */
/* files using -D<label>=<value> command line switches and source files     */
/*                                                                          */
/****************************************************************************/
#if defined(__KERNEL__) && !defined(__UBOOT__)
#include "asm/io.h"
#endif
#include "warnfix.h"

/****************************************************************************/
/*                                                                          */
/* Hardware register access macros- First Bit Set                                          */
/*                                                                          */
/****************************************************************************/

#define RMO(y)                   ( ((y) & 0x00000001) ?  0 : \
                                   ( ((y) & 0x00000002) ?  1 : \
                                     ( ((y) & 0x00000004) ?  2 : \
                                       ( ((y) & 0x00000008) ?  3 : \
                                         ( ((y) & 0x00000010) ?  4 : \
                                           ( ((y) & 0x00000020) ?  5 : \
                                             ( ((y) & 0x00000040) ?  6 : \
                                               ( ((y) & 0x00000080) ?  7 : \
                                                 ( ((y) & 0x00000100) ?  8 : \
                                                   ( ((y) & 0x00000200) ?  9 : \
                                                     ( ((y) & 0x00000400) ? 10 : \
                                                       ( ((y) & 0x00000800) ? 11 : \
                                                         ( ((y) & 0x00001000) ? 12 : \
                                                           ( ((y) & 0x00002000) ? 13 : \
                                                             ( ((y) & 0x00004000) ? 14 : \
                                                               ( ((y) & 0x00008000) ? 15 : \
                                                                 ( ((y) & 0x00010000) ? 16 : \
                                                                   ( ((y) & 0x00020000) ? 17 : \
                                                                     ( ((y) & 0x00040000) ? 18 : \
                                                                       ( ((y) & 0x00080000) ? 19 : \
                                                                         ( ((y) & 0x00100000) ? 20 : \
                                                                           ( ((y) & 0x00200000) ? 21 : \
                                                                             ( ((y) & 0x00400000) ? 22 : \
                                                                               ( ((y) & 0x00800000) ? 23 : \
                                                                                 ( ((y) & 0x01000000) ? 24 : \
                                                                                   ( ((y) & 0x02000000) ? 25 : \
                                                                                     ( ((y) & 0x04000000) ? 26 : \
                                                                                       ( ((y) & 0x08000000) ? 27 : \
                                                                                         ( ((y) & 0x10000000) ? 28 : \
                                                                                           ( ((y) & 0x20000000) ? 29 : \
                                                                                             ( ((y) & 0x40000000) ? 30 : \
                                                                                               ( ((y) & 0x80000000) ? 31 : 0 ))))))))))))))))))))))))))))))))

/*
 * Access macros used to get, set/clear bits within a hardware register.
 * These macros *do not* perform any automatic shifting of bits and are
 * meant to be used with bit definitions which include their encoded bit
 * position within the register definition (e.g. an enable bit).
 */
#if defined(__KERNEL__) && !defined(__UBOOT__)
#define CNXT_GET(reg,mask)               (readl(reg) & mask)
#define CNXT_SET(reg,mask,val)           ({writel( (readl(reg) & ~(mask)) | (val & mask), reg);})
#else
#define CNXT_GET(reg,mask)               (*(LPREG)(reg) & (mask))
#define CNXT_SET(reg,mask,val)           (*(LPREG)(reg)) =                     \
                                  ((*(LPREG)(reg) & ~(mask)) | (((unsigned long)val) & (mask)))
#endif
/*
 * Access macros used to get & set a numerical value within a hardware
 * register.  These macros perform automatic shifting (based on the mask)
 * of the numerical value used.  These macros are useful for setting a
 * numerical value into a multi-bit contiguous field within a register.
 */
#define CNXT_GET_VAL(reg,mask)           (CNXT_GET(reg,mask) >> RMO(mask))
#define CNXT_SET_VAL(reg,mask,val)       (CNXT_SET(reg,mask,((unsigned long)(val) << RMO(mask))))


/* SDE2TEAM */
/* typedef unsigned long   HW_DWORD;      /\* was u_int32; *\/ */
/* typedef unsigned short  HW_WORD;       /\* was u_int16; *\/ */
/* typedef unsigned char   HW_BYTE;       /\* was u_int8; *\/ */
/* typedef unsigned int    HW_BOOL;       /\* was bool; *\/ */
/* typedef void            HW_VOID; */
typedef unsigned long   HW_DWORD;      /* was u_int32; */
typedef unsigned short  HW_WORD;       /* was u_int16; */
typedef unsigned char   HW_BYTE;       /* was u_int8; */
typedef unsigned int    HW_BOOL;       /* was bool; */
typedef void            HW_VOID;

/* Macro:      HW_BUFFER_SPACE_AVAILABLE                                                */
/* Parameters: desc - this is a pointer to the base of the buffer descriptor.           */
/*             word - space available to write in this buffer.                          */
/* Returns:    Nothing.                                                                 */
/* Notes:      WARNING: The result will be unpredictable unless                         */
/*               the following precondition is met:                                     */
/*               THE WRITE POINTER MUST NOT BE MODIFIED BY OTHER                        */
/*               PROCESSES OR PROCESSORS!!!                                             */      
#define HW_BUFFER_SPACE_AVAILABLE( desc, space )                              \
   do                                                                         \
   {                                                                          \
      u_int32 uTempWrite;                                                     \
      u_int32 uTempRead;                                                      \
                                                                              \
      /* Ensure the read pointer is read only once! */                        \
      uTempWrite = (u_int32)((desc)->pWrite);                                 \
      uTempRead  = (u_int32)((desc)->pRead);                                  \
                                                                              \
      if (uTempWrite >= uTempRead)                                            \
      {                                                                       \
         (space) = ((u_int32)((desc)->pEnd) - uTempWrite +                    \
                    uTempRead - (u_int32)((desc)->pStart));                   \
      }                                                                       \
      else                                                                    \
      {                                                                       \
         (space) = (uTempRead - uTempWrite);                                  \
      }                                                                       \
   } while ( 0 )

/* Macro:      HW_BUFFER_DATA_AVAILABLE                                                 */
/* Parameters: desc - this is a pointer to the base of the buffer descriptor.           */
/*             data - Number of bytes available for read in this buffer.                */
/* Returns:    Nothing.                                                                 */
/* Notes:      WARNING: The result will be unpredictable unless                         */
/*               the following precondition is met:                                     */
/*               THE READ POINTER MUST NOT BE MODIFIED BY OTHER                         */
/*               PROCESSES OR PROCESSORS!!!                                             */      
#define HW_BUFFER_DATA_AVAILABLE( desc, data )                               \
   do                                                                        \
   {                                                                         \
      u_int32 uTempWrite;                                                    \
      u_int32 uTempRead;                                                     \
                                                                             \
      /* Ensure the write pointer is read only once! */                      \
      uTempWrite = (u_int32)((desc)->pWrite);                                \
      uTempRead  = (u_int32)((desc)->pRead);                                 \
                                                                             \
      if (uTempWrite >= uTempRead)                                           \
      {                                                                      \
         (data) = (uTempWrite - uTempRead);                                  \
      }                                                                      \
      else                                                                   \
      {                                                                      \
         (data) = ((u_int32)((desc)->pEnd) - uTempRead +                     \
                   uTempWrite - (u_int32)((desc)->pStart));                  \
      }                                                                      \
   } while ( 0 )

/* Macro:      HW_BUFFER_WRITE_WORD                                                     */
/* Parameters: desc - this is a pointer to the base of the buffer descriptor.           */
/*             word - the new value to be writen at the location pointed by pWrite.     */
/* Returns:    Nothing.                                                                 */
/* Notes:      WARNING: The result will be unpredictable unless                         */
/*               the following precondition is met:                                     */
/*               THE WRITE POINTER MUST NOT BE MODIFIED BY OTHER                        */
/*               PROCESSES OR PROCESSORS!!!                                             */      
#define HW_BUFFER_WRITE_WORD( desc, word )                                 \
   do                                                                      \
   {                                                                       \
      *((desc)->pWrite) = (word);                                          \
      if ( ((desc)->pWrite + 1) >= (desc)->pEnd )                          \
      {                                                                    \
         (desc)->pWrite = (desc)->pStart;                                  \
      }                                                                    \
      else                                                                 \
      {                                                                    \
         (desc)->pWrite += 1;                                              \
      }                                                                    \
   } while ( 0 )

/* Macro:      HW_BUFFER_READ_WORD                                                      */
/* Parameters: desc - this is a pointer to the base of the buffer descriptor.           */
/*             word - the new value read from the location pointed by pRead.            */
/* Returns:    Nothing.                                                                 */
/* Notes:      WARNING: The result will be unpredictable unless                         */
/*               the following precondition is met:                                     */
/*               THE READ POINTER MUST NOT BE MODIFIED BY OTHER                         */
/*               PROCESSES OR PROCESSORS!!!                                             */      
#define HW_BUFFER_READ_WORD( desc, word )                                  \
   do                                                                      \
   {                                                                       \
      (word) = *((desc)->pRead);                                           \
      if ( ((desc)->pRead + 1) >= (desc)->pEnd )                           \
      {                                                                    \
         (desc)->pRead = (desc)->pStart;                                   \
      }                                                                    \
      else                                                                 \
      {                                                                    \
         (desc)->pRead += 1;                                               \
      }                                                                    \
   } while ( 0 )

/********************************************************************************/
/* The following header file, generated automatically from HWCONFIG.CFG during  */
/* the build process, contains definitions of all the values that can be        */
/* taken by all config file keys.                                               */
/********************************************************************************/
#include "hwopts.h"

/***************************************/
/* Include Vendor Specific Definitions */
/* For runtime selection, all files    */
/* must be included.  If a compile-time*/
/* solution is used, specific vendor   */
/* files can be added or removed here. */
/***************************************/
#include <conexant.h>

/****************************************************************************/
/* Here, include the BOXCFG file, translated from the CONFIG file           */
/*                                                                          */
/* NOTE:  All FEATURE type definitions must have been defined before this   */
/*    file is included.  The only thing after this line should be the       */
/*    assignment of default values                                          */
/*                                                                          */
/****************************************************************************/
#include "boxcfg.h"

/****************************************************************************/
/* Here, all newly defined FEATURE (from CONFIG files) must be assigned a   */
/* default value.                                                           */
/*                                                                          */
/* NOTE:  All default values should be assigned such that the behavior for  */
/*    the specific feature will revert to Colorado/Klondike type behavior   */
/*                                                                          */
/* There MUST not be ANY chip-specific default values defined here.         */
/* They should ONLY be defined in each chip header file.                    */
/****************************************************************************/

/* This file is generated automatically from HWCONFIG.CFG during the */
/* build process.                                                    */
#include "hwdefault.h"
#if 0
/************************************************************************/
/* Some helper macros that depend upon definitions from the main config */
/* file and the current hardware config file.                           */
/************************************************************************/

#if ( ( I2C_ADDR_CX24116_1 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24116_2 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24116_3 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24116_4 != NOT_PRESENT) )
   #if ( PHANTOM_HW_REVISION == PHANTOM_HW_REVISION_A ) || \
       ( PHANTOM_HW_REVISION == PHANTOM_HW_REVISION_ALL )
      #define SAT_DEMOD_TYPE_PHANTOM_REV_A (1)
   #else
      #define SAT_DEMOD_TYPE_PHANTOM_REV_A (0)
   #endif
   #if ( PHANTOM_HW_REVISION == PHANTOM_HW_REVISION_B ) || \
       ( PHANTOM_HW_REVISION == PHANTOM_HW_REVISION_ALL )
      #define SAT_DEMOD_TYPE_PHANTOM (1)
   #else
      #define SAT_DEMOD_TYPE_PHANTOM (0)
   #endif
#else
   #define SAT_DEMOD_TYPE_PHANTOM (0)
   #define SAT_DEMOD_TYPE_PHANTOM_REV_A (0)
#endif

#if ( ( I2C_ADDR_CX24114_1 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24114_2 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24114_3 != NOT_PRESENT) )
   #define SAT_DEMOD_TYPE_MUSTANG (1)
#else
   #define SAT_DEMOD_TYPE_MUSTANG (0)
#endif

#if ( ( I2C_ADDR_CX24127 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24122 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24117 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24125 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24120 != NOT_PRESENT) )
   #define SAT_DEMOD_TYPE_STINGER (1)
#else
   #define SAT_DEMOD_TYPE_STINGER (0)
#endif

#if ( ( I2C_ADDR_CX24230_1 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24230_2 != NOT_PRESENT) )
   #define TERR_DEMOD_TYPE_ALTAIR (1)
#else
   #define TERR_DEMOD_TYPE_ALTAIR (0)
#endif

#if ( ( I2C_ADDR_CX24227_DEMOD_1 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24227_DEMOD_2 != NOT_PRESENT) )
   #define ATSC_DEMOD_TYPE_CX24227 (1)
#else
   #define ATSC_DEMOD_TYPE_CX24227 (0)
#endif

#if ( ( I2C_ADDR_OREN_51132_1 != NOT_PRESENT) || \
      ( I2C_ADDR_OREN_51132_2 != NOT_PRESENT) )
   #define ATSC_DEMOD_TYPE_OREN (1)
#else
   #define ATSC_DEMOD_TYPE_OREN (0)
#endif


#if (I2C_ADDR_THOMSON_STV_0297_1 != NOT_PRESENT)
   #define CABLE_DEMOD_TYPE_THOMSON (1)
#else
   #define CABLE_DEMOD_TYPE_THOMSON (0)
#endif

#if (HW_SUNBURST_ENABLE != NOT_PRESENT)
   #define CABLE_DEMOD_TYPE_SUNBURST (1)
#else
   #define CABLE_DEMOD_TYPE_SUNBURST (0)
#endif


#if ( ( I2C_ADDR_CX24130_1 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24130_2 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24130_3 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24130_4 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24123_1 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24123_2 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24123_3 != NOT_PRESENT) || \
      ( I2C_ADDR_CX24123_4 != NOT_PRESENT) )
   #define SAT_DEMOD_TYPE_COBRA (1)
#else
   #define SAT_DEMOD_TYPE_COBRA   (0)
#endif
   
#if ( ( I2C_ADDR_CX22702_1 != NOT_PRESENT) || \
      ( I2C_ADDR_CX22702_2 != NOT_PRESENT) )
   #define CX22702_DRIVER (1)
#else
   #define CX22702_DRIVER (0)
#endif

#define  FRONT_PANEL_IS_SCANBTN  \
 ( (FRONT_PANEL_KEYPAD_TYPE == FRONT_PANEL_KEYPAD_TRINITY) || \
   (FRONT_PANEL_KEYPAD_TYPE == FRONT_PANEL_KEYPAD_APEX)    || \
   (FRONT_PANEL_KEYPAD_TYPE == FRONT_PANEL_KEYPAD_CUSTOM_1)|| \
   (FRONT_PANEL_KEYPAD_TYPE == FRONT_PANEL_KEYPAD_CUSTOM_2)|| \
   (FRONT_PANEL_KEYPAD_TYPE == FRONT_PANEL_KEYPAD_GPIO)  || \
   (FRONT_PANEL_KEYPAD_TYPE == FRONT_PANEL_KEYPAD_MAGNUM))   
#endif
/***************************************************************/
/* Include the automatically generated file which pulls in the */
/* appropriate chip header file.                               */
/*                                                             */
/* This MUST follow the box configuration file inclusion AND   */
/* the default configuration definitions.                      */
/*                                                             */
/* There MUST not be ANY chip-specific default values defined  */
/* here. They should ONLY be defined in each chip header file. */
/***************************************************************/
#include "chiphdr.h"

#endif   /* #ifndef  __HWCONFIG_H__ */

/****************************************************************************
 * Modifications:
 * $Log$
 *
 ****************************************************************************/ 


