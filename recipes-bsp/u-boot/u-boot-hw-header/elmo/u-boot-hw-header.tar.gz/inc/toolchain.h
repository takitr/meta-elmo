/****************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
/*                       SOFTWARE FILE/MODULE HEADER                        */
/*                   Conexant Systems Inc. (c) 1998 - 2006                  */
/*                            All Rights Reserved                           */
/****************************************************************************/
/*
 * Filename:       toolchain.h
 *
 *
 * Description:    Toolchain-specific macro definitions
 *
 *
 * Author:         Dave Wilson
 *
 ****************************************************************************/
/* $Id: toolchain.h 99754 2009-06-25 22:40:42Z gargn $
 ****************************************************************************/
#ifndef _TOOLCHAIN_H_
#define _TOOLCHAIN_H_

/*******************************************************************************/
/* Structure packing control                                                   */
/*                                                                             */
/* Different toolchains control packed structure generation in many different  */
/* ways. We define macros that are used in header files to prevent the need to */
/* edit the header if and when new toolchains are supported.                   */
/*******************************************************************************/
#if (ARM_TOOLKIT == ADS) || (ARM_TOOLKIT == SDT) || (ARM_TOOLKIT == RVDS)

#define PACKED_STRUCT             typedef __packed struct
#define PACKED_MEMBER(type, name) type name;
#define PACKED_STRUCT_NAME(name)  name;

#endif /* ARM toolchains */

/* WindRiver's GNU toolchaim */
#if (ARM_TOOLKIT == WRGCC)

#define PACKED_STRUCT             typedef struct
#define PACKED_MEMBER(type, name) type name __attribute__ ((packed));
#define PACKED_STRUCT_NAME(name) __attribute__ ((packed)) name;;

#endif /* Vanilla GCC toolchains */

#if (ARM_TOOLKIT == GNUGCC)

#define PACKED_STRUCT             typedef struct
#define PACKED_MEMBER(type, name) type name;
#define PACKED_STRUCT_NAME(name) __attribute__ ((packed)) name;;

#endif /* GNU toolchains */

#endif /* _TOOLCHAIN_H_ */

/****************************************************************************
 * Modifications:
 * $Log$ 
 *
 ****************************************************************************/

