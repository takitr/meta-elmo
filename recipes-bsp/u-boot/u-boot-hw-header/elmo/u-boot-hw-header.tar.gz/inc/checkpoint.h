/****************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
/*                       SOFTWARE FILE/MODULE HEADER                        */
/*                   Conexant Systems Inc. (c) 1998 - 2006                  */
/*                               Austin, TX                                 */
/*                            All Rights Reserved                           */
/****************************************************************************/
/*
 * Filename:       checkpoint.h
 *
 *
 * Description:    Debug checkpoint function library
 *
 *
 * Author:         Dave Wilson
 *
 ****************************************************************************/
/* $Id: checkpoint.h 99754 2009-06-25 22:40:42Z gargn $
 ****************************************************************************/
#ifndef _CHECKPOINT_H_
#define _CHECKPOINT_H_

/* Data associated with a single recorded checkpoint */
typedef struct
{
  u_int32   uModuleID;     /* Trace ID of module generating the checkpoint  */
  char     *pszFile;       /* Filename generating the checkpoint            */
  u_int32   uLine;         /* Line number generating the checkpoint         */
  char     *pszString;     /* Checkpoint description string                 */
  u_int32   uValue;        /* Checkpoint uValueparameter                    */
} CNXT_CHECKPOINT;

#define CHECKPOINT_DUMP_ALL 0

void cnxt_checkpoint_reset(void);

void cnxt_checkpoint_control(
               bool     bEnable);

void cnxt_checkpoint_set_wrap(
               bool     bEnable);
               
void cnxt_checkpoint_dump(
               u_int32  uNumCheckpoints);
               
void cnxt_checkpoint(
               u_int32  uModuleID,
               char    *pszFile, 
               u_int32  uLine, 
               char    *pszString, 
               u_int32  uValue); 

#if (INCLUDE_SOFTWARE_CHECKPOINTS == YES)

/* Checkpoints are to be included in the code */

#define SW_CHECKPOINT_FILE_PROLOG static char *gpszCheckpointFileName = __FILE__;

#define SW_CHECKPOINT(mod, str, val)  \
                              cnxt_checkpoint((mod),                  \
                                             gpszCheckpointFileName,  \
                                             __LINE__,                \
                                             (str),                   \
                                             (val));

#else
/* Checkpoints are to be compiled out of the code */

#define SW_CHECKPOINT_FILE_PROLOG
#define SW_CHECKPOINT(mod, str, val)

#endif

#endif /* _CHECKPOINT_H_ */

/****************************************************************************
 * Modifications:
 * $Log$
 *
 ****************************************************************************/

