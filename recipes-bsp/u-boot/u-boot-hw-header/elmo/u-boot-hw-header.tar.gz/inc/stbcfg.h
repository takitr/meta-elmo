/****************************************************************************/ 
 /*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
 /*                       SOFTWARE FILE/MODULE HEADER                        */
 /*                      Conexant Systems Inc. (c) 2004                      */
 /*                         All Rights Reserved                              */
 /****************************************************************************/
 /*
  * Filename: stbcfg.h
  *
  * Description: Top Level Set Top Box ConFiGuration File for C Files
  *
  * Author: Bobby Bradford
  *
  ****************************************************************************/
 /* $Id: stbcfg.h 99754 2009-06-25 22:40:42Z gargn $
  ****************************************************************************/ 


#ifndef __STBCFG_H__
#define __STBCFG_H__


/****************************************************************************
 * FIRST ... ALWAYS ... Get the HWCONFIG header for hardware level defintions
 ****************************************************************************/
   #include "hwconfig.h"


/****************************************************************************
 * SECOND ... Get the SWCONFIG header for software level definitions
 ****************************************************************************/
   #include "swconfig.h"


/****************************************************************************
 * THIRD ... Add new high-level configurations here, as they are defined
 ****************************************************************************/
   #if (RTOS==LINUX)
      #define VFS_PRESENT  YES
   #else
      #define VFS_PRESENT  NO
   #endif

/****************************************************************************
 * FOURTH ... Include toolchain-specific macro definitions
 ****************************************************************************/
   #include "toolchain.h"

#endif   /* #ifndef __STBCFG_H__ */

/****************************************************************************
 * Modifications:
 * $Log$
 *
 ****************************************************************************/ 

