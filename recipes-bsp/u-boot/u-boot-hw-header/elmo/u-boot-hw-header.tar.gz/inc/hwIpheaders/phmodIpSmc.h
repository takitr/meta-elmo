 ///////////////////////////////////////////////////////////////////// 
//                                                                  / 
// (c) NXP B.V 2009                                                / 
//                                                                  / 
// All rights are reserved. Reproduction in whole or in part is     / 
// prohibited without the prior written consent of the copy-right   / 
// owner.                                                           / 
// The information presented in this document does not form part of / 
// any quotation or contract, is believed to be accurate and        / 
// reliable and may be changed without notice. No liability will be / 
// accepted by the publisher for any consequence of its use.        / 
// Publication thereof does not convey nor imply any license under  / 
// patent- or other industrial or intellectual property rights.     / 
 ///////////////////////////////////////////////////////////////////// 
 
/*! 
 *  @brief Header file for 
Smc *  @file phmodIpSmc.h *
 *  <pre>
 *  $Author: chandu.ponnamanda $
 *  $Revision: 105306 $
 *  $Date: 2009-07-22 06:47:13 -0500 (Wed, 22 Jul 2009) $
 *
 *  Revision history
 *  $Log: $
 *  
 *
 *  $KeysEnd$
 *  </pre>
 *
 */ 

#ifndef PHMODIPSMC_H
#define PHMODIPSMC_H

#define SMC_DATA_BASE(x)                     (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x100)
#define     SMC_DATA_DATA_MASK                                   0x000000FF
#define     SMC_DATA_DATA_SHIFT                                         0
#define     SMC_DATA_PARITY_MASK                                 0x00000100
#define     SMC_DATA_PARITY_SHIFT                                       8
#define     SMC_DATA_LAST_MASK                                   0x00000200
#define     SMC_DATA_LAST_SHIFT                                         9

#define SMC_CONV_REG(x)                      (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x00)
#define     SMC_CONV_SENSE_MASK                                  0x00000001
#define     SMC_CONV_SENSE_SHIFT                                        0
#define     SMC_CONV_ORDER_MASK                                  0x00000002
#define     SMC_CONV_ORDER_SHIFT                                        1

#define SMC_PARITY_REG(x)                    (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x04)
#define     SMC_PARITY_TXPARITY_MASK                             0x00000001
#define     SMC_PARITY_TXPARITY_SHIFT                                   0
#define     SMC_PARITY_ENABLETXNAK_MASK                          0x00000002
#define     SMC_PARITY_ENABLETXNAK_SHIFT                                1
#define     SMC_PARITY_RXPARITY_MASK                             0x00000004
#define     SMC_PARITY_RXPARITY_SHIFT                                   2
#define     SMC_PARITY_ENABLERXNAK_MASK                          0x00000008
#define     SMC_PARITY_ENABLERXNAK_SHIFT                                3
#define     SMC_PARITY_ENABLERX_DETECT_MASK                      0x00000010
#define     SMC_PARITY_ENABLERX_DETECT_SHIFT                            4
#define     SMC_PARITY_ENABLERX_REP_MASK                         0x00000020
#define     SMC_PARITY_ENABLERX_REP_SHIFT                               5
#define     SMC_PARITY_DISABLETX_GEN_MASK                        0x00000040
#define     SMC_PARITY_DISABLETX_GEN_SHIFT                              6

#define SMC_TXRETRY_REG(x)          (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x08)
#define SMC_RXRETRY_REG(x)          (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x0C)
#define     SMC_RETRY_RETRIES_MASK                               0x00000007
#define     SMC_RETRY_RETRIES_SHIFT                                     0

#define SMC_TXTIDE_REG(x)           (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x10)
#define SMC_RXTIDE_REG(x)           (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x18)
#define     SMC_TIDE_LEVEL_MASK                                  0x000000FF
#define     SMC_TIDE_LEVEL_SHIFT                                        0

#define SMC_TXCOUNT_REG(x)          (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x14)
#define SMC_RXCOUNT_REG(x)          (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x1C)
#define     SMC_COUNT_COUNT_MASK                                 0x000001FF
#define     SMC_COUNT_COUNT_SHIFT                                       0

#define SMC_RXTIME_REG(x)           (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x20)
#define     SMC_RXTIME_CYCLES_MASK                               0x0000FFFF
#define     SMC_RXTIME_CYCLES_SHIFT                                     0

#define SMC_TERM_CTRL_REG(x)        (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x24)
#define     SMC_TERM_CTRL_FLOW_CONTROL_MASK                      0x00000001
#define     SMC_TERM_CTRL_FLOW_CONTROL_SHIFT                            0
#define     SMC_TERM_CTRL_MODE_MASK                              0x00000008
#define     SMC_TERM_CTRL_MODE_SHIFT                                    3
#define     SMC_TERM_CTRL_STOPCLK_MASK                           0x00000010
#define     SMC_TERM_CTRL_STOPCLK_SHIFT                                 4
#define     SMC_TERM_CTRL_ENABLECLK_MASK                         0x00000060
#define     SMC_TERM_CTRL_ENABLECLK_SHIFT                               5
#define     SMC_TERM_CTRL_LOOPBACK_MASK                          0x00000080
#define     SMC_TERM_CTRL_LOOPBACK_SHIFT                                7

#define SMC_STABLE_REG(x)           (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x28)
#define     SMC_STABLE_DEBOUNCECOUNT_MASK                        0x000FFFFF
#define     SMC_STABLE_DEBOUNCECOUNT_SHIFT                              0

#define SMC_ICC_CTRL_REG(x)         (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x2C)
#define     SMC_ICC_CTRL_ACTIVATECARD_MASK                       0x00000001
#define     SMC_ICC_CTRL_ACTIVATECARD_SHIFT                             0
#define     SMC_ICC_CTRL_DEACTIVATECARD_MASK                     0x00000002
#define     SMC_ICC_CTRL_DEACTIVATECARD_SHIFT                           1
#define     SMC_ICC_CTRL_WARMRESET_MASK                          0x00000004
#define     SMC_ICC_CTRL_WARMRESET_SHIFT                                2

#define SMC_ICC_STAT_REG(x)         (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x30)
#define     SMC_ICC_STAT_CARDPRESENT_MASK                        0x00000001
#define     SMC_ICC_STAT_CARDPRESENT_SHIFT                              0
#define     SMC_ICC_STAT_CARDPOWER_MASK                          0x00000002
#define     SMC_ICC_STAT_CARDPOWER_SHIFT                                1
#define     SMC_ICC_STAT_CARDRESET_MASK                          0x00000004
#define     SMC_ICC_STAT_CARDRESET_SHIFT                                2

#define SMC_ATIME_REG(x)            (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x34)
#define SMC_DTIME_REG(x)            (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x38)
#define SMC_ATRSTIME_REG(x)         (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x3C)
#define SMC_ATRDTIME_REG(x)         (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x40)
#define SMC_BLKTIME_REG(x)          (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x44)
#define SMC_CHTIME_REG(x)           (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x48)
#define     SMC_TIME_CYCLES_MASK                                 0xFFFFFFFF
#define     SMC_TIME_CYCLES_SHIFT                                       0

#define SMC_CLK_DIV_REG(x)          (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x4C)
#define     SMC_CLK_DIV_DENOMINTOR_MASK                          0x0000FFFF
#define     SMC_CLK_DIV_DENOMINTOR_SHIFT                                0
#define     SMC_CLK_DIV_NUMERATOR_MASK                           0xFFFF0000
#define     SMC_CLK_DIV_NUMERATOR_SHIFT                                 16

#define SMC_FD_REG(x)               (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x50)
#define     SMC_FD_D_VALUE_MASK                                  0x000000FF
#define     SMC_FD_D_VALUE_SHIFT                                        0
#define     SMC_FD_F_VALUE_MASK                                  0x00FFFF00
#define     SMC_FD_F_VALUE_SHIFT                                        8

#define SMC_CONFIG_REG(x)           (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x54)
#define     SMC_CONFIG_OPENDRAIN_CMOS_MASK                       0x00000001
#define     SMC_CONFIG_OPENDRAIN_CMOS_SHIFT                             0
#define     SMC_CONFIG_DETECT_POLARITY_MASK                      0x00000002
#define     SMC_CONFIG_DETECT_POLARITY_SHIFT                            1
#define     SMC_CONFIG_AUTO_DETECT_CONV_MASK                     0x00000004
#define     SMC_CONFIG_AUTO_DETECT_CONV_SHIFT                           2

#define SMC_CHGUARD_REG(x)          (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x58)
#define SMC_BKGUARD_REG(x)          (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x5C)
#define     SMC_GUARD_CYCLES_MASK                                0x000000FF
#define     SMC_GUARD_CYCLES_SHIFT                                      0

#define SMC_RESET_TIMER_REG(x)      (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x60)
#define     SMC_RESET_TIMER_MASK                                 0x0000FFFF
#define     SMC_RESET_TIMER_SHIFT                                       0

#define SMC_RAW_DAT_REG(x)          (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x64)
#define     SMC_RAW_DATA_MASK                                    0x00000001
#define     SMC_RAW_DATA_SHIFT                                          0
#define     SMC_RAW_CLOCK_MASK                                   0x00000002
#define     SMC_RAW_CLOCK_SHIFT                                         1
#define     SMC_RAW_RESET_MASK                                   0x00000004
#define     SMC_RAW_RESET_SHIFT                                         2
#define     SMC_RAW_DETECT_MASK                                  0x00000008
#define     SMC_RAW_DETECT_SHIFT                                        3

#define SMC_INT_MASK_REG(x)         (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x68)
#define SMC_INT_STAT_REG(x)         (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x6C)
#define SMC_INT_QSTAT_REG(x)        (SMC_BASE + ((x) * SMC_BANK_SIZE) + 0x70)
#define     SMC_INT_CARDIN_MASK                                  0x00000001
#define     SMC_INT_CARDIN_SHIFT                                        0
#define     SMC_INT_CARDOUT_MASK                                 0x00000002
#define     SMC_INT_CARDOUT_SHIFT                                       1
#define     SMC_INT_CARDPOWERED_MASK                             0x00000004
#define     SMC_INT_CARDPOWERED_SHIFT                                   2
#define     SMC_INT_CARDUNPOWERED_MASK                           0x00000008
#define     SMC_INT_CARDUNPOWERED_SHIFT                                 3
#define     SMC_INT_CARDONLINE_MASK                              0x00000010
#define     SMC_INT_CARDONLINE_SHIFT                                    4
#define     SMC_INT_CARDOFFLINE_MASK                             0x00000020
#define     SMC_INT_CARDOFFLINE_SHIFT                                   5
#define     SMC_INT_ATRSTARTTIMEOUT_MASK                         0x00000040
#define     SMC_INT_ATRSTARTTIMEOUT_SHIFT                               6
#define     SMC_INT_ATRDURATIONTIMEOUT_MASK                      0x00000080
#define     SMC_INT_ATRDURATIONTIMEOUT_SHIFT                            7
#define     SMC_INT_BLKRXTIMEOUT_MASK                            0x00000100
#define     SMC_INT_BLKRXTIMEOUT_SHIFT                                  8
#define     SMC_INT_CHARRXTIMEOUT_MASK                           0x00000200
#define     SMC_INT_CHARRXTIMEOUT_SHIFT                                 9
#define     SMC_INT_TXERROR_MASK                                 0x00000400
#define     SMC_INT_TXERROR_SHIFT                                      10
#define     SMC_INT_RXERROR_MASK                                 0x00000800
#define     SMC_INT_RXERROR_SHIFT                                      11
#define     SMC_INT_TXTIDE_MASK                                  0x00001000
#define     SMC_INT_TXTIDE_SHIFT                                       12
#define     SMC_INT_RXREAD_MASK                                  0x00002000
#define     SMC_INT_RXREAD_SHIFT                                       13
#define     SMC_INT_VCC_EMPTY_MASK                               0x00004000
#define     SMC_INT_VCC_EMPTY_SHIFT                                    14
#define     SMC_INT_REG_FULL_MASK                                0x00008000
#define     SMC_INT_REG_FULL_SHIFT                                     15

/* For Order */
#define SMC_ORDER_DIRECT  0
#define SMC_ORDER_INVERSE 1

/* For Sense */
#define SMC_SENSE_DIRECT  0
#define SMC_SENSE_INVERSE 1

#define SMC_PARITY_EVEN 0
#define SMC_PARITY_ODD  1

#define SMC_MODE_TX 1
#define SMC_MODE_RX 0

#define SMC_CARD_DETECT_SIGNAL_LOW  0
#define SMC_CARD_DETECT_SIGNAL_HIGH 1

#endif /* PHMODIPSMC_H */
