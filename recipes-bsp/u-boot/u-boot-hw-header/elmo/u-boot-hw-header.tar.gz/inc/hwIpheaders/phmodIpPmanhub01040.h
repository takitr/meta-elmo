/*-------------------------------------------------------------------------*/
/* Copyright 2011 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef PHMODIPPMANHUB01040_H
#define PHMODIPPMANHUB01040_H
    
    /*
    * Address mask used to define alias boundaries
    */
    #define PMANHUB01040_ADDR_MASK_REG  (PMANHUB01040_BASE + 0x0)
    /*
    * Address mask used to define alias boundaries
    */
    #define PMANHUB01040_ADDR_MASK_ADDR_MASK_RW (0x0ffffffff << 0)
    #define PMANHUB01040_ADDR_MASK_ADDR_MASK_SHIFT 0
    /*
    * Blocked command info
    */
    #define PMANHUB01040_BLOCKED_CMD_REG  (PMANHUB01040_BASE + 0x20)
    /*
    * reserved
    */
    #define PMANHUB01040_BLOCKED_CMD_RESERVED_RES (0x01f << 27)
    #define PMANHUB01040_BLOCKED_CMD_RESERVED_SHIFT 27
    /*
    * Automatically generated bitfield for padding
    */
    #define PMANHUB01040_BLOCKED_CMD_RESERVED9_RES (0x03ff << 17)
    #define PMANHUB01040_BLOCKED_CMD_RESERVED9_SHIFT 17
    /*
    * Content
    */
    #define PMANHUB01040_BLOCKED_CMD_CONTENT_R (0x01 << 16)
    #define PMANHUB01040_BLOCKED_CMD_CONTENT_SHIFT 16
    /*
    * Initiator port number
    */
    #define PMANHUB01040_BLOCKED_CMD_INIT_PORT_R (0x07 << 13)
    #define PMANHUB01040_BLOCKED_CMD_INIT_PORT_SHIFT 13
    /*
    * Target port number
    */
    #define PMANHUB01040_BLOCKED_CMD_TARGET_PORT_R (0x01f << 8)
    #define PMANHUB01040_BLOCKED_CMD_TARGET_PORT_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_BLOCKED_CMD_RESERVED4_RES (0x0f << 4)
    #define PMANHUB01040_BLOCKED_CMD_RESERVED4_SHIFT 4
    /*
    * Executable
    */
    #define PMANHUB01040_BLOCKED_CMD_EXEC_R (0x01 << 3)
    #define PMANHUB01040_BLOCKED_CMD_EXEC_SHIFT 3
    /*
    * Wrap
    */
    #define PMANHUB01040_BLOCKED_CMD_WRAP_R (0x01 << 2)
    #define PMANHUB01040_BLOCKED_CMD_WRAP_SHIFT 2
    /*
    * Atomic
    */
    #define PMANHUB01040_BLOCKED_CMD_ATOMIC_R (0x01 << 1)
    #define PMANHUB01040_BLOCKED_CMD_ATOMIC_SHIFT 1
    /*
    * Read/Write
    */
    #define PMANHUB01040_BLOCKED_CMD_READ_R (0x01 << 0)
    #define PMANHUB01040_BLOCKED_CMD_READ_SHIFT 0
    /*
    * Blocked command cmd_id
    */
    #define PMANHUB01040_BLOCKED_CMD_ID_REG  (PMANHUB01040_BASE + 0x24)
    /*
    * Blocked command ID
    */
    #define PMANHUB01040_BLOCKED_CMD_ID_CMD_ID_R (0x0ffffffff << 0)
    #define PMANHUB01040_BLOCKED_CMD_ID_CMD_ID_SHIFT 0
    /*
    * Blocked command cmd_block_size
    */
    #define PMANHUB01040_BLOCKED_CMD_BS_REG  (PMANHUB01040_BASE + 0x28)
    /*
    * Blocked command cmd_block_size
    */
    #define PMANHUB01040_BLOCKED_CMD_BS_BLOCK_SIZE_R (0x0ffffffff << 0)
    #define PMANHUB01040_BLOCKED_CMD_BS_BLOCK_SIZE_SHIFT 0
    /*
    * Blocked command cmd_lines
    */
    #define PMANHUB01040_BLOCKED_CMD_LINES_REG  (PMANHUB01040_BASE + 0x2c)
    /*
    * Blocked command cmd_lines
    */
    #define PMANHUB01040_BLOCKED_CMD_LINES_CMD_LINES_R (0x0ffffffff << 0)
    #define PMANHUB01040_BLOCKED_CMD_LINES_CMD_LINES_SHIFT 0
    /*
    * Blocked command cmd_stride
    */
    #define PMANHUB01040_BLOCKED_CMD_STRIDE_REG  (PMANHUB01040_BASE + 0x30)
    /*
    * Blocked command cmd_stride
    */
    #define PMANHUB01040_BLOCKED_CMD_STRIDE_CMD_STRIDE_R (0x0ffffffff << 0)
    #define PMANHUB01040_BLOCKED_CMD_STRIDE_CMD_STRIDE_SHIFT 0
    /*
    * Blocked command cmd_addr
    */
    #define PMANHUB01040_BLOCKED_ADDR_REG  (PMANHUB01040_BASE + 0x34)
    /*
    * Blocked command cmd_addr
    */
    #define PMANHUB01040_BLOCKED_ADDR_CMD_ADDR_R (0x0ffffffff << 0)
    #define PMANHUB01040_BLOCKED_ADDR_CMD_ADDR_SHIFT 0
    /*
    * Blocked command cmd_sec_group
    */
    #define PMANHUB01040_BLOCKED_SEC_GROUP_REG  (PMANHUB01040_BASE + 0x38)
    /*
    * Blocked command cmd_sec_group
    */
    #define PMANHUB01040_BLOCKED_SEC_GROUP_SEC_GROUP_R (0x0ffffffff << 0)
    #define PMANHUB01040_BLOCKED_SEC_GROUP_SEC_GROUP_SHIFT 0
    /*
    * Blocked command memory regions accessed
    */
    #define PMANHUB01040_BLOCKED_REGION_REG  (PMANHUB01040_BASE + 0x3c)
    /*
    * Matching memory regions for the blocked command
    */
    #define PMANHUB01040_BLOCKED_REGION_REGION_R (0x0ffff << 16)
    #define PMANHUB01040_BLOCKED_REGION_REGION_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_BLOCKED_REGION_RESERVED_RES (0x07fff << 1)
    #define PMANHUB01040_BLOCKED_REGION_RESERVED_SHIFT 1
    /*
    * Blocked command matched the default region
    */
    #define PMANHUB01040_BLOCKED_REGION_DEFAULT_REGION_R (0x01 << 0)
    #define PMANHUB01040_BLOCKED_REGION_DEFAULT_REGION_SHIFT 0
    /*
    * Instruction fetch security group permissions for the default region
    */
    #define PMANHUB01040_DEF_INSTR_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x60)
    /*
    * Security group permissions for the default region for instruction fetches.
    */
    #define PMANHUB01040_DEF_INSTR_SEC_ACCESS_SEC_ACCESS_R (0x0ffffffff << 0)
    #define PMANHUB01040_DEF_INSTR_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Data read security group permissions for the default region
    */
    #define PMANHUB01040_DEF_READ_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x64)
    /*
    * Security group permissions for the default region for data reads
    */
    #define PMANHUB01040_DEF_READ_SEC_ACCESS_SEC_ACCESS_R (0x0ffffffff << 0)
    #define PMANHUB01040_DEF_READ_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Write security group permissions for the default region
    */
    #define PMANHUB01040_DEF_WRITE_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x68)
    /*
    * Security group permissions for the default region for data writes
    */
    #define PMANHUB01040_DEF_WRITE_SEC_ACCESS_SEC_ACCESS_R (0x0ffffffff << 0)
    #define PMANHUB01040_DEF_WRITE_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 0 lower address
    */
    #define PMANHUB01040_REGION0_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x100)
    /*
    * Memory region 0 lower address
    */
    #define PMANHUB01040_REGION0_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION0_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION0_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION0_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 0 upper address
    */
    #define PMANHUB01040_REGION0_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x104)
    /*
    * Memory region 0 upper address
    */
    #define PMANHUB01040_REGION0_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION0_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION0_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION0_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 0 security group permissions
    */
    #define PMANHUB01040_REGION0_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x108)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION0_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION0_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 0
    */
    #define PMANHUB01040_REGION0_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION0_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 0 attributes
    */
    #define PMANHUB01040_REGION0_ATTRIB_REG  (PMANHUB01040_BASE + 0x10c)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION0_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION0_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION0_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION0_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION0_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION0_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION0_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION0_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION0_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION0_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION0_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION0_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION0_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION0_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION0_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION0_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION0_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION0_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION0_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION0_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 1 lower address
    */
    #define PMANHUB01040_REGION1_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x120)
    /*
    * Memory region 1 lower address
    */
    #define PMANHUB01040_REGION1_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION1_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION1_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION1_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 1 upper address
    */
    #define PMANHUB01040_REGION1_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x124)
    /*
    * Memory region 1 upper address
    */
    #define PMANHUB01040_REGION1_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION1_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION1_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION1_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 1 security group permissions
    */
    #define PMANHUB01040_REGION1_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x128)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION1_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION1_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 1
    */
    #define PMANHUB01040_REGION1_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION1_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 1 attributes
    */
    #define PMANHUB01040_REGION1_ATTRIB_REG  (PMANHUB01040_BASE + 0x12c)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION1_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION1_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION1_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION1_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION1_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION1_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION1_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION1_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION1_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION1_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION1_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION1_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION1_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION1_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION1_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION1_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION1_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION1_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION1_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION1_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 2 lower address
    */
    #define PMANHUB01040_REGION2_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x140)
    /*
    * Memory region 2 lower address
    */
    #define PMANHUB01040_REGION2_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION2_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION2_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION2_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 2 upper address
    */
    #define PMANHUB01040_REGION2_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x144)
    /*
    * Memory region 2 upper address
    */
    #define PMANHUB01040_REGION2_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION2_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION2_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION2_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 2 security group permissions
    */
    #define PMANHUB01040_REGION2_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x148)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION2_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION2_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 2
    */
    #define PMANHUB01040_REGION2_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION2_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 2 attributes
    */
    #define PMANHUB01040_REGION2_ATTRIB_REG  (PMANHUB01040_BASE + 0x14c)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION2_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION2_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION2_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION2_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION2_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION2_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION2_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION2_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION2_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION2_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION2_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION2_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION2_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION2_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION2_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION2_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION2_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION2_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION2_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION2_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 3 lower address
    */
    #define PMANHUB01040_REGION3_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x160)
    /*
    * Memory region 3 lower address
    */
    #define PMANHUB01040_REGION3_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION3_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION3_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION3_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 3 upper address
    */
    #define PMANHUB01040_REGION3_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x164)
    /*
    * Memory region 3 upper address
    */
    #define PMANHUB01040_REGION3_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION3_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION3_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION3_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 3 security group permissions
    */
    #define PMANHUB01040_REGION3_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x168)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION3_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION3_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 3
    */
    #define PMANHUB01040_REGION3_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION3_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 3 attributes
    */
    #define PMANHUB01040_REGION3_ATTRIB_REG  (PMANHUB01040_BASE + 0x16c)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION3_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION3_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION3_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION3_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION3_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION3_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION3_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION3_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION3_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION3_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION3_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION3_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION3_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION3_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION3_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION3_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION3_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION3_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION3_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION3_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 4 lower address
    */
    #define PMANHUB01040_REGION4_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x180)
    /*
    * Memory region 4 lower address
    */
    #define PMANHUB01040_REGION4_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION4_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION4_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION4_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 4 upper address
    */
    #define PMANHUB01040_REGION4_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x184)
    /*
    * Memory region 4 upper address
    */
    #define PMANHUB01040_REGION4_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION4_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION4_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION4_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 4 security group permissions
    */
    #define PMANHUB01040_REGION4_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x188)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION4_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION4_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 4
    */
    #define PMANHUB01040_REGION4_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION4_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 4 attributes
    */
    #define PMANHUB01040_REGION4_ATTRIB_REG  (PMANHUB01040_BASE + 0x18c)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION4_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION4_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION4_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION4_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION4_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION4_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION4_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION4_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION4_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION4_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION4_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION4_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION4_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION4_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION4_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION4_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION4_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION4_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION4_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION4_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 5 lower address
    */
    #define PMANHUB01040_REGION5_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x1a0)
    /*
    * Memory region 5 lower address
    */
    #define PMANHUB01040_REGION5_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION5_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION5_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION5_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 5 upper address
    */
    #define PMANHUB01040_REGION5_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x1a4)
    /*
    * Memory region 5 upper address
    */
    #define PMANHUB01040_REGION5_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION5_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION5_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION5_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 5 security group permissions
    */
    #define PMANHUB01040_REGION5_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x1a8)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION5_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION5_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 5
    */
    #define PMANHUB01040_REGION5_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION5_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 5 attributes
    */
    #define PMANHUB01040_REGION5_ATTRIB_REG  (PMANHUB01040_BASE + 0x1ac)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION5_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION5_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION5_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION5_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION5_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION5_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION5_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION5_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION5_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION5_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION5_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION5_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION5_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION5_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION5_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION5_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION5_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION5_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION5_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION5_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 6 lower address
    */
    #define PMANHUB01040_REGION6_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x1c0)
    /*
    * Memory region 6 lower address
    */
    #define PMANHUB01040_REGION6_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION6_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION6_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION6_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 6 upper address
    */
    #define PMANHUB01040_REGION6_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x1c4)
    /*
    * Memory region 6 upper address
    */
    #define PMANHUB01040_REGION6_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION6_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION6_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION6_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 6 security group permissions
    */
    #define PMANHUB01040_REGION6_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x1c8)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION6_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION6_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 6
    */
    #define PMANHUB01040_REGION6_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION6_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 6 attributes
    */
    #define PMANHUB01040_REGION6_ATTRIB_REG  (PMANHUB01040_BASE + 0x1cc)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION6_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION6_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION6_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION6_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION6_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION6_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION6_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION6_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION6_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION6_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION6_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION6_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION6_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION6_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION6_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION6_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION6_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION6_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION6_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION6_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 7 lower address
    */
    #define PMANHUB01040_REGION7_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x1e0)
    /*
    * Memory region 7 lower address
    */
    #define PMANHUB01040_REGION7_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION7_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION7_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION7_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 7 upper address
    */
    #define PMANHUB01040_REGION7_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x1e4)
    /*
    * Memory region 7 upper address
    */
    #define PMANHUB01040_REGION7_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION7_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION7_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION7_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 7 security group permissions
    */
    #define PMANHUB01040_REGION7_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x1e8)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION7_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION7_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 7
    */
    #define PMANHUB01040_REGION7_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION7_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 7 attributes
    */
    #define PMANHUB01040_REGION7_ATTRIB_REG  (PMANHUB01040_BASE + 0x1ec)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION7_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION7_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION7_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION7_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION7_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION7_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION7_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION7_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION7_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION7_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION7_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION7_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION7_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION7_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION7_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION7_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION7_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION7_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION7_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION7_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 8 lower address
    */
    #define PMANHUB01040_REGION8_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x200)
    /*
    * Memory region 8 lower address
    */
    #define PMANHUB01040_REGION8_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION8_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION8_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION8_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 8 upper address
    */
    #define PMANHUB01040_REGION8_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x204)
    /*
    * Memory region 8 upper address
    */
    #define PMANHUB01040_REGION8_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION8_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION8_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION8_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 8 security group permissions
    */
    #define PMANHUB01040_REGION8_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x208)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION8_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION8_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 8
    */
    #define PMANHUB01040_REGION8_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION8_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 8 attributes
    */
    #define PMANHUB01040_REGION8_ATTRIB_REG  (PMANHUB01040_BASE + 0x20c)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION8_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION8_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION8_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION8_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION8_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION8_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION8_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION8_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION8_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION8_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION8_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION8_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION8_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION8_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION8_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION8_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION8_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION8_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION8_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION8_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 9 lower address
    */
    #define PMANHUB01040_REGION9_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x220)
    /*
    * Memory region 9 lower address
    */
    #define PMANHUB01040_REGION9_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION9_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION9_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION9_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 9 upper address
    */
    #define PMANHUB01040_REGION9_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x224)
    /*
    * Memory region 9 upper address
    */
    #define PMANHUB01040_REGION9_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION9_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION9_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION9_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 9 security group permissions
    */
    #define PMANHUB01040_REGION9_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x228)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION9_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION9_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 9
    */
    #define PMANHUB01040_REGION9_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION9_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 9 attributes
    */
    #define PMANHUB01040_REGION9_ATTRIB_REG  (PMANHUB01040_BASE + 0x22c)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION9_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION9_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION9_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION9_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION9_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION9_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION9_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION9_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION9_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION9_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION9_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION9_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION9_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION9_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION9_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION9_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION9_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION9_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION9_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION9_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 10 lower address
    */
    #define PMANHUB01040_REGION10_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x240)
    /*
    * Memory region 10 lower address
    */
    #define PMANHUB01040_REGION10_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION10_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION10_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION10_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 10 upper address
    */
    #define PMANHUB01040_REGION10_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x244)
    /*
    * Memory region 10 upper address
    */
    #define PMANHUB01040_REGION10_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION10_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION10_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION10_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 10 security group permissions
    */
    #define PMANHUB01040_REGION10_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x248)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION10_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION10_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 10
    */
    #define PMANHUB01040_REGION10_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION10_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 10 attributes
    */
    #define PMANHUB01040_REGION10_ATTRIB_REG  (PMANHUB01040_BASE + 0x24c)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION10_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION10_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION10_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION10_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION10_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION10_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION10_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION10_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION10_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION10_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION10_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION10_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION10_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION10_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION10_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION10_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION10_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION10_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION10_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION10_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 11 lower address
    */
    #define PMANHUB01040_REGION11_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x260)
    /*
    * Memory region 11 lower address
    */
    #define PMANHUB01040_REGION11_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION11_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION11_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION11_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 11 upper address
    */
    #define PMANHUB01040_REGION11_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x264)
    /*
    * Memory region 11 upper address
    */
    #define PMANHUB01040_REGION11_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION11_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION11_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION11_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 11 security group permissions
    */
    #define PMANHUB01040_REGION11_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x268)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION11_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION11_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 11
    */
    #define PMANHUB01040_REGION11_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION11_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 11 attributes
    */
    #define PMANHUB01040_REGION11_ATTRIB_REG  (PMANHUB01040_BASE + 0x26c)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION11_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION11_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION11_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION11_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION11_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION11_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION11_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION11_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION11_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION11_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION11_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION11_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION11_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION11_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION11_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION11_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION11_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION11_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION11_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION11_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 12 lower address
    */
    #define PMANHUB01040_REGION12_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x280)
    /*
    * Memory region 12 lower address
    */
    #define PMANHUB01040_REGION12_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION12_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION12_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION12_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 12 upper address
    */
    #define PMANHUB01040_REGION12_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x284)
    /*
    * Memory region 12 upper address
    */
    #define PMANHUB01040_REGION12_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION12_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION12_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION12_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 12 security group permissions
    */
    #define PMANHUB01040_REGION12_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x288)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION12_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION12_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 12
    */
    #define PMANHUB01040_REGION12_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION12_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 12 attributes
    */
    #define PMANHUB01040_REGION12_ATTRIB_REG  (PMANHUB01040_BASE + 0x28c)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION12_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION12_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION12_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION12_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION12_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION12_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION12_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION12_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION12_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION12_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION12_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION12_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION12_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION12_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION12_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION12_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION12_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION12_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION12_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION12_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 13 lower address
    */
    #define PMANHUB01040_REGION13_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x2a0)
    /*
    * Memory region 13 lower address
    */
    #define PMANHUB01040_REGION13_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION13_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION13_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION13_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 13 upper address
    */
    #define PMANHUB01040_REGION13_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x2a4)
    /*
    * Memory region 13 upper address
    */
    #define PMANHUB01040_REGION13_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION13_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION13_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION13_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 13 security group permissions
    */
    #define PMANHUB01040_REGION13_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x2a8)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION13_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION13_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 13
    */
    #define PMANHUB01040_REGION13_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION13_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 13 attributes
    */
    #define PMANHUB01040_REGION13_ATTRIB_REG  (PMANHUB01040_BASE + 0x2ac)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION13_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION13_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION13_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION13_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION13_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION13_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION13_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION13_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION13_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION13_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION13_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION13_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION13_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION13_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION13_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION13_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION13_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION13_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION13_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION13_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 14 lower address
    */
    #define PMANHUB01040_REGION14_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x2c0)
    /*
    * Memory region 14 lower address
    */
    #define PMANHUB01040_REGION14_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION14_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION14_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION14_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 14 upper address
    */
    #define PMANHUB01040_REGION14_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x2c4)
    /*
    * Memory region 14 upper address
    */
    #define PMANHUB01040_REGION14_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION14_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION14_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION14_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 14 security group permissions
    */
    #define PMANHUB01040_REGION14_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x2c8)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION14_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION14_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 14
    */
    #define PMANHUB01040_REGION14_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION14_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 14 attributes
    */
    #define PMANHUB01040_REGION14_ATTRIB_REG  (PMANHUB01040_BASE + 0x2cc)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION14_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION14_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION14_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION14_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION14_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION14_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION14_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION14_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION14_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION14_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION14_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION14_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION14_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION14_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION14_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION14_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION14_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION14_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION14_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION14_ATTRIB_VALID_SHIFT 0
    /*
    * Memory region 15 lower address
    */
    #define PMANHUB01040_REGION15_ADDR_LOW_REG  (PMANHUB01040_BASE + 0x2e0)
    /*
    * Memory region 15 lower address
    */
    #define PMANHUB01040_REGION15_ADDR_LOW_ADDR_LOW_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION15_ADDR_LOW_ADDR_LOW_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION15_ADDR_LOW_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION15_ADDR_LOW_RESERVED_SHIFT 0
    /*
    * Memory region 15 upper address
    */
    #define PMANHUB01040_REGION15_ADDR_HIGH_REG  (PMANHUB01040_BASE + 0x2e4)
    /*
    * Memory region 15 upper address
    */
    #define PMANHUB01040_REGION15_ADDR_HIGH_ADDR_HIGH_RW (0x0fffff << 12)
    #define PMANHUB01040_REGION15_ADDR_HIGH_ADDR_HIGH_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION15_ADDR_HIGH_RESERVED_RES (0x0fff << 0)
    #define PMANHUB01040_REGION15_ADDR_HIGH_RESERVED_SHIFT 0
    /*
    * Memory region 15 security group permissions
    */
    #define PMANHUB01040_REGION15_SEC_ACCESS_REG  (PMANHUB01040_BASE + 0x2e8)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION15_SEC_ACCESS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_REGION15_SEC_ACCESS_RESERVED_SHIFT 16
    /*
    * Security group access for memory region 15
    */
    #define PMANHUB01040_REGION15_SEC_ACCESS_SEC_ACCESS_RW (0x0ffff << 0)
    #define PMANHUB01040_REGION15_SEC_ACCESS_SEC_ACCESS_SHIFT 0
    /*
    * Memory region 15 attributes
    */
    #define PMANHUB01040_REGION15_ATTRIB_REG  (PMANHUB01040_BASE + 0x2ec)
    /*
    * reserved
    */
    #define PMANHUB01040_REGION15_ATTRIB_RESERVED_RES (0x07fff << 17)
    #define PMANHUB01040_REGION15_ATTRIB_RESERVED_SHIFT 17
    /*
    * Writeable
    */
    #define PMANHUB01040_REGION15_ATTRIB_WRITE_RW (0x01 << 16)
    #define PMANHUB01040_REGION15_ATTRIB_WRITE_SHIFT 16
    /*
    * reserved
    */
    #define PMANHUB01040_REGION15_ATTRIB_RESERVED2_RES (0x07 << 13)
    #define PMANHUB01040_REGION15_ATTRIB_RESERVED2_SHIFT 13
    /*
    * Executable
    */
    #define PMANHUB01040_REGION15_ATTRIB_EXEC_RW (0x01 << 12)
    #define PMANHUB01040_REGION15_ATTRIB_EXEC_SHIFT 12
    /*
    * reserved
    */
    #define PMANHUB01040_REGION15_ATTRIB_RESERVED4_RES (0x07 << 9)
    #define PMANHUB01040_REGION15_ATTRIB_RESERVED4_SHIFT 9
    /*
    * Read-as-data
    */
    #define PMANHUB01040_REGION15_ATTRIB_READ_RW (0x01 << 8)
    #define PMANHUB01040_REGION15_ATTRIB_READ_SHIFT 8
    /*
    * reserved
    */
    #define PMANHUB01040_REGION15_ATTRIB_RESERVED6_RES (0x07 << 5)
    #define PMANHUB01040_REGION15_ATTRIB_RESERVED6_SHIFT 5
    /*
    * Content
    */
    #define PMANHUB01040_REGION15_ATTRIB_CONTENT_RW (0x01 << 4)
    #define PMANHUB01040_REGION15_ATTRIB_CONTENT_SHIFT 4
    /*
    * reserved
    */
    #define PMANHUB01040_REGION15_ATTRIB_RESERVED8_RES (0x07 << 1)
    #define PMANHUB01040_REGION15_ATTRIB_RESERVED8_SHIFT 1
    /*
    * Region is valid
    */
    #define PMANHUB01040_REGION15_ATTRIB_VALID_RW (0x01 << 0)
    #define PMANHUB01040_REGION15_ATTRIB_VALID_SHIFT 0
    /*
    * MTL read data error response for initiator 0
    */
    #define PMANHUB01040_INIT0_ERR_RD_DATA_REG  (PMANHUB01040_BASE + 0x400)
    /*
    * MTL read data error response for initiator 0
    */
    #define PMANHUB01040_INIT0_ERR_RD_DATA_ERR_RD_DATA_RW (0x0ffffffff << 0)
    #define PMANHUB01040_INIT0_ERR_RD_DATA_ERR_RD_DATA_SHIFT 0
    /*
    * MTL read data error response for initiator 1
    */
    #define PMANHUB01040_INIT1_ERR_RD_DATA_REG  (PMANHUB01040_BASE + 0x404)
    /*
    * MTL read data error response for initiator 1
    */
    #define PMANHUB01040_INIT1_ERR_RD_DATA_ERR_RD_DATA_RW (0x0ffffffff << 0)
    #define PMANHUB01040_INIT1_ERR_RD_DATA_ERR_RD_DATA_SHIFT 0
    /*
    * MTL read data error response for initiator 2
    */
    #define PMANHUB01040_INIT2_ERR_RD_DATA_REG  (PMANHUB01040_BASE + 0x408)
    /*
    * MTL read data error response for initiator 2
    */
    #define PMANHUB01040_INIT2_ERR_RD_DATA_ERR_RD_DATA_RW (0x0ffffffff << 0)
    #define PMANHUB01040_INIT2_ERR_RD_DATA_ERR_RD_DATA_SHIFT 0
    /*
    * MTL read data error response for initiator 3
    */
    #define PMANHUB01040_INIT3_ERR_RD_DATA_REG  (PMANHUB01040_BASE + 0x40c)
    /*
    * MTL read data error response for initiator 3
    */
    #define PMANHUB01040_INIT3_ERR_RD_DATA_ERR_RD_DATA_RW (0x0ffffffff << 0)
    #define PMANHUB01040_INIT3_ERR_RD_DATA_ERR_RD_DATA_SHIFT 0
    /*
    * MTL read data error response for initiator 4
    */
    #define PMANHUB01040_INIT4_ERR_RD_DATA_REG  (PMANHUB01040_BASE + 0x410)
    /*
    * MTL read data error response for initiator 4
    */
    #define PMANHUB01040_INIT4_ERR_RD_DATA_ERR_RD_DATA_RW (0x0ffffffff << 0)
    #define PMANHUB01040_INIT4_ERR_RD_DATA_ERR_RD_DATA_SHIFT 0
    /*
    * MTL read data error response for initiator 5
    */
    #define PMANHUB01040_INIT5_ERR_RD_DATA_REG  (PMANHUB01040_BASE + 0x414)
    /*
    * MTL read data error response for initiator 5
    */
    #define PMANHUB01040_INIT5_ERR_RD_DATA_ERR_RD_DATA_RW (0x0ffffffff << 0)
    #define PMANHUB01040_INIT5_ERR_RD_DATA_ERR_RD_DATA_SHIFT 0
    /*
    * Interrupt clear enable
    */
    #define PMANHUB01040_INT_CLR_ENABLE_REG  (PMANHUB01040_BASE + 0xfd8)
    /*
    * reserved
    */
    #define PMANHUB01040_INT_CLR_ENABLE_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_INT_CLR_ENABLE_RESERVED_SHIFT 16
    /*
    * Interrupt clear enable
    */
    #define PMANHUB01040_INT_CLR_ENABLE_INT_CLR_ENABLE_W (0x0ffff << 0)
    #define PMANHUB01040_INT_CLR_ENABLE_INT_CLR_ENABLE_SHIFT 0
    /*
    * Interrupt set enable
    */
    #define PMANHUB01040_INT_SET_ENABLE_REG  (PMANHUB01040_BASE + 0xfdc)
    /*
    * reserved
    */
    #define PMANHUB01040_INT_SET_ENABLE_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_INT_SET_ENABLE_RESERVED_SHIFT 16
    /*
    * Interrupt set enable
    */
    #define PMANHUB01040_INT_SET_ENABLE_INT_SET_ENABLE_W (0x0ffff << 0)
    #define PMANHUB01040_INT_SET_ENABLE_INT_SET_ENABLE_SHIFT 0
    /*
    * Interrupt status
    */
    #define PMANHUB01040_INT_STATUS_REG  (PMANHUB01040_BASE + 0xfe0)
    /*
    * reserved
    */
    #define PMANHUB01040_INT_STATUS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_INT_STATUS_RESERVED_SHIFT 16
    /*
    * Interrupt status
    */
    #define PMANHUB01040_INT_STATUS_INT_STATUS_R (0x0ffff << 0)
    #define PMANHUB01040_INT_STATUS_INT_STATUS_SHIFT 0
    /*
    * Interrupt enable
    */
    #define PMANHUB01040_INT_ENABLE_REG  (PMANHUB01040_BASE + 0xfe4)
    /*
    * reserved
    */
    #define PMANHUB01040_INT_ENABLE_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_INT_ENABLE_RESERVED_SHIFT 16
    /*
    * Interrupt enable
    */
    #define PMANHUB01040_INT_ENABLE_INT_ENABLE_R (0x0ffff << 0)
    #define PMANHUB01040_INT_ENABLE_INT_ENABLE_SHIFT 0
    /*
    * Interrupt clear status
    */
    #define PMANHUB01040_INT_CLR_STATUS_REG  (PMANHUB01040_BASE + 0xfe8)
    /*
    * reserved
    */
    #define PMANHUB01040_INT_CLR_STATUS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_INT_CLR_STATUS_RESERVED_SHIFT 16
    /*
    * Interrupt clear status
    */
    #define PMANHUB01040_INT_CLR_STATUS_INT_CLR_STATUS_W (0x0ffff << 0)
    #define PMANHUB01040_INT_CLR_STATUS_INT_CLR_STATUS_SHIFT 0
    /*
    * Interrupt set status
    */
    #define PMANHUB01040_INT_SET_STATUS_REG  (PMANHUB01040_BASE + 0xfec)
    /*
    * reserved
    */
    #define PMANHUB01040_INT_SET_STATUS_RESERVED_RES (0x0ffff << 16)
    #define PMANHUB01040_INT_SET_STATUS_RESERVED_SHIFT 16
    /*
    * Interrupt set status
    */
    #define PMANHUB01040_INT_SET_STATUS_INT_SET_STATUS_W (0x0ffff << 0)
    #define PMANHUB01040_INT_SET_STATUS_INT_SET_STATUS_SHIFT 0
    /*
    * Module ID register
    */
    #define PMANHUB01040_MODULE_ID_REG  (PMANHUB01040_BASE + 0xffc)
    /*
    * Module ID
    */
    #define PMANHUB01040_MODULE_ID_MODULE_ID_R (0x0ffff << 16)
    #define PMANHUB01040_MODULE_ID_MODULE_ID_SHIFT 16
    /*
    * Major revision
    */
    #define PMANHUB01040_MODULE_ID_MAJOR_REV_R (0x0f << 12)
    #define PMANHUB01040_MODULE_ID_MAJOR_REV_SHIFT 12
    /*
    * Minor revision
    */
    #define PMANHUB01040_MODULE_ID_MINOR_REV_R (0x0f << 8)
    #define PMANHUB01040_MODULE_ID_MINOR_REV_SHIFT 8
    /*
    * Aperture size
    * 0x0 = 4k
    */
    #define PMANHUB01040_MODULE_ID_APERTURE_R (0x0ff << 0)
    #define PMANHUB01040_MODULE_ID_APERTURE_SHIFT 0

#endif // PHMODIPPMANHUB01040_H
