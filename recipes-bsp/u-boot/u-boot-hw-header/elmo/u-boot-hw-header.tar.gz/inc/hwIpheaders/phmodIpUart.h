////////////////////////////////////////////////////////////////////// 
//                                                                  // 
// (c) NXP B.V 2009                                                 // 
//                                                                  // 
// All rights are reserved. Reproduction in whole or in part is     // 
// prohibited without the prior written consent of the copy-right   // 
// owner.                                                           // 
// The information presented in this document does not form part of // 
// any quotation or contract, is believed to be accurate and        // 
// reliable and may be changed without notice. No liability will be // 
// accepted by the publisher for any consequence of its use.        //
// Publication thereof does not convey nor imply any license under  //
// patent- or other industrial or intellectual property rights.     //
////////////////////////////////////////////////////////////////////// 
 
/*! 
 *  @brief Header file for UART
 *  @file phmodIpUart.h *
 *  <pre>
 *  $Author: kumarh4 $
 *  $Revision: 122734 $
 *  $Date: 2009-10-07 07:46:33 -0500 (Wed, 07 Oct 2009) $
 *
 *  Revision history
 *  $Log: $
 *  
 *
 *  $KeysEnd$
 *  </pre>
 *
 */ 


#ifndef PHMODIPUART_H
#define PHMODIPUART_H
	
	/*
	* Receiver Buffer Register. Transmitter Holding Register. Divisor Latch LSB
	*/
	#define UART_RBR_THR_DLL_REG(n)  (UART_BASE_UNIT##n + 0x0)
	/*
	* Reserved for future use
	*/
	#define UART_RBR_THR_DLL_RESERVED0_RW (0x07fffff << 8)
	#define UART_RBR_THR_DLL_RESERVED0_SHIFT 8
	/*
	* RBR first. THR Last. DLL value
	*/
	#define UART_RBR_THR_DLL_RBRFIRST_THRLAST_DLLVAL_RW (0x0ff << 0)
	#define UART_RBR_THR_DLL_RBRFIRST_THRLAST_DLLVAL_SHIFT 0
	/*
	* Interrupt Enable Register. DLM register
	*/
	#define UART_IER_DLM_REG(n)  (UART_BASE_UNIT##n + 0x4)
	/*
	* Reserved for future use
	*/
	#define UART_IER_DLM_RESERVED1_R (0x0fffff << 11)
	#define UART_IER_DLM_RESERVED1_SHIFT 11
	/*
	* Wake Up Interrupt Enable
	*/
	#define UART_IER_DLM_WAKEUPINTEN_RESERVED_RW (0x01 << 10)
	#define UART_IER_DLM_WAKEUPINTEN_RESERVED_SHIFT 10
	#define UART_IER_DLM_WAKEUPINTEN_RESERVED_VAL0 0x00
	#define UART_IER_DLM_WAKEUPINTEN_RESERVED_VAL1 0x01
	/*
	* Auto Baud Time Out Interrupt
	*/
	#define UART_IER_DLM_ABTOINTEN_RESERVED_RW (0x01 << 9)
	#define UART_IER_DLM_ABTOINTEN_RESERVED_SHIFT 9
	#define UART_IER_DLM_ABTOINTEN_RESERVED_VAL0 0x00
	#define UART_IER_DLM_ABTOINTEN_RESERVED_VAL1 0x01
	/*
	* End of Auto Baud Interrupt Enable
	*/
	#define UART_IER_DLM_ABEOINTEN_RESERVED_RW (0x01 << 8)
	#define UART_IER_DLM_ABEOINTEN_RESERVED_SHIFT 8
	#define UART_IER_DLM_ABEOINTEN_RESERVED_VAL0 0x00
	#define UART_IER_DLM_ABEOINTEN_RESERVED_VAL1 0x01
	/*
	* CTS Int En. MSB of divisor latch value
	*/
	#define UART_IER_DLM_CTSINTEN_DLMVAL_RW (0x01 << 7)
	#define UART_IER_DLM_CTSINTEN_DLMVAL_SHIFT 7
	#define UART_IER_DLM_CTSINTEN_DLMVAL_VAL0 0x00
	#define UART_IER_DLM_CTSINTEN_DLMVAL_VAL1 0x01
	/*
	* Reserved for future use. MSB of divisor latch value
	*/
	#define UART_IER_DLM_RESERVED_DLMVAL_RW (0x03 << 4)
	#define UART_IER_DLM_RESERVED_DLMVAL_SHIFT 4
	#define UART_IER_DLM_RESERVED_DLMVAL_VAL0 0x00
	#define UART_IER_DLM_RESERVED_DLMVAL_VAL1 0x01
	#define UART_IER_DLM_RESERVED_DLMVAL_VAL2 0x02
	#define UART_IER_DLM_RESERVED_DLMVAL_VAL3 0x03
	/*
	* Modem Status Interrupt Enable. MSB of divisor latch value
	*/
	#define UART_IER_DLM_MSINTEN_DLMVAL_RW (0x01 << 3)
	#define UART_IER_DLM_MSINTEN_DLMVAL_SHIFT 3
	#define UART_IER_DLM_MSINTEN_DLMVAL_VAL0 0x00
	#define UART_IER_DLM_MSINTEN_DLMVAL_VAL1 0x01
	/*
	* Receiver Line Status Interrupt Enable. MSB of divisor latch value
	*/
	#define UART_IER_DLM_RLSINTEN_DLMVAL_RW (0x01 << 2)
	#define UART_IER_DLM_RLSINTEN_DLMVAL_SHIFT 2
	#define UART_IER_DLM_RLSINTEN_DLMVAL_VAL0 0x00
	#define UART_IER_DLM_RLSINTEN_DLMVAL_VAL1 0x01
	/*
	* Transmitter Holding Register Empty Interrupt Enable. MSB of divisor latch value
	*/
	#define UART_IER_DLM_THREINTEN_DLMVAL_RW (0x01 << 1)
	#define UART_IER_DLM_THREINTEN_DLMVAL_SHIFT 1
	#define UART_IER_DLM_THREINTEN_DLMVAL_VAL0 0x00
	#define UART_IER_DLM_THREINTEN_DLMVAL_VAL1 0x01
	/*
	* Receive Data Available Interrupt Enable. MSB of divisor latch value
	*/
	#define UART_IER_DLM_RDAINTEN_DLMVAL_RW (0x01 << 0)
	#define UART_IER_DLM_RDAINTEN_DLMVAL_SHIFT 0
	#define UART_IER_DLM_RDAINTEN_DLMVAL_VAL0 0x00
	#define UART_IER_DLM_RDAINTEN_DLMVAL_VAL1 0x01
	/*
	* Interrupt Identification Register. FIFO Control Register
	*/
	#define UART_IIR_FCR_REG(n)  (UART_BASE_UNIT##n + 0x8)
	/*
	* Reserved for future use
	*/
	#define UART_IIR_FCR_RESERVED2_R (0x0fffff << 11)
	#define UART_IIR_FCR_RESERVED2_SHIFT 11
	/*
	* ABTO Int
	*/
	#define UART_IIR_FCR_WAKEUPINT_RESERVED_R (0x01 << 10)
	#define UART_IIR_FCR_WAKEUPINT_RESERVED_SHIFT 10
	#define UART_IIR_FCR_WAKEUPINT_RESERVED_VAL0 0x00
	#define UART_IIR_FCR_WAKEUPINT_RESERVED_VAL1 0x01
	/*
	* ABTO Int
	*/
	#define UART_IIR_FCR_ABTOINT_RESERVED_R (0x01 << 9)
	#define UART_IIR_FCR_ABTOINT_RESERVED_SHIFT 9
	#define UART_IIR_FCR_ABTOINT_RESERVED_VAL0 0x00
	#define UART_IIR_FCR_ABTOINT_RESERVED_VAL1 0x01
	/*
	* ABEO Int
	*/
	#define UART_IIR_FCR_ABEOINT_RESERVED_R (0x01 << 8)
	#define UART_IIR_FCR_ABEOINT_RESERVED_SHIFT 8
	#define UART_IIR_FCR_ABEOINT_RESERVED_VAL0 0x00
	#define UART_IIR_FCR_ABEOINT_RESERVED_VAL1 0x01
	/*
	* FIFOEn. Receiver trigger level selection.
	*/
	#define UART_IIR_FCR_FIFOEN_RXTRIGLEVEL_RW (0x01 << 6)
	#define UART_IIR_FCR_FIFOEN_RXTRIGLEVEL_SHIFT 6
	#define UART_IIR_FCR_FIFOEN_RXTRIGLEVEL_VAL0 0x00
	#define UART_IIR_FCR_FIFOEN_RXTRIGLEVEL_VAL1 0x01
	/*
	* Reserved for future use
	*/
	#define UART_IIR_FCR_RESERVED3_R (0x01 << 4)
	#define UART_IIR_FCR_RESERVED3_SHIFT 4
	#define UART_IIR_FCR_RESERVED3_VAL0 0x00
	#define UART_IIR_FCR_RESERVED3_VAL1 0x01
	/*
	* IntId. DMA mode select.
	*/
	#define UART_IIR_FCR_INTID_DMAMODE_RW (0x01 << 3)
	#define UART_IIR_FCR_INTID_DMAMODE_SHIFT 3
	#define UART_IIR_FCR_INTID_DMAMODE_VAL0 0x00
	#define UART_IIR_FCR_INTID_DMAMODE_VAL1 0x01
	/*
	* IntId. Transmitter FIFO reset.
	*/
	#define UART_IIR_FCR_INTID_TXFIFORST_RW (0x01 << 2)
	#define UART_IIR_FCR_INTID_TXFIFORST_SHIFT 2
	#define UART_IIR_FCR_INTID_TXFIFORST_VAL0 0x00
	#define UART_IIR_FCR_INTID_TXFIFORST_VAL1 0x01
	/*
	* IntId. Receiver FIFO reset.
	*/
	#define UART_IIR_FCR_INTID_RXFIFORST_RW (0x01 << 1)
	#define UART_IIR_FCR_INTID_RXFIFORST_SHIFT 1
	#define UART_IIR_FCR_INTID_RXFIFORST_VAL0 0x00
	#define UART_IIR_FCR_INTID_RXFIFORST_VAL1 0x01
	/*
	* IntStatus. FIFO enable.
	*/
	#define UART_IIR_FCR_INTSTATUS_RFOEN_RW (0x01 << 0)
	#define UART_IIR_FCR_INTSTATUS_RFOEN_SHIFT 0
	#define UART_IIR_FCR_INTSTATUS_RFOEN_VAL0 0x00
	#define UART_IIR_FCR_INTSTATUS_RFOEN_VAL1 0x01
	/*
	* Line Control Register
	*/
	#define UART_LCR_REG(n)  (UART_BASE_UNIT##n + 0xc)
	/*
	* Reserved for future use
	*/
	#define UART_LCR_RESERVED4_R (0x07fffff << 8)
	#define UART_LCR_RESERVED4_SHIFT 8
	/*
	* Divisor Latch Access bit
	*/
	#define UART_LCR_DLAB_RW (0x01 << 7)
	#define UART_LCR_DLAB_SHIFT 7
	#define UART_LCR_DLAB_VAL0 0x00
	#define UART_LCR_DLAB_VAL1 0x01
	/*
	* Break Control Bit
	*/
	#define UART_LCR_BRKCTRL_RW (0x01 << 6)
	#define UART_LCR_BRKCTRL_SHIFT 6
	#define UART_LCR_BRKCTRL_VAL0 0x00
	#define UART_LCR_BRKCTRL_VAL1 0x01
	/*
	* ParStick
	*/
	#define UART_LCR_PARSTICK_RW (0x01 << 5)
	#define UART_LCR_PARSTICK_SHIFT 5
	#define UART_LCR_PARSTICK_VAL0 0x00
	#define UART_LCR_PARSTICK_VAL1 0x01
	/*
	* RBR ParEven
	*/
	#define UART_LCR_PAREVEN_RW (0x01 << 4)
	#define UART_LCR_PAREVEN_SHIFT 4
	#define UART_LCR_PAREVEN_VAL0 0x00
	#define UART_LCR_PAREVEN_VAL1 0x01
	/*
	* Parity Enable
	*/
	#define UART_LCR_PAREN_RW (0x01 << 3)
	#define UART_LCR_PAREN_SHIFT 3
	#define UART_LCR_PAREN_VAL0 0x00
	#define UART_LCR_PAREN_VAL1 0x01
	/*
	* Number of stop bits selector
	*/
	#define UART_LCR_STOPBITNUM_RW (0x01 << 2)
	#define UART_LCR_STOPBITNUM_SHIFT 2
	#define UART_LCR_STOPBITNUM_VAL0 0x00
	#define UART_LCR_STOPBITNUM_VAL1 0x01
	/*
	* Word Length Select
	*/
	#define UART_LCR_WDLENSEL_RW (0x03 << 0)
	#define UART_LCR_WDLENSEL_SHIFT 0
	#define UART_LCR_WDLENSEL_VAL0 0x00
	#define UART_LCR_WDLENSEL_VAL1 0x01
	#define UART_LCR_WDLENSEL_VAL2 0x02
	#define UART_LCR_WDLENSEL_VAL3 0x03
	/*
	* Modem Control Register
	*/
	#define UART_MCR_REG(n)  (UART_BASE_UNIT##n + 0x10)
	/*
	* Reserved for future use
	*/
	#define UART_MCR_RESERVED5_R (0x07fffff << 8)
	#define UART_MCR_RESERVED5_SHIFT 8
	/*
	* Auto-cts flow control enable
	*/
	#define UART_MCR_AUTOCTSEN_RW (0x01 << 7)
	#define UART_MCR_AUTOCTSEN_SHIFT 7
	#define UART_MCR_AUTOCTSEN_VAL0 0x00
	#define UART_MCR_AUTOCTSEN_VAL1 0x01
	/*
	* Auto-rts flow control enable
	*/
	#define UART_MCR_AUTORTSEN_RW (0x01 << 6)
	#define UART_MCR_AUTORTSEN_SHIFT 6
	#define UART_MCR_AUTORTSEN_VAL0 0x00
	#define UART_MCR_AUTORTSEN_VAL1 0x01
	/*
	* Reserved for future use
	*/
	#define UART_MCR_RESERVED6_R (0x01 << 5)
	#define UART_MCR_RESERVED6_SHIFT 5
	#define UART_MCR_RESERVED6_VAL0 0x00
	#define UART_MCR_RESERVED6_VAL1 0x01
	/*
	* Loop-back mode enable
	*/
	#define UART_MCR_LOOPEN_RW (0x01 << 4)
	#define UART_MCR_LOOPEN_SHIFT 4
	#define UART_MCR_LOOPEN_VAL0 0x00
	#define UART_MCR_LOOPEN_VAL1 0x01
	/*
	* Inverse control for the out2_an output
	*/
	#define UART_MCR_OUT2_RW (0x01 << 3)
	#define UART_MCR_OUT2_SHIFT 3
	#define UART_MCR_OUT2_VAL0 0x00
	#define UART_MCR_OUT2_VAL1 0x01
	/*
	* Inverse control for the out2_an output
	*/
	#define UART_MCR_OUT1_RW (0x01 << 2)
	#define UART_MCR_OUT1_SHIFT 2
	#define UART_MCR_OUT1_VAL0 0x00
	#define UART_MCR_OUT1_VAL1 0x01
	/*
	* Request To Send
	*/
	#define UART_MCR_RTS_RW (0x01 << 1)
	#define UART_MCR_RTS_SHIFT 1
	#define UART_MCR_RTS_VAL0 0x00
	#define UART_MCR_RTS_VAL1 0x01
	/*
	* Inverse control for the Data Terminal Ready output
	*/
	#define UART_MCR_DTR_RW (0x01 << 0)
	#define UART_MCR_DTR_SHIFT 0
	#define UART_MCR_DTR_VAL0 0x00
	#define UART_MCR_DTR_VAL1 0x01
	/*
	* Line Status Register
	*/
	#define UART_LSR_REG(n)  (UART_BASE_UNIT##n + 0x14)
	/*
	* Reserved for future use
	*/
	#define UART_LSR_RESERVED7_R (0x07fffff << 8)
	#define UART_LSR_RESERVED7_SHIFT 8
	/*
	* Error in receiver FIFO
	*/
	#define UART_LSR_RXERR_R (0x01 << 7)
	#define UART_LSR_RXERR_SHIFT 7
	#define UART_LSR_RXERR_VAL0 0x00
	#define UART_LSR_RXERR_VAL1 0x01
	/*
	* Transmitter Empty
	*/
	#define UART_LSR_TEMT_R (0x01 << 6)
	#define UART_LSR_TEMT_SHIFT 6
	#define UART_LSR_TEMT_VAL0 0x00
	#define UART_LSR_TEMT_VAL1 0x01
	/*
	* Transmitter Holding Register Empty
	*/
	#define UART_LSR_THRE_R (0x01 << 5)
	#define UART_LSR_THRE_SHIFT 5
	#define UART_LSR_THRE_VAL0 0x00
	#define UART_LSR_THRE_VAL1 0x01
	/*
	* Break Indication
	*/
	#define UART_LSR_BI_R (0x01 << 4)
	#define UART_LSR_BI_SHIFT 4
	#define UART_LSR_BI_VAL0 0x00
	#define UART_LSR_BI_VAL1 0x01
	/*
	* Framing Error
	*/
	#define UART_LSR_FE_R (0x01 << 3)
	#define UART_LSR_FE_SHIFT 3
	#define UART_LSR_FE_VAL0 0x00
	#define UART_LSR_FE_VAL1 0x01
	/*
	* Parity Error
	*/
	#define UART_LSR_PE_R (0x01 << 2)
	#define UART_LSR_PE_SHIFT 2
	#define UART_LSR_PE_VAL0 0x00
	#define UART_LSR_PE_VAL1 0x01
	/*
	* Overrun Error
	*/
	#define UART_LSR_OE_R (0x01 << 1)
	#define UART_LSR_OE_SHIFT 1
	#define UART_LSR_OE_VAL0 0x00
	#define UART_LSR_OE_VAL1 0x01
	/*
	* Data Ready
	*/
	#define UART_LSR_DR_R (0x01 << 0)
	#define UART_LSR_DR_SHIFT 0
	#define UART_LSR_DR_VAL0 0x00
	#define UART_LSR_DR_VAL1 0x01
	/*
	* Modem Status Register
	*/
	#define UART_MSR_REG(n)  (UART_BASE_UNIT##n + 0x18)
	/*
	* Reserved for future use
	*/
	#define UART_MSR_RESERVED8_R (0x07fffff << 8)
	#define UART_MSR_RESERVED8_SHIFT 8
	/*
	* Data Carrier Detect
	*/
	#define UART_MSR_DCD_R (0x01 << 7)
	#define UART_MSR_DCD_SHIFT 7
	#define UART_MSR_DCD_VAL0 0x00
	#define UART_MSR_DCD_VAL1 0x01
	/*
	* Ring Indicator
	*/
	#define UART_MSR_RI_R (0x01 << 6)
	#define UART_MSR_RI_SHIFT 6
	#define UART_MSR_RI_VAL0 0x00
	#define UART_MSR_RI_VAL1 0x01
	/*
	* Data Set Ready
	*/
	#define UART_MSR_DSR_R (0x01 << 5)
	#define UART_MSR_DSR_SHIFT 5
	#define UART_MSR_DSR_VAL0 0x00
	#define UART_MSR_DSR_VAL1 0x01
	/*
	* Clear To Send
	*/
	#define UART_MSR_CTS_R (0x01 << 4)
	#define UART_MSR_CTS_SHIFT 4
	#define UART_MSR_CTS_VAL0 0x00
	#define UART_MSR_CTS_VAL1 0x01
	/*
	* Delta Data Carrier Detect
	*/
	#define UART_MSR_DDCD_R (0x01 << 3)
	#define UART_MSR_DDCD_SHIFT 3
	#define UART_MSR_DDCD_VAL0 0x00
	#define UART_MSR_DDCD_VAL1 0x01
	/*
	* Trailing Edge Ring Indicator
	*/
	#define UART_MSR_TERI_R (0x01 << 2)
	#define UART_MSR_TERI_SHIFT 2
	#define UART_MSR_TERI_VAL0 0x00
	#define UART_MSR_TERI_VAL1 0x01
	/*
	* Delta Data Set Ready
	*/
	#define UART_MSR_DDSR_R (0x01 << 1)
	#define UART_MSR_DDSR_SHIFT 1
	#define UART_MSR_DDSR_VAL0 0x00
	#define UART_MSR_DDSR_VAL1 0x01
	/*
	* Delta Clear To Send
	*/
	#define UART_MSR_DCTS_R (0x01 << 0)
	#define UART_MSR_DCTS_SHIFT 0
	#define UART_MSR_DCTS_VAL0 0x00
	#define UART_MSR_DCTS_VAL1 0x01
	/*
	* Scratch Register
	*/
	#define UART_SCR_REG(n)  (UART_BASE_UNIT##n + 0x1c)
	/*
	* Reserved for future use
	*/
	#define UART_SCR_RESERVED9_R (0x07fffff << 8)
	#define UART_SCR_RESERVED9_SHIFT 8
	/*
	* Scratch value
	*/
	#define UART_SCR_SCRVAL_RW (0x0ff << 0)
	#define UART_SCR_SCRVAL_SHIFT 0
	/*
	* Auto-baud Control Register
	*/
	#define UART_ACR_REG(n)  (UART_BASE_UNIT##n + 0x20)
	/*
	* Reserved for future use
	*/
	#define UART_ACR_RESERVED10_R (0x01fffff << 10)
	#define UART_ACR_RESERVED10_SHIFT 10
	/*
	* ABTOInt Clear
	*/
	#define UART_ACR_ABTOINTCLR_W (0x01 << 9)
	#define UART_ACR_ABTOINTCLR_SHIFT 9
	#define UART_ACR_ABTOINTCLR_VAL0 0x00
	#define UART_ACR_ABTOINTCLR_VAL1 0x01
	/*
	* ABEOInt Clear
	*/
	#define UART_ACR_ABEOINTCLR_W (0x01 << 8)
	#define UART_ACR_ABEOINTCLR_SHIFT 8
	#define UART_ACR_ABEOINTCLR_VAL0 0x00
	#define UART_ACR_ABEOINTCLR_VAL1 0x01
	/*
	* Reserved for future use
	*/
	#define UART_ACR_RESERVED11_R (0x0f << 3)
	#define UART_ACR_RESERVED11_SHIFT 3
	#define UART_ACR_RESERVED11_VAL0 0x00
	#define UART_ACR_RESERVED11_VAL1 0x01
	#define UART_ACR_RESERVED11_VAL2 0x02
	#define UART_ACR_RESERVED11_VAL3 0x03
	#define UART_ACR_RESERVED11_VAL4 0x04
	#define UART_ACR_RESERVED11_VAL5 0x05
	#define UART_ACR_RESERVED11_VAL6 0x06
	#define UART_ACR_RESERVED11_VAL7 0x07
	#define UART_ACR_RESERVED11_VAL8 0x08
	#define UART_ACR_RESERVED11_VAL9 0x09
	#define UART_ACR_RESERVED11_VAL10 0x0a
	#define UART_ACR_RESERVED11_VAL11 0x0b
	#define UART_ACR_RESERVED11_VAL12 0x0c
	#define UART_ACR_RESERVED11_VAL13 0x0d
	#define UART_ACR_RESERVED11_VAL14 0x0e
	#define UART_ACR_RESERVED11_VAL15 0x0f
	/*
	* Auto-restart mode
	*/
	#define UART_ACR_AUTORESTART_RW (0x01 << 2)
	#define UART_ACR_AUTORESTART_SHIFT 2
	#define UART_ACR_AUTORESTART_VAL0 0x00
	#define UART_ACR_AUTORESTART_VAL1 0x01
	/*
	* Auto-baud mode
	*/
	#define UART_ACR_MODE_RW (0x01 << 1)
	#define UART_ACR_MODE_SHIFT 1
	#define UART_ACR_MODE_VAL0 0x00
	#define UART_ACR_MODE_VAL1 0x01
	/*
	* Auto-baud run
	*/
	#define UART_ACR_START_RW (0x01 << 0)
	#define UART_ACR_START_SHIFT 0
	#define UART_ACR_START_VAL0 0x00
	#define UART_ACR_START_VAL1 0x01
	/*
	* IrDA Control Register
	*/
	#define UART_ICR_REG(n)  (UART_BASE_UNIT##n + 0x24)
	/*
	* Reserved for future use
	*/
	#define UART_ICR_RESERVED12_R (0x01ffffff << 6)
	#define UART_ICR_RESERVED12_SHIFT 6
	/*
	* PulseDiv
	*/
	#define UART_ICR_PULSEDIV_RW (0x03 << 3)
	#define UART_ICR_PULSEDIV_SHIFT 3
	#define UART_ICR_PULSEDIV_VAL0 0x00
	#define UART_ICR_PULSEDIV_VAL1 0x01
	#define UART_ICR_PULSEDIV_VAL2 0x02
	#define UART_ICR_PULSEDIV_VAL3 0x03
	/*
	* FixPulseEn
	*/
	#define UART_ICR_FIXPULSEEN_RW (0x01 << 2)
	#define UART_ICR_FIXPULSEEN_SHIFT 2
	#define UART_ICR_FIXPULSEEN_VAL0 0x00
	#define UART_ICR_FIXPULSEEN_VAL1 0x01
	/*
	* IrDAInv
	*/
	#define UART_ICR_IRDAINV_RW (0x01 << 1)
	#define UART_ICR_IRDAINV_SHIFT 1
	#define UART_ICR_IRDAINV_VAL0 0x00
	#define UART_ICR_IRDAINV_VAL1 0x01
	/*
	* IrDAEn
	*/
	#define UART_ICR_IRDAEN_RW (0x01 << 0)
	#define UART_ICR_IRDAEN_SHIFT 0
	#define UART_ICR_IRDAEN_VAL0 0x00
	#define UART_ICR_IRDAEN_VAL1 0x01
	/*
	* Fractional Divider Register
	*/
	#define UART_FDR_REG(n)  (UART_BASE_UNIT##n + 0x28)
	/*
	* Reserved for future use
	*/
	#define UART_FDR_RESERVED13_R (0x07fffff << 8)
	#define UART_FDR_RESERVED13_SHIFT 8
	/*
	* Baud-rate pre-scaler multiplier value
	*/
	#define UART_FDR_MULVAL_RW (0x07 << 4)
	#define UART_FDR_MULVAL_SHIFT 4
	#define UART_FDR_MULVAL_VAL0 0x00
	#define UART_FDR_MULVAL_VAL1 0x01
	#define UART_FDR_MULVAL_VAL2 0x02
	#define UART_FDR_MULVAL_VAL3 0x03
	#define UART_FDR_MULVAL_VAL4 0x04
	#define UART_FDR_MULVAL_VAL5 0x05
	#define UART_FDR_MULVAL_VAL6 0x06
	#define UART_FDR_MULVAL_VAL7 0x07
	/*
	* Baud-rate generation pre-scaler divisor value
	*/
	#define UART_FDR_DIVADDVAL_RW (0x0f << 0)
	#define UART_FDR_DIVADDVAL_SHIFT 0
	#define UART_FDR_DIVADDVAL_VAL0 0x00
	#define UART_FDR_DIVADDVAL_VAL1 0x01
	#define UART_FDR_DIVADDVAL_VAL2 0x02
	#define UART_FDR_DIVADDVAL_VAL3 0x03
	#define UART_FDR_DIVADDVAL_VAL4 0x04
	#define UART_FDR_DIVADDVAL_VAL5 0x05
	#define UART_FDR_DIVADDVAL_VAL6 0x06
	#define UART_FDR_DIVADDVAL_VAL7 0x07
	#define UART_FDR_DIVADDVAL_VAL8 0x08
	#define UART_FDR_DIVADDVAL_VAL9 0x09
	#define UART_FDR_DIVADDVAL_VAL10 0x0a
	#define UART_FDR_DIVADDVAL_VAL11 0x0b
	#define UART_FDR_DIVADDVAL_VAL12 0x0c
	#define UART_FDR_DIVADDVAL_VAL13 0x0d
	#define UART_FDR_DIVADDVAL_VAL14 0x0e
	#define UART_FDR_DIVADDVAL_VAL15 0x0f
	/*
	* NHP Pop Register
	*/
	#define UART_POP_REG(n)  (UART_BASE_UNIT##n + 0x30)
	/*
	* Reserved for future use
	*/
	#define UART_POP_RESERVED14_R (0x03fffffff << 1)
	#define UART_POP_RESERVED14_SHIFT 1
	/*
	* PopRBR
	*/
	#define UART_POP_POPRBR_W (0x01 << 0)
	#define UART_POP_POPRBR_SHIFT 0
	#define UART_POP_POPRBR_VAL0 0x00
	#define UART_POP_POPRBR_VAL1 0x01
	/*
	* NHP Mode Selection Register
	*/
	#define UART_MODE_REG(n)  (UART_BASE_UNIT##n + 0x34)
	/*
	* Reserved for future use
	*/
	#define UART_MODE_RESERVED15_R (0x03fffffff << 1)
	#define UART_MODE_RESERVED15_SHIFT 1
	/*
	* NHP
	*/
	#define UART_MODE_NHP_RW (0x01 << 0)
	#define UART_MODE_NHP_SHIFT 0
	#define UART_MODE_NHP_VAL0 0x00
	#define UART_MODE_NHP_VAL1 0x01
	/*
	* Configuration Register
	*/
	#define UART_CFG_REG(n)  (UART_BASE_UNIT##n + 0xfd4)
	/*
	* Reserved for future use
	*/
	#define UART_CFG_RESERVED16_R (0x03ffff << 13)
	#define UART_CFG_RESERVED16_SHIFT 13
	/*
	* HasIrDA
	*/
	#define UART_CFG_HASIRDA_R (0x01 << 12)
	#define UART_CFG_HASIRDA_SHIFT 12
	#define UART_CFG_HASIRDA_VAL0 0x00
	#define UART_CFG_HASIRDA_VAL1 0x01
	/*
	* Reserved for future use
	*/
	#define UART_CFG_RESERVED17_R (0x01 << 10)
	#define UART_CFG_RESERVED17_SHIFT 10
	#define UART_CFG_RESERVED17_VAL0 0x00
	#define UART_CFG_RESERVED17_VAL1 0x01
	/*
	* HasLevel
	*/
	#define UART_CFG_HASLEVEL_R (0x01 << 9)
	#define UART_CFG_HASLEVEL_SHIFT 9
	#define UART_CFG_HASLEVEL_VAL0 0x00
	#define UART_CFG_HASLEVEL_VAL1 0x01
	/*
	* HasDMA
	*/
	#define UART_CFG_HASDMA_R (0x01 << 8)
	#define UART_CFG_HASDMA_SHIFT 8
	#define UART_CFG_HASDMA_VAL0 0x00
	#define UART_CFG_HASDMA_VAL1 0x01
	/*
	* Reserved for future use
	*/
	#define UART_CFG_RESERVED18_R (0x01 << 6)
	#define UART_CFG_RESERVED18_SHIFT 6
	#define UART_CFG_RESERVED18_VAL0 0x00
	#define UART_CFG_RESERVED18_VAL1 0x01
	/*
	* Modem
	*/
	#define UART_CFG_MODEM_R (0x01 << 4)
	#define UART_CFG_MODEM_SHIFT 4
	#define UART_CFG_MODEM_VAL0 0x00
	#define UART_CFG_MODEM_VAL1 0x01
	/*
	* Reserved for future use
	*/
	#define UART_CFG_RESERVED19_R (0x01 << 2)
	#define UART_CFG_RESERVED19_SHIFT 2
	#define UART_CFG_RESERVED19_VAL0 0x00
	#define UART_CFG_RESERVED19_VAL1 0x01
	/*
	* Type
	*/
	#define UART_CFG_TYPE_R (0x03 << 0)
	#define UART_CFG_TYPE_SHIFT 0
	#define UART_CFG_TYPE_VAL0 0x00
	#define UART_CFG_TYPE_VAL1 0x01
	#define UART_CFG_TYPE_VAL2 0x02
	#define UART_CFG_TYPE_VAL3 0x03
	/*
	* Interrupt Clear Enable Register
	*/
	#define UART_INTCE_REG(n)  (UART_BASE_UNIT##n + 0xfd8)
	/*
	* Reserved for future use
	*/
	#define UART_INTCE_RESERVED20_R (0x07fff << 16)
	#define UART_INTCE_RESERVED20_SHIFT 16
	/*
	* Overrun Error Interrupt Enable Clear
	*/
	#define UART_INTCE_OEINTENCLR_W (0x01 << 15)
	#define UART_INTCE_OEINTENCLR_SHIFT 15
	#define UART_INTCE_OEINTENCLR_VAL0 0x00
	#define UART_INTCE_OEINTENCLR_VAL1 0x01
	/*
	* Parity Error Interrupt Enable Clear
	*/
	#define UART_INTCE_PEINTENCLR_W (0x01 << 14)
	#define UART_INTCE_PEINTENCLR_SHIFT 14
	#define UART_INTCE_PEINTENCLR_VAL0 0x00
	#define UART_INTCE_PEINTENCLR_VAL1 0x01
	/*
	* Frame Error Interrupt Enable Clear
	*/
	#define UART_INTCE_FEINTENCLR_W (0x01 << 13)
	#define UART_INTCE_FEINTENCLR_SHIFT 13
	#define UART_INTCE_FEINTENCLR_VAL0 0x00
	#define UART_INTCE_FEINTENCLR_VAL1 0x01
	/*
	* Break Indication Interrupt Enable Clear
	*/
	#define UART_INTCE_BIINTENCLR_W (0x01 << 12)
	#define UART_INTCE_BIINTENCLR_SHIFT 12
	#define UART_INTCE_BIINTENCLR_VAL0 0x00
	#define UART_INTCE_BIINTENCLR_VAL1 0x01
	/*
	* Reserved for future use
	*/
	#define UART_INTCE_RESERVED21_R (0x01 << 10)
	#define UART_INTCE_RESERVED21_SHIFT 10
	#define UART_INTCE_RESERVED21_VAL0 0x00
	#define UART_INTCE_RESERVED21_VAL1 0x01
	/*
	* Auto-Baud Time-Out Interrupt Enable Clear
	*/
	#define UART_INTCE_ABTOINTENCLR_W (0x01 << 9)
	#define UART_INTCE_ABTOINTENCLR_SHIFT 9
	#define UART_INTCE_ABTOINTENCLR_VAL0 0x00
	#define UART_INTCE_ABTOINTENCLR_VAL1 0x01
	/*
	* End of Auto-Baud Interrupt Enable Clear
	*/
	#define UART_INTCE_ABEOINTENCLR_W (0x01 << 8)
	#define UART_INTCE_ABEOINTENCLR_SHIFT 8
	#define UART_INTCE_ABEOINTENCLR_VAL0 0x00
	#define UART_INTCE_ABEOINTENCLR_VAL1 0x01
	/*
	* Reserved for future use
	*/
	#define UART_INTCE_RESERVED22_W (0x01 << 7)
	#define UART_INTCE_RESERVED22_SHIFT 7
	#define UART_INTCE_RESERVED22_VAL0 0x00
	#define UART_INTCE_RESERVED22_VAL1 0x01
	/*
	* Receiver Data Available Interrupt Enable Clear
	*/
	#define UART_INTCE_RXDAINTENCLR_W (0x01 << 6)
	#define UART_INTCE_RXDAINTENCLR_SHIFT 6
	#define UART_INTCE_RXDAINTENCLR_VAL0 0x00
	#define UART_INTCE_RXDAINTENCLR_VAL1 0x01
	/*
	* Receiver Time-Out Interrupt Enable Clear
	*/
	#define UART_INTCE_RXTOINTENCLR_W (0x01 << 5)
	#define UART_INTCE_RXTOINTENCLR_SHIFT 5
	#define UART_INTCE_RXTOINTENCLR_VAL0 0x00
	#define UART_INTCE_RXTOINTENCLR_VAL1 0x01
	/*
	* Transmitter Holding Register Empty Interrupt Enable Clear
	*/
	#define UART_INTCE_THREINTENCLR_W (0x01 << 4)
	#define UART_INTCE_THREINTENCLR_SHIFT 4
	#define UART_INTCE_THREINTENCLR_VAL0 0x00
	#define UART_INTCE_THREINTENCLR_VAL1 0x01
	/*
	* Delta Carrier Detect Interrupt Enable Clear
	*/
	#define UART_INTCE_DDCDINTENCLR_W (0x01 << 3)
	#define UART_INTCE_DDCDINTENCLR_SHIFT 3
	#define UART_INTCE_DDCDINTENCLR_VAL0 0x00
	#define UART_INTCE_DDCDINTENCLR_VAL1 0x01
	/*
	* Trailling Edge Rind Indicator Interrupt Enable Clear
	*/
	#define UART_INTCE_TERIINTENCLR_W (0x01 << 2)
	#define UART_INTCE_TERIINTENCLR_SHIFT 2
	#define UART_INTCE_TERIINTENCLR_VAL0 0x00
	#define UART_INTCE_TERIINTENCLR_VAL1 0x01
	/*
	* Delta Data Set Interrupt Enable Clear
	*/
	#define UART_INTCE_DDSRINTENCLR_W (0x01 << 1)
	#define UART_INTCE_DDSRINTENCLR_SHIFT 1
	#define UART_INTCE_DDSRINTENCLR_VAL0 0x00
	#define UART_INTCE_DDSRINTENCLR_VAL1 0x01
	/*
	* Delta Clear To Send Interrupt Enable Clear
	*/
	#define UART_INTCE_DCTSINTENCLR_W (0x01 << 0)
	#define UART_INTCE_DCTSINTENCLR_SHIFT 0
	#define UART_INTCE_DCTSINTENCLR_VAL0 0x00
	#define UART_INTCE_DCTSINTENCLR_VAL1 0x01

#endif // PHMODIPUART_H
