/*=======================================================================*/
/*         Copyright 2010 Trident Microsystems (Far East) Ltd.           */
/*     All rights are reserved. Reproduction in whole or in part is      */
/*     prohibited without the written consent of the copyright owner.    */
/*-----------------------------------------------------------------------*/
/*
 * Filename:       phmodIpTimer.h
 *
 * Description:    TIMERs hardware register definitions
 *
 * Author:         Amarinder Singh Sethi
 *
 ****************************************************************************/
/* $Id: phmodIpTimer.h 149842 2010-03-04 06:54:09Z asethi $
 ****************************************************************************/

#ifndef _PHMODTIMER_H_
#define _PHMODTIMER_H_

/* Timer module MMIO registers */

#define TIMER_VALUE_REG                    (TIMER_BASE + 0x00)
#define TIMER_NUM_VALUE_REG(x)             (TIMER_VALUE_REG + ((x) << 4))
#define   TIMER_NUM_VALUE_MASK             0xFFFFFFFF
#define   TIMER_NUM_VALUE_SHIFT                  0

#define TIMER_LIMIT_REG                    (TIMER_BASE + 0x04)
#define TIMER_NUM_LIMIT_REG(x)             (TIMER_LIMIT_REG + ((x) << 4))
#define   TIMER_NUM_LIMIT_MASK             0xFFFFFFFF
#define   TIMER_NUM_LIMIT_SHIFT                  0

#define TIMER_MODE_REG                     (TIMER_BASE + 0x08)
#define TIMER_NUM_MODE_REG(x)              (TIMER_MODE_REG  + ((x) << 4))
#define    TIMER_ENABLE_MASK               0x00000001
#define    TIMER_ENABLE_SHIFT                    0
#define       TIMER_STOP                   (0UL<<0)
#define       TIMER_ENABLE                 (1UL<<0)
#define    TIMER_RST_CNT_MASK              0x00000002
#define    TIMER_RST_CNT_SHIFT                   1
#define       TIMER_RST_CNT_RESET          (0UL<<1)
#define       TIMER_RST_CNT_CONTINUE       (1UL<<1)
#define    TIMER_WATCHDOG_ENABLE_MASK      0x00000004
#define    TIMER_WATCHDOG_ENABLE_SHIFT          2
#define       TIMER_WATCHDOG_DISABLE       (0UL<<2)
#define       TIMER_WATCHDOG_ENABLE        (1UL<<2)
#define    TIMER_INT_ENABLE_MASK           0x00000008
#define    TIMER_INT_ENABLE_SHIFT               3
#define       TIMER_INT_DISABLE            (0UL<<3)
#define       TIMER_INT_ENABLE             (1UL<<3)
#define    TIMER_RTC_TRIGGER_MASK          0x00000010
#define    TIMER_RTC_TRIGGER_SHIFT              4
#define       TIMER_RTC_TRIGGER_DISABLE    (0UL<<4)
#define       TIMER_RTC_TRIGGER_ENABLE     (1UL<<4)

#define TIMER_BASE_REG                     (TIMER_BASE + 0x0C)
#define TIMER_NUM_BASE_REG(x)              (TIMER_BASE_REG + ((x) << 4))
#define    TIMER_NUM_BASE_MASK             0xFFFFFFFF
#define    TIMER_NUM_BASE_SHIFT                 0

#define TIMER_INT_STATUS_REG               (TIMER_BASE + 0x100)
#define    TIMER_INT_STATUS_MASK           0x0000FFFF
#define    TIMER_INT_STATUS_SHIFT               0

#endif /* _PHMODTIMER_H_ */
