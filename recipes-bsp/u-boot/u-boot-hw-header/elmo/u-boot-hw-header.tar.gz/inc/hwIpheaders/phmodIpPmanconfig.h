/*-------------------------------------------------------------------------*/
/* Copyright 2011 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef PHMODIPPMANCONFIG_H
#define PHMODIPPMANCONFIG_H
	
	
	/*
	* Reset bits for each hub
	*/
	#define PMANCONFIG_HUB_RESET_REG  (PMANCONFIG_BASE + 0x0)
	/*
	* Reserved
	*/
	#define PMANCONFIG_HUB_RESET_RESERVED_RES (0x01fffffff << 3)
	#define PMANCONFIG_HUB_RESET_RESERVED_SHIFT 3
	/*
	* Soft Reset Hub 2 and associated arbiter
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_HUB_RESET_RESETHUB2_RW (0x01 << 2)
	#define PMANCONFIG_HUB_RESET_RESETHUB2_SHIFT 2
	#define PMANCONFIG_HUB_RESET_RESETHUB2_VAL0 0x00
	#define PMANCONFIG_HUB_RESET_RESETHUB2_VAL1 0x01
	/*
	* Soft Reset Hub 1 and associated arbiter and monitor
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_HUB_RESET_RESETHUB1_RW (0x01 << 1)
	#define PMANCONFIG_HUB_RESET_RESETHUB1_SHIFT 1
	/*
	* Soft Reset Hub 0 and associated arbiter and monitor
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_HUB_RESET_RESETHUB0_RW (0x01 << 0)
	#define PMANCONFIG_HUB_RESET_RESETHUB0_SHIFT 0
	/*
	* Forces splitter to select one output
	*/
	#define PMANCONFIG_ROUTING_CONTROL_REG  (PMANCONFIG_BASE + 0x4)
	/*
	* Reserved
	*/
	#define PMANCONFIG_ROUTING_CONTROL_RESERVED_RES (0x03fffffff << 2)
	#define PMANCONFIG_ROUTING_CONTROL_RESERVED_SHIFT 2
	/*
	* When high, access to the on-chip SRAM is DISABLED. This bit resets low to allow 
	* the SRAM to be accessed for booting.
	*/
	#define PMANCONFIG_ROUTING_CONTROL_FORCE_DRAM1_RW (0x01 << 1)
	#define PMANCONFIG_ROUTING_CONTROL_FORCE_DRAM1_SHIFT 1
	/*
	* When high, access to the DRAM1 is (generally) DISABLED. This bit resets low to a
	* llow the DRAM1.
	*/
	#define PMANCONFIG_ROUTING_CONTROL_FORCE_DRAM0_RW (0x01 << 0)
	#define PMANCONFIG_ROUTING_CONTROL_FORCE_DRAM0_SHIFT 0
	/*
	* General parameters for MTL Mux for Hub 0 (DDR 0)
	*/
	#define PMANCONFIG_HUB0_CONTROL_REG  (PMANCONFIG_BASE + 0x10)
	/*
	* Reserved
	*/
	#define PMANCONFIG_HUB0_CONTROL_RESERVED_RES (0x03 << 30)
	#define PMANCONFIG_HUB0_CONTROL_RESERVED_SHIFT 30
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 0
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB0_CONTROL_H0I5_CMD_LIMIT_RW (0x01f << 25)
	#define PMANCONFIG_HUB0_CONTROL_H0I5_CMD_LIMIT_SHIFT 25
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 0
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB0_CONTROL_H0I4_CMD_LIMIT_RW (0x01f << 20)
	#define PMANCONFIG_HUB0_CONTROL_H0I4_CMD_LIMIT_SHIFT 20
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 0
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB0_CONTROL_H0I3_CMD_LIMIT_RW (0x01f << 15)
	#define PMANCONFIG_HUB0_CONTROL_H0I3_CMD_LIMIT_SHIFT 15
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 0
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB0_CONTROL_H0I2_CMD_LIMIT_RW (0x01f << 10)
	#define PMANCONFIG_HUB0_CONTROL_H0I2_CMD_LIMIT_SHIFT 10
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 0
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB0_CONTROL_H0I1_CMD_LIMIT_RW (0x01f << 5)
	#define PMANCONFIG_HUB0_CONTROL_H0I1_CMD_LIMIT_SHIFT 5
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 0
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB0_CONTROL_H0I0_CMD_LIMIT_RW (0x01f << 0)
	#define PMANCONFIG_HUB0_CONTROL_H0I0_CMD_LIMIT_SHIFT 0
	/*
	* General parameters for MTL Mux for Hub 1 (DDR1)
	*/
	#define PMANCONFIG_HUB1_CONTROL_REG  (PMANCONFIG_BASE + 0x14)
	/*
	* Reserved
	*/
	#define PMANCONFIG_HUB1_CONTROL_RESERVED_RES (0x03 << 30)
	#define PMANCONFIG_HUB1_CONTROL_RESERVED_SHIFT 30
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 1
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB1_CONTROL_H1I5_CMD_LIMIT_RW (0x01f << 25)
	#define PMANCONFIG_HUB1_CONTROL_H1I5_CMD_LIMIT_SHIFT 25
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 1
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB1_CONTROL_H1I4_CMD_LIMIT_RW (0x01f << 20)
	#define PMANCONFIG_HUB1_CONTROL_H1I4_CMD_LIMIT_SHIFT 20
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 1
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB1_CONTROL_H1I3_CMD_LIMIT_RW (0x01f << 15)
	#define PMANCONFIG_HUB1_CONTROL_H1I3_CMD_LIMIT_SHIFT 15
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 1
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB1_CONTROL_H1I2_CMD_LIMIT_RW (0x01f << 10)
	#define PMANCONFIG_HUB1_CONTROL_H1I2_CMD_LIMIT_SHIFT 10
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 1
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB1_CONTROL_H1I1_CMD_LIMIT_RW (0x01f << 5)
	#define PMANCONFIG_HUB1_CONTROL_H1I1_CMD_LIMIT_SHIFT 5
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to 16 Bit DDR 1
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB1_CONTROL_H1I0_CMD_LIMIT_RW (0x01f << 0)
	#define PMANCONFIG_HUB1_CONTROL_H1I0_CMD_LIMIT_SHIFT 0
	/*
	* General parameters for MTL Mux for Hub 2 (Malone SRAM)
	*/
	#define PMANCONFIG_HUB2_CONTROL_REG  (PMANCONFIG_BASE + 0x18)
	/*
	* Reserved
	*/
	#define PMANCONFIG_HUB2_CONTROL_RESERVED_RES (0x07ffffff << 5)
	#define PMANCONFIG_HUB2_CONTROL_RESERVED_SHIFT 5
	/*
	* Limits the Total number of pipelined transactions,
	* after top level arbitration going to SRAM
	* 0 = No Limit (pipeline is 16 deep)
	* 1-16 = Max number of pipelined transactions
	* 17-31= Reserved
	*/
	#define PMANCONFIG_HUB2_CONTROL_H2I0_CMD_LIMIT_RW (0x01f << 0)
	#define PMANCONFIG_HUB2_CONTROL_H2I0_CMD_LIMIT_SHIFT 0
	/*
	* Select for monitor connected to Hub 0
	*/
	#define PMANCONFIG_HUB0_MONITOR_SELECT_REG  (PMANCONFIG_BASE + 0x20)
	/*
	* Reserved
	*/
	#define PMANCONFIG_HUB0_MONITOR_SELECT_RESERVED_RES (0x01fffffff << 3)
	#define PMANCONFIG_HUB0_MONITOR_SELECT_RESERVED_SHIFT 3
	/*
	* Selects which MTL initiator port on HUB0 is to be monitored
	*/
	#define PMANCONFIG_HUB0_MONITOR_SELECT_SELECT_RW (0x07 << 0)
	#define PMANCONFIG_HUB0_MONITOR_SELECT_SELECT_SHIFT 0
	/*
	* Select for monitor connected to Hub 1
	*/
	#define PMANCONFIG_HUB1_MONITOR_SELECT_REG  (PMANCONFIG_BASE + 0x24)
	/*
	* Reserved
	*/
	#define PMANCONFIG_HUB1_MONITOR_SELECT_RESERVED_RES (0x01fffffff << 3)
	#define PMANCONFIG_HUB1_MONITOR_SELECT_RESERVED_SHIFT 3
	/*
	* Selects which MTL initiator port on HUB1 is to be monitored
	*/
	#define PMANCONFIG_HUB1_MONITOR_SELECT_SELECT_RW (0x07 << 0)
	#define PMANCONFIG_HUB1_MONITOR_SELECT_SELECT_SHIFT 0
	/*
	* Soft Resets for memory clock domain on a node basis
	*/
	#define PMANCONFIG_NODE_RESET_REG  (PMANCONFIG_BASE + 0x30)
	/*
	* Reserved
	*/
	#define PMANCONFIG_NODE_RESET_RESERVED_RES (0x07ff << 21)
	#define PMANCONFIG_NODE_RESET_RESERVED_SHIFT 21
	/*
	* Soft Reset Node 20 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET20_RW (0x01 << 20)
	#define PMANCONFIG_NODE_RESET_RESET20_SHIFT 20
	/*
	* Soft Reset Node 19 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET19_RW (0x01 << 19)
	#define PMANCONFIG_NODE_RESET_RESET19_SHIFT 19
	/*
	* Soft Reset Node 18 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET18_RW (0x01 << 18)
	#define PMANCONFIG_NODE_RESET_RESET18_SHIFT 18
	/*
	* Soft Reset Node 17 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET17_RW (0x01 << 17)
	#define PMANCONFIG_NODE_RESET_RESET17_SHIFT 17
	/*
	* Soft Reset Node 16 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET16_RW (0x01 << 16)
	#define PMANCONFIG_NODE_RESET_RESET16_SHIFT 16
	/*
	* Soft Reset Node 15 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET15_RW (0x01 << 15)
	#define PMANCONFIG_NODE_RESET_RESET15_SHIFT 15
	/*
	* Soft Reset Node 14 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET14_RW (0x01 << 14)
	#define PMANCONFIG_NODE_RESET_RESET14_SHIFT 14
	/*
	* Soft Reset Node 13 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET13_RW (0x01 << 13)
	#define PMANCONFIG_NODE_RESET_RESET13_SHIFT 13
	/*
	* Soft Reset Node 12 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET12_RW (0x01 << 12)
	#define PMANCONFIG_NODE_RESET_RESET12_SHIFT 12
	/*
	* Soft Reset Node 11 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET11_RW (0x01 << 11)
	#define PMANCONFIG_NODE_RESET_RESET11_SHIFT 11
	/*
	* Soft Reset Node 10 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET10_RW (0x01 << 10)
	#define PMANCONFIG_NODE_RESET_RESET10_SHIFT 10
	/*
	* Soft Reset Node 9 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET09_RW (0x01 << 9)
	#define PMANCONFIG_NODE_RESET_RESET09_SHIFT 9
	/*
	* Soft Reset Node 8 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET08_RW (0x01 << 8)
	#define PMANCONFIG_NODE_RESET_RESET08_SHIFT 8
	/*
	* Soft Reset Node 7 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET07_RW (0x01 << 7)
	#define PMANCONFIG_NODE_RESET_RESET07_SHIFT 7
	/*
	* Soft Reset Node 6 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET06_RW (0x01 << 6)
	#define PMANCONFIG_NODE_RESET_RESET06_SHIFT 6
	/*
	* Soft Reset Node 5 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET05_RW (0x01 << 5)
	#define PMANCONFIG_NODE_RESET_RESET05_SHIFT 5
	/*
	* Soft Reset Node 4 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET04_RW (0x01 << 4)
	#define PMANCONFIG_NODE_RESET_RESET04_SHIFT 4
	/*
	* Soft Reset Node 3 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET03_RW (0x01 << 3)
	#define PMANCONFIG_NODE_RESET_RESET03_SHIFT 3
	/*
	* Soft Reset Node 2 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET02_RW (0x01 << 2)
	#define PMANCONFIG_NODE_RESET_RESET02_SHIFT 2
	/*
	* Soft Reset Node 1 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET01_RW (0x01 << 1)
	#define PMANCONFIG_NODE_RESET_RESET01_SHIFT 1
	/*
	* Soft Reset Node 0 memory clock domain
	* (Will not reset to zero after programming)
	*/
	#define PMANCONFIG_NODE_RESET_RESET00_RW (0x01 << 0)
	#define PMANCONFIG_NODE_RESET_RESET00_SHIFT 0
	/*
	* Threshold value for all IP_1820s
	*/
	#define PMANCONFIG_NODE_THRESHOLD_REG  (PMANCONFIG_BASE + 0x34)
	/*
	* Reserved
	*/
	#define PMANCONFIG_NODE_THRESHOLD_RESERVED_RES (0x07ffffff << 5)
	#define PMANCONFIG_NODE_THRESHOLD_RESERVED_SHIFT 5
	/*
	* This 5-bit value is driven to the threshold input on all IP_1820s inside the PMA
	* N network.
	*/
	#define PMANCONFIG_NODE_THRESHOLD_THRESHOLD_RW (0x01f << 0)
	#define PMANCONFIG_NODE_THRESHOLD_THRESHOLD_SHIFT 0
	/*
	* ARM926 Line Buffer config register 1 (node 4)
	*/
	#define PMANCONFIG_A926_LBUF_CONFIG1_REG  (PMANCONFIG_BASE + 0x60)
	/*
	* Setting this bit high invalidates the line buffer
	*/
	#define PMANCONFIG_A926_LBUF_CONFIG1_CFG_INVALIDATE_RW (0x01 << 31)
	#define PMANCONFIG_A926_LBUF_CONFIG1_CFG_INVALIDATE_SHIFT 31
	/*
	* Setting this bit high indicates read operations must be in order (this bit
	* should always be high).
	*/
	#define PMANCONFIG_A926_LBUF_CONFIG1_CFG_IN_ORDER_RW (0x01 << 30)
	#define PMANCONFIG_A926_LBUF_CONFIG1_CFG_IN_ORDER_SHIFT 30
	/*
	* Reserved
	*/
	#define PMANCONFIG_A926_LBUF_CONFIG1_RESERVED_RES (0x03fff << 16)
	#define PMANCONFIG_A926_LBUF_CONFIG1_RESERVED_SHIFT 16
	/*
	* This field indicates which IDs can be buffered. In general, only bit zero is
	* significant.
	*/
	#define PMANCONFIG_A926_LBUF_CONFIG1_CFG_ID_RW (0x0ffff << 0)
	#define PMANCONFIG_A926_LBUF_CONFIG1_CFG_ID_SHIFT 0
	/*
	* ARM926 Line Buffer config register 2 (node 4)
	*/
	#define PMANCONFIG_A926_LBUF_CONFIG2_REG  (PMANCONFIG_BASE + 0x64)
	/*
	* Addresses which, after masking, match this value are considered cacheable
	*/
	#define PMANCONFIG_A926_LBUF_CONFIG2_CFG_ADDR_RW (0x0ffff << 16)
	#define PMANCONFIG_A926_LBUF_CONFIG2_CFG_ADDR_SHIFT 16
	/*
	* This mask is bitwise ANDed with the incoming address before comparing
	* to the cfg_addr value. When cfg_mask and cfg_addr are both all zeros,
	* then all addresses are considered buffferable in the line buffer.
	*/
	#define PMANCONFIG_A926_LBUF_CONFIG2_CFG_MASK_RW (0x0ffff << 0)
	#define PMANCONFIG_A926_LBUF_CONFIG2_CFG_MASK_SHIFT 0
	/*
	* Content Region 0 Low Address for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_CONTENT_0_LO_REG  (PMANCONFIG_BASE + 0x1c0)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked. At reset, LOW > HIGH, disabling this range.
	*/
	#define PMANCONFIG_ADSP_CONTENT_0_LO_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_ADSP_CONTENT_0_LO_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_CONTENT_0_LO_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_ADSP_CONTENT_0_LO_RESERVED_SHIFT 0
	/*
	* Content Region 0 High Address for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_CONTENT_0_HI_REG  (PMANCONFIG_BASE + 0x1c4)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked.
	*/
	#define PMANCONFIG_ADSP_CONTENT_0_HI_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_ADSP_CONTENT_0_HI_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_CONTENT_0_HI_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_ADSP_CONTENT_0_HI_RESERVED_SHIFT 0
	/*
	* Content Region 1 Low Address for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_CONTENT_1_LO_REG  (PMANCONFIG_BASE + 0x1c8)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked. At reset, LOW > HIGH, disabling this range.
	*/
	#define PMANCONFIG_ADSP_CONTENT_1_LO_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_ADSP_CONTENT_1_LO_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_CONTENT_1_LO_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_ADSP_CONTENT_1_LO_RESERVED_SHIFT 0
	/*
	* Content Region 1 High Address for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_CONTENT_1_HI_REG  (PMANCONFIG_BASE + 0x1cc)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked.
	*/
	#define PMANCONFIG_ADSP_CONTENT_1_HI_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_ADSP_CONTENT_1_HI_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_CONTENT_1_HI_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_ADSP_CONTENT_1_HI_RESERVED_SHIFT 0
	/*
	* Content Region 2 Low Address for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_CONTENT_2_LO_REG  (PMANCONFIG_BASE + 0x1d0)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked. At reset, LOW > HIGH, disabling this range.
	*/
	#define PMANCONFIG_ADSP_CONTENT_2_LO_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_ADSP_CONTENT_2_LO_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_CONTENT_2_LO_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_ADSP_CONTENT_2_LO_RESERVED_SHIFT 0
	/*
	* Content Region 2 High Address for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_CONTENT_2_HI_REG  (PMANCONFIG_BASE + 0x1d4)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked.
	*/
	#define PMANCONFIG_ADSP_CONTENT_2_HI_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_ADSP_CONTENT_2_HI_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_CONTENT_2_HI_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_ADSP_CONTENT_2_HI_RESERVED_SHIFT 0
	/*
	* Content Region 3 Low Address for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_CONTENT_3_LO_REG  (PMANCONFIG_BASE + 0x1d8)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked. At reset, LOW > HIGH, disabling this range.
	*/
	#define PMANCONFIG_ADSP_CONTENT_3_LO_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_ADSP_CONTENT_3_LO_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_CONTENT_3_LO_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_ADSP_CONTENT_3_LO_RESERVED_SHIFT 0
	/*
	* Content Region 3 High Address for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_CONTENT_3_HI_REG  (PMANCONFIG_BASE + 0x1dc)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked.
	*/
	#define PMANCONFIG_ADSP_CONTENT_3_HI_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_ADSP_CONTENT_3_HI_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_CONTENT_3_HI_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_ADSP_CONTENT_3_HI_RESERVED_SHIFT 0
	/*
	* Source address pointer 0 (base first area) for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_POINTER_S0_REG  (PMANCONFIG_BASE + 0x1e0)
	/*
	* Source address pointer 0
	* Addresses with MSB's >= to this value and 
	* < POINTER_S1 register value to be translated
	* to equivalent address space starting at
	* POINTER_T0 register value
	*/
	#define PMANCONFIG_ADSP_POINTER_S0_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_ADSP_POINTER_S0_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_POINTER_S0_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_ADSP_POINTER_S0_RESERVED_SHIFT 0
	/*
	* Source address pointer 1 (base second area) for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_POINTER_S1_REG  (PMANCONFIG_BASE + 0x1e4)
	/*
	* Source address pointer 1
	* Addresses with MSB's >= to this value and 
	* < POINTER_S2 register value to be translated
	* to equivalent address space starting at
	* POINTER_T1 register value
	*/
	#define PMANCONFIG_ADSP_POINTER_S1_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_ADSP_POINTER_S1_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_POINTER_S1_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_ADSP_POINTER_S1_RESERVED_SHIFT 0
	/*
	* Source address pointer 2 (base third area) for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_POINTER_S2_REG  (PMANCONFIG_BASE + 0x1e8)
	/*
	* Source address pointer 2
	* Addresses with MSB's >= to this value and 
	* <= POINTER_S3 register value to be translated
	* to equivalent address space starting at
	* POINTER_T2 register value
	*/
	#define PMANCONFIG_ADSP_POINTER_S2_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_ADSP_POINTER_S2_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_POINTER_S2_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_ADSP_POINTER_S2_RESERVED_SHIFT 0
	/*
	* Source address pointer 3 (limit third area) for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_POINTER_S3_REG  (PMANCONFIG_BASE + 0x1ec)
	/*
	* Source address pointer 2
	*/
	#define PMANCONFIG_ADSP_POINTER_S3_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_ADSP_POINTER_S3_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_POINTER_S3_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_ADSP_POINTER_S3_RESERVED_SHIFT 0
	/*
	* Target address pointer 0 (base first area mapped) for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_POINTER_T0_REG  (PMANCONFIG_BASE + 0x1f0)
	/*
	* Target address pointer 0
	* MSB's of target base address for
	* POINTER_S0 <= source address < POINTER_S1
	*/
	#define PMANCONFIG_ADSP_POINTER_T0_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_ADSP_POINTER_T0_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_POINTER_T0_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_ADSP_POINTER_T0_RESERVED_SHIFT 0
	/*
	* Target address pointer 1 (base second area mapped) for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_POINTER_T1_REG  (PMANCONFIG_BASE + 0x1f4)
	/*
	* Target address pointer 1
	* MSB's of target base address for
	* POINTER_S1 <= source address < POINTER_S2
	*/
	#define PMANCONFIG_ADSP_POINTER_T1_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_ADSP_POINTER_T1_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_POINTER_T1_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_ADSP_POINTER_T1_RESERVED_SHIFT 0
	/*
	* Target address pointer 2 (base third area mapped) for Audio DSP (node 2)
	*/
	#define PMANCONFIG_ADSP_POINTER_T2_REG  (PMANCONFIG_BASE + 0x1f8)
	/*
	* Target address pointer 1
	* MSB's of target base address for
	* POINTER_S2 <= source address <= POINTER_S3
	*/
	#define PMANCONFIG_ADSP_POINTER_T2_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_ADSP_POINTER_T2_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_ADSP_POINTER_T2_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_ADSP_POINTER_T2_RESERVED_SHIFT 0
	/*
	* Content Region 0 Low Address for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_CONTENT_0_LO_REG  (PMANCONFIG_BASE + 0x200)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked. At reset, LOW > HIGH, disabling this range.
	*/
	#define PMANCONFIG_VDSP_CONTENT_0_LO_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_VDSP_CONTENT_0_LO_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_CONTENT_0_LO_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_VDSP_CONTENT_0_LO_RESERVED_SHIFT 0
	/*
	* Content Region 0 High Address for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_CONTENT_0_HI_REG  (PMANCONFIG_BASE + 0x204)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked.
	*/
	#define PMANCONFIG_VDSP_CONTENT_0_HI_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_VDSP_CONTENT_0_HI_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_CONTENT_0_HI_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_VDSP_CONTENT_0_HI_RESERVED_SHIFT 0
	/*
	* Content Region 1 Low Address for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_CONTENT_1_LO_REG  (PMANCONFIG_BASE + 0x208)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked. At reset, LOW > HIGH, disabling this range.
	*/
	#define PMANCONFIG_VDSP_CONTENT_1_LO_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_VDSP_CONTENT_1_LO_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_CONTENT_1_LO_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_VDSP_CONTENT_1_LO_RESERVED_SHIFT 0
	/*
	* Content Region 1 High Address for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_CONTENT_1_HI_REG  (PMANCONFIG_BASE + 0x20c)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked.
	*/
	#define PMANCONFIG_VDSP_CONTENT_1_HI_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_VDSP_CONTENT_1_HI_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_CONTENT_1_HI_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_VDSP_CONTENT_1_HI_RESERVED_SHIFT 0
	/*
	* Content Region 2 Low Address for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_CONTENT_2_LO_REG  (PMANCONFIG_BASE + 0x210)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked. At reset, LOW > HIGH, disabling this range.
	*/
	#define PMANCONFIG_VDSP_CONTENT_2_LO_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_VDSP_CONTENT_2_LO_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_CONTENT_2_LO_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_VDSP_CONTENT_2_LO_RESERVED_SHIFT 0
	/*
	* Content Region 2 High Address for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_CONTENT_2_HI_REG  (PMANCONFIG_BASE + 0x214)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked.
	*/
	#define PMANCONFIG_VDSP_CONTENT_2_HI_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_VDSP_CONTENT_2_HI_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_CONTENT_2_HI_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_VDSP_CONTENT_2_HI_RESERVED_SHIFT 0
	/*
	* Content Region 3 Low Address for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_CONTENT_3_LO_REG  (PMANCONFIG_BASE + 0x218)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked. At reset, LOW > HIGH, disabling this range.
	*/
	#define PMANCONFIG_VDSP_CONTENT_3_LO_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_VDSP_CONTENT_3_LO_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_CONTENT_3_LO_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_VDSP_CONTENT_3_LO_RESERVED_SHIFT 0
	/*
	* Content Region 3 High Address for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_CONTENT_3_HI_REG  (PMANCONFIG_BASE + 0x21c)
	/*
	* Operations where the supplied address is >= the LOW address and <= the HIGH addr
	* ess are marked as content access. Note that only the beginning address of a burs
	* t is checked.
	*/
	#define PMANCONFIG_VDSP_CONTENT_3_HI_POINTER_RW (0x0fffff << 12)
	#define PMANCONFIG_VDSP_CONTENT_3_HI_POINTER_SHIFT 12
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_CONTENT_3_HI_RESERVED_RES (0x0fff << 0)
	#define PMANCONFIG_VDSP_CONTENT_3_HI_RESERVED_SHIFT 0
	/*
	* Source address pointer 0 (base first area) for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_POINTER_S0_REG  (PMANCONFIG_BASE + 0x220)
	/*
	* Source address pointer 0
	* Addresses with MSB's >= to this value and 
	* < POINTER_S1 register value to be translated
	* to equivalent address space starting at
	* POINTER_T0 register value
	*/
	#define PMANCONFIG_VDSP_POINTER_S0_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_VDSP_POINTER_S0_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_POINTER_S0_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_VDSP_POINTER_S0_RESERVED_SHIFT 0
	/*
	* Source address pointer 1 (base second area) for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_POINTER_S1_REG  (PMANCONFIG_BASE + 0x224)
	/*
	* Source address pointer 1
	* Addresses with MSB's >= to this value and 
	* < POINTER_S2 register value to be translated
	* to equivalent address space starting at
	* POINTER_T1 register value
	*/
	#define PMANCONFIG_VDSP_POINTER_S1_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_VDSP_POINTER_S1_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_POINTER_S1_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_VDSP_POINTER_S1_RESERVED_SHIFT 0
	/*
	* Source address pointer 2 (base third area) for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_POINTER_S2_REG  (PMANCONFIG_BASE + 0x228)
	/*
	* Source address pointer 2
	* Addresses with MSB's >= to this value and 
	* <= POINTER_S3 register value to be translated
	* to equivalent address space starting at
	* POINTER_T2 register value
	*/
	#define PMANCONFIG_VDSP_POINTER_S2_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_VDSP_POINTER_S2_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_POINTER_S2_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_VDSP_POINTER_S2_RESERVED_SHIFT 0
	/*
	* Source address pointer 3 (limit third area) for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_POINTER_S3_REG  (PMANCONFIG_BASE + 0x22c)
	/*
	* Source address pointer 2
	*/
	#define PMANCONFIG_VDSP_POINTER_S3_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_VDSP_POINTER_S3_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_POINTER_S3_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_VDSP_POINTER_S3_RESERVED_SHIFT 0
	/*
	* Target address pointer 0 (base first area mapped) for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_POINTER_T0_REG  (PMANCONFIG_BASE + 0x230)
	/*
	* Target address pointer 0
	* MSB's of target base address for
	* POINTER_S0 <= source address < POINTER_S1
	*/
	#define PMANCONFIG_VDSP_POINTER_T0_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_VDSP_POINTER_T0_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_POINTER_T0_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_VDSP_POINTER_T0_RESERVED_SHIFT 0
	/*
	* Target address pointer 1 (base second area mapped) for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_POINTER_T1_REG  (PMANCONFIG_BASE + 0x234)
	/*
	* Target address pointer 1
	* MSB's of target base address for
	* POINTER_S1 <= source address < POINTER_S2
	*/
	#define PMANCONFIG_VDSP_POINTER_T1_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_VDSP_POINTER_T1_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_POINTER_T1_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_VDSP_POINTER_T1_RESERVED_SHIFT 0
	/*
	* Target address pointer 2 (base third area mapped) for Video DSP (node 3)
	*/
	#define PMANCONFIG_VDSP_POINTER_T2_REG  (PMANCONFIG_BASE + 0x238)
	/*
	* Target address pointer 1
	* MSB's of target base address for
	* POINTER_S2 <= source address <= POINTER_S3
	*/
	#define PMANCONFIG_VDSP_POINTER_T2_POINTER_RW (0x07ff << 21)
	#define PMANCONFIG_VDSP_POINTER_T2_POINTER_SHIFT 21
	/*
	* Reserved
	*/
	#define PMANCONFIG_VDSP_POINTER_T2_RESERVED_RES (0x01fffff << 0)
	#define PMANCONFIG_VDSP_POINTER_T2_RESERVED_SHIFT 0
	/*
	* Module identification register
	*/
	#define PMANCONFIG_MODULE_ID_REG  (PMANCONFIG_BASE + 0xffc)
	/*
	* Module ID value – 0xA125
	*/
	#define PMANCONFIG_MODULE_ID_MOD_ID_R (0x0ffff << 16)
	#define PMANCONFIG_MODULE_ID_MOD_ID_SHIFT 16
	/*
	* Major revision number
	*/
	#define PMANCONFIG_MODULE_ID_MAJOR_REV_R (0x07 << 12)
	#define PMANCONFIG_MODULE_ID_MAJOR_REV_SHIFT 12
	/*
	* Minor revision number
	*/
	#define PMANCONFIG_MODULE_ID_MINOR_REV_R (0x0f << 8)
	#define PMANCONFIG_MODULE_ID_MINOR_REV_SHIFT 8
	/*
	* Aperture size – multiple of 4K bytes
	*/
	#define PMANCONFIG_MODULE_ID_APERTURE_R (0x0ff << 0)
	#define PMANCONFIG_MODULE_ID_APERTURE_SHIFT 0

#endif // PHMODIPPMANCONFIG_H
