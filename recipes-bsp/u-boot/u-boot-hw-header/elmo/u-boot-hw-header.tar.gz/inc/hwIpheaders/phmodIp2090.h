/*-------------------------------------------------------------------------*/
/* Copyright 2011 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef _PHMODIP2090_H_
#define _PHMODIP2090_H_
    
    /*
    * Bit
    */
    #define IP_2090_MODE_SET_REG(n)  (IP2090_BASE_UNIT##n + 0x0)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_MODE_SET_RESERVED1_RES (0x07fffffff << 1)
    #define IP_2090_MODE_SET_RESERVED1_SHIFT 1
    /*
    * Requested mode
    */
    #define IP_2090_MODE_SET_SET_MODE_W (0x01 << 0)
    #define IP_2090_MODE_SET_SET_MODE_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_MODE_GET_REG(n)  (IP2090_BASE_UNIT##n + 0x4)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_MODE_GET_RESERVED1_RES (0x07fffffff << 1)
    #define IP_2090_MODE_GET_RESERVED1_SHIFT 1
    /*
    * Current mode
    */
    #define IP_2090_MODE_GET_GET_MODE_R (0x01 << 0)
    #define IP_2090_MODE_GET_GET_MODE_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_TEST_TYPE_REG(n)  (IP2090_BASE_UNIT##n + 0x10)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_TEST_TYPE_RESERVED2_RES (0x03fffff << 10)
    #define IP_2090_TEST_TYPE_RESERVED2_SHIFT 10
    #define IP_2090_TEST_TYPE_LOOP_RW (0x03 << 8)
    #define IP_2090_TEST_TYPE_LOOP_SHIFT 8
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_TEST_TYPE_RESERVED3_RES (0x03f << 2)
    #define IP_2090_TEST_TYPE_RESERVED3_SHIFT 2
    #define IP_2090_TEST_TYPE_TYPE_RW (0x03 << 0)
    #define IP_2090_TEST_TYPE_TYPE_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_TEST_STATUS_REG(n)  (IP2090_BASE_UNIT##n + 0x14)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_TEST_STATUS_RESERVED1_RES (0x03fffffff << 2)
    #define IP_2090_TEST_STATUS_RESERVED1_SHIFT 2
    /*
    * Test status
    */
    #define IP_2090_TEST_STATUS_TEST_STATUS_R (0x03 << 0)
    #define IP_2090_TEST_STATUS_TEST_STATUS_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_TEST_START_REG(n)  (IP2090_BASE_UNIT##n + 0x20)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_TEST_START_RESERVED1_RES (0x07fffffff << 1)
    #define IP_2090_TEST_START_RESERVED1_SHIFT 1
    #define IP_2090_TEST_START_START_W (0x01 << 0)
    #define IP_2090_TEST_START_START_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_ADDRESS_START_REG(n)  (IP2090_BASE_UNIT##n + 0x50)
    /*
    * MTL start address for pattern generation
    */
    #define IP_2090_ADDRESS_START_START_ADDRESS_RW (0x0ffffffff << 0)
    #define IP_2090_ADDRESS_START_START_ADDRESS_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_ADDRESS_END_REG(n)  (IP2090_BASE_UNIT##n + 0x60)
    /*
    * MTL end address for pattern generation
    */
    #define IP_2090_ADDRESS_END_END_ADDRESS_RW (0x0ffffffff << 0)
    #define IP_2090_ADDRESS_END_END_ADDRESS_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_MTL_BLOCK_SIZE_REG(n)  (IP2090_BASE_UNIT##n + 0x70)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_MTL_BLOCK_SIZE_RESERVED1_RES (0x01ffffff << 7)
    #define IP_2090_MTL_BLOCK_SIZE_RESERVED1_SHIFT 7
    /*
    * MTL block-size used for generated MTL transfers
    */
    #define IP_2090_MTL_BLOCK_SIZE_MTL_BLOCK_SIZE_RW (0x07f << 0)
    #define IP_2090_MTL_BLOCK_SIZE_MTL_BLOCK_SIZE_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_SEED_RANDOM_GEN0_REG(n)  (IP2090_BASE_UNIT##n + 0x110)
    /*
    * Seed for random generator for lower 16 bits (DQ0-15)
    */
    #define IP_2090_SEED_RANDOM_GEN0_SEED_RND_RW (0x0ffffffff << 0)
    #define IP_2090_SEED_RANDOM_GEN0_SEED_RND_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_SEED_RANDOM_GEN1_REG(n)  (IP2090_BASE_UNIT##n + 0x114)
    /*
    * Seed for random generator for upper 16 bits (DQ16-31)
    */
    #define IP_2090_SEED_RANDOM_GEN1_SEED_RND_RW (0x0ffffffff << 0)
    #define IP_2090_SEED_RANDOM_GEN1_SEED_RND_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_PATTERN_REG(n)  (IP2090_BASE_UNIT##n + 0x120)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_PATTERN_RESERVED1_RES (0x0ffffff << 8)
    #define IP_2090_PATTERN_RESERVED1_SHIFT 8
    /*
    * Source for fixed pattern of one DDR burst
    */
    #define IP_2090_PATTERN_FIXED_PATTERN_RW (0x0ff << 0)
    #define IP_2090_PATTERN_FIXED_PATTERN_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_INVERT_DQ_REG(n)  (IP2090_BASE_UNIT##n + 0x130)
    /*
    * Inversion for data signals DQ[31:0]
    */
    #define IP_2090_INVERT_DQ_INVERT_DQ_RW (0x0ffffffff << 0)
    #define IP_2090_INVERT_DQ_INVERT_DQ_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_MASK_DQ_REG(n)  (IP2090_BASE_UNIT##n + 0x150)
    /*
    * Mask for data signals DQ[31:0]
    */
    #define IP_2090_MASK_DQ_MASK_DQ_RW (0x0ffffffff << 0)
    #define IP_2090_MASK_DQ_MASK_DQ_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_START_STORAGE_REG(n)  (IP2090_BASE_UNIT##n + 0x200)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_START_STORAGE_RESERVED1_RES (0x03ffffff << 6)
    #define IP_2090_START_STORAGE_RESERVED1_SHIFT 6
    /*
    * Start storage point w.r.t failure in DDR-words 
    * - 0 means failed data and following storage-1 DDR words are stored 
    * - storage-1 means storage-1 words before failure and failure are stored 
    * - all values in between 0 and storage-1 are valid 
    * Note: also related commands are stored
    */
    #define IP_2090_START_STORAGE_START_STORAGE_RW (0x03f << 0)
    #define IP_2090_START_STORAGE_START_STORAGE_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_READ_POINTER_STORAGE_REG(n)  (IP2090_BASE_UNIT##n + 0x204)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_READ_POINTER_STORAGE_RESERVED1_RES (0x03ffffff << 6)
    #define IP_2090_READ_POINTER_STORAGE_RESERVED1_SHIFT 6
    /*
    * Pointer to stored data, addressing in DDR-words
    */
    #define IP_2090_READ_POINTER_STORAGE_POINTER_RW (0x03f << 0)
    #define IP_2090_READ_POINTER_STORAGE_POINTER_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_STORED_VALID_REG(n)  (IP2090_BASE_UNIT##n + 0x208)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_STORED_VALID_RESERVED1_RES (0x07fffffff << 1)
    #define IP_2090_STORED_VALID_RESERVED1_SHIFT 1
    /*
    * Value in registers STORED_**** valid
    */
    #define IP_2090_STORED_VALID_VALID_R (0x01 << 0)
    #define IP_2090_STORED_VALID_VALID_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_STORED_DATA_REG(n)  (IP2090_BASE_UNIT##n + 0x210)
    /*
    * Storde data (DQ16-31 of one DDR word, only applicabel if ddr_width=32)
    */
    #define IP_2090_STORED_DATA_BYTE_2_3_R (0x0ffff << 16)
    #define IP_2090_STORED_DATA_BYTE_2_3_SHIFT 16
    /*
    * Stored data (DQ0-15 of one DDR-word)
    */
    #define IP_2090_STORED_DATA_BYTE_0_1_R (0x0ffff << 0)
    #define IP_2090_STORED_DATA_BYTE_0_1_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_STORED_ADDR_REG(n)  (IP2090_BASE_UNIT##n + 0x214)
    /*
    * Observed DFI address 
    * - valid width depends on number of bits used on DDR bus (rest of the bits is 0) 
    * 
    * - clock-cycle corresponds with data in STORED_DATA
    */
    #define IP_2090_STORED_ADDR_DFI_ADDRESS_R (0x0ffffffff << 0)
    #define IP_2090_STORED_ADDR_DFI_ADDRESS_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_STORED_BA_REG(n)  (IP2090_BASE_UNIT##n + 0x218)
    /*
    * Observed DFI bank address 
    * - valid width depends on number of bits used on DDR bus (rest of the bits is 0) 
    * 
    * - clock-cycle corresponds with data in STORED_DATA
    */
    #define IP_2090_STORED_BA_DFI_BANK_R (0x0ffffffff << 0)
    #define IP_2090_STORED_BA_DFI_BANK_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_STORED_CTL_REG(n)  (IP2090_BASE_UNIT##n + 0x21c)
    /*
    * Automatically generated bitfield for padding
    */
    #define IP_2090_STORED_CTL_RESERVED6_RES (0x03ffffff << 6)
    #define IP_2090_STORED_CTL_RESERVED6_SHIFT 6
    /*
    * observed dfi_cs_n
    */
    #define IP_2090_STORED_CTL_DFI_CS_N_R (0x01 << 5)
    #define IP_2090_STORED_CTL_DFI_CS_N_SHIFT 5
    /*
    * observed dfi_odt
    */
    #define IP_2090_STORED_CTL_DFI_ODT_R (0x01 << 4)
    #define IP_2090_STORED_CTL_DFI_ODT_SHIFT 4
    /*
    * observed dfi_cke
    */
    #define IP_2090_STORED_CTL_DFI_CKE_R (0x01 << 3)
    #define IP_2090_STORED_CTL_DFI_CKE_SHIFT 3
    /*
    * observed dfi_ras_n
    */
    #define IP_2090_STORED_CTL_DFI_RAS_N_R (0x01 << 2)
    #define IP_2090_STORED_CTL_DFI_RAS_N_SHIFT 2
    /*
    * observed dfi_cas_n
    */
    #define IP_2090_STORED_CTL_DFI_CAS_N_R (0x01 << 1)
    #define IP_2090_STORED_CTL_DFI_CAS_N_SHIFT 1
    /*
    * observed dfi_cs_n 
    * Note: for all observed signals, clock-cycle corresponds with STORED_DATA
    */
    #define IP_2090_STORED_CTL_DFI_WE_N_R (0x01 << 0)
    #define IP_2090_STORED_CTL_DFI_WE_N_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_EXPECTED_DATA_REG(n)  (IP2090_BASE_UNIT##n + 0x220)
    /*
    * Expected data (DQ16-31 of one DDR word, only applicabel if ddr_width=32)
    */
    #define IP_2090_EXPECTED_DATA_BYTE_2_3_R (0x0ffff << 16)
    #define IP_2090_EXPECTED_DATA_BYTE_2_3_SHIFT 16
    /*
    * Expected data (DQ0-15 of one DDR-word)
    */
    #define IP_2090_EXPECTED_DATA_BYTE_0_1_R (0x0ffff << 0)
    #define IP_2090_EXPECTED_DATA_BYTE_0_1_SHIFT 0
    /*
    * Bit
    */
    #define IP_2090_MODULE_ID_REG(n)  (IP2090_BASE_UNIT##n + 0xffc)
    /*
    * Unique Module ID
    */
    #define IP_2090_MODULE_ID_MODULE_ID_R (0x0ffff << 16)
    #define IP_2090_MODULE_ID_MODULE_ID_SHIFT 16
    /*
    * Major revision of module implementation
    */
    #define IP_2090_MODULE_ID_MAJOR_REVISION_R (0x0f << 12)
    #define IP_2090_MODULE_ID_MAJOR_REVISION_SHIFT 12
    /*
    * Minor revision of module implementation
    */
    #define IP_2090_MODULE_ID_MINOR_REVISION_R (0x0f << 8)
    #define IP_2090_MODULE_ID_MINOR_REVISION_SHIFT 8
    /*
    * Aperture size/4K
    */
    #define IP_2090_MODULE_ID_APERTURE_R (0x0ff << 0)
    #define IP_2090_MODULE_ID_APERTURE_SHIFT 0

#endif // _PHMODIP2090_H_
