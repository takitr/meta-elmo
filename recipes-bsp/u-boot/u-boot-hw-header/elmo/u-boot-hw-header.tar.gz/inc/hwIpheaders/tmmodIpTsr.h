/****************************************************************************/
/* CONEXANT PROPRIETARY AND CONFIDENTIAL                                    */
/* SOFTWARE FILE/MODULE HEADER                                              */
/* Conexant Systems Inc. (c) 2006-2007                                      */
/* Austin, TX                                                               */
/* All Rights Reserved                                                      */
/****************************************************************************/
/*
* Filename: tmmodIpTsr.h
*
*
* Description: Public header file defining hardware-specific values
* (such as register addresses, bit definitions, etc.) for TSR Unit  
*
* Author:  Srinivasan Venkataraman
*
****************************************************************************/
/* $Id: tmmodIpTsr.h 211608 2011-06-20 03:06:42Z prasadl1 $
****************************************************************************/

#ifndef _TMMODIPTSR_H_
#define _TMMODIPTSR_H_

/****************************************************************************/
/*                            DEMULTIPLEXER - TSR UNIT DEFINITIONS          */
/****************************************************************************/

#define TSR_BASE(x)                                     (TEMPEST_COMMON_MAP + 0x19000 + ((x) * TSP_SIZE))

/* TSR DMA IN APERTURES --- fix me TODO */  
#define TEMPEST_TSR_DMA_IN(unit, input)                 (TEMPEST_COMMON_MAP + 0x180000 + ((unit)*0x10000) + ((input)*0x4000) )

/* TSR Control Register */
#define TSR_HOST_CTRL_REG(unit)                         ((volatile HW_DWORD *)(TSR_BASE(unit)+ 0x000))

#define TSR_ENABLE                                      (1UL<<0)  /* 0=Disable 1=Enable */
#define TSR_DSS_OVER_DVB                                (1UL<<1)  /* 0=Disable DSS Repackaging 
                                                                     1=Enable Repackaging of DSS into DVB packets */
#define TSR_DSS_REPACKAGE_SCID_REMAP                    (1UL<<2)  /* 0=Disable 
                                                                     1=SCID remapped as per Stream Remap Configuration */
#define TSR_DSS_REPACKAGE_PID_REMAP                     (1UL<<3)  /* 0=Disable 1=PID remapped */
#define TSR_REMUX_TO_TSI                                (1UL<<4)  /* 0=Passthrough TSS 0 to TSI (legacy mode) 
                                                                     1=Enable Remux to TSI */
#define TSR_REMUX_FROM_TSO                              (1UL<<5)  /* 0=Passthrough TSO to TSS 0 (legacy mode) 
                                                                     1=Enable Remux from TSO */
#define TSR_TSI_HANDSHAKE                               (1UL<<6)  /* 0=Disable 1=Enable */
#define TSR_TSS_HANDSHAKE                               (1UL<<7)  /* 0=Disable 1=Enable */

#define TSR_NUM_WRAP_BITS_SHIFT                         (8)
#define TSR_NUM_WRAP_BITS_MASK                          (0x7<<TSR_NUM_WRAP_BITS_SHIFT)
#define    TSR_NUM_WRAP_BITS                            (2)       /* Valid values are 0,1,2,3,4 */

#define TSR_TIMESTAMP_STYLE_MPEG                        (1UL << 11)   /* 0 = 27 MHZ Clock Counter for timestamping
                                                                         1 = MPEG Style timestamping */
#define TSR_TIMESTAMP_BITS_SIZE_MASK                    (0x0000F000)

#define TSR_TSI_NULL_PKT_INS                            (1UL<<16) /* 0=Disable 
                                                                     1=Enable null pkt insertion to TSI Output */
#define TSR_TSS_NULL_PKT_INS                            (1UL<<17) /* 0=Disable 
                                                                     1=Enable null pkt insertion to TSS Output */
#define TSR_TSX_PACE_ENABLE                             (1UL<<18) /* 0=Disable 
                                                                     1=Enable pacing to TSX output using timestamps */
/* PS Repackage Mode
 * 0=PS or raw data pcktized into 188 bytes with no header
 * 1=PS or raw data pcktized into 188 bytes incl. 4 bytes of header 
 */
#define TSR_PS_REPACKAGE_MODE_SHIFT                     (19)
#define TSR_PS_REPACKAGE_MODE_MASK                      (1UL<<TSR_PS_REPACKAGE_MODE_SHIFT)
/* 188 bytes payload */
#define TSR_PS_REPACKAGE_MODE_0                         (0UL<<TSR_PS_REPACKAGE_MODE_SHIFT)
/* DVB style packet - 4 bytes header with 184 byte payload */
#define TSR_PS_REPACKAGE_MODE_1                         (1UL<<TSR_PS_REPACKAGE_MODE_SHIFT)

#define TSR_DESTINATION_MODE                            (1UL<<20) /* 0=Input Selected 1=PID Selected */
#define TSR_NULL_PKT_INSERTION_MODE_SINGLE_PKT          (1UL<<21) /* 0=Continuous 1=Single Packet */
                                                                  /* This mode controls whether one null packet or continuous 
                                                                     null packets are inserted into the TSI output when the TSI 
                                                                     packet timeout is reached. In continuous packet mode, null 
                                                                     packets will be repeatedly added until real data arrives. 
                                                                     In single packet mode only one null packet will be added 
                                                                     until real data arrives.
                                                                     Single packet mode is intended to help push the last real 
                                                                     packet all the way through the TSR/TSP pipeline without 
                                                                     incurring excessive processing bandwidth (and thereby 
                                                                     saving power by allowing the TSP to go to sleep between 
                                                                     packets). 
                                                                  */   
#define TSR_NULL_PKT_INSERTION_MODE_CONT_PKT            (0UL<<21)


#define TSR_SPILLOVER_PR_TSS_FIFO                       (0) /* TBD*/
#define TSR_SPILLOVER_PR_SPILLOVER_FETCH                (1)
#define TSR_SPILLOVER_PR_EQUAL                          (2)
#define TSR_SPILLOVER_PRIORITY_MASK                     (0x00C00000)
#define TSR_SPILLOVER_TRIGGER_LEVEL(x)                  (x)*64 /* x MUST be between 0 and 15 */
#define TSR_SPILLOVER_TRIGGER_LEVEL_MASK                (0x0F000000)
#define TSR_TSI_FIFO_PKT_SZ_MASK                        (0x30000000)
#define TSR_TSS_FIFO_PKT_SZ_MASK                        (0xC0000000)
#define TSR_FIFO_PKT_SZ_DVB                             (0)
#define TSR_FIFO_PKT_SZ_DSS                             (1)
#define TSR_FIFO_PKT_SZ_ALTERNATE                       (3)


/* TSR Alternate Packet Register */
#define TSR_ALTERNATE_PKT_REG(unit)                     ((volatile HW_DWORD *)(TSR_BASE(unit)+0x00C))
#define TSR_ALTERNATE_PKT_LENGTH_MASK                   (0x000000FF)
#define TSR_ALTERNATE_PKT_SYNC_BYTE_MASK                (0x00FF0000)

/* TSR HOST Interrupt Enable and Status Registers */
#define TSR_HOST_INT_ENABLE_REG(unit)                   ((volatile HW_DWORD *)(TSR_BASE(unit)+0x010))
#define TSR_HOST_INT_STATUS_REG(unit)                   ((volatile HW_DWORD *)(TSR_BASE(unit)+0x014))

#define TSR_HOST_INT_TSS0                               (1UL<<0)
#define TSR_HOST_INT_TSS1                               (1UL<<1)
#define TSR_HOST_INT_TSS2                               (1UL<<2)
#define TSR_HOST_INT_TSS3                               (1UL<<3)
#define TSR_HOST_INT_TSS4                               (1UL<<4)
#define TSR_HOST_INT_DMA0                               (1UL<<8)
#define TSR_HOST_INT_DMA1                               (1UL<<9)
#define TSR_HOST_INT_DMA2                               (1UL<<10)
#define TSR_HOST_INT_DMA3                               (1UL<<11)
#define TSR_HOST_INT_TSO0                               (1UL<<16)
#define TSR_HOST_INT_HSX                                (1UL<<20)

/* TSR HOST Interrupt Control Register */
#define TSR_HOST_INT_CTRL_REG(unit)                     ((volatile HW_DWORD *)(TSR_BASE(unit)+0x018))

#define TSR_HOST_INT_CTRL_REG_ENABLE_ALL                (0x003F3FFF)

#define TSR_HOST_INT_TSS_DATA_ACQ                       (1UL<<0)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSS_DATA_LOST                      (1UL<<1)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSS_SYNC_ACQ                       (1UL<<2)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSS_SYNC_LOST                      (1UL<<3)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSS_FIFO_OVRFLW                    (1UL<<4)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSS_SYSMEM_BUFF_OVRFLW             (1UL<<5)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSS_LWM                            (1UL<<6)  /* 0=Disable 1=Enable */ 
#define TSR_HOST_INT_TSS_HWM                            (1UL<<7)  /* 0=Disable 1=Enable */

#define TSR_HOST_INT_DMA_DATA_ACQ                       (1UL<<8)   /* 0=Disable 1=Enable */
#define TSR_HOST_INT_DMA_DATA_LOST                      (1UL<<9)   /* 0=Disable 1=Enable */
#define TSR_HOST_INT_DMA_SYNC_ACQ                       (1UL<<10)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_DMA_SYNC_LOST                      (1UL<<11)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_DMA_OVRFLW                         (1UL<<12)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_DMA_UNDRFLW                        (1UL<<13)  /* 0=Disable 1=Enable */

#define TSR_HOST_INT_TSO_DATA_ACQ                       (1UL<<16)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSO_DATA_LOST                      (1UL<<17)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSO_SYNC_ACQ                       (1UL<<18)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSO_SYNC_LOST                      (1UL<<19)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSO_OVRFLW                         (1UL<<20)  /* 0=Disable 1=Enable */
#define TSR_HOST_INT_TSO_UNDRFLW                        (1UL<<21)  /* 0=Disable 1=Enable */

/* TSR Clock Generator Register */
#define TSR_CLK_GEN_REG(unit)                           ((volatile HW_DWORD *)(TSR_BASE(unit)+0x020))
#define TSR_CLK_HIGH_CNT_MASK                           (0x000000FF)
#define TSR_CLK_LOW_CNT_MASK                            (0x0000FF00)

/* TSR TSI Packet Timeout Register */
#define TSR_TSI_PKT_TIMEOUT_REG(unit)                   ((volatile HW_DWORD *)(TSR_BASE(unit)+0x024))

/* TSR TSS Packet Timeout Register */
#define TSR_TSS_PKT_TIMEOUT_REG(unit)                   ((volatile HW_DWORD *)(TSR_BASE(unit)+0x028))

#define TSR_PKT_TIMEOUT_CYCLE_CNT_MASK                  (0x0000FFC0)  /* Cycle count mask for both 
                                                                         TSR TSI and TSS Pkt Timeout Registers */

/* TSR Timestamp Counter Register */
#define TSR_TIMESTAMP_CTR_REG(unit)                     ((volatile HW_DWORD *)(TSR_BASE(unit)+0x02C))

#define TSR_TIMESTAMP_REG_EXTN_CTR_MASK                 (0x000001FF)
#define TSR_TIMESTAMP_REG_BASE_CTR_MASK                 (0xFFFFFE00)
#define TSR_TIMESTAMP_REG_27MHZ_CTR_MASK                (0xFFFFFFFF) 

/* TSR Input Control Registers */
#define TSR_TSS_CTRL_ENABLE                             (1UL<<0)  /* 0=Disable Ctrl 1=Enable */
#define TSR_TSO_CTRL_ENABLE                             (1UL<<0)  /* 0=Disable Ctrl 1=Enable */
#define TSR_DMA_CTRL_ENABLE                             (1UL<<0)  /* 0=Disable Ctrl 1=Enable */
#define TSR_MCARD_CTRL_ENABLE                           (1UL<<0)  /* 0=Disable Ctrl 1=Enable */

/* Bit 10 and Bit 1 defines the TSRSyncMode 
 * bit-10  bit-1           SyncMode
 * ------  -----  --------------------------------------------
 *   0       0    External Sync - Sync from External sync input
 *   0       1    Auto Sync     - Sync from data value
 *   1       0    Raw Sync      - No Sync
 *   1       1    Full Sync     - Sync from External sync input and data value
 */
#define TSR_INPUT_CTRL_SYNC_MODE_MASK                   (0x00000402)

#define TSR_TSS_CTRL_SYNC_MODE_EXTERNAL                 ((0UL<<10)|(0UL<<1))   /* Bit 10 is most significant bit */
#define TSR_TSS_CTRL_SYNC_MODE_AUTO                     ((0UL<<10)|(1UL<<1))
#define TSR_TSS_CTRL_SYNC_MODE_RAW                      ((1UL<<10)|(0UL<<1))
#define TSR_TSS_CTRL_SYNC_MODE_FULL                     ((1UL<<10)|(1UL<<1))

#define TSR_DMA_CTRL_SYNC_MODE_ASSUME                   ((0UL<<10)|(0UL<<1))
#define TSR_DMA_CTRL_SYNC_MODE_AUTO                     ((0UL<<10)|(1UL<<1))
#define TSR_DMA_CTRL_SYNC_MODE_RAW                      ((1UL<<10)|(0UL<<1))
#define TSR_DMA_CTRL_SYNC_MODE_FULL                     ((1UL<<10)|(1UL<<1))

#define TSR_INPUT_CTRL_XPRT_MODE_MASK                   (0x0000000C)
#define TSR_INPUT_CTRL_XPRT_MODE_SHIFT                  (2)
#define TSR_INPUT_CTRL_XPRT_MODE_DVB                    (0)     /* 00=DVB packet (188 bytes) */ 
#define TSR_INPUT_CTRL_XPRT_MODE_DSS                    (1)     /* 01=DSS packet (130 bytes) */ 
#define TSR_INPUT_CTRL_XPRT_MODE_PS_RAW                 (2)     /* 10=PS/RAW (data is repackaged into 188 bytes) */ 
#define TSR_INPUT_CTRL_XPRT_MODE_ALT                    (3)     /* 11=Alternate (use alt. sync byte and packet length) */ 

/* Capture mode bit control */
#define TSR_TSS_CTRL_CAP_MODE_CTRL_SHIFT                (4)
#define TSR_TSS_CTRL_CAP_MODE_CTRL_MASK                 (1UL<<TSR_TSS_CTRL_CAP_MODE_CTRL_SHIFT)
#define    TSR_TSS_CTRL_CAP_MODE_CTRL_ENABLE            (1UL<<TSR_TSS_CTRL_CAP_MODE_CTRL_SHIFT)   /* 1=Capture to System Memory */ 
#define    TSR_TSS_CTRL_CAP_MODE_CTRL_DISABLE           (0UL<<TSR_TSS_CTRL_CAP_MODE_CTRL_SHIFT)   /* 0=Output to FIFO */

#define TSR_TSO_CTRL_TIMESTAMPED_STREAM                 (1UL<<4)   /* 0=Stream Not Timestamped 
                                                                      1=Stream already has 4 byte timestamp header at the front of each packet. 
                                                                      The total packet length is 4 more than the packet sized defined in bits [3:2]. 

                                                                      Note this bit also acts globally within the TSR 
                                                                      and will force the stream to the TSP to be have a timestamp header.

                                                                    */

#define TSR_MCARD_CTRL_FIFO_SWAP_ENABLE                 (1UL<<4)   /* 0=TSS to TSS FIFO, MCARD to MCARD FIFO
                                                                      1=TSS to MCARD FIFO, MCARD to TSS FIFO */
#define TSR_DMA_CTRL_STREAM_TIMESTAMPED                 (1UL<<4)   /* 0=Stream Not Timestamped
                                                                      1=Stream already has 4 byte timestamp header 
                                                                        at the front of each packet. The total packet 
                                                                        length is 4 more than the packet sized defined in bits [3:2].*/   
#define TSR_TSS_CTRL_SPILLOVER_ENABLE                   (1UL<<5)   /* 0=Disable (overflow causes data loss)
                                                                      1=Enable (overflow spills over to system memory */
#define TSR_MCARD_CTRL_SOURCE_DMA                       (1UL<<5)   /* 0=MCARD FIFO
                                                                      1=DMA FIFO */

#define TSR_INPUT_CTRL_DEST_FIFO_TSS                    (1UL<<6)   /* 0=TSI (to TSP's Transport Stream Input 
                                                                      1=TSS (back to TSS) */

/* PID filter control */
#define TSR_TSS_CTRL_PID_FILTER_CTRL_SHIFT              (7)
#define TSR_TSS_CTRL_PID_FILTER_CTRL_MASK               (1UL<<TSR_TSS_CTRL_PID_FILTER_CTRL_SHIFT)
#define    TSR_TSS_CTRL_PID_FILTER_CTRL_ENABLE          (1UL<<TSR_TSS_CTRL_PID_FILTER_CTRL_SHIFT)   /* 0=No Filtering */
#define    TSR_TSS_CTRL_PID_FILTER_CTRL_DISABLE         (0UL<<TSR_TSS_CTRL_PID_FILTER_CTRL_SHIFT)   /* 1=Filter accdg to PID Table */

/* PID Remap control */
#define TSR_TSS_CTRL_PID_REMAP_SHIFT                    (8) 
#define TSR_TSS_CTRL_PID_REMAP_MASK                     (0x3UL<<TSR_TSS_CTRL_PID_REMAP_SHIFT)
#define    TSR_TSS_CTRL_NO_PID_REMAP                    (0)
#define    TSR_TSS_CTRL_REMAP_PID_TO_IDX                (1)
#define    TSR_TSS_CTRL_REMAP_IDX_TO_IDX                (2)
#define    TSR_TSS_CTRL_UNMAP_IDX_PID                   (3)


#define TSR_MCARD_CTRL_TSR_SELECT_ONE                   (1UL<<12)   /* 0=TSR 0
                                                                       1=TSR 1
                                                                       [This is only implemented in TSR 0 and only 
                                                                       for the first two MCARD transport streams, 
                                                                       the third TS comes from TSR0 and 
                                                                       the fourth comes from TSR1] */

#define TSR_TSS_CTRL_XPRT_ERROR_INDICATOR_INS           (1UL<<15)  /* 0=Not Modified
                                                                      1=Xprt Error Indicator inserted into pkt hdr */
#define TSR_MCARD_CTRL_XPRT_ERROR_INDICATOR_INS         (1UL<<15)  /* 0=Not Modified 
                                                                      1=Xprt Error Indicator inserted into pkt hdr */

#define TSR_TSS_CTRL_TIMESTAMP_ENABLE                   (1UL<<16)  /* 0=Disable 1=Enable */                                               
#define TSR_DMA_CTRL_ENDIAN_BIG                         (1UL<<16)  /* 0=Little Endian 1=Big Endian */

#define TSR_TSS_CTRL_HANDSHAKE_ENABLE                   (1UL<<17)  /* 0=Disable 1=Enable */                                               

#define TSR_DMA_CTRL_REQ_THRESHOLD_MASK                 (0x000C0000)
#define TSR_DMA_CTRL_REQ_THRESHOLD_GR_16                (0)
#define TSR_DMA_CTRL_REQ_THRESHOLD_GR_32                (1)
#define TSR_DMA_CTRL_REQ_THRESHOLD_GR_48                (2)
#define TSR_DMA_CTRL_REQ_THRESHOLD_GR_64                (3)

#define TSR_TSO_CTRL_REG(unit)                          ((volatile HW_DWORD *)(TSR_BASE(unit)+0x40))

#define TSR_TSS_CTRL_REG(unit, input)                   ((volatile HW_DWORD *)(TSR_BASE(unit)+0x100+(input*0x20)))

/* System Memory pointers used for spill over or capture mode. */
#define TSR_TSS_WRITE_PTR_OFFSET                        (0)  /* The number of words offset this address 
                                                                is from the base of the buffer descriptor */
#define TSR_TSS_READ_PTR_OFFSET                         (1)  /* The number of words offset this address 
                                                                is from the base of the buffer descriptor */
#define TSR_TSS_START_PTR_OFFSET                        (2)  /* The number of words offset this address 
                                                                is from the base of the buffer descriptor */
#define TSR_TSS_END_PTR_OFFSET                          (3)  /* The number of words offset this address 
                                                                is from the base of the buffer descriptor */

#define TSR_TSS_BUFF_DESC_WORD_MASK                     (0xFFFFFFFF)

#define TSR_TSS_WRITE_PTR_REG(unit, input)              ((volatile HW_DWORD *)(TSR_BASE(unit)+0x110+(input*0x20)))
#define TSR_TSS_READ_PTR_REG(unit, input)               ((volatile HW_DWORD *)(TSR_BASE(unit)+0x114+(input*0x20)))
#define TSR_TSS_READ_WRITE_PTR_WRAP_CNT_MASK            ( ((0xFUL)<<(32-TSR_NUM_WRAP_BITS)) & TSR_TSS_BUFF_DESC_WORD_MASK )
#define TSR_TSS_READ_WRITE_PTR_REG_MASK                 ( (0xFFFFFFFF) & ~(TSR_TSS_READ_WRITE_PTR_WRAP_CNT_MASK) )

#define TSR_TSS_START_PTR_REG(unit, input)              ((volatile HW_DWORD *)(TSR_BASE(unit)+0x118+(input*0x20)))
#define TSR_TSS_END_PTR_REG(unit, input)                ((volatile HW_DWORD *)(TSR_BASE(unit)+0x11C+(input*0x20)))
#define TSR_TSS_START_END_PTR_REG_MASK                  (0xFFFFFFFF)


#define TSR_DMA_CTRL_REG(unit,input)                    ((volatile HW_DWORD *)(TSR_BASE(unit)+0x200+(input*0x20)))

#define TSR_MCARD_CTRL_REG(unit,input)                  ((volatile HW_DWORD *)(TSR_BASE(unit)+0x300+(input*0x20)))

/* TSR Inputs Status Registers */
#define TSR_TSO_STATUS_REG(unit)                        ((volatile HW_DWORD *)(TSR_BASE(unit)+0x304))
#define TSR_TSS_STATUS_REG(unit, input)                 ((volatile HW_DWORD *)(TSR_BASE(unit)+0x104+(input*0x20)))
#define TSR_DMA_STATUS_REG(unit,input)                  ((volatile HW_DWORD *)(TSR_BASE(unit)+0x204+(input*0x20)))
#define TSR_MCARD_STATUS_REG(unit,input)                ((volatile HW_DWORD *)(TSR_BASE(unit)+0x304+(input*0x20)))

/* TSR Inputs Status Register Bit Definitions */
#define TSR_STATUS_DATA_ACQ                             (1UL<<0) /* 0=Not acquired (read), no effect (write)
                                                                    1=Acquired (read), clear (write) */
#define TSR_STATUS_DATA_LOST                            (1UL<<1) /* 0=Not lost (read), no effect (write)
                                                                    1=Lost (read), clear (write) */
#define TSR_STATUS_SYNC_ACQ                             (1UL<<2) /* 0=Not acquired (read), no effect (write)
                                                                    1=Acquired (read), clear (write) */
#define TSR_STATUS_SYNC_LOST                            (1UL<<3) /* 0=Not lost (read), no effect (write)
                                                                    1=Lost (read), clear (write) */
#define TSR_STATUS_FIFO_OVRFLW                          (1UL<<4) /* 0=No overflow (read), no effect (write)
                                                                    1=Overflow (read), clear (write) */
#define TSR_STATUS_SYSMEM_BUFF_OVRFLW                   (1UL<<5) /* 0=No overflow (read), no effect (write)
                                                                    1=Overflow (read), clear (write) */
#define TSR_STATUS_LWM                                  (1UL<<6) /* 0=No LWM 1=Buffer level has gone below LWM */
#define TSR_STATUS_HWM                                  (1UL<<7) /* 0=No HWM 1=Buffer level has gone above HWM */

/* Other TSR-TSS Related Registers */
#define TSR_TSS_LWM_REG(unit, input)                    ((volatile HW_DWORD *)(TSR_BASE(unit)+0x108+(input*0x20)))
#define TSR_TSS_HWM_REG(unit, input)                    ((volatile HW_DWORD *)(TSR_BASE(unit)+0x10C+(input*0x20)))
#define TSR_TSS_LMW_HWM_REG_MASK                        (0xFFFFFFFF)
#define TSR_TSS_LMW_HWM_REG_MASK                        (0xFFFFFFFF)

/* TSR PID Table Register */
#define TSR_PID_TBL_PID_REG(unit, idx)                  ((volatile HW_DWORD *)(TSR_BASE(unit)+0x400+(idx*0x04)))

#define TSR_PID_TBL_PID_MASK                            (0x00001FFF)
#define TSR_PID_TBL_PID_ENABLE                          (1UL<<16) /* 0=Disable 1=Enable match on this table entry */
#define TSR_PID_TBL_PS_PID                              (1UL<<17) /* 0=Matched PID 1=Generated PID for PS to TS repkging */
#define TSR_PID_TBL_STRM_TYPE_MASK                      (0x000C0000)
#define TSR_PID_TBL_STRM_TSS_INPUT                      (0)
#define TSR_PID_TBL_STRM_DMA_INPUT                      (1)
#define TSR_PID_TBL_STRM_TSP_TS_OUTPUT                  (2)
#define TSR_PID_TBL_STRM_MCARD_INPUT                    (3)

#define TSR_PID_TBL_STRM_IDX_MASK                       (0x00700000)

#define TSR_PID_TBL_DEST_FIFO_TSS                       (1UL<<23) /* 0=TSI (to TSP�s Transport Stream Input)
                                                                     1=TSS (back to TSS) (Not supported for TSS input) */
#define TSR_PID_TBL_NUM_PASSES_MASK                     (0x03000000)
#define TSR_PID_TBL_NUM_PASSES_1                        (0)
#define TSR_PID_TBL_NUM_PASSES_2                        (1)
#define TSR_PID_TBL_NUM_PASSES_3                        (2)
#define TSR_PID_TBL_NUM_PASSES_4                        (3)



/**************************
 *  SET/GET Write pointer *
 *************************/

/* Macro:      CNXT_TSR_TSS_BUFF_GET_WRITE_ADDRESS                                      */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write address of the buffer.                                         */
#define CNXT_TSR_TSS_BUFF_GET_WRITE_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSR_TSS_WRITE_PTR_OFFSET,TSR_TSS_READ_WRITE_PTR_REG_MASK))

/* Macro:      CNXT_TSR_TSS_BUFF_SET_WRITE_ADDRESS                                      */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write address of this buffer.     */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSR_TSS_BUFF_SET_WRITE_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSR_TSS_WRITE_PTR_OFFSET,TSR_TSS_READ_WRITE_PTR_REG_MASK,(value)))

/* Macro:      CNXT_TSR_TSS_BUFF_SET_WRITE_ADDR_AND_WRAP_CNT                            */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write address of this buffer.     */
/*                      wrap_cnt - the new wrap cnt value                               */      
/* Returns:    Nothing.                                                                 */
#define CNXT_TSR_TSS_BUFF_SET_WRITE_ADDR_AND_WRAP_CNT(buff_desc_addr,value,wrap_cnt) \
         (CNXT_SET_VAL((buff_desc_addr)+TSR_TSS_WRITE_PTR_OFFSET,(TSR_TSS_BUFF_DESC_WORD_MASK),(( value) + ((wrap_cnt)<<(RMO(TSR_TSS_READ_WRITE_PTR_WRAP_CNT_MASK))) )))

/* Macro:      CNXT_TSR_TSS_BUFF_GET_WRITE_ADDR_AND_WRAP_CNT                            */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write pointer including wrap count.                                  */
#define CNXT_TSR_TSS_BUFF_GET_WRITE_ADDR_AND_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSR_TSS_WRITE_PTR_OFFSET,(TSR_TSS_BUFF_DESC_WORD_MASK)))

/* Macro:      CNXT_TSR_TSS_BUFF_GET_WRITE_WRAP_CNT                                     */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write wrap count of the buffer.                                      */
#define CNXT_TSR_TSS_BUFF_GET_WRITE_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSR_TSS_WRITE_PTR_OFFSET,TSR_TSS_READ_WRITE_PTR_WRAP_CNT_MASK))

/* Macro:      CNXT_TSR_TSS_BUFF_SET_WRITE_WRAP_CNT                                     */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write wrap count of this buffer.  */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSR_TSS_BUFF_SET_WRITE_WRAP_CNT(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSR_TSS_WRITE_PTR_OFFSET,TSR_TSS_READ_WRITE_PTR_WRAP_CNT_MASK,(value)))



/**************************
 *  SET/GET Read pointer  *
 *************************/

/* Macro:      CNXT_TSR_TSS_BUFF_GET_READ_ADDRESS                                       */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The read address of the buffer.                                          */
#define CNXT_TSR_TSS_BUFF_GET_READ_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSR_TSS_READ_PTR_OFFSET,TSR_TSS_READ_WRITE_PTR_REG_MASK))

/* Macro:      CNXT_TSR_TSS_BUFF_SET_READ_ADDRESS                                       */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the read address of this buffer.      */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSR_TSS_BUFF_SET_READ_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSR_TSS_READ_PTR_OFFSET,TSR_TSS_READ_WRITE_PTR_REG_MASK,(value)))

/* Macro:      CNXT_TSR_TSS_BUFF_SET_READ_ADDR_AND_WRAP_CNT                             */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the read address of this buffer.      */
/*                      wrap_cnt - the new wrap cnt value                               */      
/* Returns:    Nothing.                                                                 */
#define CNXT_TSR_TSS_BUFF_SET_READ_ADDR_AND_WRAP_CNT(buff_desc_addr,value,wrap_cnt) \
         (CNXT_SET_VAL((buff_desc_addr)+TSR_TSS_READ_PTR_OFFSET,(TSR_TSS_BUFF_DESC_WORD_MASK),( (value) + ((wrap_cnt)<<(RMO(TSR_TSS_READ_WRITE_PTR_WRAP_CNT_MASK))) )))

/* Macro:      CNXT_TSR_TSS_BUFF_GET_READ_ADDR_AND_WRAP_CNT                             */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The read pointer including wrap count.                                   */
#define CNXT_TSR_TSS_BUFF_GET_READ_ADDR_AND_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSR_TSS_READ_PTR_OFFSET,(TSR_TSS_BUFF_DESC_WORD_MASK)))

/* Macro:      CNXT_TSR_TSS_BUFF_GET_READ_WRAP_CNT                                      */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write wrap count of the buffer.                                      */
#define CNXT_TSR_TSS_BUFF_GET_READ_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSR_TSS_READ_PTR_OFFSET,TSR_TSS_READ_WRITE_PTR_WRAP_CNT_MASK))

/* Macro:      CNXT_TSR_TSS_BUFF_SET_READ_WRAP_CNT                                      */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write wrap count of this buffer.  */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSR_TSS_BUFF_SET_READ_WRAP_CNT(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSR_TSS_READ_PTR_OFFSET,TSR_TSS_READ_WRITE_PTR_WRAP_CNT_MASK,(value)))


/***************************
 *  SET/GET Start pointer  *
 **************************/

/* Macro:      CNXT_TSR_TSS_BUFF_GET_START_ADDRESS                                      */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The start address of the buffer.                                         */
#define CNXT_TSR_TSS_BUFF_GET_START_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSR_TSS_START_PTR_OFFSET,TSR_TSS_START_END_PTR_REG_MASK))

/* Macro:      CNXT_TSR_TSS_BUFF_SET_START_ADDRESS                                      */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the start address of this buffer.     */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSR_TSS_BUFF_SET_START_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSR_TSS_START_PTR_OFFSET,TSR_TSS_START_END_PTR_REG_MASK,(value)))


/*************************
 *  SET/GET End pointer  *
 ************************/

/* Macro:      CNXT_TSR_TSS_BUFF_GET_END_ADDRESS                                        */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The end address of the buffer.                                           */
#define CNXT_TSR_TSS_BUFF_GET_END_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSR_TSS_END_PTR_OFFSET,TSR_TSS_START_END_PTR_REG_MASK))

/* Macro:      CNXT_TSR_TSS_BUFF_SET_END_ADDRESS                                       */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the end address of this buffer.       */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSR_TSS_BUFF_SET_END_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSR_TSS_END_PTR_OFFSET,TSR_TSS_START_END_PTR_REG_MASK,(value)))


/****************************************************************************/
/* end: _TMMODIPTSP_H_                                                           */
/* updated: 03-nov-2006, Pecos Changes                                      */
/****************************************************************************/

#endif /*_TMMODIPTSR_H_*/

