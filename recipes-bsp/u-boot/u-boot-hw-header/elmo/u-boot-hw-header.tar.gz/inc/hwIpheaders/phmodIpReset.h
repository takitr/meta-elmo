/*-------------------------------------------------------------------------*/
/* Copyright 2011 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef PHMODIPRESET_H
#define PHMODIPRESET_H
   
   /*
   * Reset Status Register
   */
   #define RESET_RST_STATUS_REG_REG1  (RESET_BASE_UNIT1 + 0x0)
   #define RESET_RST_STATUS_REG_RESERVED_RES (0x01ffffff << 7)
   #define RESET_RST_STATUS_REG_RESERVED_SHIFT 7
   /*
   * If set, this bit indicates that the reset source was a wakeup reset . This bit i
   * s cleared by writing a 1 to this bit position.
   */
   #define RESET_RST_STATUS_REG_WAKE_UP_RESET_RW (0x01 << 6)
   #define RESET_RST_STATUS_REG_WAKE_UP_RESET_SHIFT 6
   #define RESET_RST_STATUS_REG_WAKE_UP_RESET_VAL0 0x00
   #define RESET_RST_STATUS_REG_WAKE_UP_RESET_VAL1 0x01
   /*
   * If set, this bit indicates that the reset source was a SSP reset request. This b
   * it is cleared by writing a 1 to this bit position.
   */
   #define RESET_RST_STATUS_REG_SSP_RESET_RW (0x01 << 5)
   #define RESET_RST_STATUS_REG_SSP_RESET_SHIFT 5
   /*
   * If set, this bit indicates that the reset source was a soft reset. This bit is c
   * leared by writing a 1 to this bit position.
   */
   #define RESET_RST_STATUS_REG_SOFT_RESET_RW (0x01 << 4)
   #define RESET_RST_STATUS_REG_SOFT_RESET_SHIFT 4
   /*
   * If set, this bit indicates that the reset source was a smartcard reset. This bit
   *  is cleared by writing a 1 to this bit position.
   */
   #define RESET_RST_STATUS_REG_SMARTCARD_RESET_RW (0x01 << 3)
   #define RESET_RST_STATUS_REG_SMARTCARD_RESET_SHIFT 3
   #define RESET_RST_STATUS_REG_SMARTCARD_RESET_VAL0 0x00
   #define RESET_RST_STATUS_REG_SMARTCARD_RESET_VAL1 0x01
   /*
   * If set, this bit indicates that the reset source was a pushbutton reset. This bi
   * t is cleared by writing a 1 to this bit position.
   */
   #define RESET_RST_STATUS_REG_PUSHBUTTON_RESET_RW (0x01 << 2)
   #define RESET_RST_STATUS_REG_PUSHBUTTON_RESET_SHIFT 2
   /*
   * If set, this bit indicates that the reset source was a watchdog timeout . This b
   * it is cleared by writing a 1 to this bit position.
   */
   #define RESET_RST_STATUS_REG_TIMEOUT_RW (0x01 << 1)
   #define RESET_RST_STATUS_REG_TIMEOUT_SHIFT 1
   /*
   * If set, this bit indicates that the reset source was an assertion of the nPOR si
   * gnal. This bit is never cleared
   */
   #define RESET_RST_STATUS_REG_POR_RESET_RW (0x01 << 0)
   #define RESET_RST_STATUS_REG_POR_RESET_SHIFT 0
   /*
   * Standby Control Register
   */
   #define RESET_RST_STANDBY_REG_REG1  (RESET_BASE_UNIT1 + 0x4)
   /*
   * Reserved
   */
   #define RESET_RST_STANDBY_REG_RESERVED_RES (0x03fffffff << 2)
   #define RESET_RST_STANDBY_REG_RESERVED_SHIFT 2
   /*
   * When set by Standby Controller (M3), causes reset controller to drive reset to a
   * ll modules in power down domain. This bit is cleared by writing a 0 to this bit 
   * position.
   */
   #define RESET_RST_STANDBY_REG_STANDBY_RESET_RW (0x01 << 1)
   #define RESET_RST_STANDBY_REG_STANDBY_RESET_SHIFT 1
   /*
   * When set by Standby Controller (M3), this bit prevents the debug modules from be
   * ing reset when standby_reset is asserted. This bit is cleared by writing a 0 to 
   * this bit position.Need to unlock the register to write into it. Refer LOCK CMD a
   * nd LOCK status register defines.
   */
   #define RESET_RST_STANDBY_REG_STANDBY_EMUL_RW (0x01 << 0)
   #define RESET_RST_STANDBY_REG_STANDBY_EMUL_SHIFT 0
   /*
   * Soft reset Register
   */
   #define RESET_RST_SOFTRESET_REG_REG1  (RESET_BASE_UNIT1 + 0x8)
   /*
   * Reserved
   */
   #define RESET_RST_SOFTRESET_REG_RESERVED_RES (0x07fffffff << 1)
   #define RESET_RST_SOFTRESET_REG_RESERVED_SHIFT 1
   /*
   * When set, causes a chip reset. Chip reset clears this bit.Need to unlock the reg
   * ister to write into it. Refer LOCK CMD and LOCK status register defines.
   */
   #define RESET_RST_SOFTRESET_REG_SOFTRESET_RW (0x01 << 0)
   #define RESET_RST_SOFTRESET_REG_SOFTRESET_SHIFT 0
   /*
   * Global Reset Register 0
   */
   #define RESET_RST_GRESET0_REG_REG1  (RESET_BASE_UNIT1 + 0xc)
   /*
   * The Global Reset Register provides reset control to individual functions in the 
   * chip. Each bit maps to a specific function in the device. (Refer reset_sheet she
   * et for bit definitions). Need to unlock the register to write into it. Refer LOC
   * K CMD and LOCK status register defines.
   */
   #define RESET_RST_GRESET0_REG_GRESET0_RW (0x0ffffffff << 0)
   #define RESET_RST_GRESET0_REG_GRESET0_SHIFT 0

   #define RESET_RST_GRESET0_M3_SYSRESET_RW        (0x1 << 19)
   #define RESET_RST_GRESET0_M3_SYSRESET_SHIFT     19
   #define RESET_RST_GRESET0_M3_SYSRESET_DEASSERT  (0UL << 19)
   #define RESET_RST_GRESET0_M3_SYSRESET_ASSERT    (1UL << 19)

   #define RESET_RST_GRESET0_GMAC0_RESET_RW        (0x1 << 6)
   #define RESET_RST_GRESET0_GMAC0_RESET_SHIFT     6
   #define RESET_RST_GRESET0_GMAC0_RESET_DEASSERT  (0UL << 6)
   #define RESET_RST_GRESET0_GMAC0_RESET_ASSERT    (1UL << 6)

   /*
   * Global Reset Register 1
   */
   #define RESET_RST_GRESET1_REG_REG1  (RESET_BASE_UNIT1 + 0x10)
   /*
   * The Global Reset Register provides reset control to individual functions in the 
   * chip. Each bit maps to a specific function in the device. (Refer reset_sheet she
   * et for bit definitions). Need to unlock the register to write into it. Refer LOC
   * K CMD and LOCK status register defines.
   */
   #define RESET_RST_GRESET1_REG_GRESET1_RW (0x0ffffffff << 0)
   #define RESET_RST_GRESET1_REG_GRESET1_SHIFT 0

   #define RESET_RST_GRESET0_HARELY_SYSRESET_RW        (0x1 << 12)
   #define RESET_RST_GRESET0_HARELY_SYSRESET_SHIFT     12
   #define RESET_RST_GRESET0_HARELY_SYSRESET_DEASSERT  (0UL << 12)
   #define RESET_RST_GRESET0_HARELY_SYSRESET_ASSERT    (1UL << 12)


   
   /*
   * Global Reset Register 2
   */
   #define RESET_RST_GRESET2_REG_REG1  (RESET_BASE_UNIT1 + 0x14)
   /*
   * The Global Reset Register provides reset control to individual functions in the 
   * chip. Each bit maps to a specific function in the device. (Refer reset_sheet she
   * et for bit definitions). Need to unlock the register to write into it. Refer LOC
   * K CMD and LOCK status register defines.
   */
   #define RESET_RST_GRESET2_REG_GRESET2_RW (0x0ffffffff << 0)
   #define RESET_RST_GRESET2_REG_GRESET2_SHIFT 0
   /*
   * Push Button Reset Control Register
   */
   #define RESET_RST_PUSHBUTTON_RESET_CTL_REG_REG1  (RESET_BASE_UNIT1 + 0x1c)
   /*
   * Pushbutton timer control in 20ns decrements. Reset value set to 4 sec.
   */
   #define RESET_RST_PUSHBUTTON_RESET_CTL_REG_PUSHBUTTON_TIMER_CONTROL_RW (0x0ffffffff << 0)
   #define RESET_RST_PUSHBUTTON_RESET_CTL_REG_PUSHBUTTON_TIMER_CONTROL_SHIFT 0
   /*
   * Smartcard reset control register.Need to unlock the register to write into it. R
   * efer LOCK CMD and LOCK status register defines.
   */
   #define RESET_RST_SMARTCARD_RESET_CTL_REG1  (RESET_BASE_UNIT1 + 0x20)
   /*
   * Reserved
   */
   #define RESET_RST_SMARTCARD_RESET_CTL_RESERVED_RES (0x03fff << 18)
   #define RESET_RST_SMARTCARD_RESET_CTL_RESERVED_SHIFT 18
   /*
   * When this bit is set, the chip will be reset upon a removal of Smartcard 1. If t
   * his bit is clear, the chip will not be reset upon a removal of Smartcard 1.
   */
   #define RESET_RST_SMARTCARD_RESET_CTL_EN_SMTCD1_REM_RST_RW (0x01 << 17)
   #define RESET_RST_SMARTCARD_RESET_CTL_EN_SMTCD1_REM_RST_SHIFT 17
   /*
   * When this bit is set, the chip will be reset upon an insertion of Smartcard 1. I
   * f this bit is clear, the chip will not be reset upon an insertion of Smartcard 1
   * .
   */
   #define RESET_RST_SMARTCARD_RESET_CTL_EN_SMTCD1_INS_RST_RW (0x01 << 16)
   #define RESET_RST_SMARTCARD_RESET_CTL_EN_SMTCD1_INS_RST_SHIFT 16
   /*
   * Reserved
   */
   #define RESET_RST_SMARTCARD_RESET_CTL_RESERVED3_RES (0x03f << 10)
   #define RESET_RST_SMARTCARD_RESET_CTL_RESERVED3_SHIFT 10
   /*
   * When this bit is set, the chip will be reset upon a removal of Smartcard 0. If t
   * his bit is clear, the chip will not be reset upon a removal of Smartcard 0.
   */
   #define RESET_RST_SMARTCARD_RESET_CTL_EN_SMTCD0_REM_RST_RW (0x01 << 9)
   #define RESET_RST_SMARTCARD_RESET_CTL_EN_SMTCD0_REM_RST_SHIFT 9
   /*
   * When this bit is set, the chip will be reset upon an insertion of Smartcard 0. I
   * f this bit is clear, the chip will not be reset upon an insertion of Smartcard 0
   * .
   */
   #define RESET_RST_SMARTCARD_RESET_CTL_EN_SMTCD0_INS_RST_RW (0x01 << 8)
   #define RESET_RST_SMARTCARD_RESET_CTL_EN_SMTCD0_INS_RST_SHIFT 8
   /*
   * Reserved
   */
   #define RESET_RST_SMARTCARD_RESET_CTL_RESERVED6_RES (0x07f << 1)
   #define RESET_RST_SMARTCARD_RESET_CTL_RESERVED6_SHIFT 1
   /*
   * When set, this bit locks the Smartcard Reset Control Register so that it can no 
   * longer be changed. This bit can only be cleared by reset.
   */
   #define RESET_RST_SMARTCARD_RESET_CTL_LOCK_RW (0x01 << 0)
   #define RESET_RST_SMARTCARD_RESET_CTL_LOCK_SHIFT 0
   /*
   * Soft reset for the A9 that is self-clearing.
   */
   #define RESET_RST_A9_SELFRESET_CTL_REG1  (RESET_BASE_UNIT1 + 0x24)
   /*
   * Reserved
   */
   #define RESET_RST_A9_SELFRESET_CTL_RESERVED_RES (0x07fffffff << 1)
   #define RESET_RST_A9_SELFRESET_CTL_RESERVED_SHIFT 1
   /*
   * Apart from the soft reset one that stays set and the SSP has to clear it, this s
   * econd soft reset bit can be set by A9 to self reset. It would stay asserted for 
   * 16 cycles, and then reset itself.
   */
   #define RESET_RST_A9_SELFRESET_CTL_A9_SELFRESET_RW (0x01 << 0)
   #define RESET_RST_A9_SELFRESET_CTL_A9_SELFRESET_SHIFT 0
   /*
   * Lock Command Register
   */
   #define RESET_RST_LOCKCMD_REG_REG1  (RESET_BASE_UNIT1 + 0x28)
   /*
   * Refer Register description for write sequence.(apollo_rgu_reg_summary sheet)
   */
   #define RESET_RST_LOCKCMD_REG_LOCK_CMD_W (0x0ffffffff << 0)
   #define RESET_RST_LOCKCMD_REG_LOCK_CMD_SHIFT 0
   /*
   * Lock status Register
   */
   #define RESET_RST_LOCKSTAT_REG_REG1  (RESET_BASE_UNIT1 + 0x2c)
   /*
   * Reserved
   */
   #define RESET_RST_LOCKSTAT_REG_RESERVED_RES (0x0fffffff << 4)
   #define RESET_RST_LOCKSTAT_REG_RESERVED_SHIFT 4
   /*
   * Softreset register lock
   */
   #define RESET_RST_LOCKSTAT_REG_SOFTRESET_REGISTER_LOCK_RW (0x01 << 3)
   #define RESET_RST_LOCKSTAT_REG_SOFTRESET_REGISTER_LOCK_SHIFT 3
   /*
   * Standby register lock
   */
   #define RESET_RST_LOCKSTAT_REG_STANDBY_REGISTER_LOCK_RW (0x01 << 2)
   #define RESET_RST_LOCKSTAT_REG_STANDBY_REGISTER_LOCK_SHIFT 2
   /*
   * Global reset registers lock
   */
   #define RESET_RST_LOCKSTAT_REG_GLOBAL_RESET_LOCK_RW (0x01 << 1)
   #define RESET_RST_LOCKSTAT_REG_GLOBAL_RESET_LOCK_SHIFT 1
   /*
   * Smartcard control register lock
   */
   #define RESET_RST_LOCKSTAT_REG_SMARTCARD_CTRL_LOCK_RW (0x01 << 0)
   #define RESET_RST_LOCKSTAT_REG_SMARTCARD_CTRL_LOCK_SHIFT 0
   /*
   * Chip Configuration Register
   */
   #define RESET_RST_CONFIG_REG_REG1  (RESET_BASE_UNIT1 + 0x30)
   /*
   * Reserved
   */
   #define RESET_RST_CONFIG_REG_RESERVED_RES (0x01 << 31)
   #define RESET_RST_CONFIG_REG_RESERVED_SHIFT 31
   /*
   * IOA16 - Smart Port 1 Select
   * 0 = using Smart Port 1
   * 1 = not using Smart Port 1
   */
   #define RESET_RST_CONFIG_REG_SM1__RW (0x01 << 30)
   #define RESET_RST_CONFIG_REG_SM1__SHIFT 30
   #define RESET_RST_CONFIG_REG_SM1__VAL0 0x00
   #define RESET_RST_CONFIG_REG_SM1__VAL1 0x01
   /*
   * Reserved
   */
   #define RESET_RST_CONFIG_REG_RESERVED2_RES (0x01 << 29)
   #define RESET_RST_CONFIG_REG_RESERVED2_SHIFT 29
   /*
   * IOA24 -- Smart Port 0 NDS Select
   * 0=Smart Port 0 is used forNDS with aux bits
   * 1=Smart Port 0 is not used for NDS smartcard
   */
   #define RESET_RST_CONFIG_REG_NDS0_RW (0x01 << 28)
   #define RESET_RST_CONFIG_REG_NDS0_SHIFT 28
   /*
   * Reserved
   */
   #define RESET_RST_CONFIG_REG_RESERVED4_RES (0x0f << 24)
   #define RESET_RST_CONFIG_REG_RESERVED4_SHIFT 24
   /*
   * (IO_CS0#) -- PCI Hostbridge Enable (PCI Mode)
   * 0 = PCI device
   * 1 = PCI host bridge
   */
   #define RESET_RST_CONFIG_REG_PCI_HOST_RW (0x01 << 23)
   #define RESET_RST_CONFIG_REG_PCI_HOST_SHIFT 23
   /*
   * Reserved
   */
   #define RESET_RST_CONFIG_REG_RESERVED6_RES (0x03f << 17)
   #define RESET_RST_CONFIG_REG_RESERVED6_SHIFT 17
   /*
   * IO_CS4# -- PCI or Standard IO bus mode
   * 0 = PCI mode
   * 1 = Standard IO mode
   */
   #define RESET_RST_CONFIG_REG_PCI__RW (0x01 << 16)
   #define RESET_RST_CONFIG_REG_PCI__SHIFT 16
   /*
   * Reserved
   */
   #define RESET_RST_CONFIG_REG_RESERVED8_RES (0x0ff << 8)
   #define RESET_RST_CONFIG_REG_RESERVED8_SHIFT 8
   /*
   * IO_CS5# -- UART Boot Pins Selection 0 = Use pins pio001_uart1tx and pio002_uart1
   * rx for the UART 
   * 1 = Use pins ao_pio068_uart1tx_sstx and ao_pio069_uart1rx_ssrx for the UART
   */
   #define RESET_RST_CONFIG_REG_UART_PINS_RW (0x01 << 7)
   #define RESET_RST_CONFIG_REG_UART_PINS_SHIFT 7
   /*
   * IOA23 -- UART Boot Override 
   * 0 = Boot from UART, and ignore boot device selection configuration straps, I/O a
   * ddress bus width set according to the boot device selection 
   * 1 = Boot according to the boot device selection configuration straps
   */
   #define RESET_RST_CONFIG_REG_UART_BOOT__RW (0x01 << 6)
   #define RESET_RST_CONFIG_REG_UART_BOOT__SHIFT 6
   /*
   * {IOA26 ,IO_CS2#,IO_CS3#,IOA21,IOA22} -- 10000 = NOR x8 21-bit
   * 10001 = NOR x8 22-bit
   * 10010 = NOR x8 23-bit
   * 10011 = NOR x8 24-bit
   * 10100 = NOR x8 25-bit
   * 10101 = NOR x8 26-bit
   * 10110 = NOR x8 27-bit
   * 10111 = ARM held in reset (I/O address bus width is 16 bits)
   * 11000 = NOR x16 21-bit
   * 11001 = NOR x16 22-bit
   * 11010 = NOR x16 23-bit
   * 11011 = NOR x16 24-bit
   * 11100 = NOR x16 25-bit
   * 11101 = NOR x16 26-bit
   * 11110 = NOR x16 27-bit
   * 11111 = NOR x16 ADM Mode (I/O address bus width is 16 bits) 
   * 
   * 00000 = NAND x16 Small 4-cycle address (I/O address bus width is 16 bits)
   * 00001 = NAND x16 Small 5-cycle address (I/O address bus width is 16 bits)
   * 00010 = NAND x16 Large 4-cycle address (I/O address bus width is 16 bits)
   * 00011 = NAND x16 Large 5-cycle address (I/O address bus width is 16 bits)
   * 00100 = NAND x8 Small 4-cycle address (I/O address bus width is 16 bits)
   * 00101 = NAND x8 Small 5-cycle address (I/O address bus width is 16 bits)
   * 00110 = NAND x8 Large 4-cycle address (I/O address bus width is 16 bits)
   * 00111 = NAND x8 Large 5-cycle address (I/O address bus width is 16 bits)
   * 01000 = PCI device mode boot, ARM held in reset (I/O address bus width is 21 bit
   * s)
   * 01001 = NAND x16 Small 3-cycle address (I/O address bus width is 16 bits)
   * 01010 = ARM held in reset (I/O address bus width is 16 bits)
   * 01011 = NAND x8 Small 3-cycle address (I/O address bus width is 16 bits)
   * 01100 = SPI Flash 16-bit address (I/O address bus width is 16 bits)
   * 01101 = SPI Flash 24-bit address (I/O address bus width is 16 bits)
   * 01110 = SPI Flash 32-bit address (I/O address bus width is 16 bits)
   * 01111 = ARM held in reset (I/O address bus width is 16 bits)
   */
   #define RESET_RST_CONFIG_REG_BOOT_DEVICE_SELECTION_RW (0x01f << 1)
   #define RESET_RST_CONFIG_REG_BOOT_DEVICE_SELECTION_SHIFT 1
   /*
   * IO_CS1# -- 0 = 200mS reset sequence
   * 1 = 1mS reset sequence
   */
   #define RESET_RST_CONFIG_REG_SHORT_RESET_RW (0x01 << 0)
   #define RESET_RST_CONFIG_REG_SHORT_RESET_SHIFT 0

#endif // PHMODIPRESET_H
