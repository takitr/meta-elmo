 ///////////////////////////////////////////////////////////////////// 
//                                                                  / 
// (c) NXP B.V 2009                                                / 
//                                                                  / 
// All rights are reserved. Reproduction in whole or in part is     / 
// prohibited without the prior written consent of the copy-right   / 
// owner.                                                           / 
// The information presented in this document does not form part of / 
// any quotation or contract, is believed to be accurate and        / 
// reliable and may be changed without notice. No liability will be / 
// accepted by the publisher for any consequence of its use.        / 
// Publication thereof does not convey nor imply any license under  / 
// patent- or other industrial or intellectual property rights.     / 
 ///////////////////////////////////////////////////////////////////// 
 
/*! 
 *  @brief Header file for 
tpsao *  @file phmodIpTpsao.h *
 *  <pre>
 *  $Author: gargn $
 *  $Revision: 99754 $
 *  $Date: 2009-06-25 17:40:42 -0500 (Thu, 25 Jun 2009) $
 *
 *  Revision history
 *  $Log: $
 *  
 *
 *  $KeysEnd$
 *  </pre>
 *
 */ 


#ifndef PHMODIPTPSAO_H
#define PHMODIPTPSAO_H
	
	
	/*
	* Provides status of buffers and other Audio Out components/situations.
	*/
	#define TPSAO_AO_STATUS_REG  (TPSAO_BASE + 0x0)
	/*
	* A read returns 0x0.
	*/
	#define TPSAO_AO_STATUS_RESERVED_R (0x01ffffff << 6)
	#define TPSAO_AO_STATUS_RESERVED_SHIFT 6
	/*
	* 0 = Audio Out is ready to receive a CC1; CC2 pair.;1 = Audio Out is not ready to
	*  receive a CC1; CC2 pair. Try again in a;few SCK clock intervals.
	*/
	#define TPSAO_AO_STATUS_CC_BUSY_R (0x01 << 5)
	#define TPSAO_AO_STATUS_CC_BUSY_SHIFT 5
	#define TPSAO_AO_STATUS_CC_BUSY_VAL0 0x00
	#define TPSAO_AO_STATUS_CC_BUSY_VAL1 0x01
	/*
	* 1 =DMA buffer 1 in memory will be used for the next sample to be;transmitted.;0 
	* =DMA buffer 2 in memory will contain the next sample.
	*/
	#define TPSAO_AO_STATUS_BUF1_ACTIVE_R (0x01 << 4)
	#define TPSAO_AO_STATUS_BUF1_ACTIVE_SHIFT 4
	#define TPSAO_AO_STATUS_BUF1_ACTIVE_VAL0 0x00
	#define TPSAO_AO_STATUS_BUF1_ACTIVE_VAL1 0x01
	#define TPSAO_AO_STATUS_UNDERRUN_R (0x01 << 3)
	#define TPSAO_AO_STATUS_UNDERRUN_SHIFT 3
	#define TPSAO_AO_STATUS_UNDERRUN_VAL0 0x00
	#define TPSAO_AO_STATUS_UNDERRUN_VAL1 0x01
	/*
	* Bandwidth Error indicates that no new data was transmitted due to an inability o
	* f the DMA interface adapter to provide the required data in time for the start o
	* f a new frame. The last data set is repeated. If HBE_INTEN is an 1; then an inte
	* rrupt is also sent to the system. The HBE flag stays set until an 1 is written t
	* o ACK_HBE.
	*/
	#define TPSAO_AO_STATUS_HBE_R (0x01 << 2)
	#define TPSAO_AO_STATUS_HBE_SHIFT 2
	#define TPSAO_AO_STATUS_HBE_VAL0 0x00
	#define TPSAO_AO_STATUS_HBE_VAL1 0x01
	#define TPSAO_AO_STATUS_BUF2_EMPTY_R (0x01 << 1)
	#define TPSAO_AO_STATUS_BUF2_EMPTY_SHIFT 1
	#define TPSAO_AO_STATUS_BUF2_EMPTY_VAL0 0x00
	#define TPSAO_AO_STATUS_BUF2_EMPTY_VAL1 0x01
	#define TPSAO_AO_STATUS_BUF1_EMPTY_R (0x01 << 0)
	#define TPSAO_AO_STATUS_BUF1_EMPTY_SHIFT 0
	#define TPSAO_AO_STATUS_BUF1_EMPTY_VAL0 0x00
	#define TPSAO_AO_STATUS_BUF1_EMPTY_VAL1 0x01
	/*
	* Control register to configure Audio Out options
	*/
	#define TPSAO_AO_CTL_REG  (TPSAO_BASE + 0x4)
	/*
	* Resets the Audio Out logic. See Section 3.9.2 on page 25-13 for a;description of
	*  software reset.
	*/
	#define TPSAO_AO_CTL_RESET_RW (0x01 << 31)
	#define TPSAO_AO_CTL_RESET_SHIFT 31
	#define TPSAO_AO_CTL_RESET_VAL0 0x00
	#define TPSAO_AO_CTL_RESET_VAL1 0x01
	/*
	* Transmission Enable flag;0 = Audio Out is inactive.;1 = Audio Out transmits samp
	* les and acts as DMA master to read;samples from local memory.;Do not change any 
	* of the framing configurations while transmission;is enabled.
	*/
	#define TPSAO_AO_CTL_TRANS_ENABLE_RW (0x01 << 30)
	#define TPSAO_AO_CTL_TRANS_ENABLE_SHIFT 30
	#define TPSAO_AO_CTL_TRANS_ENABLE_VAL0 0x00
	#define TPSAO_AO_CTL_TRANS_ENABLE_VAL1 0x01
	/*
	* 00 = Mono; 32 bits/sample. Left and right data sent to each active;output are th
	* e same.;01 = Stereo; 32 bits/sample;10 = Mono; 16 bits/sample. Left and right da
	* ta are the same.;11 = Stereo; 16 bits/sample
	*/
	#define TPSAO_AO_CTL_TRANS_MODE_RW (0x01 << 28)
	#define TPSAO_AO_CTL_TRANS_MODE_SHIFT 28
	#define TPSAO_AO_CTL_TRANS_MODE_VAL0 0x00
	#define TPSAO_AO_CTL_TRANS_MODE_VAL1 0x01
	/*
	* 0 =Leave MSB unchanged.;1 = Invert MSB (not applied to codec control fields).
	*/
	#define TPSAO_AO_CTL_SIGN_CONVERT_RW (0x01 << 27)
	#define TPSAO_AO_CTL_SIGN_CONVERT_SHIFT 27
	#define TPSAO_AO_CTL_SIGN_CONVERT_VAL0 0x00
	#define TPSAO_AO_CTL_SIGN_CONVERT_VAL1 0x01
	/*
	* Setting this bit will enable the Audio Input port to capture data in a;mode wher
	* e the first data bit is driven on the same clock edge;during which WS is driven.
	*  In this mode the data is sampled one;clock earlier compared to the standard I2S
	*  mode.;0 = Standard I2S mode. First data bit expected the next clock after;WS ha
	* s been sampled.;1 = Early mode. First data bit expected the same clock during wh
	* ich;WS has been sampled.;Limitation: Early mode = 1 is allowed only for 32 bits/
	* sample and;stereo.
	*/
	#define TPSAO_AO_CTL_EARLY_MODE_RW (0x01 << 26)
	#define TPSAO_AO_CTL_EARLY_MODE_SHIFT 26
	#define TPSAO_AO_CTL_EARLY_MODE_VAL0 0x00
	#define TPSAO_AO_CTL_EARLY_MODE_VAL1 0x01
	/*
	* A read returns 0x0
	*/
	#define TPSAO_AO_CTL_RESERVED_1_R (0x01 << 25)
	#define TPSAO_AO_CTL_RESERVED_1_SHIFT 25
	#define TPSAO_AO_CTL_RESERVED_1_VAL0 0x00
	#define TPSAO_AO_CTL_RESERVED_1_VAL1 0x01
	/*
	* 0 = CC1 emission disabled.;1 = CC1 emission enabled.
	*/
	#define TPSAO_AO_CTL_CC1_EN_RW (0x01 << 24)
	#define TPSAO_AO_CTL_CC1_EN_SHIFT 24
	#define TPSAO_AO_CTL_CC1_EN_VAL0 0x00
	#define TPSAO_AO_CTL_CC1_EN_VAL1 0x01
	/*
	* 0 = CC2 emission disabled.;1 = CC2 emission enabled.
	*/
	#define TPSAO_AO_CTL_CC2_EN_RW (0x01 << 23)
	#define TPSAO_AO_CTL_CC2_EN_SHIFT 23
	#define TPSAO_AO_CTL_CC2_EN_VAL0 0x00
	#define TPSAO_AO_CTL_CC2_EN_VAL1 0x01
	/*
	* 0 = Emit 50% AO_WS.;1 = Emit single AO_SCK cycle AO_WS.
	*/
	#define TPSAO_AO_CTL_WS_PULSE_RW (0x01 << 22)
	#define TPSAO_AO_CTL_WS_PULSE_SHIFT 22
	#define TPSAO_AO_CTL_WS_PULSE_VAL0 0x00
	#define TPSAO_AO_CTL_WS_PULSE_VAL1 0x01
	/*
	* A read returns 0x0
	*/
	#define TPSAO_AO_CTL_RESERVED_2_R (0x01fff << 8)
	#define TPSAO_AO_CTL_RESERVED_2_SHIFT 8
	/*
	* UNDERRUN Interrupt Enable.;0 = No interrupt for UNDERRUN condition;1 = Interrupt
	*  if an UNDERRUN error occurs.
	*/
	#define TPSAO_AO_CTL_UDR_INTEN_RW (0x01 << 7)
	#define TPSAO_AO_CTL_UDR_INTEN_SHIFT 7
	#define TPSAO_AO_CTL_UDR_INTEN_VAL0 0x00
	#define TPSAO_AO_CTL_UDR_INTEN_VAL1 0x01
	/*
	* HBE Interrupt Enable:;0 = No interrupt for HBE condition;1 = Interrupt if a data
	*  bus bandwidth error occurs.
	*/
	#define TPSAO_AO_CTL_HBE_INTEN_RW (0x01 << 6)
	#define TPSAO_AO_CTL_HBE_INTEN_SHIFT 6
	#define TPSAO_AO_CTL_HBE_INTEN_VAL0 0x00
	#define TPSAO_AO_CTL_HBE_INTEN_VAL1 0x01
	/*
	* Buffer 2 Empty Interrupt Enable:;0 = No interrupt when DMA buffer is empty.;1 = 
	* Interrupt if DMA buffer 2 in memory is empty.
	*/
	#define TPSAO_AO_CTL_BUF2_INTEN_RW (0x01 << 5)
	#define TPSAO_AO_CTL_BUF2_INTEN_SHIFT 5
	#define TPSAO_AO_CTL_BUF2_INTEN_VAL0 0x00
	#define TPSAO_AO_CTL_BUF2_INTEN_VAL1 0x01
	/*
	* Buffer 1 Empty Interrupt Enable:;0 = No interrupt when DMA buffer 1 is empty.;1 
	* = Interrupt if DMA buffer 1 in memory is empty.
	*/
	#define TPSAO_AO_CTL_BUF1_INTEN_RW (0x01 << 4)
	#define TPSAO_AO_CTL_BUF1_INTEN_SHIFT 4
	#define TPSAO_AO_CTL_BUF1_INTEN_VAL0 0x00
	#define TPSAO_AO_CTL_BUF1_INTEN_VAL1 0x01
	/*
	* Write a 1 to clear the UNDERRUN flag and remove any pending UNDERRUN interrupt r
	* equest. ACK_UDR always reads 0.
	*/
	#define TPSAO_AO_CTL_ACK_UDR_RW (0x01 << 3)
	#define TPSAO_AO_CTL_ACK_UDR_SHIFT 3
	#define TPSAO_AO_CTL_ACK_UDR_VAL0 0x00
	#define TPSAO_AO_CTL_ACK_UDR_VAL1 0x01
	/*
	* Write a 1 to clear the HBE flag and remove any pending HBE interrupt request. AC
	* K_HBE always reads as 0.
	*/
	#define TPSAO_AO_CTL_ACK_HBE_RW (0x01 << 2)
	#define TPSAO_AO_CTL_ACK_HBE_SHIFT 2
	#define TPSAO_AO_CTL_ACK_HBE_VAL0 0x00
	#define TPSAO_AO_CTL_ACK_HBE_VAL1 0x01
	/*
	* Write a 1 to clear the BUF2_EMPTYflag and remove any pending BUF2_EMPTY interrup
	* t request. ACK2 always reads 0.
	*/
	#define TPSAO_AO_CTL_ACK2_RW (0x01 << 1)
	#define TPSAO_AO_CTL_ACK2_SHIFT 1
	#define TPSAO_AO_CTL_ACK2_VAL0 0x00
	#define TPSAO_AO_CTL_ACK2_VAL1 0x01
	/*
	* Write a 1 to clear the BUF1_EMPTY flag and remove any pending BUF1_EMPTY interru
	* pt request. ACK1 always reads 0.
	*/
	#define TPSAO_AO_CTL_ACK1_RW (0x01 << 0)
	#define TPSAO_AO_CTL_ACK1_SHIFT 0
	#define TPSAO_AO_CTL_ACK1_VAL0 0x00
	#define TPSAO_AO_CTL_ACK1_VAL1 0x01
	/*
	* Control register to configure Audio Out serial timing and data options
	*/
	#define TPSAO_AO_SERIAL_REG  (TPSAO_BASE + 0x8)
	/*
	* 0 = The D/A subsystem is the timing master over the Audio Out;serial interface. 
	* SCK and WS act as inputs.;1 = AO is the timing master over serial interface. SCK
	*  and WS act;as outputs. This mode is required for 4; 6 or 8 channel operation.;T
	* he SER_MASTER bit should only be changed while Audio Out is;disabled i.e.;TRANS_
	* ENABLE = 0.
	*/
	#define TPSAO_AO_SERIAL_SER_MASTER_RW (0x01 << 31)
	#define TPSAO_AO_SERIAL_SER_MASTER_SHIFT 31
	#define TPSAO_AO_SERIAL_SER_MASTER_VAL0 0x00
	#define TPSAO_AO_SERIAL_SER_MASTER_VAL1 0x01
	/*
	* 0 = Data is transmitted MSB first.;1 = Data is transmitted LSB first.
	*/
	#define TPSAO_AO_SERIAL_DATAMODE_RW (0x01 << 30)
	#define TPSAO_AO_SERIAL_DATAMODE_SHIFT 30
	#define TPSAO_AO_SERIAL_DATAMODE_VAL0 0x00
	#define TPSAO_AO_SERIAL_DATAMODE_VAL1 0x01
	/*
	* 0 = The parallel-to-serial converter samples WS on positive edges;of SCK and out
	* puts data on the negative edge of SCK.;1 = The parallel-to-serial converter samp
	* les WS on negative edges;of SCK and outputs data on positive edges of SCK.
	*/
	#define TPSAO_AO_SERIAL_CLOCK_EDGE_RW (0x01 << 29)
	#define TPSAO_AO_SERIAL_CLOCK_EDGE_SHIFT 29
	#define TPSAO_AO_SERIAL_CLOCK_EDGE_VAL0 0x00
	#define TPSAO_AO_SERIAL_CLOCK_EDGE_VAL1 0x01
	/*
	* A read returns 0x0.
	*/
	#define TPSAO_AO_SERIAL_RESERVED_RW (0x01ff << 19)
	#define TPSAO_AO_SERIAL_RESERVED_SHIFT 19
	/*
	* 00 = Only SD[0] is active.;01 = SD[0] and SD[1] are active.;10 = SD[0] ; SD[1]; 
	* and SD[2] are active.;11 = SD[0]; SD[1] ; SD[2] and SD[3] are active.;Each SD ou
	* tput receives either 1 or 2 channels depending on;TRANS_MODE. Non-active channel
	* s receive 0 value samples. In;mono modes; each channel of a SD output receives i
	* dentical left;and right samples.
	*/
	#define TPSAO_AO_SERIAL_NR_CHAN_RW (0x01 << 17)
	#define TPSAO_AO_SERIAL_NR_CHAN_SHIFT 17
	#define TPSAO_AO_SERIAL_NR_CHAN_VAL0 0x00
	#define TPSAO_AO_SERIAL_NR_CHAN_VAL1 0x01
	/*
	* Sets the divider used to derive WS from SCK. Set to 0...511 for a;serial frame l
	* ength of 1...512.;Note the frame size limitations discussed in Section 23.4.6.1 
	* on;page 23-16.
	*/
	#define TPSAO_AO_SERIAL_WSDIV_RW (0x0ff << 8)
	#define TPSAO_AO_SERIAL_WSDIV_SHIFT 8
	/*
	* Sets the divider used to derive SCK from OSCLK. Set to 0...255 for;division by 1
	* ...256.
	*/
	#define TPSAO_AO_SERIAL_SCKDIV_RW (0x0ff << 0)
	#define TPSAO_AO_SERIAL_SCKDIV_SHIFT 0
	/*
	* Control register to configure data framing
	*/
	#define TPSAO_AO_FRAMING_REG  (TPSAO_BASE + 0xc)
	/*
	* 0 = Serial frame starts with a WS negedge.;1 = Serial frame starts with a WS pos
	* edge.;This bit should not be changed during operation of Audio Out i.e.;;only up
	* date this bit when TRANS_ENABLE = 0.
	*/
	#define TPSAO_AO_FRAMING_POLARITY_RW (0x01 << 31)
	#define TPSAO_AO_FRAMING_POLARITY_SHIFT 31
	#define TPSAO_AO_FRAMING_POLARITY_VAL0 0x00
	#define TPSAO_AO_FRAMING_POLARITY_VAL1 0x01
	/*
	* Start/Stop bit position MSB. Note that SSPOS is a 5-bit field; while;bit SSPOS4 
	* is non-adjacent for backwards compatibility in 16-bit/;sample modes. Program thi
	* s field along with AO_FRAMING[3:0].
	*/
	#define TPSAO_AO_FRAMING_SSPOS4_RW (0x01 << 30)
	#define TPSAO_AO_FRAMING_SSPOS4_SHIFT 30
	#define TPSAO_AO_FRAMING_SSPOS4_VAL0 0x00
	#define TPSAO_AO_FRAMING_SSPOS4_VAL1 0x01
	/*
	* A read returns 0x0.
	*/
	#define TPSAO_AO_FRAMING_RESERVED_RW (0x07f << 22)
	#define TPSAO_AO_FRAMING_RESERVED_SHIFT 22
	/*
	* Defines the bit position within a serial frame where the first data bit of the l
	* eft channel is placed. The first bit of a serial frame is bit 0.
	*/
	#define TPSAO_AO_FRAMING_LEFTPOS_RW (0x0ff << 13)
	#define TPSAO_AO_FRAMING_LEFTPOS_SHIFT 13
	/*
	* Defines the bit position within a serial frame where the first data bit of the r
	* ight channel is placed.
	*/
	#define TPSAO_AO_FRAMING_RIGHTPOS_RW (0x0ff << 4)
	#define TPSAO_AO_FRAMING_RIGHTPOS_SHIFT 4
	/*
	* Start/Stop bit position. Note that SSPOS is a 5-bit field; while bit;SSPOS4 is n
	* on-adjacent for backwards compatibility in 16-bit/;sample modes. Program this fi
	* eld along with AO_FRAMING[30].;If DATAMODE = MSB first; transmission starts with
	*  the MSB of the;sample i.e.; bit 15 for 16-bit/sample modes or bit 31 for 32-bit
	* /;sample modes. SSPOS determines the bit index (0..31) in the;parallel input wor
	* d of the last transmitted data bit.;If DATAMODE = LSB first; SSPOS determines th
	* e bit index (0..31);in the parallel word of the first transmitted data bit. Bits
	*  SSPOS up to;and including the MSB are transmitted i.e.; up to bit 15 in 16-bit/
	* ;sample mode and bit 31 in 32-bit/sample mode.
	*/
	#define TPSAO_AO_FRAMING_SSPOS_RW (0x0f << 0)
	#define TPSAO_AO_FRAMING_SSPOS_SHIFT 0
	#define TPSAO_AO_FRAMING_SSPOS_VAL0 0x00
	#define TPSAO_AO_FRAMING_SSPOS_VAL1 0x01
	#define TPSAO_AO_FRAMING_SSPOS_VAL2 0x02
	#define TPSAO_AO_FRAMING_SSPOS_VAL3 0x03
	#define TPSAO_AO_FRAMING_SSPOS_VAL4 0x04
	#define TPSAO_AO_FRAMING_SSPOS_VAL5 0x05
	#define TPSAO_AO_FRAMING_SSPOS_VAL6 0x06
	#define TPSAO_AO_FRAMING_SSPOS_VAL7 0x07
	#define TPSAO_AO_FRAMING_SSPOS_VAL8 0x08
	#define TPSAO_AO_FRAMING_SSPOS_VAL9 0x09
	#define TPSAO_AO_FRAMING_SSPOS_VAL10 0x0a
	#define TPSAO_AO_FRAMING_SSPOS_VAL11 0x0b
	#define TPSAO_AO_FRAMING_SSPOS_VAL12 0x0c
	#define TPSAO_AO_FRAMING_SSPOS_VAL13 0x0d
	#define TPSAO_AO_FRAMING_SSPOS_VAL14 0x0e
	#define TPSAO_AO_FRAMING_SSPOS_VAL15 0x0f
	/*
	* Base address of DMA buffer 1 in memory
	*/
	#define TPSAO_AO_BASE1_REG  (TPSAO_BASE + 0x14)
	/*
	* Base Address of DMA buffer1 in memory - must be a 64-byte aligned address in loc
	* al memory.
	*/
	#define TPSAO_AO_BASE1_BASE1_RW (0x01ffffff << 6)
	#define TPSAO_AO_BASE1_BASE1_SHIFT 6
	/*
	* A read returns 0x0.
	*/
	#define TPSAO_AO_BASE1_RESERVED_RW (0x03f << 0)
	#define TPSAO_AO_BASE1_RESERVED_SHIFT 0
	/*
	* Base address of DMA buffer 2 in memory
	*/
	#define TPSAO_AO_BASE2_REG  (TPSAO_BASE + 0x18)
	/*
	* Base Address of DMA buffer2 in memory - must be a 64-byte aligned address in loc
	* al memory.
	*/
	#define TPSAO_AO_BASE2_BASE2_RW (0x01ffffff << 6)
	#define TPSAO_AO_BASE2_BASE2_SHIFT 6
	/*
	* A read returns 0x0.
	*/
	#define TPSAO_AO_BASE2_RESERVED_RW (0x03f << 0)
	#define TPSAO_AO_BASE2_RESERVED_SHIFT 0
	/*
	* The DMA Buffer size in samples
	*/
	#define TPSAO_AO_SIZE_REG  (TPSAO_BASE + 0x1c)
	/*
	* DMA buffer size in samples. The number of mono samples or stereo;sample pairs is
	*  read from a DMA buffer in memory before switching;to the other DMA buffer in me
	* mory. Buffer size in bytes is as follows:;16 bps; mono: 2 * SIZE;32 bps; mono: 4
	*  * SIZE;16 bps; stereo: 4 * SIZE;32 bps; stereo: 8 * SIZE;The contents of the SI
	* ZE register is evaluated when a full buffer is acknowledged by AO_CTL.ACKx . It 
	* is valid for next buffer pending to be filled.
	*/
	#define TPSAO_AO_SIZE_SIZE_RW (0x01ffffff << 6)
	#define TPSAO_AO_SIZE_SIZE_SHIFT 6
	/*
	* A read returns 0x0.
	*/
	#define TPSAO_AO_SIZE_RESERVED_RW (0x03f << 0)
	#define TPSAO_AO_SIZE_RESERVED_SHIFT 0
	/*
	* A read returns 0x0.
	*/
	#define TPSAO_AO_CC_REG  (TPSAO_BASE + 0x20)
	/*
	* The 16-bit value of CC1 is shifted into each emitted serial frame starting at bi
	* t position CC1_POS; as long as CC1_EN is asserted.
	*/
	#define TPSAO_AO_CC_CC1_RW (0x07fff << 16)
	#define TPSAO_AO_CC_CC1_SHIFT 16
	/*
	* The 16-bit value of CC2 is shifted into each emitted serial frame starting at bi
	* t position CC2_POS; as long as CC2_EN is asserted.
	*/
	#define TPSAO_AO_CC_CC2_RW (0x0ffff << 0)
	#define TPSAO_AO_CC_CC2_SHIFT 0
	/*
	* Codec data position
	*/
	#define TPSAO_AO_CFC_REG  (TPSAO_BASE + 0x24)
	/*
	* A read returns 0x0.
	*/
	#define TPSAO_AO_CFC_RESERVED_RW (0x01fff << 18)
	#define TPSAO_AO_CFC_RESERVED_SHIFT 18
	/*
	* Defines the bit position within a serial frame where the first data bit of CC1 i
	* s placed. It is not allowed to program 0x0 or 0x20 into;CC1_POS
	*/
	#define TPSAO_AO_CFC_CC1_POS_RW (0x07f << 10)
	#define TPSAO_AO_CFC_CC1_POS_SHIFT 10
	/*
	* Defines the bit position within a serial frame where the first data bit of CC2 i
	* s placed. It is not allowed to program 0x0 or 0x20 into;CC2_POS
	*/
	#define TPSAO_AO_CFC_CC2_POS_RW (0x03ff << 0)
	#define TPSAO_AO_CFC_CC2_POS_SHIFT 0
	/*
	* Content Protection; write only
	*/
	#define TPSAO_AO_CPR_REG  (TPSAO_BASE + 0x70)
	/*
	* A read returns 0x0.
	*/
	#define TPSAO_AO_CPR_RESERVED_W (0x01fffff << 10)
	#define TPSAO_AO_CPR_RESERVED_SHIFT 10
	/*
	* Protected encoded content; a read returns 0x0; 0 = non protected content; 1 = pr
	* otected encoded content.
	*/
	#define TPSAO_AO_CPR_PEC_W (0x01 << 9)
	#define TPSAO_AO_CPR_PEC_SHIFT 9
	#define TPSAO_AO_CPR_PEC_VAL0 0x00
	#define TPSAO_AO_CPR_PEC_VAL1 0x01
	/*
	* Protected decoded content; a read returns 0x0; 0 = non protected content; 1 = pr
	* otected decoded content.
	*/
	#define TPSAO_AO_CPR_PDC_W (0x01 << 8)
	#define TPSAO_AO_CPR_PDC_SHIFT 8
	#define TPSAO_AO_CPR_PDC_VAL0 0x00
	#define TPSAO_AO_CPR_PDC_VAL1 0x01
	/*
	* Content ID;write only; a read returns 0x00.
	*/
	#define TPSAO_AO_CPR_CONT_ID_W (0x0ff << 0)
	#define TPSAO_AO_CPR_CONT_ID_SHIFT 0
	/*
	* Powerdown function
	*/
	#define TPSAO_AO_PWR_DWN_REG  (TPSAO_BASE + 0xff4)
	/*
	* A read returns 0x0.
	*/
	#define TPSAO_AO_PWR_DWN_RESERVED_RW (0x03fffffff << 1)
	#define TPSAO_AO_PWR_DWN_RESERVED_SHIFT 1
	/*
	* The bit is used to provide power control status for system software block power 
	* management.
	*/
	#define TPSAO_AO_PWR_DWN_PWR_DWN_RW (0x01 << 0)
	#define TPSAO_AO_PWR_DWN_PWR_DWN_SHIFT 0
	#define TPSAO_AO_PWR_DWN_PWR_DWN_VAL0 0x00
	#define TPSAO_AO_PWR_DWN_PWR_DWN_VAL1 0x01
	/*
	* Provides module ID number; including major and minor revision levels.
	*/
	#define TPSAO_AO_MODULE_ID_REG  (TPSAO_BASE + 0xffc)
	/*
	* Module ID. This field identifies the block as type Audio Out.
	*/
	#define TPSAO_AO_MODULE_ID_ID_R (0x07fff << 16)
	#define TPSAO_AO_MODULE_ID_ID_SHIFT 16
	/*
	* Major Revision ID. This field is incremented by 1 when changes introduced in the
	*  block result in software incompatibility with the previous version of the block
	* . First version default = 0.
	*/
	#define TPSAO_AO_MODULE_ID_MAJ_REV_R (0x07 << 12)
	#define TPSAO_AO_MODULE_ID_MAJ_REV_SHIFT 12
	#define TPSAO_AO_MODULE_ID_MAJ_REV_VAL0 0x00
	#define TPSAO_AO_MODULE_ID_MAJ_REV_VAL1 0x01
	#define TPSAO_AO_MODULE_ID_MAJ_REV_VAL2 0x02
	#define TPSAO_AO_MODULE_ID_MAJ_REV_VAL3 0x03
	#define TPSAO_AO_MODULE_ID_MAJ_REV_VAL4 0x04
	#define TPSAO_AO_MODULE_ID_MAJ_REV_VAL5 0x05
	#define TPSAO_AO_MODULE_ID_MAJ_REV_VAL6 0x06
	#define TPSAO_AO_MODULE_ID_MAJ_REV_VAL7 0x07
	/*
	* Minor Revision ID. This field is incremented by 1 when changes introduced in the
	*  block result in software compatibility with the previous version of the block. 
	* First version default = 0.
	*/
	#define TPSAO_AO_MODULE_ID_MIN_REV_R (0x07 << 8)
	#define TPSAO_AO_MODULE_ID_MIN_REV_SHIFT 8
	#define TPSAO_AO_MODULE_ID_MIN_REV_VAL0 0x00
	#define TPSAO_AO_MODULE_ID_MIN_REV_VAL1 0x01
	#define TPSAO_AO_MODULE_ID_MIN_REV_VAL2 0x02
	#define TPSAO_AO_MODULE_ID_MIN_REV_VAL3 0x03
	#define TPSAO_AO_MODULE_ID_MIN_REV_VAL4 0x04
	#define TPSAO_AO_MODULE_ID_MIN_REV_VAL5 0x05
	#define TPSAO_AO_MODULE_ID_MIN_REV_VAL6 0x06
	#define TPSAO_AO_MODULE_ID_MIN_REV_VAL7 0x07
	/*
	* Aperture size. Identifies the MMIO aperture size in units of 4 kB for the AO blo
	* ck. AO has an MMIO aperture size of 4 kB. Aperture = 0: 4 kB.
	*/
	#define TPSAO_AO_MODULE_ID_APERTURE_R (0x0ff << 0)
	#define TPSAO_AO_MODULE_ID_APERTURE_SHIFT 0

#endif // PHMODIPTPSAO_H
