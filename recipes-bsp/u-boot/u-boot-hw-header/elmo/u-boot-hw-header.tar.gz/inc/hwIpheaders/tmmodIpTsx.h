/****************************************************************************/
/* CONEXANT PROPRIETARY AND CONFIDENTIAL                                    */
/* SOFTWARE FILE/MODULE HEADER                                              */
/* Conexant Systems Inc. (c) 2006-2007                                      */
/* Austin, TX                                                               */
/* All Rights Reserved                                                      */
/****************************************************************************/
/*
* Filename: tmmodIpTsx.h
*
*
* Description: Public header file defining hardware-specific values
* (such as register addresses, bit definitions, etc.) for transport
* stream crossbar module
*
* Author: Srinivasan Venkataraman
*
****************************************************************************/
/* $Id: tmmodIpTsx.h 104206 2009-07-16 21:31:05Z venkatas $
****************************************************************************/

#ifndef _TMMODIPTSX_H_
#define _TMMODIPTSX_H_

#define TSX_HSDP_PORT_CTRL_REG(x)  (TSX_HSDP_PORT_CTRL_BASE  + ((x) * TSX_HSDP_BANK_SIZE))
#define     TSX_HSDP_PORT_ENABLE_MASK                          0x00000001
#define     TSX_HSDP_PORT_ENABLE_SHIFT                         0
#define         TSX_HSDP_PORT_ENABLE                           (1UL<<0)
#define         TSX_HSDP_PORT_DISABLE                          (0UL<<0)
#define     TSX_HSDP_PORT_DIRECTION_MASK                       0x00000002
#define     TSX_HSDP_PORT_DIRECTION_SHIFT                      1
#define         TSX_HSDP_PORT_DIRECTION_INPUT                  (0UL<<1)
#define         TSX_HSDP_PORT_DIRECTION_OUTPUT                 (1UL<<1)
#define     TSX_HSDP_CLOCK_DIRECTION_MASK                      0x00000004
#define     TSX_HSDP_CLOCK_DIRECTION_SHIFT                     2
#define         TSX_HSDP_CLOCK_DIRECTION_INPUT                 (0UL<<2)
#define         TSX_HSDP_CLOCK_DIRECTION_OUTPUT                (1UL<<2)
#define     TSX_HSDP_CLOCK_POLARITY_MASK                       0x00000008
#define     TSX_HSDP_CLOCK_POLARITY_SHIFT                      3
#define         TSX_HSDP_CLOCK_POLARITY_RISING                 (0UL<<3)
#define         TSX_HSDP_CLOCK_POLARITY_FALLING                (1UL<<3)
#define     TSX_HSDP_CLOCK_GAP_MASK                            0x00000080
#define     TSX_HSDP_CLOCK_GAP_SHIFT                           7
#define         TSX_HSDP_CLOCK_GAP_DATAVALID                   (0UL<<7)
#define         TSX_HSDP_CLOCK_GAP_CLOCK                       (1UL<<7)
#define     TSX_HSDP_SYNC_POLARITY_MASK                        0x00000100
#define     TSX_HSDP_SYNC_POLARITY_SHIFT                       8
#define         TSX_HSDP_SYNC_POLARITY_HIGH                    (0UL<<8)
#define         TSX_HSDP_SYNC_POLARITY_LOW                     (1UL<<8)
#define     TSX_HSDP_SYNC_WIDTH_MASK                           0x00000200
#define     TSX_HSDP_SYNC_WIDTH_SHIFT                          9
#define         TSX_HSDP_SYNC_WIDTH_BIT                        (0UL<<9)
#define         TSX_HSDP_SYNC_WIDTH_BYTE                       (1UL<<9)
#define     TSX_HSDP_SYNC_SOURCE_MASK                          0x00000C00
#define     TSX_HSDP_SYNC_SOURCE_SHIFT                         10
#define         TSX_HSDP_SYNC_SOURCE_SYNCLEAD                  (0UL<<10)
#define         TSX_HSDP_SYNC_SOURCE_SYNCLEVEL                 (1UL<<10)
#define         TSX_HSDP_SYNC_SOURCE_DVLEAD                    (2UL<<10)
#define         TSX_HSDP_SYNC_SOURCE_SYNCDVLEV                 (3UL<<10)
#define     TSX_HSDP_DATAVALID_POLARITY_MASK                   0x00001000
#define     TSX_HSDP_DATAVALID_POLARITY_SHIFT                  12
#define         TSX_HSDP_DATAVALID_POLARITY_HIGH                (0UL<<12)
#define         TSX_HSDP_DATAVALID_POLARITY_LOW                (1UL<<12)
#define     TSX_HSDP_DATAVALID_WIDTH_MASK                      0x00002000
#define     TSX_HSDP_DATAVALID_WIDTH_SHIFT                     13
#define         TSX_HSDP_DATAVALID_WIDTH_FIRST                 (0UL<<13)
#define         TSX_HSDP_DATAVALID_WIDTH_EVERY                 (1UL<<13)
#define     TSX_HSDP_DATAVALID_FUNC_MASK                       0x0000C000
#define     TSX_HSDP_DATAVALID_FUNC_SHIFT                      14
#define         TSX_HSDP_DATAVALID_FUNC_DATAVALID              (0UL<<14)
#define         TSX_HSDP_DATAVALID_FUNC_DATAENA                (1UL<<14)
#define         TSX_HSDP_DATAVALID_FUNC_DEASSERT               (2UL<<14)
#define         TSX_HSDP_DATAVALID_FUNC_ASSERT                 (3UL<<14)
#define     TSX_HSDP_ERRFAIL_POLARITY_MASK                     0x00010000
#define     TSX_HSDP_ERRFAIL_POLARITY_SHIFT                    16
#define         TSX_HSDP_ERRFAIL_POLARITY_HIGH                 (0UL<<16)
#define         TSX_HSDP_ERRFAIL_POLARITY_LOW                  (1UL<<16)
#define     TSX_HSDP_ERRFAIL_PASSTHRU_MASK                     0x00020000
#define     TSX_HSDP_ERRFAIL_PASSTRHU_SHIFT                    17
#define         TSX_HSDP_ERRFAIL_PASSTHRU_SYNC                 (0UL<<17)
#define         TSX_HSDP_ERRFAIL_PASSTHRU_PASS                 (1UL<<17)
#define     TSX_HSDP_ERRFAIL_FUNC_MASK                         0x000C0000
#define     TSX_HSDP_ERRFAIL_FUNC_SHIFT                        18
#define         TSX_HSDP_ERRFAIL_FUNC_ERRFAIL                  (0UL<<18)
#define         TSX_HSDP_ERRFAIL_FUNC_DATA                     (1UL<<18)
#define         TSX_HSDP_ERRFAIL_FUNC_DEASSERT                 (2UL<<18)
#define         TSX_HSDP_ERRFAIL_FUNC_ASSERT                   (3UL<<18)
#define     TSX_HSDP_ERRFAIL_WIDTH_MASK                        0x00300000
#define     TSX_HSDP_ERRFAIL_WIDTH_SHIFT                       20
#define         TSX_HSDP_ERRFAIL_WIDTH_BYTE                    (0UL<<20)
#define         TSX_HSDP_ERRFAIL_WIDTH_BIT                     (1UL<<20)
#define         TSX_HSDP_ERRFAIL_WIDTH_PACKET                  (2UL<<20)
#define     TSX_HSDP_SER_CONVERSION_MASK                       0x00400000
#define     TSX_HSDP_SER_CONVERSION_SHIFT                      22
#define         TSX_HSDP_SER_CONVERSION_PAR                    (0UL<<22)
#define         TSX_HSDP_SER_CONVERSION_SER2PAR                (1UL<<22)
#define     TSX_HSDP_RW_POLARITY_MASK                          0x00800000
#define     TSX_HSDP_RW_POLARITY_SHIFT                         23
#define         TSX_HSDP_RW_POLARITY_HIGH                      (0UL<<23)
#define         TSX_HSDP_RW_POLARITY_LOW                       (1UL<<23)

#define TSX_HSDP_PACKET_CTRL_REG(x)  (TSX_HSDP_PACKET_CTRL_BASE + ((x) * TSX_HSDP_BANK_SIZE))
#define     TSX_HSDP_PACKET_LENGTH_MASK                        0x000000FF
#define     TSX_HSDP_PACKET_LENGTH_SHIFT                       0
#define     TSX_HSDP_PACKET_THRESHOLD_MASK                     0x0000FF00
#define     TSX_HSDP_PACKET_THRESHOLD_SHIFT                    8
#define     TSX_HSDP_PACKET_SYNCBYTE_MASK                      0x00FF0000
#define     TSX_HSDP_PACKET_SYNCBYTE_SHIFT                     16
#define     TSX_HSDP_PACKET_DSSMODE_MASK                       0x01000000
#define     TSX_HSDP_PACKET_DSSMODE_SHIFT                      24
#define         TSX_HSDP_PACKET_DSSMODE_MPEG                   (0UL<<24)
#define         TSX_HSDP_PACKET_DSSMODE_DSS                    (1UL<<24)
#define     TSX_HSDP_PACKET_MODE_MASK                          0x02000000
#define     TSX_HSDP_PACKET_MODE_SHIFT                         25
#define         TSX_HSDP_PACKET_THRESHOLD_DIS                  (0UL<<25)
#define         TSX_HSDP_PACKET_THRESHOLD_ENA                  (1UL<<25)
#define     TSX_HSDP_PACKET_SPLICE_MASK                        0x04000000
#define     TSX_HSDP_PACKET_SPLICE_SHIFT                       26
#define         TSX_HSDP_PACKET_SPLICE_NO                      (0UL<<26)
#define         TSX_HSDP_PACKET_SPLICE_YES                     (1UL<<26)
#define     TSX_HSDP_PACKET_GAP_MASK                           0x08000000
#define     TSX_HSDP_PACKET_GAP_SHIFT                          27
#define         TSX_HSDP_PACKET_GAP_NONE                       (0UL<<27)
#define         TSX_HSDP_PACKET_GAP_INSERT                     (1UL<<27)

#define TSX_HSDP_MUX_CTRL_REG(x)     (TSX_HSDP_MUX_CTRL_BASE + ((x) * TSX_HSDP_BANK_SIZE))
#define     TSX_HSDP_MUX_DATA_GROUP_MASK                       0x00000003
#define     TSX_HSDP_MUX_DATA_GROUP_SHIFT                      0
#define         TSX_HSDP_MUX_DATA_GROUP_HSDP                   (1UL<<0)
#define         TSX_HSDP_MUX_DATA_GROUP_TSP                    (2UL<<0)
#define     TSX_HSDP_MUX_DATA_SOURCE_MASK                      0x000000F0
#define     TSX_HSDP_MUX_DATA_SOURCE_SHIFT                     4

#define TSX_HSDP_CLOCK_CTRL_REG(x)   (TSX_HSDP_CLOCK_CTRL_BASE  + ((x) * TSX_HSDP_BANK_SIZE))
#define     TSX_HSDP_CLOCK_DELAY_MASK                          0x00070000
#define     TSX_HSDP_CLOCK_DELAY_SHIFT                         16
#define     TSX_HSDP_CLOCK_DELAYENABLE_MASK                    0x00080000
#define     TSX_HSDP_CLOCK_DELAYENABLE_SHIFT                   19
#define         TSX_HSDP_CLOCK_DELAY_ENABLE                    (1UL<<19)
#define         TSX_HSDP_CLOCK_DELAY_DISABLE                   (0UL<<19)
#define     TSX_HSDP_CLOCK_ADVANCE_MASK                        0x00100000
#define     TSX_HSDP_CLOCK_ADVANCE_SHIFT                       20
#define         TSX_HSDP_CLOCK_ADVANCE_ENABLE                  (1UL<<20)
#define         TSX_HSDP_CLOCK_ADVANCE_DISABLE                 (0UL<<20)

#define TSX_HSDP_PORT_STS_REG(x)     (TSX_HSDP_PORT_STS_BASE  + ((x) * TSX_HSDP_BANK_SIZE))
#define     TSX_HSDP_PORT_STATUS_INSYNC_MASK                   0x00000001
#define     TSX_HSDP_PORT_STATUS_INSYNC_SHIFT                  0
#define     TSX_HSDP_PORT_STATUS_SYNCLOST_MASK                 0x00000002
#define     TSX_HSDP_PORT_STATUS_SYNCLOST_SHIFT                1
#define     TSX_HSDP_PORT_STATUS_ERRFAIL_MASK                  0x00000004
#define     TSX_HSDP_PORT_STATUS_ERRFAIL_SHIFT                 2
#define     TSX_HSDP_PORT_STATUS_SPLICEDONE_MASK               0x00000008
#define     TSX_HSDP_PORT_STATUS_SPLICEDONE_SHIFT              3
#define     TSX_HSDP_PORT_STATUS_FIFO_OVERRUN_MASK             0x00000010
#define     TSX_HSDP_PORT_STATUS_FIFO_OVERRUN_SHIFT            4
#define     TSX_HSDP_PORT_STATUS_FIFO_UNDERRUN_MASK            0x00000020
#define     TSX_HSDP_PORT_STATUS_FIFO_UNDERRUN_SHIFT           5
#define     TSX_HSDP_PORT_STATUS_INPUT_VALID_MASK              0x00000040
#define     TSX_HSDP_PORT_STATUS_INPUT_VALID_SHIFT             6
#define     TSX_HSDP_PORT_STATUS_FIFO_FULL_MASK                0x00000080
#define     TSX_HSDP_PORT_STATUS_FIFO_FULL_SHIFT               7
#define     TSX_HSDP_PORT_STATUS_CLOCK_DETECTED_MASK           0x00000100
#define     TSX_HSDP_PORT_STATUS_CLOCK_DETECTED_SHIFT          8
#define     TSX_HSDP_PORT_STATUS_CLOCK_LOST_MASK               0x00000200
#define     TSX_HSDP_PORT_STATUS_CLOCK_LOST_SHIFT              9

#define TSX_HSDP_INTR_ENA_REG(x)     (TSX_HSDP_INTR_ENA_BASE  + ((x) * TSX_HSDP_BANK_SIZE))
#define     TSX_HSDP_INTR_ENA_INSYNC_MASK                      0x00000001
#define     TSX_HSDP_INTR_ENA_INSYNC_SHIFT                     0
#define     TSX_HSDP_INTR_ENA_SYNCLOST_MASK                    0x00000002
#define     TSX_HSDP_INTR_ENA_SYNCLOST_SHIFT                   1
#define     TSX_HSDP_INTR_ENA_ERRFAIL_MASK                     0x00000004
#define     TSX_HSDP_INTR_ENA_ERRFAIL_SHIFT                    2
#define     TSX_HSDP_INTR_ENA_SPLICEDONE_MASK                  0x00000008
#define     TSX_HSDP_INTR_ENA_SPLICEDONE_SHIFT                 3
#define     TSX_HSDP_INTR_ENA_FIFO_OVERRUN_MASK                0x00000010
#define     TSX_HSDP_INTR_ENA_FIFO_OVERRUN_SHIFT               4
#define     TSX_HSDP_INTR_ENA_FIFO_UNDERRUN_MASK               0x00000020
#define     TSX_HSDP_INTR_ENA_FIFO_UNDERRUN_SHIFT              5
#define     TSX_HSDP_INTR_ENA_INPUT_VALID_MASK                 0x00000040
#define     TSX_HSDP_INTR_ENA_INPUT_VALID_SHIFT                6
#define     TSX_HSDP_INTR_ENA_FIFO_FULL_MASK                   0x00000080
#define     TSX_HSDP_INTR_ENA_FIFO_FULL_SHIFT                  7
#define     TSX_HSDP_INTR_ENA_CLOCK_DETECTED_MASK              0x00000100
#define     TSX_HSDP_INTR_ENA_CLOCK_DETECTED_SHIFT             8
#define     TSX_HSDP_INTR_ENA_CLOCK_LOST_MASK                  0x00000200
#define     TSX_HSDP_INTR_ENA_CLOCK_LOST_SHIFT                 9

#define TSX_HSDP_FIFO_STATUS_REG(x)     (TSX_HSDP_FIFO_STATUS_BASE + ((x) * TSX_HSDP_BANK_SIZE))
#define     TSX_HSDP_FIFO_BYTES_FREE_MASK                      0x0000FFFF
#define     TSX_HSDP_FIFO_BYTES_FREE_SHIFT                     0


/* TSX TSP input registers */
#define TSX_TSP_IN_PORT_CTRL_BASE       (TSX_TSP_IN_BASE + 0x00)
#define TSX_TSP_IN_PACKET_CTRL_BASE     (TSX_TSP_IN_BASE + 0x04)
#define TSX_TSP_IN_PORT_STS_BASE        (TSX_TSP_IN_BASE + 0x10)
#define TSX_TSP_IN_INTR_ENA_BASE        (TSX_TSP_IN_BASE + 0x14)

#define TSX_TSP_IN_PORT_CTRL_REG(x)     (TSX_TSP_IN_PORT_CTRL_BASE + ((x) * TSX_TSP_IN_BANK_SIZE))
#define     TSX_TSP_IN_PORT_ENABLE_MASK                        0x00000001
#define     TSX_TSP_IN_PORT_ENABLE_SHIFT                       0
#define         TSX_TSP_IN_PORT_ENABLE                         (1UL<<0)
#define         TSX_TSP_IN_PORT_DISABLE                        (0UL<<0)
#define     TSX_TSP_IN_SYNC_SOURCE_MASK                        0x00000C00
#define     TSX_TSP_IN_SYNC_SOURCE_SHIFT                       10
#define         TSX_TSP_IN_SYNC_SOURCE_SYNCLEAD                (0UL<<10)
#define         TSX_TSP_IN_SYNC_SOURCE_SYNCLEVEL               (1UL<<10)
#define         TSX_TSP_IN_SYNC_SOURCE_SYNCDATA                (2UL<<10)
#define     TSX_TSP_IN_ERRFAIL_PASSTHRU_MASK                   0x00020000
#define     TSX_TSP_IN_ERRFAIL_PASSTRHU_SHIFT                  17
#define         TSX_TSP_IN_ERRFAIL_PASSTHRU_SYNC               (0UL<<17)
#define         TSX_TSP_IN_ERRFAIL_PASSTHRU_PASS               (1UL<<17)
#define     TSX_TSP_IN_ERRFAIL_FUNC_MASK                       0x000C0000
#define     TSX_TSP_IN_ERRFAIL_FUNC_SHIFT                      18
#define         TSX_TSP_IN_ERRFAIL_FUNC_ERRFAIL                (0UL<<18)
#define         TSX_TSP_IN_ERRFAIL_FUNC_IGNORE                 (2UL<<18)

#define TSX_TSP_IN_PACKET_CTRL_REG(x)   (TSX_TSP_IN_PACKET_CTRL_BASE + ((x) * TSX_TSP_IN_BANK_SIZE))
#define     TSX_TSP_IN_PACKET_LENGTH_MASK                      0x000000FF
#define     TSX_TSP_IN_PACKET_LENGTH_SHIFT                     0
#define     TSX_TSP_IN_PACKET_SYNCBYTE_MASK                    0x00FF0000
#define     TSX_TSP_IN_PACKET_SYNCBYTE_SHIFT                   16
#define     TSX_TSP_IN_PACKET_DSSMODE_MASK                     0x01000000
#define     TSX_TSP_IN_PACKET_DSSMODE_SHIFT                    24
#define         TSX_TSP_IN_PACKET_DSSMODE_MPEG                 (0UL<<24)
#define         TSX_TSP_IN_PACKET_DSSMODE_DSS                  (1UL<<24)

#define TSX_TSP_IN_PORT_STS_REG(x)      (TSX_TSP_IN_PORT_STS_BASE + ((x) * TSX_TSP_IN_BANK_SIZE))
#define     TSX_TSP_IN_PORT_STATUS_INSYNC_MASK                 0x00000001
#define     TSX_TSP_IN_PORT_STATUS_INSYNC_SHIFT                0
#define     TSX_TSP_IN_PORT_STATUS_SYNCLOST_MASK               0x00000002
#define     TSX_TSP_IN_PORT_STATUS_SYNCLOST_SHIFT              1
#define     TSX_TSP_IN_PORT_STATUS_ERRFAIL_MASK                0x00000004
#define     TSX_TSP_IN_PORT_STATUS_ERRFAIL_SHIFT               2

#define TSX_TSP_IN_INTR_ENA_REG(x)      (TSX_TSP_IN_INTR_ENA_BASE + ((x) * TSX_TSP_IN_BANK_SIZE))
#define     TSX_TSP_IN_INTR_ENA_INSYNC_MASK                    0x00000001
#define     TSX_TSP_IN_INTR_ENA_INSYNC_SHIFT                   0
#define     TSX_TSP_IN_INTR_ENA_SYNCLOST_MASK                  0x00000002
#define     TSX_TSP_IN_INTR_ENA_SYNCLOST_SHIFT                 1
#define     TSX_TSP_IN_INTR_ENA_ERRFAIL_MASK                   0x00000004
#define     TSX_TSP_IN_INTR_ENA_ERRFAIL_SHIFT                  2

/* TSX TSP output registers */
#define TSX_TSP_OUT_PORT_CTRL_BASE      (TSX_TSP_OUT_BASE + 0x00)
#define TSX_TSP_OUT_MUX_CTRL_BASE       (TSX_TSP_OUT_BASE + 0x08)

#define TSX_TSP_OUT_PORT_CTRL_REG(x)    (TSX_TSP_OUT_PORT_CTRL_BASE + ((x) * TSX_TSP_OUT_BANK_SIZE))
#define     TSX_TSP_OUT_PORT_ENABLE_MASK                       0x00000001
#define     TSX_TSP_OUT_PORT_ENABLE_SHIFT                      0
#define         TSX_TSP_OUT_PORT_ENABLE                        (1UL<<0)
#define         TSX_TSP_OUT_PORT_DISABLE                       (0UL<<0)
#define     TSX_TSP_OUT_ERRFAIL_PASSTHRU_MASK                  0x00020000
#define     TSX_TSP_OUT_ERRFAIL_PASSTRHU_SHIFT                 17
#define         TSX_TSP_OUT_ERRFAIL_PASSTHRU_SYNC              (0UL<<17)
#define         TSX_TSP_OUT_ERRFAIL_PASSTHRU_PASS              (1UL<<17)
#define     TSX_TSP_OUT_ERRFAIL_FUNC_MASK                      0x000C0000
#define     TSX_TSP_OUT_ERRFAIL_FUNC_SHIFT                     18
#define         TSX_TSP_OUT_ERRFAIL_FUNC_ERRFAIL               (0UL<<18)
#define         TSX_TSP_OUT_ERRFAIL_FUNC_DEASSERT              (2UL<<18)
#define         TSX_TSP_OUT_ERRFAIL_FUNC_ASSERT                (3UL<<18)
#define     TSX_TSP_OUT_ERRFAIL_WIDTH_MASK                     0x00300000
#define     TSX_TSP_OUT_ERRFAIL_WIDTH_SHIFT                    20
#define         TSX_TSP_OUT_ERRFAIL_WIDTH_BYTE                 (0UL<<20)
#define         TSX_TSP_OUT_ERRFAIL_WIDTH_PACKET               (2UL<<20)

#define TSX_TSP_OUT_MUX_CTRL_REG(x)     (TSX_TSP_OUT_MUX_CTRL_BASE + ((x) * TSX_TSP_OUT_BANK_SIZE))
#define     TSX_TSP_OUT_MUX_DATA_SOURCE_MASK                   0x000000F0
#define     TSX_TSP_OUT_MUX_DATA_SOURCE_SHIFT                  4

/* TSX IMP registers */
#define TSX_IMP_MUX_CTRL_BASE           (TSX_IMP_BASE + 0x08)

#define TSX_IMP_MUX_CTRL_REG(x)         (TSX_IMP_MUX_CTRL_BASE + ((x) * TSX_IMP_BANK_SIZE))
#define     TSX_IMP_MUX_DATA_SOURCE_MASK                       0x000000F0
#define     TSX_IMP_MUX_DATA_SOURCE_SHIFT                      4

/* common registers */
#define TSX_INTR_STATUS_REG             (TSX_COMMON_BASE + 0x00)
#define     TSX_INTR_STATUS_HSDP_MASK                          0x000003FF
#define     TSX_INTR_STATUS_HSDP_SHIFT                         0
#define     TSX_INTR_STATUS_HSDP0_MASK                         0x00000001
#define     TSX_INTR_STATUS_HSDP0_SHIFT                        0
#define     TSX_INTR_STATUS_HSDP1_MASK                         0x00000002
#define     TSX_INTR_STATUS_HSDP1_SHIFT                        1
#define     TSX_INTR_STATUS_HSDP2_MASK                         0x00000004
#define     TSX_INTR_STATUS_HSDP2_SHIFT                        2
#define     TSX_INTR_STATUS_HSDP3_MASK                         0x00000008
#define     TSX_INTR_STATUS_HSDP3_SHIFT                        3
#define     TSX_INTR_STATUS_HSDP4_MASK                         0x00000010
#define     TSX_INTR_STATUS_HSDP4_SHIFT                        4
#define     TSX_INTR_STATUS_HSDP5_MASK                         0x00000020
#define     TSX_INTR_STATUS_HSDP5_SHIFT                        5
#define     TSX_INTR_STATUS_HSDP6_MASK                         0x00000040
#define     TSX_INTR_STATUS_HSDP6_SHIFT                        6
#define     TSX_INTR_STATUS_HSDP7_MASK                         0x00000080
#define     TSX_INTR_STATUS_HSDP7_SHIFT                        7
#define     TSX_INTR_STATUS_HSDP8_MASK                         0x00000100
#define     TSX_INTR_STATUS_HSDP8_SHIFT                        8
#define     TSX_INTR_STATUS_HSDP9_MASK                         0x00000200
#define     TSX_INTR_STATUS_HSDP9_SHIFT                        9
#define     TSX_INTR_STATUS_TSP_MASK                           0x00070000
#define     TSX_INTR_STATUS_TSP_SHIFT                          16
#define     TSX_INTR_STATUS_TSP_IN0_MASK                       0x00010000
#define     TSX_INTR_STATUS_TSP_IN0_SHIFT                      16
#define     TSX_INTR_STATUS_TSP_IN1_MASK                       0x00020000
#define     TSX_INTR_STATUS_TSP_IN1_SHIFT                      17
#define     TSX_INTR_STATUS_TSP_IN2_MASK                       0x00040000
#define     TSX_INTR_STATUS_TSP_IN2_SHIFT                      18

#endif /* _TMMODIPTSP_H_ */

/*******************************************************************************
 * Modifications:
 * $Log$
 *
 ******************************************************************************/

