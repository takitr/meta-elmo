/*-------------------------------------------------------------------------*/
/* Copyright 2011 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef PHMODIPGLOBALREG_H
#define PHMODIPGLOBALREG_H
   
   /*
   * Malone Main Control Register
   */
   #define GLOBALREG_A926_MAIN_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x80)
   /*
   * Reserved
   */
   #define GLOBALREG_A926_MAIN_CTRL_RESERVED_RW (0x0fff << 20)
   #define GLOBALREG_A926_MAIN_CTRL_RESERVED_SHIFT 20
   #define GLOBALREG_A926_MAIN_CTRL_FMVD_CLK_CTRL_RW (0x01f << 15)
   #define GLOBALREG_A926_MAIN_CTRL_FMVD_CLK_CTRL_SHIFT 15
   #define GLOBALREG_A926_MAIN_CTRL_GLBREG_REMAP_VECTOR_EN_RW (0x01 << 14)
   #define GLOBALREG_A926_MAIN_CTRL_GLBREG_REMAP_VECTOR_EN_SHIFT 14
   #define GLOBALREG_A926_MAIN_CTRL_RESERVED3_RW (0x01 << 13)
   #define GLOBALREG_A926_MAIN_CTRL_RESERVED3_SHIFT 13
   #define GLOBALREG_A926_MAIN_CTRL_RESERVED4_RW (0x0ff << 5)
   #define GLOBALREG_A926_MAIN_CTRL_RESERVED4_SHIFT 5
   #define GLOBALREG_A926_MAIN_CTRL_RESERVED5_RW (0x01 << 4)
   #define GLOBALREG_A926_MAIN_CTRL_RESERVED5_SHIFT 4
   #define GLOBALREG_A926_MAIN_CTRL_RESERVED6_RW (0x01 << 3)
   #define GLOBALREG_A926_MAIN_CTRL_RESERVED6_SHIFT 3
   #define GLOBALREG_A926_MAIN_CTRL_SYS_BIGENDIAN_RW (0x01 << 2)
   #define GLOBALREG_A926_MAIN_CTRL_SYS_BIGENDIAN_SHIFT 2
   #define GLOBALREG_A926_MAIN_CTRL_FMVD_SW_RST_RW (0x01 << 1)
   #define GLOBALREG_A926_MAIN_CTRL_FMVD_SW_RST_SHIFT 1
   /*
   * ARM926 is in Wait for interrupt standby state (read-only)
   */
   #define GLOBALREG_A926_MAIN_CTRL_ARM_STANDBYWFI_RW (0x01 << 0)
   #define GLOBALREG_A926_MAIN_CTRL_ARM_STANDBYWFI_SHIFT 0
   /*
   * Malone Reset Vector
   */
   #define GLOBALREG_A926_RESET_VECTOR_REG1  (GLOBALREG_BASE_UNIT1 + 0x84)
   /*
   * Reserved
   */
   #define GLOBALREG_A926_RESET_VECTOR_RESERVED_RW (0x0ffff << 16)
   #define GLOBALREG_A926_RESET_VECTOR_RESERVED_SHIFT 16
   /*
   * Malone Reset Vector
   */
   #define GLOBALREG_A926_RESET_VECTOR_A926_RESET_VECTOR_RW (0x0ffff << 0)
   #define GLOBALREG_A926_RESET_VECTOR_A926_RESET_VECTOR_SHIFT 0
   /*
   * The PIO Pin Mux 0 Select register controls the selection of primary functions fo
   * r PIO pin 0-31. Bit 0 corresponds to PIO[0], bit 1 to PIO[1], and so on up to PI
   * O[31].
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_REG  (GLOBALREG_BASE_UNIT1 + 0x100)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_031_RW (0x01 << 31)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_031_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_030_RW (0x01 << 30)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_030_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_029_RW (0x01 << 29)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_029_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_028_RW (0x01 << 28)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_028_SHIFT 28
   /*
   * uhf1
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_027_RW (0x01 << 27)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_027_SHIFT 27
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_026_RW (0x01 << 26)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_026_SHIFT 26
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_025_RW (0x01 << 25)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_025_SHIFT 25
   /*
   * pwm2
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_024_RW (0x01 << 24)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_024_SHIFT 24
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_023_RW (0x01 << 23)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_023_SHIFT 23
   /*
   * dibn
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_022_RW (0x01 << 22)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_022_SHIFT 22
   /*
   * dibp
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_021_RW (0x01 << 21)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_021_SHIFT 21
   /*
   * uart1ctl2_00
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_020_RW (0x01 << 20)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_020_SHIFT 20
   /*
   * uart1ctl1_00
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_019_RW (0x01 << 19)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_019_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_018_RW (0x01 << 18)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_018_SHIFT 18
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_017_RW (0x01 << 17)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_017_SHIFT 17
   /*
   * pwm1
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_016_RW (0x01 << 16)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_016_SHIFT 16
   /*
   * sda3
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_015_RW (0x01 << 15)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_015_SHIFT 15
   /*
   * scl3
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_014_RW (0x01 << 14)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_014_SHIFT 14
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_013_RW (0x01 << 13)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_013_SHIFT 13
   /*
   * irin1
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_012_RW (0x01 << 12)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_012_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_011_RW (0x01 << 11)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_011_SHIFT 11
   /*
   * irout1
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_010_RW (0x01 << 10)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_010_SHIFT 10
   /*
   * uart1ctl1_01
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_009_RW (0x01 << 9)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_009_SHIFT 9
   /*
   * uart1ctl2_01
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_008_RW (0x01 << 8)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_008_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_007_RW (0x01 << 7)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_007_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_006_RW (0x01 << 6)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_006_SHIFT 6
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_005_RW (0x01 << 5)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_005_SHIFT 5
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_004_RW (0x01 << 4)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_004_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_003_RW (0x01 << 3)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_003_SHIFT 3
   /*
   * uart1rx_00
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_002_RW (0x01 << 2)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_002_SHIFT 2
   /*
   * uart1tx
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_001_RW (0x01 << 1)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_001_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_000_RW (0x01 << 0)
   #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_000_SHIFT 0
   /*
   * The PIO Pin Mux 1 Select register controls the selection of primary functions fo
   * r PIO pin 63-32. . Bit 0 corresponds to PIO[32], bit 1 to PIO[33], and so on up 
   * to PIO[63].
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_REG  (GLOBALREG_BASE_UNIT1 + 0x104)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_063_RW (0x01 << 31)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_063_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_062_RW (0x01 << 30)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_062_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_061_RW (0x01 << 29)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_061_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_060_RW (0x01 << 28)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_060_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_059_RW (0x01 << 27)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_059_SHIFT 27
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_058_RW (0x01 << 26)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_058_SHIFT 26
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_057_RW (0x01 << 25)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_057_SHIFT 25
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_056_RW (0x01 << 24)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_056_SHIFT 24
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_055_RW (0x01 << 23)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_055_SHIFT 23
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_054_RW (0x01 << 22)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_054_SHIFT 22
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_053_RW (0x01 << 21)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_053_SHIFT 21
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_052_RW (0x01 << 20)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_052_SHIFT 20
   /*
   * intclk1
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_051_RW (0x01 << 19)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_051_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_050_RW (0x01 << 18)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_050_SHIFT 18
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_049_RW (0x01 << 17)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_049_SHIFT 17
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_048_RW (0x01 << 16)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_048_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_047_RW (0x01 << 15)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_047_SHIFT 15
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_046_RW (0x01 << 14)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_046_SHIFT 14
   /*
   * usb1vbusdrive
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_045_RW (0x01 << 13)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_045_SHIFT 13
   /*
   * usb1fault
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_044_RW (0x01 << 12)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_044_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_043_RW (0x01 << 11)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_043_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_042_RW (0x01 << 10)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_042_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_041_RW (0x01 << 9)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_041_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_040_RW (0x01 << 8)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_040_SHIFT 8
   /*
   * audtxspdif
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_039_RW (0x01 << 7)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_039_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_038_RW (0x01 << 6)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_038_SHIFT 6
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_037_RW (0x01 << 5)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_037_SHIFT 5
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_036_RW (0x01 << 4)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_036_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_035_RW (0x01 << 3)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_035_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_034_RW (0x01 << 2)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_034_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_033_RW (0x01 << 1)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_033_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_032_RW (0x01 << 0)
   #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_032_SHIFT 0
   /*
   * The PIO Pin Mux 2 Select register controls the selection of primary functions fo
   * r PIO pin 95-64. Bit 0 corresponds to PIO[64], bit 1 to PIO[65], and so on up to
   *  bit 31 which corresponds to PIO[95].
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_REG  (GLOBALREG_BASE_UNIT1 + 0x108)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_095_RW (0x01 << 31)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_095_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_094_RW (0x01 << 30)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_094_SHIFT 30
   /*
   * hs3d[7]
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_093_RW (0x01 << 29)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_093_SHIFT 29
   /*
   * hs3d[5]
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_092_RW (0x01 << 28)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_092_SHIFT 28
   /*
   * hs3d[3]
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_091_RW (0x01 << 27)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_091_SHIFT 27
   /*
   * hs3d[1]
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_090_RW (0x01 << 26)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_090_SHIFT 26
   /*
   * hs3clk
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_089_RW (0x01 << 25)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_089_SHIFT 25
   /*
   * hs3sync
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_088_RW (0x01 << 24)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_088_SHIFT 24
   /*
   * hs3err
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_087_RW (0x01 << 23)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_087_SHIFT 23
   /*
   * hs3val
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_086_RW (0x01 << 22)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_086_SHIFT 22
   /*
   * hs3d[0]
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_085_RW (0x01 << 21)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_085_SHIFT 21
   /*
   * hs3d[2]
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_084_RW (0x01 << 20)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_084_SHIFT 20
   /*
   * hs3d[4]
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_083_RW (0x01 << 19)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_083_SHIFT 19
   /*
   * hs3d[6]
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_082_RW (0x01 << 18)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_082_SHIFT 18
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_081_RW (0x01 << 17)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_081_SHIFT 17
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_080_RW (0x01 << 16)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_080_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_079_RW (0x01 << 15)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_079_SHIFT 15
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_078_RW (0x01 << 14)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_078_SHIFT 14
   /*
   * usb2vbusdrive
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_077_RW (0x01 << 13)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_077_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_076_RW (0x01 << 12)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_076_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_075_RW (0x01 << 11)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_075_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_074_RW (0x01 << 10)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_074_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_073_RW (0x01 << 9)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_073_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_072_RW (0x01 << 8)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_072_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_071_RW (0x01 << 7)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_071_SHIFT 7
   /*
   * io_reg
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_070_RW (0x01 << 6)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_070_SHIFT 6
   /*
   * uart1rx_01
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_069_RW (0x01 << 5)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_069_SHIFT 5
   /*
   * uart1tx
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_068_RW (0x01 << 4)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_068_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_067_RW (0x01 << 3)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_067_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_066_RW (0x01 << 2)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_066_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_065_RW (0x01 << 1)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_065_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_064_RW (0x01 << 0)
   #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_064_SHIFT 0
   /*
   * The PIO Pin Mux 3 Select register controls the selection of primary functions fo
   * r PIO pin 127-96. Bit 0 corresponds to PIO[96], bit 1 to PIO[97], and so on up t
   * o bit 31 which corresponds to PIO[127].
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_REG  (GLOBALREG_BASE_UNIT1 + 0x10c)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_127_RW (0x01 << 31)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_127_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_126_RW (0x01 << 30)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_126_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_125_RW (0x01 << 29)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_125_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_124_RW (0x01 << 28)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_124_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_123_RW (0x01 << 27)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_123_SHIFT 27
   /*
   * hs2d[2]
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_122_RW (0x01 << 26)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_122_SHIFT 26
   /*
   * hs2d[1]
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_121_RW (0x01 << 25)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_121_SHIFT 25
   /*
   * hs2d[0]
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_120_RW (0x01 << 24)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_120_SHIFT 24
   /*
   * hs2clk
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_119_RW (0x01 << 23)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_119_SHIFT 23
   /*
   * uhf2
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_118_RW (0x01 << 22)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_118_SHIFT 22
   /*
   * gmii0rxdv
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_117_RW (0x01 << 21)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_117_SHIFT 21
   /*
   * rgmii0rxer
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_116_RW (0x01 << 20)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_116_SHIFT 20
   /*
   * rgmii0txck
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_115_RW (0x01 << 19)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_115_SHIFT 19
   /*
   * rgmii0txd[0]
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_114_RW (0x01 << 18)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_114_SHIFT 18
   /*
   * rgmii0txd[1]
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_113_RW (0x01 << 17)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_113_SHIFT 17
   /*
   * rgmii0txd[2]
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_112_RW (0x01 << 16)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_112_SHIFT 16
   /*
   * rgmii0txd[3]
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_111_RW (0x01 << 15)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_111_SHIFT 15
   /*
   * rgmii0txen
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_110_RW (0x01 << 14)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_110_SHIFT 14
   /*
   * rgmii0txer
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_109_RW (0x01 << 13)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_109_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_108_RW (0x01 << 12)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_108_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_107_RW (0x01 << 11)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_107_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_106_RW (0x01 << 10)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_106_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_105_RW (0x01 << 9)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_105_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_104_RW (0x01 << 8)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_104_SHIFT 8
   /*
   * resetinn
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_103_RW (0x01 << 7)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_103_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_102_RW (0x01 << 6)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_102_SHIFT 6
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_101_RW (0x01 << 5)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_101_SHIFT 5
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_100_RW (0x01 << 4)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_100_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_090_RW (0x01 << 3)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_090_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_098_RW (0x01 << 2)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_098_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_097_RW (0x01 << 1)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_097_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_096_RW (0x01 << 0)
   #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_096_SHIFT 0
   /*
   * The PIO Pin Mux 4 Select register controls the selection of primary functions fo
   * r PIO pin 159-128. Bit 0 corresponds to PIO[128], bit 1 to PIO[129], and so on u
   * p to bit 31 which corresponds to PIO[159].
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_REG  (GLOBALREG_BASE_UNIT1 + 0x110)
   /*
   * rgmii0col
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_159_RW (0x01 << 31)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_159_SHIFT 31
   /*
   * rgmii0crs
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_158_RW (0x01 << 30)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_158_SHIFT 30
   /*
   * rgmii0mdc
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_157_RW (0x01 << 29)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_157_SHIFT 29
   /*
   * rgmii0mdio
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_156_RW (0x01 << 28)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_156_SHIFT 28
   /*
   * rgmii0rxck
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_155_RW (0x01 << 27)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_155_SHIFT 27
   /*
   * rgmii0rxd0
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_154_RW (0x01 << 26)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_154_SHIFT 26
   /*
   * rgmii0rxd1
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_153_RW (0x01 << 25)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_153_SHIFT 25
   /*
   * rgmii0rxd2
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_152_RW (0x01 << 24)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_152_SHIFT 24
   /*
   * rgmii0rxd3
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_151_RW (0x01 << 23)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_151_SHIFT 23
   /*
   * hs4d0
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_150_RW (0x01 << 22)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_150_SHIFT 22
   /*
   * hs4clk
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_149_RW (0x01 << 21)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_149_SHIFT 21
   /*
   * hs4val
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_148_RW (0x01 << 20)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_148_SHIFT 20
   /*
   * hs4sync
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_147_RW (0x01 << 19)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_147_SHIFT 19
   /*
   * hs4err
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_146_RW (0x01 << 18)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_146_SHIFT 18
   /*
   * hs5d0
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_145_RW (0x01 << 17)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_145_SHIFT 17
   /*
   * hs5clk
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_144_RW (0x01 << 16)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_144_SHIFT 16
   /*
   * hs5val
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_143_RW (0x01 << 15)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_143_SHIFT 15
   /*
   * hs5sync
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_142_RW (0x01 << 14)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_142_SHIFT 14
   /*
   * hs5err
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_141_RW (0x01 << 13)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_141_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_140_RW (0x01 << 12)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_140_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_139_RW (0x01 << 11)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_139_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_138_RW (0x01 << 10)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_138_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_137_RW (0x01 << 9)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_137_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_136_RW (0x01 << 8)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_136_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_135_RW (0x01 << 7)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_135_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_134_RW (0x01 << 6)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_134_SHIFT 6
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_133_RW (0x01 << 5)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_133_SHIFT 5
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_132_RW (0x01 << 4)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_132_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_131_RW (0x01 << 3)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_131_SHIFT 3
   /*
   * hs2val
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_130_RW (0x01 << 2)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_130_SHIFT 2
   /*
   * hs2sync
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_129_RW (0x01 << 1)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_129_SHIFT 1
   /*
   * hs2err
   */
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_128_RW (0x01 << 0)
   #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_128_SHIFT 0
   /*
   * The PIO Pin Mux 5 Select register controls the selection of primary functions fo
   * r PIO pin 191-160. Bit 0 corresponds to PIO[160], bit 1 to PIO[161], and so on u
   * p to bit 31 which corresponds to PIO[191].
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_REG  (GLOBALREG_BASE_UNIT1 + 0x114)
   /*
   * rgmii1col
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_191_RW (0x01 << 31)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_191_SHIFT 31
   /*
   * rgmii1crs
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_190_RW (0x01 << 30)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_190_SHIFT 30
   /*
   * rgmii1mdc
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_189_RW (0x01 << 29)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_189_SHIFT 29
   /*
   * rgmii1mdio
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_188_RW (0x01 << 28)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_188_SHIFT 28
   /*
   * rgmii1rxck
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_187_RW (0x01 << 27)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_187_SHIFT 27
   /*
   * rgmii1rxd0
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_186_RW (0x01 << 26)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_186_SHIFT 26
   /*
   * rgmii1rxd1
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_185_RW (0x01 << 25)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_185_SHIFT 25
   /*
   * rgmii1rxd2
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_184_RW (0x01 << 24)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_184_SHIFT 24
   /*
   * rgmii1rxd3
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_183_RW (0x01 << 23)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_183_SHIFT 23
   /*
   * rgmii1rxdv
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_182_RW (0x01 << 22)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_182_SHIFT 22
   /*
   * rgmii1rxer
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_181_RW (0x01 << 21)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_181_SHIFT 21
   /*
   * rgmii1txck
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_180_RW (0x01 << 20)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_180_SHIFT 20
   /*
   * rgmii1txd[1]
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_179_RW (0x01 << 19)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_179_SHIFT 19
   /*
   * scl2
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_178_RW (0x01 << 18)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_178_SHIFT 18
   /*
   * sda2
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_177_RW (0x01 << 17)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_177_SHIFT 17
   /*
   * rgmii1txd[1]
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_176_RW (0x01 << 16)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_176_SHIFT 16
   /*
   * hs2d[6]
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_175_RW (0x01 << 15)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_175_SHIFT 15
   /*
   * hs2d[5]
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_174_RW (0x01 << 14)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_174_SHIFT 14
   /*
   * hs2d[4]
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_173_RW (0x01 << 13)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_173_SHIFT 13
   /*
   * hs2d[3]
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_172_RW (0x01 << 12)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_172_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_171_RW (0x01 << 11)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_171_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_170_RW (0x01 << 10)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_170_SHIFT 10
   /*
   * hs2d[7]
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_169_RW (0x01 << 9)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_169_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_168_RW (0x01 << 8)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_168_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_167_RW (0x01 << 7)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_167_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_166_RW (0x01 << 6)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_166_SHIFT 6
   /*
   * rgmii1txd[2]
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_165_RW (0x01 << 5)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_165_SHIFT 5
   /*
   * rgmii1txd[3]
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_164_RW (0x01 << 4)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_164_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_163_RW (0x01 << 3)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_163_SHIFT 3
   /*
   * rgmii1txen
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_162_RW (0x01 << 2)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_162_SHIFT 2
   /*
   * rgmii1txer
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_161_RW (0x01 << 1)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_161_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_160_RW (0x01 << 0)
   #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_160_SHIFT 0
   /*
   * The PIO Pin Mux 6 Select register controls the selection of primary functions fo
   * r PIO pin 223-192. Bit 0 corresponds to PIO[192], bit 1 to PIO[193], and so on u
   * p to bit 31 which corresponds to PIO[223].
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_REG  (GLOBALREG_BASE_UNIT1 + 0x118)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_223_RW (0x01 << 31)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_223_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_222_RW (0x01 << 30)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_222_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_221_RW (0x01 << 29)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_221_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_220_RW (0x01 << 28)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_220_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_219_RW (0x01 << 27)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_219_SHIFT 27
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_218_RW (0x01 << 26)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_218_SHIFT 26
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_217_RW (0x01 << 25)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_217_SHIFT 25
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_216_RW (0x01 << 24)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_216_SHIFT 24
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_215_RW (0x01 << 23)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_215_SHIFT 23
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_214_RW (0x01 << 22)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_214_SHIFT 22
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_213_RW (0x01 << 21)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_213_SHIFT 21
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_212_RW (0x01 << 20)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_212_SHIFT 20
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_211_RW (0x01 << 19)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_211_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_210_RW (0x01 << 18)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_210_SHIFT 18
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_209_RW (0x01 << 17)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_209_SHIFT 17
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_208_RW (0x01 << 16)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_208_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_207_RW (0x01 << 15)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_207_SHIFT 15
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_206_RW (0x01 << 14)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_206_SHIFT 14
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_205_RW (0x01 << 13)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_205_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_204_RW (0x01 << 12)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_204_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_203_RW (0x01 << 11)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_203_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_202_RW (0x01 << 10)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_202_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_201_RW (0x01 << 9)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_201_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_200_RW (0x01 << 8)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_200_SHIFT 8
   /*
   * ethled2
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_199_RW (0x01 << 7)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_199_SHIFT 7
   /*
   * ethled1
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_198_RW (0x01 << 6)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_198_SHIFT 6
   /*
   * ethled0
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_197_RW (0x01 << 5)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_197_SHIFT 5
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_196_RW (0x01 << 4)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_196_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_195_RW (0x01 << 3)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_195_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_194_RW (0x01 << 2)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_194_SHIFT 2
   /*
   * usb2fault
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_193_RW (0x01 << 1)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_193_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_192_RW (0x01 << 0)
   #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_192_SHIFT 0
   /*
   * The PIO Pin Mux 0 Select register controls the selection of secondary functions 
   * for PIO pin 0-31. Bit 0 corresponds to PIO[0], bit 1 to PIO[1], and so on up to 
   * PIO[31].
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_REG  (GLOBALREG_BASE_UNIT1 + 0x120)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_031_RW (0x01 << 31)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_031_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_030_RW (0x01 << 30)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_030_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_029_RW (0x01 << 29)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_029_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_028_RW (0x01 << 28)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_028_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_027_RW (0x01 << 27)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_027_SHIFT 27
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_026_RW (0x01 << 26)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_026_SHIFT 26
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_025_RW (0x01 << 25)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_025_SHIFT 25
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_024_RW (0x01 << 24)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_024_SHIFT 24
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_023_RW (0x01 << 23)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_023_SHIFT 23
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_022_RW (0x01 << 22)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_022_SHIFT 22
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_021_RW (0x01 << 21)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_021_SHIFT 21
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_020_RW (0x01 << 20)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_020_SHIFT 20
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_019_RW (0x01 << 19)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_019_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_018_RW (0x01 << 18)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_018_SHIFT 18
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_017_RW (0x01 << 17)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_017_SHIFT 17
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_016_RW (0x01 << 16)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_016_SHIFT 16
   /*
   * uart3rx_00
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_015_RW (0x01 << 15)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_015_SHIFT 15
   /*
   * uart3tx
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_014_RW (0x01 << 14)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_014_SHIFT 14
   /*
   * hs6sync
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_013_RW (0x01 << 13)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_013_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_012_RW (0x01 << 12)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_012_SHIFT 12
   /*
   * hs6d0
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_011_RW (0x01 << 11)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_011_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_010_RW (0x01 << 10)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_010_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_009_RW (0x01 << 9)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_009_SHIFT 9
   /*
   * ssclk_sync_serial
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_008_RW (0x01 << 8)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_008_SHIFT 8
   /*
   * sscs_sync_serial
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_007_RW (0x01 << 7)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_007_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_006_RW (0x01 << 6)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_006_SHIFT 6
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_005_RW (0x01 << 5)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_005_SHIFT 5
   /*
   * uart2rx_01
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_004_RW (0x01 << 4)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_004_SHIFT 4
   /*
   * uart2tx
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_003_RW (0x01 << 3)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_003_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_002_RW (0x01 << 2)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_002_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_001_RW (0x01 << 1)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_001_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_000_RW (0x01 << 0)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_000_SHIFT 0
   /*
   * The PIO Pin Mux 1 Select register controls the selection of secondary functions 
   * for PIO pin 63-32. . Bit 0 corresponds to PIO[32], bit 1 to PIO[33], and so on u
   * p to PIO[63].
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_REG  (GLOBALREG_BASE_UNIT1 + 0x124)
   /*
   * io_iord#
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_063_RW (0x01 << 31)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_063_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_062_RW (0x01 << 30)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_062_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_061_RW (0x01 << 29)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_061_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_GMUX_060_RW (0x01 << 28)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_GMUX_060_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_059_RW (0x01 << 27)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_059_SHIFT 27
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_058_RW (0x01 << 26)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_058_SHIFT 26
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_057_RW (0x01 << 25)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_057_SHIFT 25
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_056_RW (0x01 << 24)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_056_SHIFT 24
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_055_RW (0x01 << 23)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_055_SHIFT 23
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_054_RW (0x01 << 22)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_054_SHIFT 22
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_053_RW (0x01 << 21)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_053_SHIFT 21
   /*
   * intclk0
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_052_RW (0x01 << 20)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_052_SHIFT 20
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_051_RW (0x01 << 19)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_051_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_050_RW (0x01 << 18)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_050_SHIFT 18
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_049_RW (0x01 << 17)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_049_SHIFT 17
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_048_RW (0x01 << 16)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_048_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_047_RW (0x01 << 15)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_047_SHIFT 15
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_046_RW (0x01 << 14)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_046_SHIFT 14
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_045_RW (0x01 << 13)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_045_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_044_RW (0x01 << 12)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_044_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_043_RW (0x01 << 11)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_043_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_042_RW (0x01 << 10)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_042_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_041_RW (0x01 << 9)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_041_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_040_RW (0x01 << 8)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_040_SHIFT 8
   /*
   * intclk0
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_039_RW (0x01 << 7)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_039_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_038_RW (0x01 << 6)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_038_SHIFT 6
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_037_RW (0x01 << 5)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_037_SHIFT 5
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_036_RW (0x01 << 4)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_036_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_035_RW (0x01 << 3)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_035_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_034_RW (0x01 << 2)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_034_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_033_RW (0x01 << 1)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_033_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_032_RW (0x01 << 0)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_032_SHIFT 0
   /*
   * The PIO Pin Mux 2 Select register controls the selection of secondary functions 
   * for PIO pin 95-64. Bit 0 corresponds to PIO[64], bit 1 to PIO[65], and so on up 
   * to bit 31 which corresponds to PIO[95].
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_REG  (GLOBALREG_BASE_UNIT1 + 0x128)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_095_RW (0x01 << 31)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_095_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_094_RW (0x01 << 30)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_094_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_093_RW (0x01 << 29)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_093_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_092_RW (0x01 << 28)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_092_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_091_RW (0x01 << 27)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_091_SHIFT 27
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_090_RW (0x01 << 26)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_090_SHIFT 26
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_089_RW (0x01 << 25)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_089_SHIFT 25
   /*
   * sig_656vs
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_088_RW (0x01 << 24)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_088_SHIFT 24
   /*
   * memwrn
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_087_RW (0x01 << 23)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_087_SHIFT 23
   /*
   * sig_656hs
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_086_RW (0x01 << 22)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_086_SHIFT 22
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_085_RW (0x01 << 21)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_085_SHIFT 21
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_084_RW (0x01 << 20)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_084_SHIFT 20
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_083_RW (0x01 << 19)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_083_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_082_RW (0x01 << 18)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_082_SHIFT 18
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_081_RW (0x01 << 17)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_081_SHIFT 17
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_080_RW (0x01 << 16)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_080_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_079_RW (0x01 << 15)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_079_SHIFT 15
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_078_RW (0x01 << 14)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_078_SHIFT 14
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_077_RW (0x01 << 13)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_077_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_076_RW (0x01 << 12)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_076_SHIFT 12
   /*
   * hs6val
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_075_RW (0x01 << 11)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_075_SHIFT 11
   /*
   * hs6err
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_074_RW (0x01 << 10)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_074_SHIFT 10
   /*
   * hs6clk
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_073_RW (0x01 << 9)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_073_SHIFT 9
   /*
   * uart3tx
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_072_RW (0x01 << 8)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_072_SHIFT 8
   /*
   * uart3rx_01
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_071_RW (0x01 << 7)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_071_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_070_RW (0x01 << 6)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_070_SHIFT 6
   /*
   * ssrx_sync_serial
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_069_RW (0x01 << 5)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_069_SHIFT 5
   /*
   * sstx_sync_serial
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_068_RW (0x01 << 4)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_068_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_067_RW (0x01 << 3)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_067_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_066_RW (0x01 << 2)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_066_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_065_RW (0x01 << 1)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_065_SHIFT 1
   /*
   * io_iowr#
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_064_RW (0x01 << 0)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_064_SHIFT 0
   /*
   * The PIO Pin Mux 3 Select register controls the selection of secondary functions 
   * for PIO pin 127-96. Bit 0 corresponds to PIO[96], bit 1 to PIO[97], and so on up
   *  to bit 31 which corresponds to PIO[127].
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_REG  (GLOBALREG_BASE_UNIT1 + 0x12c)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_127_RW (0x01 << 31)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_127_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_126_RW (0x01 << 30)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_126_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_125_RW (0x01 << 29)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_125_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_124_RW (0x01 << 28)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_124_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_123_RW (0x01 << 27)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_123_SHIFT 27
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_122_RW (0x01 << 26)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_122_SHIFT 26
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_121_RW (0x01 << 25)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_121_SHIFT 25
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_120_RW (0x01 << 24)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_120_SHIFT 24
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_119_RW (0x01 << 23)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_119_SHIFT 23
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_118_RW (0x01 << 22)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_118_SHIFT 22
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_117_RW (0x01 << 21)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_117_SHIFT 21
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_116_RW (0x01 << 20)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_116_SHIFT 20
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_115_RW (0x01 << 19)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_115_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_114_RW (0x01 << 18)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_114_SHIFT 18
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_113_RW (0x01 << 17)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_113_SHIFT 17
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_112_RW (0x01 << 16)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_112_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_111_RW (0x01 << 15)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_111_SHIFT 15
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_110_RW (0x01 << 14)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_110_SHIFT 14
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_109_RW (0x01 << 13)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_109_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_108_RW (0x01 << 12)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_108_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_107_RW (0x01 << 11)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_107_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_106_RW (0x01 << 10)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_106_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_105_RW (0x01 << 9)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_105_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_104_RW (0x01 << 8)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_104_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_103_RW (0x01 << 7)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_103_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_102_RW (0x01 << 6)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_102_SHIFT 6
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_101_RW (0x01 << 5)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_101_SHIFT 5
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_100_RW (0x01 << 4)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_100_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_090_RW (0x01 << 3)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_090_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_098_RW (0x01 << 2)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_098_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_097_RW (0x01 << 1)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_097_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_096_RW (0x01 << 0)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_096_SHIFT 0
   /*
   * The PIO Pin Mux 4 Select register controls the selection of secondary functions 
   * for PIO pin 159-128. Bit 0 corresponds to PIO[128], bit 1 to PIO[129], and so on
   *  up to bit 31 which corresponds to PIO[159].
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_REG  (GLOBALREG_BASE_UNIT1 + 0x130)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_159_RW (0x01 << 31)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_159_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_158_RW (0x01 << 30)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_158_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_157_RW (0x01 << 29)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_157_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_156_RW (0x01 << 28)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_156_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_155_RW (0x01 << 27)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_155_SHIFT 27
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_154_RW (0x01 << 26)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_154_SHIFT 26
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_153_RW (0x01 << 25)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_153_SHIFT 25
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_152_RW (0x01 << 24)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_152_SHIFT 24
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_151_RW (0x01 << 23)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_151_SHIFT 23
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_150_RW (0x01 << 22)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_150_SHIFT 22
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_149_RW (0x01 << 21)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_149_SHIFT 21
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_148_RW (0x01 << 20)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_148_SHIFT 20
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_147_RW (0x01 << 19)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_147_SHIFT 19
   /*
   * pwm3
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_146_RW (0x01 << 18)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_146_SHIFT 18
   /*
   * i2sind2
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_145_RW (0x01 << 17)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_145_SHIFT 17
   /*
   * i2sinosclk
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_144_RW (0x01 << 16)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_144_SHIFT 16
   /*
   * i2sind1
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_143_RW (0x01 << 15)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_143_SHIFT 15
   /*
   * i2sinws
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_142_RW (0x01 << 14)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_142_SHIFT 14
   /*
   * i2sinsck
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_141_RW (0x01 << 13)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_141_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_140_RW (0x01 << 12)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_140_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_139_RW (0x01 << 11)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_139_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_138_RW (0x01 << 10)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_138_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_137_RW (0x01 << 9)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_137_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_136_RW (0x01 << 8)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_136_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_135_RW (0x01 << 7)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_135_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_134_RW (0x01 << 6)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_134_SHIFT 6
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_133_RW (0x01 << 5)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_133_SHIFT 5
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_132_RW (0x01 << 4)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_132_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_131_RW (0x01 << 3)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_131_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_130_RW (0x01 << 2)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_130_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_129_RW (0x01 << 1)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_129_SHIFT 1
   /*
   * sataled2
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_128_RW (0x01 << 0)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_128_SHIFT 0
   /*
   * The PIO Pin Mux 5 Select register controls the selection of secondary functions 
   * for PIO pin 191-160. Bit 0 corresponds to PIO[160], bit 1 to PIO[161], and so on
   *  up to bit 31 which corresponds to PIO[191].
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_REG  (GLOBALREG_BASE_UNIT1 + 0x134)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_191_RW (0x01 << 31)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_191_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_190_RW (0x01 << 30)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_190_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_189_RW (0x01 << 29)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_189_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_188_RW (0x01 << 28)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_188_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_187_RW (0x01 << 27)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_187_SHIFT 27
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_186_RW (0x01 << 26)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_186_SHIFT 26
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_185_RW (0x01 << 25)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_185_SHIFT 25
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_184_RW (0x01 << 24)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_184_SHIFT 24
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_183_RW (0x01 << 23)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_183_SHIFT 23
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_182_RW (0x01 << 22)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_182_SHIFT 22
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_181_RW (0x01 << 21)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_181_SHIFT 21
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_180_RW (0x01 << 20)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_180_SHIFT 20
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_179_RW (0x01 << 19)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_179_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_178_RW (0x01 << 18)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_178_SHIFT 18
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_177_RW (0x01 << 17)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_177_SHIFT 17
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_176_RW (0x01 << 16)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_176_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_175_RW (0x01 << 15)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_175_SHIFT 15
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_174_RW (0x01 << 14)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_174_SHIFT 14
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_173_RW (0x01 << 13)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_173_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_172_RW (0x01 << 12)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_172_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_171_RW (0x01 << 11)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_171_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_170_RW (0x01 << 10)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_170_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_169_RW (0x01 << 9)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_169_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_168_RW (0x01 << 8)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_168_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_167_RW (0x01 << 7)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_167_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_166_RW (0x01 << 6)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_166_SHIFT 6
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_165_RW (0x01 << 5)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_165_SHIFT 5
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_164_RW (0x01 << 4)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_164_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_163_RW (0x01 << 3)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_163_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_162_RW (0x01 << 2)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_162_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_161_RW (0x01 << 1)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_161_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_160_RW (0x01 << 0)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_160_SHIFT 0
   /*
   * The PIO Pin Mux 6 Select register controls the selection of secondary functions 
   * for PIO pin 223-192. Bit 0 corresponds to PIO[192], bit 1 to PIO[193], and so on
   *  up to bit 31 which corresponds to PIO[223].
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_REG  (GLOBALREG_BASE_UNIT1 + 0x138)
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_223_RW (0x01 << 31)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_223_SHIFT 31
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_222_RW (0x01 << 30)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_222_SHIFT 30
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_221_RW (0x01 << 29)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_221_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_220_RW (0x01 << 28)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_220_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_219_RW (0x01 << 27)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_219_SHIFT 27
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_218_RW (0x01 << 26)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_218_SHIFT 26
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_217_RW (0x01 << 25)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_217_SHIFT 25
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_216_RW (0x01 << 24)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_216_SHIFT 24
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_215_RW (0x01 << 23)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_215_SHIFT 23
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_214_RW (0x01 << 22)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_214_SHIFT 22
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_213_RW (0x01 << 21)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_213_SHIFT 21
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_212_RW (0x01 << 20)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_212_SHIFT 20
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_211_RW (0x01 << 19)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_211_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_210_RW (0x01 << 18)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_210_SHIFT 18
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_209_RW (0x01 << 17)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_209_SHIFT 17
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_208_RW (0x01 << 16)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_208_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_207_RW (0x01 << 15)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_207_SHIFT 15
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_206_RW (0x01 << 14)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_206_SHIFT 14
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_205_RW (0x01 << 13)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_205_SHIFT 13
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_204_RW (0x01 << 12)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_204_SHIFT 12
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_203_RW (0x01 << 11)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_203_SHIFT 11
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_202_RW (0x01 << 10)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_202_SHIFT 10
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_201_RW (0x01 << 9)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_201_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_200_RW (0x01 << 8)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_200_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_199_RW (0x01 << 7)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_199_SHIFT 7
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_198_RW (0x01 << 6)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_198_SHIFT 6
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_197_RW (0x01 << 5)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_197_SHIFT 5
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_196_RW (0x01 << 4)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_196_SHIFT 4
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_195_RW (0x01 << 3)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_195_SHIFT 3
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_194_RW (0x01 << 2)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_194_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_193_RW (0x01 << 1)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_193_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_192_RW (0x01 << 0)
   #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_192_SHIFT 0
   /*
   * Alternate Function Pin select Register 0
   */
   #define GLOBALREG_ALT_PIN_MUX_0_REG  (GLOBALREG_BASE_UNIT1 + 0x140)
   /*
   * Reserved
   */
   #define GLOBALREG_ALT_PIN_MUX_0_RESERVED_RW (0x01 << 31)
   #define GLOBALREG_ALT_PIN_MUX_0_RESERVED_SHIFT 31
   #define GLOBALREG_ALT_PIN_MUX_0_ALT30_PCIRGC2_RW (0x01 << 30)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT30_PCIRGC2_SHIFT 30
   #define GLOBALREG_ALT_PIN_MUX_0_ALT29_PCIRG1_RW (0x01 << 29)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT29_PCIRG1_SHIFT 29
   /*
   * Reserved
   */
   #define GLOBALREG_ALT_PIN_MUX_0_RESERVED3_RW (0x03f << 23)
   #define GLOBALREG_ALT_PIN_MUX_0_RESERVED3_SHIFT 23
   #define GLOBALREG_ALT_PIN_MUX_0_ALT22_TESTI2S_RW (0x01 << 22)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT22_TESTI2S_SHIFT 22
   #define GLOBALREG_ALT_PIN_MUX_0_ALT21_EPHYDBG_RW (0x01 << 21)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT21_EPHYDBG_SHIFT 21
   #define GLOBALREG_ALT_PIN_MUX_0_ALT20_RW (0x01 << 20)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT20_SHIFT 20
   #define GLOBALREG_ALT_PIN_MUX_0_ALT19_RW (0x01 << 19)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT19_SHIFT 19
   #define GLOBALREG_ALT_PIN_MUX_0_ALT18_RW (0x01 << 18)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT18_SHIFT 18
   #define GLOBALREG_ALT_PIN_MUX_0_ALT17_MUART_RW (0x01 << 17)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT17_MUART_SHIFT 17
   #define GLOBALREG_ALT_PIN_MUX_0_ALT16_MODEMDBG_RW (0x01 << 16)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT16_MODEMDBG_SHIFT 16
   #define GLOBALREG_ALT_PIN_MUX_0_ALT15_I2C5_RW (0x01 << 15)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT15_I2C5_SHIFT 15
   #define GLOBALREG_ALT_PIN_MUX_0_ALT14_I2C4_RW (0x01 << 14)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT14_I2C4_SHIFT 14
   #define GLOBALREG_ALT_PIN_MUX_0_ALT13_DBGI2C_RW (0x01 << 13)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT13_DBGI2C_SHIFT 13
   #define GLOBALREG_ALT_PIN_MUX_0_ALT12_UART2_RW (0x01 << 12)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT12_UART2_SHIFT 12
   #define GLOBALREG_ALT_PIN_MUX_0_ALT11_USB11_RW (0x01 << 11)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT11_USB11_SHIFT 11
   #define GLOBALREG_ALT_PIN_MUX_0_ALT10_TASTERDBG_RW (0x01 << 10)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT10_TASTERDBG_SHIFT 10
   #define GLOBALREG_ALT_PIN_MUX_0_ALT09_MEMRD_RW (0x01 << 9)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT09_MEMRD_SHIFT 9
   #define GLOBALREG_ALT_PIN_MUX_0_ALT08_TBUS_RW (0x01 << 8)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT08_TBUS_SHIFT 8
   #define GLOBALREG_ALT_PIN_MUX_0_ALT07_MCARDSS_RW (0x01 << 7)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT07_MCARDSS_SHIFT 7
   #define GLOBALREG_ALT_PIN_MUX_0_ALT06_TRACE_RW (0x01 << 6)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT06_TRACE_SHIFT 6
   #define GLOBALREG_ALT_PIN_MUX_0_ALT05_SDIO_RW (0x01 << 5)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT05_SDIO_SHIFT 5
   #define GLOBALREG_ALT_PIN_MUX_0_ALT04_DAC_RW (0x01 << 4)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT04_DAC_SHIFT 4
   #define GLOBALREG_ALT_PIN_MUX_0_ALT03_656_RW (0x01 << 3)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT03_656_SHIFT 3
   #define GLOBALREG_ALT_PIN_MUX_0_ALT02_BLCAR_RW (0x01 << 2)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT02_BLCAR_SHIFT 2
   #define GLOBALREG_ALT_PIN_MUX_0_ALT01_UART1_RW (0x01 << 1)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT01_UART1_SHIFT 1
   #define GLOBALREG_ALT_PIN_MUX_0_ALT00_I2SHDMI_RW (0x01 << 0)
   #define GLOBALREG_ALT_PIN_MUX_0_ALT00_I2SHDMI_SHIFT 0
   /*
   * Alternate Function Pin select Register 1
   */
   #define GLOBALREG_ALT_PIN_MUX_1_REG  (GLOBALREG_BASE_UNIT1 + 0x144)
   /*
   * spare
   */
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG1_RW (0x01fff << 19)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG1_SHIFT 19
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_SECDBG_OPVERRIDE_RW (0x01 << 18)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_SECDBG_OPVERRIDE_SHIFT 18
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL2_2_RW (0x01 << 17)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL2_2_SHIFT 17
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL2_1_RW (0x01 << 16)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL2_1_SHIFT 16
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL2_0_RW (0x01 << 15)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL2_0_SHIFT 15
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL1_2_RW (0x01 << 14)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL1_2_SHIFT 14
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL1_1_RW (0x01 << 13)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL1_1_SHIFT 13
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL1_0_RW (0x01 << 12)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_UART1CTL1_0_SHIFT 12
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL5_RW (0x01 << 11)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL5_SHIFT 11
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL4_RW (0x01 << 10)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL4_SHIFT 10
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL3_RW (0x01 << 9)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL3_SHIFT 9
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL2_RW (0x01 << 8)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL2_SHIFT 8
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL1_RW (0x01 << 7)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL1_SHIFT 7
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL0_RW (0x01 << 6)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL0_SHIFT 6
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_TYPHOON_I2C_RW (0x01 << 5)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_TYPHOON_I2C_SHIFT 5
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BURSTROM_RW (0x01 << 4)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BURSTROM_SHIFT 4
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_SATALED1_RW (0x01 << 3)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_SATALED1_SHIFT 3
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BURT_MPG2_RW (0x01 << 2)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BURT_MPG2_SHIFT 2
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BURT_MPG1_RW (0x01 << 1)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BURT_MPG1_SHIFT 1
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BURT_MPG0_RW (0x01 << 0)
   #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BURT_MPG0_SHIFT 0
   /*
   * Alternate Function Pin select Register 2
   */
   #define GLOBALREG_ALT_PIN_MUX_2_REG  (GLOBALREG_BASE_UNIT1 + 0x148)
   /*
   * Spare
   */
   #define GLOBALREG_ALT_PIN_MUX_2_ALT_REG2_RW (0x0ffffffff << 0)
   #define GLOBALREG_ALT_PIN_MUX_2_ALT_REG2_SHIFT 0
   /*
   * Internal bus DRAM low address
   */
   #define GLOBALREG_DMA_GATE_LO_REG1  (GLOBALREG_BASE_UNIT1 + 0x200)
   /*
   * Lowest DCSN address mapped to DRAM, granularity of 64K. Internal bus DRAM apertu
   * re is reset to start at 0.
   */
   #define GLOBALREG_DMA_GATE_LO_DMA_GATE_LO_RW (0x0ffff << 16)
   #define GLOBALREG_DMA_GATE_LO_DMA_GATE_LO_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_DMA_GATE_LO_RESERVED_RW (0x0ffff << 0)
   #define GLOBALREG_DMA_GATE_LO_RESERVED_SHIFT 0
   /*
   * Internal bus DRAM high address
   */
   #define GLOBALREG_DMA_GATE_HI_REG1  (GLOBALREG_BASE_UNIT1 + 0x204)
   /*
   * First address outside DCSN DRAM space, granularity of 64K. Internal bus DRAM ape
   * rture is reset to 64MB.
   */
   #define GLOBALREG_DMA_GATE_HI_DMA_GATE_HI_RW (0x0ffff << 16)
   #define GLOBALREG_DMA_GATE_HI_DMA_GATE_HI_SHIFT 16
   #define GLOBALREG_DMA_GATE_HI_RESERVED_RW (0x0ffff << 0)
   #define GLOBALREG_DMA_GATE_HI_RESERVED_SHIFT 0
   /*
   * Enables writes to DMA_GATE_LO and DMA_GATE_HI
   */
   #define GLOBALREG_APERTURE_WE_REG1  (GLOBALREG_BASE_UNIT1 + 0x208)
   /*
   * Reserved
   */
   #define GLOBALREG_APERTURE_WE_RESERVED_RW (0x07fffffff << 1)
   #define GLOBALREG_APERTURE_WE_RESERVED_SHIFT 1
   /*
   * 0 = Writing to DMA_GATE_LO or DMA_GATE_HI is disabled.
   * 1 = Writing to DMA_GATE_LO or DMA_GATE_HI is enabled.
   * When writing to either DMA_GATE_LO or DMA_GATE_HI occurs, this bit is automatica
   * lly
   * cleared.
   */
   #define GLOBALREG_APERTURE_WE_DRAM_WE_RW (0x01 << 0)
   #define GLOBALREG_APERTURE_WE_DRAM_WE_SHIFT 0
   /*
   * Flash space low address
   */
   #define GLOBALREG_FLASH_LO_REG1  (GLOBALREG_BASE_UNIT1 + 0x20c)
   /*
   * Low address of Flash/SPI/ISA space
   */
   #define GLOBALREG_FLASH_LO_FLASH_LO_RW (0x0f << 28)
   #define GLOBALREG_FLASH_LO_FLASH_LO_SHIFT 28
   /*
   * Reserved
   */
   #define GLOBALREG_FLASH_LO_RESERVED_RW (0x0fffffff << 0)
   #define GLOBALREG_FLASH_LO_RESERVED_SHIFT 0
   /*
   * Flash space high address
   */
   #define GLOBALREG_FLASH_HI_REG1  (GLOBALREG_BASE_UNIT1 + 0x210)
   /*
   * High address of Flash/SPI/ISA space
   */
   #define GLOBALREG_FLASH_HI_FLASH_HI_RW (0x0f << 28)
   #define GLOBALREG_FLASH_HI_FLASH_HI_SHIFT 28
   #define GLOBALREG_FLASH_HI_RESERVED_RW (0x0fffffff << 0)
   #define GLOBALREG_FLASH_HI_RESERVED_SHIFT 0
   /*
   * Malone DMA Gate High
   */
   #define GLOBALREG_FMVD_DMA_GATE_HI_REG1  (GLOBALREG_BASE_UNIT1 + 0x220)
   /*
   * Malone DMA Gate High
   */
   #define GLOBALREG_FMVD_DMA_GATE_HI_FMVD_DMA_GATE_HI_RW (0x0ffff << 16)
   #define GLOBALREG_FMVD_DMA_GATE_HI_FMVD_DMA_GATE_HI_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_FMVD_DMA_GATE_HI_RESERVED_RW (0x0ffff << 0)
   #define GLOBALREG_FMVD_DMA_GATE_HI_RESERVED_SHIFT 0
   /*
   * Malone DMA Gate Low
   */
   #define GLOBALREG_FMVD_DMA_GATE_LO_REG1  (GLOBALREG_BASE_UNIT1 + 0x224)
   /*
   * Malone DMA Gate Low
   */
   #define GLOBALREG_FMVD_DMA_GATE_LO_FMVD_DMA_GATE_LO_RW (0x0ffff << 16)
   #define GLOBALREG_FMVD_DMA_GATE_LO_FMVD_DMA_GATE_LO_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_FMVD_DMA_GATE_LO_RESERVED_RW (0x0ffff << 0)
   #define GLOBALREG_FMVD_DMA_GATE_LO_RESERVED_SHIFT 0
   /*
   * Base 14 MMIO Offset
   */
   #define GLOBALREG_BASE14_MMIO_REG1  (GLOBALREG_BASE_UNIT1 + 0x240)
   /*
   * Base 14 (MMIO) value used for DCS-N address decoding when WIN2K = 1. When WIN2K 
   * = 0 then this field is not used, and the PCI/XIO BASE14 value (MMIO register) is
   *  used instead.
   */
   #define GLOBALREG_BASE14_MMIO_BASE14_MMIO_RW (0x07ff << 21)
   #define GLOBALREG_BASE14_MMIO_BASE14_MMIO_SHIFT 21
   /*
   * Reserved
   */
   #define GLOBALREG_BASE14_MMIO_RESERVED_RW (0x01fffff << 0)
   #define GLOBALREG_BASE14_MMIO_RESERVED_SHIFT 0
   /*
   * BIS Base Address
   */
   #define GLOBALREG_BIS_BASE_ADDR_REG1  (GLOBALREG_BASE_UNIT1 + 0x2f0)
   /*
   * BIS Base Address (no output)
   */
   #define GLOBALREG_BIS_BASE_ADDR_BIS_BASE_ADDR_RW (0x0ffffffff << 0)
   #define GLOBALREG_BIS_BASE_ADDR_BIS_BASE_ADDR_SHIFT 0
   /*
   * GMAC0 Control
   */
   #define GLOBALREG_GMAC0_CTL_REG  (GLOBALREG_BASE_UNIT1 + 0x300)
   /*
   * Reserved
   */
   #define GLOBALREG_GMAC0_CTL_RESERVED_RW (0x03ffff << 14)
   #define GLOBALREG_GMAC0_CTL_RESERVED_SHIFT 14
   /*
   * Selects whether the internal 10/100 Ethernet PHY is used, or an external PHY is 
   * used.
   * 0 = internal 10/100 Ethernet PHY
   * 1 = external PHY
   */
   #define GLOBALREG_GMAC0_CTL_GMAC0_EXT_PHY_RW (0x01 << 13)
   #define GLOBALREG_GMAC0_CTL_GMAC0_EXT_PHY_SHIFT 13
   /*
   * Tx clock output phase selection for RGMII 10/100 modes.
   * 0 = 0 degree phase shift
   * 1 = 180 degrees phase shift
   */
   #define GLOBALREG_GMAC0_CTL_GMAC0_RGMII_10_100_TX_PHASE_RW (0x01 << 12)
   #define GLOBALREG_GMAC0_CTL_GMAC0_RGMII_10_100_TX_PHASE_SHIFT 12
   /*
   * Tx clock output phase selection for RGMII gigabit mode.
   * 0 = 0 degree phase shift
   * 1 = 90 degrees phase shift
   * 2 = 180 degrees phase shift
   * 3 = 270 degrees phase shift
   */
   #define GLOBALREG_GMAC0_CTL_GMAC0_RGMII_1000_TX_PHASE_RW (0x03 << 10)
   #define GLOBALREG_GMAC0_CTL_GMAC0_RGMII_1000_TX_PHASE_SHIFT 10
   /*
   * Rx clock input delay selection, used in MII and RGMII modes.
   * 0 = no added delay
   * 1 = 1 delay element added
   * 2 = 2 delay elements added
   * 3 = 3 delay elements added
   */
   #define GLOBALREG_GMAC0_CTL_GMAC0_RX_DELAY_SEL_RW (0x03 << 8)
   #define GLOBALREG_GMAC0_CTL_GMAC0_RX_DELAY_SEL_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_GMAC0_CTL_RESERVED5_RW (0x03 << 6)
   #define GLOBALREG_GMAC0_CTL_RESERVED5_SHIFT 6
   /*
   * PHY interface select
   * 0 = MII (must be selected if internal PHY is used)
   * 1 = RGMII
   * 2 = RMII
   * 3 = Reserved
   */
   #define GLOBALREG_GMAC0_CTL_GMAC0_PHY_INTF_SEL_RW (0x03 << 4)
   #define GLOBALREG_GMAC0_CTL_GMAC0_PHY_INTF_SEL_SHIFT 4
   /*
   * Whether bus accesses are cacheable.
   * 0 = non-cacheable
   * 1 = cacheable
   */
   #define GLOBALREG_GMAC0_CTL_GMAC0_HPROT_CACHEABLE_RW (0x01 << 3)
   #define GLOBALREG_GMAC0_CTL_GMAC0_HPROT_CACHEABLE_SHIFT 3
   /*
   * Whether bus accesses are bufferable.
   * 0 = non-bufferable
   * 1 = bufferable
   */
   #define GLOBALREG_GMAC0_CTL_GMAC0_HPROT_BUFFERABLE_RW (0x01 << 2)
   #define GLOBALREG_GMAC0_CTL_GMAC0_HPROT_BUFFERABLE_SHIFT 2
   /*
   * Whether bus accesses are privileged or user.
   * 0 = user
   * 1 = privileged
   */
   #define GLOBALREG_GMAC0_CTL_GMAC0_HPROT_PRIVILEGED_RW (0x01 << 1)
   #define GLOBALREG_GMAC0_CTL_GMAC0_HPROT_PRIVILEGED_SHIFT 1
   /*
   * Whether bus accesses are data or opcode.
   * 0 = opcode
   * 1 = data
   */
   #define GLOBALREG_GMAC0_CTL_GMAC0_HPROT_DATA_RW (0x01 << 0)
   #define GLOBALREG_GMAC0_CTL_GMAC0_HPROT_DATA_SHIFT 0
   /*
   * GMAC1 Control
   */
   #define GLOBALREG_GMAC1_CTL_REG  (GLOBALREG_BASE_UNIT1 + 0x304)
   /*
   * Reserved
   */
   #define GLOBALREG_GMAC1_CTL_RESERVED_RW (0x03ffff << 14)
   #define GLOBALREG_GMAC1_CTL_RESERVED_SHIFT 14
   /*
   * Selects whether the internal 10/100 Ethernet PHY is used, or an external PHY is 
   * used.
   * 0 = internal 10/100 Ethernet PHY
   * 1 = external PHY
   */
   #define GLOBALREG_GMAC1_CTL_GMAC1_EXT_PHY_RW (0x01 << 13)
   #define GLOBALREG_GMAC1_CTL_GMAC1_EXT_PHY_SHIFT 13
   /*
   * Tx clock output phase selection for RGMII 10/100 modes.
   * 0 = 0 degree phase shift
   * 1 = 180 degrees phase shift
   */
   #define GLOBALREG_GMAC1_CTL_GMAC1_RGMII_10_100_TX_PHASE_RW (0x01 << 12)
   #define GLOBALREG_GMAC1_CTL_GMAC1_RGMII_10_100_TX_PHASE_SHIFT 12
   /*
   * Tx clock output phase selection for RGMII gigabit mode.
   * 0 = 0 degree phase shift
   * 1 = 90 degrees phase shift
   * 2 = 180 degrees phase shift
   * 3 = 270 degrees phase shift
   */
   #define GLOBALREG_GMAC1_CTL_GMAC1_RGMII_1000_TX_PHASE_RW (0x03 << 10)
   #define GLOBALREG_GMAC1_CTL_GMAC1_RGMII_1000_TX_PHASE_SHIFT 10
   /*
   * Rx clock input delay selection, used in MII and RGMII modes.
   * 0 = no added delay
   * 1 = 1 delay element added
   * 2 = 2 delay elements added
   * 3 = 3 delay elements added
   */
   #define GLOBALREG_GMAC1_CTL_GMAC1_RX_DELAY_SEL_RW (0x03 << 8)
   #define GLOBALREG_GMAC1_CTL_GMAC1_RX_DELAY_SEL_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_GMAC1_CTL_RESERVED5_RW (0x03 << 6)
   #define GLOBALREG_GMAC1_CTL_RESERVED5_SHIFT 6
   /*
   * PHY interface select
   * 0 = MII
   * 1 = RGMII
   * 2 = RMII
   * 3 = Reserved
   */
   #define GLOBALREG_GMAC1_CTL_GMAC1_PHY_INTF_SEL_RW (0x03 << 4)
   #define GLOBALREG_GMAC1_CTL_GMAC1_PHY_INTF_SEL_SHIFT 4
   /*
   * Whether bus accesses are cacheable.
   * 0 = non-cacheable
   * 1 = cacheable
   */
   #define GLOBALREG_GMAC1_CTL_GMAC1_HPROT_CACHEABLE_RW (0x01 << 3)
   #define GLOBALREG_GMAC1_CTL_GMAC1_HPROT_CACHEABLE_SHIFT 3
   /*
   * Whether bus accesses are bufferable.
   * 0 = non-bufferable
   * 1 = bufferable
   */
   #define GLOBALREG_GMAC1_CTL_GMAC1_HPROT_BUFFERABLE_RW (0x01 << 2)
   #define GLOBALREG_GMAC1_CTL_GMAC1_HPROT_BUFFERABLE_SHIFT 2
   /*
   * Whether bus accesses are privileged or user.
   * 0 = user
   * 1 = privileged
   */
   #define GLOBALREG_GMAC1_CTL_GMAC1_HPROT_PRIVILEGED_RW (0x01 << 1)
   #define GLOBALREG_GMAC1_CTL_GMAC1_HPROT_PRIVILEGED_SHIFT 1
   /*
   * Whether bus accesses are data or opcode.
   * 0 = opcode
   * 1 = data
   */
   #define GLOBALREG_GMAC1_CTL_GMAC1_HPROT_DATA_RW (0x01 << 0)
   #define GLOBALREG_GMAC1_CTL_GMAC1_HPROT_DATA_SHIFT 0
   /*
   * Host Processor Control
   */
   #define GLOBALREG_HOST_CTL_REG1  (GLOBALREG_BASE_UNIT1 + 0x308)
   /*
   * Reserved
   */
   #define GLOBALREG_HOST_CTL_RESERVED_RW (0x07fffff << 9)
   #define GLOBALREG_HOST_CTL_RESERVED_SHIFT 9
   /*
   * When set, disables the burst modification logic for the DMA controller's accesse
   * s to main memory. This logic lengthens bursts under certain conditions, which im
   * proves performance.
   */
   #define GLOBALREG_HOST_CTL_DMAC_PMAN_BMOD_DISABLE_RW (0x01 << 8)
   #define GLOBALREG_HOST_CTL_DMAC_PMAN_BMOD_DISABLE_SHIFT 8
   /*
   * When set, disables the burst modification logic for the DMA controller's ACP por
   * t accesses. This logic lengthens bursts under certain conditions, which improves
   *  performance.
   */
   #define GLOBALREG_HOST_CTL_DMAC_ACP_BMOD_DISABLE_RW (0x01 << 7)
   #define GLOBALREG_HOST_CTL_DMAC_ACP_BMOD_DISABLE_SHIFT 7
   /*
   * Controls the out-of-reset default exception handling state:
   * 0 = ARM mode
   * 1 = Thumb mode
   * This bit is only sampled during reset, and sets the initial state of SCTLR.TE.
   */
   #define GLOBALREG_HOST_CTL_HOST_TEINIT_RW (0x01 << 6)
   #define GLOBALREG_HOST_CTL_HOST_TEINIT_SHIFT 6
   /*
   * Host processor non-maskable FIQ configuration
   * 0 = FIQ interrupt is maskable, 1 = FIQ interrupt is non-maskable
   * Only takes effect after a host processor reset.
   */
   #define GLOBALREG_HOST_CTL_HOST_CFGNMFI_RW (0x01 << 5)
   #define GLOBALREG_HOST_CTL_HOST_CFGNMFI_SHIFT 5
   /*
   * Host processor endianness:
   * 0 = little endian, 1 = big endian
   * Only takes effect after a host processor reset.
   */
   #define GLOBALREG_HOST_CTL_HOST_ENDIAN_RW (0x01 << 4)
   #define GLOBALREG_HOST_CTL_HOST_ENDIAN_SHIFT 4
   /*
   * Controls the location of the host processor exception vectors after reset, and t
   * he location of the first instruction executed after reset is released.
   * 0 = exception vectors start at 0x00000000
   * 1 = exception vectors start at 0xffff0000
   * This bit is only sampled during reset, and sets the initial state of SCTLR.V.
   */
   #define GLOBALREG_HOST_CTL_HOST_VINITHI_RW (0x01 << 3)
   #define GLOBALREG_HOST_CTL_HOST_VINITHI_SHIFT 3
   /*
   * Host Processor Maximum Clock Latency
   */
   #define GLOBALREG_HOST_CTL_HOST_MAXCLKLATENCY_RW (0x07 << 0)
   #define GLOBALREG_HOST_CTL_HOST_MAXCLKLATENCY_SHIFT 0
   /*
   * Typhoon Control
   */
   #define GLOBALREG_TYPHOON_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x30c)
   /*
   * Reserved
   */
   #define GLOBALREG_TYPHOON_CTRL_RESERVED_RW (0x07fffffff << 1)
   #define GLOBALREG_TYPHOON_CTRL_RESERVED_SHIFT 1
   /*
   * direct tv mode
   */
   #define GLOBALREG_TYPHOON_CTRL_DIRECT_TV_MODE_RW (0x01 << 0)
   #define GLOBALREG_TYPHOON_CTRL_DIRECT_TV_MODE_SHIFT 0
   /*
   * Auxillary trigger in connections control
   */
   #define GLOBALREG_CROSS_TRIG_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x310)
   /*
   * Reserved
   */
   #define GLOBALREG_CROSS_TRIG_CTRL_RESERVED_RW (0x03fffffff << 2)
   #define GLOBALREG_CROSS_TRIG_CTRL_RESERVED_SHIFT 2
   /*
   * selects the function, which is either the debug interrupt from the AV GIC, or th
   * e FMVD Trimedia's data breakpoint bit 0. 1 -- debug intr ;0 -- FMVD Trimedia's d
   * ata breakpoint bit 0
   */
   #define GLOBALREG_CROSS_TRIG_CTRL_CTITRIGIN2_7_SEL_RW (0x01 << 1)
   #define GLOBALREG_CROSS_TRIG_CTRL_CTITRIGIN2_7_SEL_SHIFT 1
   /*
   * selects the function, which is either the debug interrupt from the AV GIC, or th
   * e Audio Trimedia's data breakpoint bit 0. 1 -- debug intr ;0 -- Audio Trimedia's
   *  data breakpoint bit 0
   */
   #define GLOBALREG_CROSS_TRIG_CTRL_CTITRIGIN2_5_SEL_RW (0x01 << 0)
   #define GLOBALREG_CROSS_TRIG_CTRL_CTITRIGIN2_5_SEL_SHIFT 0
   /*
   * Slave address bits for IIC DTL
   */
   #define GLOBALREG_IIC_SLAVE_ADDR_REG1  (GLOBALREG_BASE_UNIT1 + 0x314)
   /*
   * Reserved
   */
   #define GLOBALREG_IIC_SLAVE_ADDR_RESERVED_RW (0x0ffffff << 8)
   #define GLOBALREG_IIC_SLAVE_ADDR_RESERVED_SHIFT 8
   /*
   * Slave address used by the IIC
   */
   #define GLOBALREG_IIC_SLAVE_ADDR_IIC_SLAVE_ADDR_RW (0x07f << 1)
   #define GLOBALREG_IIC_SLAVE_ADDR_IIC_SLAVE_ADDR_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_IIC_SLAVE_ADDR_RESERVED2_RW (0x01 << 0)
   #define GLOBALREG_IIC_SLAVE_ADDR_RESERVED2_SHIFT 0
   /*
   * Sata Control
   */
   #define GLOBALREG_SATA_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x318)
   /*
   * Reserved
   */
   #define GLOBALREG_SATA_CTRL_RESERVED_RW (0x07fffffff << 1)
   #define GLOBALREG_SATA_CTRL_RESERVED_SHIFT 1
   /*
   * 0 = DWC_ahsata enabled, 1 = DWC_ahsata disabled (placed under reset)
   */
   #define GLOBALREG_SATA_CTRL_SATA_ENABLE_N_RW (0x01 << 0)
   #define GLOBALREG_SATA_CTRL_SATA_ENABLE_N_SHIFT 0
   /*
   * USB Control
   */
   #define GLOBALREG_USB_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x31c)
   /*
   * Reserved
   */
   #define GLOBALREG_USB_CTRL_RESERVED_RW (0x03ffff << 14)
   #define GLOBALREG_USB_CTRL_RESERVED_SHIFT 14
   /*
   * Spare Control
   */
   #define GLOBALREG_USB_CTRL_USB2_DEV_WAKEUP_N_RW (0x01 << 13)
   #define GLOBALREG_USB_CTRL_USB2_DEV_WAKEUP_N_SHIFT 13
   /*
   * usb control
   */
   #define GLOBALREG_USB_CTRL_USB2_HOST_WAKEUP_N_RW (0x01 << 12)
   #define GLOBALREG_USB_CTRL_USB2_HOST_WAKEUP_N_SHIFT 12
   /*
   * Spare Control
   */
   #define GLOBALREG_USB_CTRL_USB1_DEV_WAKEUP_N_RW (0x01 << 11)
   #define GLOBALREG_USB_CTRL_USB1_DEV_WAKEUP_N_SHIFT 11
   /*
   * usb control
   */
   #define GLOBALREG_USB_CTRL_USB1_HOST_WAKEUP_N_RW (0x01 << 10)
   #define GLOBALREG_USB_CTRL_USB1_HOST_WAKEUP_N_SHIFT 10
   /*
   * Spare Control
   */
   #define GLOBALREG_USB_CTRL_USB0_DEV_WAKEUP_N_RW (0x01 << 9)
   #define GLOBALREG_USB_CTRL_USB0_DEV_WAKEUP_N_SHIFT 9
   /*
   * usb control
   */
   #define GLOBALREG_USB_CTRL_USB0_HOST_WAKEUP_N_RW (0x01 << 8)
   #define GLOBALREG_USB_CTRL_USB0_HOST_WAKEUP_N_SHIFT 8
   /*
   * Drive VBUS polarity select for usb2 core. The default polarity of vbusdrive is a
   * ctive high. Setting this bit to 1 will invert the polarity of vbusdrive.
   */
   #define GLOBALREG_USB_CTRL_USB2_VBUSDRIVE_POL_SEL_RW (0x01 << 7)
   #define GLOBALREG_USB_CTRL_USB2_VBUSDRIVE_POL_SEL_SHIFT 7
   /*
   * Drive VBUS polarity select for usb1 core. The default polarity of vbusdrive is a
   * ctive high. Setting this bit to 1 will invert the polarity of vbusdrive.
   */
   #define GLOBALREG_USB_CTRL_USB1_VBUSDRIVE_POL_SEL_RW (0x01 << 6)
   #define GLOBALREG_USB_CTRL_USB1_VBUSDRIVE_POL_SEL_SHIFT 6
   /*
   * Drive VBUS polarity select for usb0 core. The default polarity of vbusdrive is a
   * ctive high. Setting this bit to 1 will invert the polarity of vbusdrive.
   */
   #define GLOBALREG_USB_CTRL_USB0_VBUSDRIVE_POL_SEL_RW (0x01 << 5)
   #define GLOBALREG_USB_CTRL_USB0_VBUSDRIVE_POL_SEL_SHIFT 5
   /*
   * VBUS powerfault polarity select for usb2 core. The default polarity of vbusfault
   *  is active low. Setting this bit to1 will invert the polarity of vbusfault.
   */
   #define GLOBALREG_USB_CTRL_USB2_VBUSFAULT_POL_SEL_RW (0x01 << 4)
   #define GLOBALREG_USB_CTRL_USB2_VBUSFAULT_POL_SEL_SHIFT 4
   /*
   * VBUS powerfault polarity select for usb1 core. The default polarity of vbusfault
   *  is active low. Setting this bit to1 will invert the polarity of vbusfault.
   */
   #define GLOBALREG_USB_CTRL_USB1_VBUSFAULT_POL_SEL_RW (0x01 << 3)
   #define GLOBALREG_USB_CTRL_USB1_VBUSFAULT_POL_SEL_SHIFT 3
   /*
   * VBUS powerfault polarity select for usb0 core. The default polarity of vbusfault
   *  is active low. Setting this bit to1 will invert the polarity of vbusfault.
   */
   #define GLOBALREG_USB_CTRL_USB0_VBUSFAULT_POL_SEL_RW (0x01 << 2)
   #define GLOBALREG_USB_CTRL_USB0_VBUSFAULT_POL_SEL_SHIFT 2
   /*
   * Reserved
   */
   #define GLOBALREG_USB_CTRL_RESERVED13_RW (0x01 << 1)
   #define GLOBALREG_USB_CTRL_RESERVED13_SHIFT 1
   /*
   * Reserved
   */
   #define GLOBALREG_USB_CTRL_RESERVED14_RW (0x01 << 0)
   #define GLOBALREG_USB_CTRL_RESERVED14_SHIFT 0
   /*
   * Accelerator Coherency Port Attributes 0
   */
   #define GLOBALREG_REG_ACP_ATTR0_REG1  (GLOBALREG_BASE_UNIT1 + 0x320)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR0_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_REG_ACP_ATTR0_RESERVED_SHIFT 27
   /*
   * ACP write port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR0_ACP_WR_ATTRIBUTES0_RW (0x07ff << 16)
   #define GLOBALREG_REG_ACP_ATTR0_ACP_WR_ATTRIBUTES0_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR0_RESERVED2_RW (0x01f << 11)
   #define GLOBALREG_REG_ACP_ATTR0_RESERVED2_SHIFT 11
   /*
   * ACP read port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR0_ACP_RD_ATTRIBUTES0_RW (0x07ff << 0)
   #define GLOBALREG_REG_ACP_ATTR0_ACP_RD_ATTRIBUTES0_SHIFT 0
   /*
   * Accelerator Coherency Port Attributes 1
   */
   #define GLOBALREG_REG_ACP_ATTR1_REG1  (GLOBALREG_BASE_UNIT1 + 0x324)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR1_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_REG_ACP_ATTR1_RESERVED_SHIFT 27
   /*
   * ACP write port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR1_ACP_WR_ATTRIBUTES1_RW (0x07ff << 16)
   #define GLOBALREG_REG_ACP_ATTR1_ACP_WR_ATTRIBUTES1_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR1_RESERVED2_RW (0x01f << 11)
   #define GLOBALREG_REG_ACP_ATTR1_RESERVED2_SHIFT 11
   /*
   * ACP read port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR1_ACP_RD_ATTRIBUTES1_RW (0x07ff << 0)
   #define GLOBALREG_REG_ACP_ATTR1_ACP_RD_ATTRIBUTES1_SHIFT 0
   /*
   * Accelerator Coherency Port Attributes 2
   */
   #define GLOBALREG_REG_ACP_ATTR2_REG1  (GLOBALREG_BASE_UNIT1 + 0x328)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR2_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_REG_ACP_ATTR2_RESERVED_SHIFT 27
   /*
   * ACP write port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR2_ACP_WR_ATTRIBUTES2_RW (0x07ff << 16)
   #define GLOBALREG_REG_ACP_ATTR2_ACP_WR_ATTRIBUTES2_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR2_RESERVED2_RW (0x01f << 11)
   #define GLOBALREG_REG_ACP_ATTR2_RESERVED2_SHIFT 11
   /*
   * ACP read port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR2_ACP_RD_ATTRIBUTES2_RW (0x07ff << 0)
   #define GLOBALREG_REG_ACP_ATTR2_ACP_RD_ATTRIBUTES2_SHIFT 0
   /*
   * Accelerator Coherency Port Attributes 3
   */
   #define GLOBALREG_REG_ACP_ATTR3_REG1  (GLOBALREG_BASE_UNIT1 + 0x32c)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR3_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_REG_ACP_ATTR3_RESERVED_SHIFT 27
   /*
   * ACP write port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR3_ACP_WR_ATTRIBUTES3_RW (0x07ff << 16)
   #define GLOBALREG_REG_ACP_ATTR3_ACP_WR_ATTRIBUTES3_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR3_RESERVED2_RW (0x01f << 11)
   #define GLOBALREG_REG_ACP_ATTR3_RESERVED2_SHIFT 11
   /*
   * ACP read port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR3_ACP_RD_ATTRIBUTES3_RW (0x07ff << 0)
   #define GLOBALREG_REG_ACP_ATTR3_ACP_RD_ATTRIBUTES3_SHIFT 0
   /*
   * Accelerator Coherency Port Attributes 4
   */
   #define GLOBALREG_REG_ACP_ATTR4_REG1  (GLOBALREG_BASE_UNIT1 + 0x330)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR4_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_REG_ACP_ATTR4_RESERVED_SHIFT 27
   /*
   * ACP write port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR4_ACP_WR_ATTRIBUTES4_RW (0x07ff << 16)
   #define GLOBALREG_REG_ACP_ATTR4_ACP_WR_ATTRIBUTES4_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR4_RESERVED2_RW (0x01f << 11)
   #define GLOBALREG_REG_ACP_ATTR4_RESERVED2_SHIFT 11
   /*
   * ACP read port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR4_ACP_RD_ATTRIBUTES4_RW (0x07ff << 0)
   #define GLOBALREG_REG_ACP_ATTR4_ACP_RD_ATTRIBUTES4_SHIFT 0
   /*
   * Accelerator Coherency Port Attributes 5
   */
   #define GLOBALREG_REG_ACP_ATTR5_REG1  (GLOBALREG_BASE_UNIT1 + 0x334)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR5_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_REG_ACP_ATTR5_RESERVED_SHIFT 27
   /*
   * ACP write port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR5_ACP_WR_ATTRIBUTES5_RW (0x07ff << 16)
   #define GLOBALREG_REG_ACP_ATTR5_ACP_WR_ATTRIBUTES5_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR5_RESERVED2_RW (0x01f << 11)
   #define GLOBALREG_REG_ACP_ATTR5_RESERVED2_SHIFT 11
   /*
   * ACP read port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR5_ACP_RD_ATTRIBUTES5_RW (0x07ff << 0)
   #define GLOBALREG_REG_ACP_ATTR5_ACP_RD_ATTRIBUTES5_SHIFT 0
   /*
   * Accelerator Coherency Port Attributes 6
   */
   #define GLOBALREG_REG_ACP_ATTR6_REG1  (GLOBALREG_BASE_UNIT1 + 0x338)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR6_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_REG_ACP_ATTR6_RESERVED_SHIFT 27
   /*
   * ACP write port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR6_ACP_WR_ATTRIBUTES6_RW (0x07ff << 16)
   #define GLOBALREG_REG_ACP_ATTR6_ACP_WR_ATTRIBUTES6_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR6_RESERVED2_RW (0x01f << 11)
   #define GLOBALREG_REG_ACP_ATTR6_RESERVED2_SHIFT 11
   /*
   * ACP read port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR6_ACP_RD_ATTRIBUTES6_RW (0x07ff << 0)
   #define GLOBALREG_REG_ACP_ATTR6_ACP_RD_ATTRIBUTES6_SHIFT 0
   /*
   * Accelerator Coherency Port Attributes 7
   */
   #define GLOBALREG_REG_ACP_ATTR7_REG1  (GLOBALREG_BASE_UNIT1 + 0x33c)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR7_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_REG_ACP_ATTR7_RESERVED_SHIFT 27
   /*
   * ACP write port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR7_ACP_WR_ATTRIBUTES7_RW (0x07ff << 16)
   #define GLOBALREG_REG_ACP_ATTR7_ACP_WR_ATTRIBUTES7_SHIFT 16
   /*
   * Reserved
   */
   #define GLOBALREG_REG_ACP_ATTR7_RESERVED2_RW (0x01f << 11)
   #define GLOBALREG_REG_ACP_ATTR7_RESERVED2_SHIFT 11
   /*
   * ACP read port attributes
   */
   #define GLOBALREG_REG_ACP_ATTR7_ACP_RD_ATTRIBUTES7_RW (0x07ff << 0)
   #define GLOBALREG_REG_ACP_ATTR7_ACP_RD_ATTRIBUTES7_SHIFT 0
   /*
   * Host Processor Timestamp Control
   */
   #define GLOBALREG_REG_HOST_TS_REG1  (GLOBALREG_BASE_UNIT1 + 0x340)
   /*
   * This mask is OR'ed with bits 31:8 of the timestamp value. When the result is all
   *  1's, and timestamp generation is enabled, then a timestamp will be inserted in 
   * the trace output.
   */
   #define GLOBALREG_REG_HOST_TS_HOST_PTM_TS_SYNC_MASK_RW (0x0ffffff << 8)
   #define GLOBALREG_REG_HOST_TS_HOST_PTM_TS_SYNC_MASK_SHIFT 8
   /*
   * Reserved
   */
   #define GLOBALREG_REG_HOST_TS_RESERVED_RW (0x07f << 1)
   #define GLOBALREG_REG_HOST_TS_RESERVED_SHIFT 1
   /*
   * Enables generation of timestamps in the trace output when debugging
   */
   #define GLOBALREG_REG_HOST_TS_HOST_PTM_TS_SYNC_EN_RW (0x01 << 0)
   #define GLOBALREG_REG_HOST_TS_HOST_PTM_TS_SYNC_EN_SHIFT 0
   /*
   * Noise Sensor Control
   */
   #define GLOBALREG_REG_NOISE_CONTROL_REG1  (GLOBALREG_BASE_UNIT1 + 0x380)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_NOISE_CONTROL_RESERVED_RW (0x0fffff << 12)
   #define GLOBALREG_REG_NOISE_CONTROL_RESERVED_SHIFT 12
   /*
   * bit 11 - Reserved
   * bit 10 - reset - reset noise sensor
   * bit 9:2 dacsel[7:0] - DAC Reference Voltage control
   * bit 1:0 - muxsel[1:0] - sets detection type
   */
   #define GLOBALREG_REG_NOISE_CONTROL_REG_NOISE_CONTROL_RW (0x0fff << 0)
   #define GLOBALREG_REG_NOISE_CONTROL_REG_NOISE_CONTROL_SHIFT 0
   /*
   * Temperature Sensor Control
   */
   #define GLOBALREG_REG_TEMP_CONTROL_REG1  (GLOBALREG_BASE_UNIT1 + 0x384)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_TEMP_CONTROL_RESERVED_RW (0x01ffffff << 7)
   #define GLOBALREG_REG_TEMP_CONTROL_RESERVED_SHIFT 7
   /*
   * bit 6 - Reserved
   * bit 5:0 - temp_sel_enc - 6 to 40 bit one-hot encoder to select Temperature Thres
   * hold
   */
   #define GLOBALREG_REG_TEMP_CONTROL_REG_TEMP_CONTROL_RW (0x07f << 0)
   #define GLOBALREG_REG_TEMP_CONTROL_REG_TEMP_CONTROL_SHIFT 0
   /*
   * SIST measurement results
   */
   #define GLOBALREG_REG_SENSOR_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x388)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_SENSOR_CTRL_RESERVED_RW (0x03fff << 18)
   #define GLOBALREG_REG_SENSOR_CTRL_RESERVED_SHIFT 18
   /*
   * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
   * 000 : Selects TCB control of sensor to go to PLL_OUT
   * 001 : Noise sensor is outputted
   * 010 : Temperature sensor is outputted
   * 011 : Reserved
   * 100 : Reserved
   * 101 : LVT Ringo is ouputted
   * 110 : SVT Ringo is outputted
   * 111 : Reserved
   */
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_5_CTRL_RW (0x07 << 15)
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_5_CTRL_SHIFT 15
   /*
   * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
   * 000 : Selects TCB control of sensor to go to PLL_OUT
   * 001 : Noise sensor is outputted
   * 010 : Temperature sensor is outputted
   * 011 : Reserved
   * 100 : Reserved
   * 101 : LVT Ringo is ouputted
   * 110 : SVT Ringo is outputted
   * 111 : Reserved
   */
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_4_CTRL_RW (0x07 << 12)
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_4_CTRL_SHIFT 12
   /*
   * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
   * 000 : Selects TCB control of sensor to go to PLL_OUT
   * 001 : Noise sensor is outputted
   * 010 : Temperature sensor is outputted
   * 011 : Reserved
   * 100 : Reserved
   * 101 : LVT Ringo is ouputted
   * 110 : SVT Ringo is outputted
   * 111 : Reserved
   */
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_3_CTRL_RW (0x07 << 9)
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_3_CTRL_SHIFT 9
   /*
   * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
   * 000 : Selects TCB control of sensor to go to PLL_OUT
   * 001 : Noise sensor is outputted
   * 010 : Temperature sensor is outputted
   * 011 : Reserved
   * 100 : Reserved
   * 101 : LVT Ringo is ouputted
   * 110 : SVT Ringo is outputted
   * 111 : Reserved
   */
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_2_CTRL_RW (0x07 << 6)
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_2_CTRL_SHIFT 6
   /*
   * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
   * 000 : Selects TCB control of sensor to go to PLL_OUT
   * 001 : Noise sensor is outputted
   * 010 : Temperature sensor is outputted
   * 011 : Reserved
   * 100 : Reserved
   * 101 : LVT Ringo is ouputted
   * 110 : SVT Ringo is outputted
   * 111 : Reserved
   */
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_1_CTRL_RW (0x07 << 3)
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_1_CTRL_SHIFT 3
   /*
   * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
   * 000 : Selects TCB control of sensor to go to PLL_OUT
   * 001 : Noise sensor is outputted
   * 010 : Temperature sensor is outputted
   * 011 : Reserved
   * 100 : Reserved
   * 101 : LVT Ringo is ouputted
   * 110 : SVT Ringo is outputted
   * 111 : Reserved
   */
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_0_CTRL_RW (0x07 << 0)
   #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_0_CTRL_SHIFT 0
   /*
   * Miscellaneous IO pin control
   */
   #define GLOBALREG_IO_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x38c)
   /*
   * Reserved
   */
   #define GLOBALREG_IO_CTRL_RESERVED_RW (0x07fffffff << 1)
   #define GLOBALREG_IO_CTRL_RESERVED_SHIFT 1
   /*
   * PLL out enable
   */
   #define GLOBALREG_IO_CTRL_PLL_OUT_EN_RW (0x01 << 0)
   #define GLOBALREG_IO_CTRL_PLL_OUT_EN_SHIFT 0
   /*
   * ADSP Trimedia powerdown request
   */
   #define GLOBALREG_ADSP_TM_PWRDWN_CONTROL_REG1  (GLOBALREG_BASE_UNIT1 + 0x400)
   /*
   * Reserved
   */
   #define GLOBALREG_ADSP_TM_PWRDWN_CONTROL_RESERVED_RW (0x07fffffff << 1)
   #define GLOBALREG_ADSP_TM_PWRDWN_CONTROL_RESERVED_SHIFT 1
   /*
   * ADSP Trimedia powerdown request:
   * 0 = Do not request a Trimedia powerdown.
   * 1 = Request a Trimedia powerdown.
   */
   #define GLOBALREG_ADSP_TM_PWRDWN_CONTROL_ADSP_TM_PWRDWN_REQ_RW (0x01 << 0)
   #define GLOBALREG_ADSP_TM_PWRDWN_CONTROL_ADSP_TM_PWRDWN_REQ_SHIFT 0
   /*
   * ADSP Trimedia powerdown acknowledge
   */
   #define GLOBALREG_ADSP_TM_PWRDWN_STATUS_REG1  (GLOBALREG_BASE_UNIT1 + 0x404)
   /*
   * Reserved
   */
   #define GLOBALREG_ADSP_TM_PWRDWN_STATUS_RESERVED_R (0x07fffffff << 1)
   #define GLOBALREG_ADSP_TM_PWRDWN_STATUS_RESERVED_SHIFT 1
   /*
   * 0 = ADSP Trimedia does not acknowledge powerdown
   * request.
   * 1 = ADSP Trimedia acknowledges powerdown request.
   */
   #define GLOBALREG_ADSP_TM_PWRDWN_STATUS_ADSP_TM_PWRDWN_ACK_R (0x01 << 0)
   #define GLOBALREG_ADSP_TM_PWRDWN_STATUS_ADSP_TM_PWRDWN_ACK_SHIFT 0
   /*
   * ADSP Trimedia miscellaneous control
   */
   #define GLOBALREG_ADSP_TM_MISC_REG1  (GLOBALREG_BASE_UNIT1 + 0x408)
   /*
   * Reserved
   */
   #define GLOBALREG_ADSP_TM_MISC_RESERVED_RW (0x0fffffff << 4)
   #define GLOBALREG_ADSP_TM_MISC_RESERVED_SHIFT 4
   /*
   * When de-asserted, prohibits hardware initiated
   * prefetch.
   */
   #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_LS_PREF_ALLOWED_RW (0x01 << 3)
   #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_LS_PREF_ALLOWED_SHIFT 3
   /*
   * When asserted, allows ADSP TM to change its own memory apertures (DRAM and APERT
   * URE 1). The value on this pin should be set before the ADSP TM reset is de-asser
   * ted and may not be changed when ADSP TM is running.
   */
   #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_APERT_MODIFIABLE_RW (0x01 << 2)
   #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_APERT_MODIFIABLE_SHIFT 2
   /*
   * When de-asserted, prohibits the execution of non-aligned load and store operatio
   * ns.
   */
   #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_NONAL_ALLOWED_RW (0x01 << 1)
   #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_NONAL_ALLOWED_SHIFT 1
   /*
   * When asserted, does not allow external devices to access most of the ADSP TM int
   * ernal MMIO registers.
   */
   #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_DEBUG_NOT_ALLOWED_RW (0x01 << 0)
   #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_DEBUG_NOT_ALLOWED_SHIFT 0
   /*
   * ADSP Trimedia observe signals
   */
   #define GLOBALREG_ADSP_TM_OBSERVE_REG1  (GLOBALREG_BASE_UNIT1 + 0x40c)
   /*
   * Reserved
   */
   #define GLOBALREG_ADSP_TM_OBSERVE_RESERVED_R (0x0ffffff << 8)
   #define GLOBALREG_ADSP_TM_OBSERVE_RESERVED_SHIFT 8
   /*
   * ADSP Trimedia observe signal
   */
   #define GLOBALREG_ADSP_TM_OBSERVE_ADSP_TM_OBSERVE_R (0x0ff << 0)
   #define GLOBALREG_ADSP_TM_OBSERVE_ADSP_TM_OBSERVE_SHIFT 0
   /*
   * VDSP Trimedia powerdown request
   */
   #define GLOBALREG_VDSP_TM_PWRDWN_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x420)
   /*
   * Reserved
   */
   #define GLOBALREG_VDSP_TM_PWRDWN_CTRL_RESERVED_RW (0x07fffffff << 1)
   #define GLOBALREG_VDSP_TM_PWRDWN_CTRL_RESERVED_SHIFT 1
   /*
   * VDSP Trimedia powerdown request:
   * 0 = Do not request a Trimedia powerdown.
   * 1 = Request a Trimedia powerdown.
   */
   #define GLOBALREG_VDSP_TM_PWRDWN_CTRL_VDSP_TM_PWRDWN_REQ_RW (0x01 << 0)
   #define GLOBALREG_VDSP_TM_PWRDWN_CTRL_VDSP_TM_PWRDWN_REQ_SHIFT 0
   /*
   * VDSP Trimedia powerdown acknowledge
   */
   #define GLOBALREG_VDSP_TM_PWRDWN_STATUS_REG1  (GLOBALREG_BASE_UNIT1 + 0x424)
   /*
   * Reserved
   */
   #define GLOBALREG_VDSP_TM_PWRDWN_STATUS_RESERVED_R (0x07fffffff << 1)
   #define GLOBALREG_VDSP_TM_PWRDWN_STATUS_RESERVED_SHIFT 1
   /*
   * 0 = VDSP Trimedia does not acknowledge powerdown request.
   * 1 = VDSP Trimedia acknowledges powerdown request.
   */
   #define GLOBALREG_VDSP_TM_PWRDWN_STATUS_VDSP_TM_PWRDWN_ACK_R (0x01 << 0)
   #define GLOBALREG_VDSP_TM_PWRDWN_STATUS_VDSP_TM_PWRDWN_ACK_SHIFT 0
   /*
   * VDSP Trimedia miscellaneous control
   */
   #define GLOBALREG_VDSP_TM_MISC_REG1  (GLOBALREG_BASE_UNIT1 + 0x428)
   /*
   * Reserved
   */
   #define GLOBALREG_VDSP_TM_MISC_RESERVED_RW (0x0fffffff << 4)
   #define GLOBALREG_VDSP_TM_MISC_RESERVED_SHIFT 4
   /*
   * When de-asserted, prohibits hardware initiated
   * prefetch.
   */
   #define GLOBALREG_VDSP_TM_MISC_VDSP_TM_LS_PREF_ALLOWED_RW (0x01 << 3)
   #define GLOBALREG_VDSP_TM_MISC_VDSP_TM_LS_PREF_ALLOWED_SHIFT 3
   /*
   * When asserted, allows VDSP TM to change its own memory apertures (DRAM and APERT
   * URE 1). The value on this pin should be set before the VDSP TM reset is de-asser
   * ted and may not be changed when VDSP TM is running.
   */
   #define GLOBALREG_VDSP_TM_MISC_VDSP_TM_APERT_MODIFIABLE_RW (0x01 << 2)
   #define GLOBALREG_VDSP_TM_MISC_VDSP_TM_APERT_MODIFIABLE_SHIFT 2
   /*
   * When de-asserted, prohibits the execution of non-aligned load and store operatio
   * ns.
   */
   #define GLOBALREG_VDSP_TM_MISC_VDSP_TM_NONAL_ALLOWED_RW (0x01 << 1)
   #define GLOBALREG_VDSP_TM_MISC_VDSP_TM_NONAL_ALLOWED_SHIFT 1
   /*
   * When asserted, does not allow external devices to access most of the VDSP TM int
   * ernal MMIO registers.
   */
   #define GLOBALREG_VDSP_TM_MISC_VDSP_TM_DEBUG_NOT_ALLOWED_RW (0x01 << 0)
   #define GLOBALREG_VDSP_TM_MISC_VDSP_TM_DEBUG_NOT_ALLOWED_SHIFT 0
   /*
   * VDSP Trimedia observe signals
   */
   #define GLOBALREG_VDSP_TM_OBSERVE_REG1  (GLOBALREG_BASE_UNIT1 + 0x42c)
   /*
   * Reserved
   */
   #define GLOBALREG_VDSP_TM_OBSERVE_RESERVED_R (0x0ffffff << 8)
   #define GLOBALREG_VDSP_TM_OBSERVE_RESERVED_SHIFT 8
   /*
   * VDSP Trimedia observe signal
   */
   #define GLOBALREG_VDSP_TM_OBSERVE_VDSP_TM_OBSERVE_R (0x0ff << 0)
   #define GLOBALREG_VDSP_TM_OBSERVE_VDSP_TM_OBSERVE_SHIFT 0
   /*
   * The I/O PAD cell associated with the hardware modem can be controlled /observed 
   * using GPIO registers and an sreg MODEM CSR. The GPIO registers are used to contr
   * ol/observe PWRCLK BUFFER pads C, I, OEN ports. MODEM CSR is used to control/obse
   * rve DIB
   * DATA RECEIVER (PDN, IEN, C) ports and controls the PWRCLK BUFFER pads (gpio_mode
   *  and d[5:0]) ports Table
   */
   #define GLOBALREG_MODEM_REG1  (GLOBALREG_BASE_UNIT1 + 0x430)
   /*
   * Reserved
   */
   #define GLOBALREG_MODEM_RESERVED_RW (0x03fffff << 10)
   #define GLOBALREG_MODEM_RESERVED_SHIFT 10
   /*
   * DIB DATA RECEIVER PAD data
   */
   #define GLOBALREG_MODEM_HAL_GPIO_DIFFRX_RW (0x01 << 9)
   #define GLOBALREG_MODEM_HAL_GPIO_DIFFRX_SHIFT 9
   /*
   * DIB DATA RECEIVER PAD enable. 1 = enabled
   */
   #define GLOBALREG_MODEM_HAL_GPIO_DIFFEN_RW (0x01 << 8)
   #define GLOBALREG_MODEM_HAL_GPIO_DIFFEN_SHIFT 8
   /*
   * DIB DATA RECEIVER Power On. 1 = Power On.
   */
   #define GLOBALREG_MODEM_HAL_GPIO_DIFFPDN_RW (0x01 << 7)
   #define GLOBALREG_MODEM_HAL_GPIO_DIFFPDN_SHIFT 7
   /*
   * Drive strength for PWRCLK BUFFER PADS
   */
   #define GLOBALREG_MODEM_HAL_GPIO_DRV_RW (0x03f << 1)
   #define GLOBALREG_MODEM_HAL_GPIO_DRV_SHIFT 1
   /*
   * Select HAL / GPIO mode. 0 = HAL, 1 = GPIO
   */
   #define GLOBALREG_MODEM_HAL_GPIO_MODE_RW (0x01 << 0)
   #define GLOBALREG_MODEM_HAL_GPIO_MODE_SHIFT 0
   /*
   * Pads configuration Register 0
   */
   #define GLOBALREG_PAD_CONFIGURATION_0_REG  (GLOBALREG_BASE_UNIT1 + 0x434)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_FSCL1_EF_RW (0x01 << 31)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_FSCL1_EF_SHIFT 31
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_FSCL2_EF_RW (0x01 << 30)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_FSCL2_EF_SHIFT 30
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_FSDA1_EF_RW (0x01 << 29)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_FSDA1_EF_SHIFT 29
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_FSDA2_EF_RW (0x01 << 28)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_FSDA2_EF_SHIFT 28
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_HDMIHTPLG_EPD_RW (0x01 << 27)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_HDMIHTPLG_EPD_SHIFT 27
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO110_RGMII0TXEN_EHS0_RW (0x01 << 26)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO110_RGMII0TXEN_EHS0_SHIFT 26
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO110_RGMII0TXEN_EHS1_RW (0x01 << 25)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO110_RGMII0TXEN_EHS1_SHIFT 25
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO111_RGMII0TXD3_EHS0_RW (0x01 << 24)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO111_RGMII0TXD3_EHS0_SHIFT 24
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO111_RGMII0TXD3_EHS1_RW (0x01 << 23)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO111_RGMII0TXD3_EHS1_SHIFT 23
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO112_RGMII0TXD2_EHS0_RW (0x01 << 22)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO112_RGMII0TXD2_EHS0_SHIFT 22
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO112_RGMII0TXD2_EHS1_RW (0x01 << 21)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO112_RGMII0TXD2_EHS1_SHIFT 21
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO113_RGMII0TXD1_EHS0_RW (0x01 << 20)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO113_RGMII0TXD1_EHS0_SHIFT 20
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO113_RGMII0TXD1_EHS1_RW (0x01 << 19)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO113_RGMII0TXD1_EHS1_SHIFT 19
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO114_RGMII0TXD0_EHS0_RW (0x01 << 18)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO114_RGMII0TXD0_EHS0_SHIFT 18
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO114_RGMII0TXD0_EHS1_RW (0x01 << 17)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO114_RGMII0TXD0_EHS1_SHIFT 17
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO115_RGMII0TXCK_EHS0_RW (0x01 << 16)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO115_RGMII0TXCK_EHS0_SHIFT 16
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO115_RGMII0TXCK_EHS1_RW (0x01 << 15)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO115_RGMII0TXCK_EHS1_SHIFT 15
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO197_ETHLED0_DS0_RW (0x01 << 14)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO197_ETHLED0_DS0_SHIFT 14
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO197_ETHLED0_DS1_RW (0x01 << 13)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO197_ETHLED0_DS1_SHIFT 13
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO198_ETHLED1_DS0_RW (0x01 << 12)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO198_ETHLED1_DS0_SHIFT 12
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO198_ETHLED1_DS1_RW (0x01 << 11)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO198_ETHLED1_DS1_SHIFT 11
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO199_ETHLED2_DS0_RW (0x01 << 10)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO199_ETHLED2_DS0_SHIFT 10
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO199_ETHLED2_DS1_RW (0x01 << 9)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_LPIO199_ETHLED2_DS1_SHIFT 9
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO014_SCL3_UART3TX_I2SOUTD3_EF_RW (0x01 << 8)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO014_SCL3_UART3TX_I2SOUTD3_EF_SHIFT 8
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO014_SCL3_UART3TX_I2SOUTD3_EGP_RW (0x01 << 7)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO014_SCL3_UART3TX_I2SOUTD3_EGP_SHIFT 7
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO015_SDA3_UART3RX_I2SOUTD4_EF_RW (0x01 << 6)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO015_SDA3_UART3RX_I2SOUTD4_EF_SHIFT 6
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO015_SDA3_UART3RX_I2SOUTD4_EGP_RW (0x01 << 5)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO015_SDA3_UART3RX_I2SOUTD4_EGP_SHIFT 5
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO016_PWM1_DS0_RW (0x01 << 4)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO016_PWM1_DS0_SHIFT 4
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO016_PWM1_DS1_RW (0x01 << 3)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO016_PWM1_DS1_SHIFT 3
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO024_PWM2_DS0_RW (0x01 << 2)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO024_PWM2_DS0_SHIFT 2
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO024_PWM2_DS1_RW (0x01 << 1)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO024_PWM2_DS1_SHIFT 1
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO146_HS4ERR_USB11VBUSDRIVE_PWM3_DS0_RW (0x01 << 0)
   #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO146_HS4ERR_USB11VBUSDRIVE_PWM3_DS0_SHIFT 0
   /*
   * Pads configuration Register 1
   */
   #define GLOBALREG_PAD_CONFIGURATION_1_REG  (GLOBALREG_BASE_UNIT1 + 0x438)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO146_HS4ERR_USB11VBUSDRIVE_PWM3_DS1_RW (0x01 << 31)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO146_HS4ERR_USB11VBUSDRIVE_PWM3_DS1_SHIFT 31
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO162_RGMII1TXEN_SDCMD_EHS0_RW (0x01 << 30)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO162_RGMII1TXEN_SDCMD_EHS0_SHIFT 30
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO162_RGMII1TXEN_SDCMD_EHS1_RW (0x01 << 29)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO162_RGMII1TXEN_SDCMD_EHS1_SHIFT 29
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO164_RGMII1TXD3_SDDATA3_EHS0_RW (0x01 << 28)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO164_RGMII1TXD3_SDDATA3_EHS0_SHIFT 28
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO164_RGMII1TXD3_SDDATA3_EHS1_RW (0x01 << 27)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO164_RGMII1TXD3_SDDATA3_EHS1_SHIFT 27
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO165_RGMII1TXD2_SDDATA2_EHS0_RW (0x01 << 26)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO165_RGMII1TXD2_SDDATA2_EHS0_SHIFT 26
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO165_RGMII1TXD2_SDDATA2_EHS1_RW (0x01 << 25)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO165_RGMII1TXD2_SDDATA2_EHS1_SHIFT 25
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO176_RGMII1TXD1_SDDATA1_EHS0_RW (0x01 << 24)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO176_RGMII1TXD1_SDDATA1_EHS0_SHIFT 24
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO176_RGMII1TXD1_SDDATA1_EHS1_RW (0x01 << 23)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO176_RGMII1TXD1_SDDATA1_EHS1_SHIFT 23
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO177_SDA2_EF_RW (0x01 << 22)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO177_SDA2_EF_SHIFT 22
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO177_SDA2_EGP_RW (0x01 << 21)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO177_SDA2_EGP_SHIFT 21
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO178_SCL2_EF_RW (0x01 << 20)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO178_SCL2_EF_SHIFT 20
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO178_SCL2_EGP_RW (0x01 << 19)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO178_SCL2_EGP_SHIFT 19
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO179_RGMII1TXD0_SDDATA0_EHS0_RW (0x01 << 18)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO179_RGMII1TXD0_SDDATA0_EHS0_SHIFT 18
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO179_RGMII1TXD0_SDDATA0_EHS1_RW (0x01 << 17)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO179_RGMII1TXD0_SDDATA0_EHS1_SHIFT 17
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO180_RGMII1TXCK_SDCLK_EHS0_RW (0x01 << 16)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO180_RGMII1TXCK_SDCLK_EHS0_SHIFT 16
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO180_RGMII1TXCK_SDCLK_EHS1_RW (0x01 << 15)
   #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO180_RGMII1TXCK_SDCLK_EHS1_SHIFT 15
   #define GLOBALREG_PAD_CONFIGURATION_1_AOD_FSCL0_EF_RW (0x01 << 14)
   #define GLOBALREG_PAD_CONFIGURATION_1_AOD_FSCL0_EF_SHIFT 14
   #define GLOBALREG_PAD_CONFIGURATION_1_AOD_FSDA0_EF_RW (0x01 << 13)
   #define GLOBALREG_PAD_CONFIGURATION_1_AOD_FSDA0_EF_SHIFT 13
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SCL1_ECS_RW (0x01 << 12)
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SCL1_ECS_SHIFT 12
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SCL1_EF_RW (0x01 << 11)
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SCL1_EF_SHIFT 11
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SCL1_EHS_RW (0x01 << 10)
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SCL1_EHS_SHIFT 10
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SDA1_ECS_RW (0x01 << 9)
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SDA1_ECS_SHIFT 9
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SDA1_EF_RW (0x01 << 8)
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SDA1_EF_SHIFT 8
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SDA1_EHS_RW (0x01 << 7)
   #define GLOBALREG_PAD_CONFIGURATION_1_HDMI_SDA1_EHS_SHIFT 7
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO013_SM1RST_HS6SYNC_I2SOUTWS_EPUN_RW (0x01 << 6)
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO013_SM1RST_HS6SYNC_I2SOUTWS_EPUN_SHIFT 6
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM0_RW (0x01 << 5)
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM0_SHIFT 5
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM1_RW (0x01 << 4)
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM1_SHIFT 4
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM2_RW (0x01 << 3)
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM2_SHIFT 3
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM3_RW (0x01 << 2)
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM3_SHIFT 2
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM4_RW (0x01 << 1)
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM4_SHIFT 1
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM5_RW (0x01 << 0)
   #define GLOBALREG_PAD_CONFIGURATION_1_PIO021_DIBP_DSM5_SHIFT 0
   /*
   * Pads configuration Register 2
   */
   #define GLOBALREG_PAD_CONFIGURATION_2_REG  (GLOBALREG_BASE_UNIT1 + 0x43c)
   /*
   * Reserved
   */
   #define GLOBALREG_PAD_CONFIGURATION_2_RESERVED_RW (0x07ffffff << 5)
   #define GLOBALREG_PAD_CONFIGURATION_2_RESERVED_SHIFT 5
   #define GLOBALREG_PAD_CONFIGURATION_2_PIO021_DIBP_DSP0_RW (0x01 << 4)
   #define GLOBALREG_PAD_CONFIGURATION_2_PIO021_DIBP_DSP0_SHIFT 4
   #define GLOBALREG_PAD_CONFIGURATION_2_PIO021_DIBP_DSP1_RW (0x01 << 3)
   #define GLOBALREG_PAD_CONFIGURATION_2_PIO021_DIBP_DSP1_SHIFT 3
   #define GLOBALREG_PAD_CONFIGURATION_2_PIO021_DIBP_DSP2_RW (0x01 << 2)
   #define GLOBALREG_PAD_CONFIGURATION_2_PIO021_DIBP_DSP2_SHIFT 2
   #define GLOBALREG_PAD_CONFIGURATION_2_PIO021_DIBP_DSP3_RW (0x01 << 1)
   #define GLOBALREG_PAD_CONFIGURATION_2_PIO021_DIBP_DSP3_SHIFT 1
   #define GLOBALREG_PAD_CONFIGURATION_2_PIO021_DIBP_DSP4_RW (0x01 << 0)
   #define GLOBALREG_PAD_CONFIGURATION_2_PIO021_DIBP_DSP4_SHIFT 0
   /*
   * Miscellaneous Status
   */
   #define GLOBALREG_REG_MISC_STATUS_REG  (GLOBALREG_BASE_UNIT1 + 0x440)
   /*
   * Reserved
   */
   #define GLOBALREG_REG_MISC_STATUS_RESERVED_R (0x01fffffff << 3)
   #define GLOBALREG_REG_MISC_STATUS_RESERVED_SHIFT 3
   /*
   * When set, indicates that the debugger wants the A9 to be in emulated power-down,
   *  instead of actual power-down (read-only).
   */
   #define GLOBALREG_REG_MISC_STATUS_A9_DBGNOPWRDWN_R (0x01 << 2)
   #define GLOBALREG_REG_MISC_STATUS_A9_DBGNOPWRDWN_SHIFT 2
   /*
   * L2 Cache controller is idle when set (read-only).
   */
   #define GLOBALREG_REG_MISC_STATUS_L2CACHE_IDLE_R (0x01 << 1)
   #define GLOBALREG_REG_MISC_STATUS_L2CACHE_IDLE_SHIFT 1
   /*
   * HDMI Hotplug status (read-only).
   * This register bit reflects the state of the HDMI hotplug input pin.
   */
   #define GLOBALREG_REG_MISC_STATUS_HDMI_HOTPLUG_IN_R (0x01 << 0)
   #define GLOBALREG_REG_MISC_STATUS_HDMI_HOTPLUG_IN_SHIFT 0
   /*
   * Spare Control
   */
   #define GLOBALREG_GLBREG_MISC1_REG  (GLOBALREG_BASE_UNIT1 + 0x500)
   /*
   * Global register spare bits
   */
   #define GLOBALREG_GLBREG_MISC1_GLBREG_MISC1_1_RW (0x07fff << 17)
   #define GLOBALREG_GLBREG_MISC1_GLBREG_MISC1_1_SHIFT 17
   /*
   * When set, enables debug access through CP14.
   */
   #define GLOBALREG_GLBREG_MISC1_DBGSWENABLE_RW (0x01 << 16)
   #define GLOBALREG_GLBREG_MISC1_DBGSWENABLE_SHIFT 16
   /*
   * Global register spare bits
   */
   #define GLOBALREG_GLBREG_MISC1_GLBREG_MISC1_0_RW (0x01fff << 3)
   #define GLOBALREG_GLBREG_MISC1_GLBREG_MISC1_0_SHIFT 3
   #define GLOBALREG_GLBREG_MISC1_ADAC_TEST_CLK_SEL_RW (0x01 << 2)
   #define GLOBALREG_GLBREG_MISC1_ADAC_TEST_CLK_SEL_SHIFT 2
   #define GLOBALREG_GLBREG_MISC1_ADAC_FIFO_BYPASS_RW (0x01 << 1)
   #define GLOBALREG_GLBREG_MISC1_ADAC_FIFO_BYPASS_SHIFT 1
   #define GLOBALREG_GLBREG_MISC1_AUPLL_DIV_UPDATE_RW (0x01 << 0)
   #define GLOBALREG_GLBREG_MISC1_AUPLL_DIV_UPDATE_SHIFT 0
   /*
   * Spare Control
   */
   #define GLOBALREG_GLBREG_MISC2_REG  (GLOBALREG_BASE_UNIT1 + 0x504)
   /*
   * Global register spare bits - all ones
   */
   #define GLOBALREG_GLBREG_MISC2_GLBREG_MISC2_0_RW (0x07 << 29)
   #define GLOBALREG_GLBREG_MISC2_GLBREG_MISC2_0_SHIFT 29
   #define GLOBALREG_GLBREG_MISC2_PIO119_HS2CLK_EHS1_RW (0x01 << 28)
   #define GLOBALREG_GLBREG_MISC2_PIO119_HS2CLK_EHS1_SHIFT 28
   #define GLOBALREG_GLBREG_MISC2_PIO119_HS2CLK_EHS0_RW (0x01 << 27)
   #define GLOBALREG_GLBREG_MISC2_PIO119_HS2CLK_EHS0_SHIFT 27
   #define GLOBALREG_GLBREG_MISC2_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EHS1_RW (0x01 << 26)
   #define GLOBALREG_GLBREG_MISC2_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EHS1_SHIFT 26
   #define GLOBALREG_GLBREG_MISC2_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EHS0_RW (0x01 << 25)
   #define GLOBALREG_GLBREG_MISC2_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EHS0_SHIFT 25
   #define GLOBALREG_GLBREG_MISC2_AOD_SGPIO7_FP0G3_EHS1_RW (0x01 << 24)
   #define GLOBALREG_GLBREG_MISC2_AOD_SGPIO7_FP0G3_EHS1_SHIFT 24
   #define GLOBALREG_GLBREG_MISC2_AOD_SGPIO7_FP0G3_EHS0_RW (0x01 << 23)
   #define GLOBALREG_GLBREG_MISC2_AOD_SGPIO7_FP0G3_EHS0_SHIFT 23
   #define GLOBALREG_GLBREG_MISC2_PIO074_SM1CLK_HS6ERR_I2SOUTD2_EPUN_RW (0x01 << 22)
   #define GLOBALREG_GLBREG_MISC2_PIO074_SM1CLK_HS6ERR_I2SOUTD2_EPUN_SHIFT 22
   #define GLOBALREG_GLBREG_MISC2_PIO074_SM1CLK_HS6ERR_I2SOUTD2_EPD_RW (0x01 << 21)
   #define GLOBALREG_GLBREG_MISC2_PIO074_SM1CLK_HS6ERR_I2SOUTD2_EPD_SHIFT 21
   #define GLOBALREG_GLBREG_MISC2_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EPUN_RW (0x01 << 20)
   #define GLOBALREG_GLBREG_MISC2_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EPUN_SHIFT 20
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EPWR_RW (0x01 << 19)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EPWR_SHIFT 19
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EPUNP_RW (0x01 << 18)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EPUNP_SHIFT 18
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EPUNM_RW (0x01 << 17)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EPUNM_SHIFT 17
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EPDP_RW (0x01 << 16)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EPDP_SHIFT 16
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EPDM_RW (0x01 << 15)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EPDM_SHIFT 15
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_ENZIP_RW (0x01 << 14)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_ENZIP_SHIFT 14
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_ENZIM_RW (0x01 << 13)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_ENZIM_SHIFT 13
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EGPP_RW (0x01 << 12)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EGPP_SHIFT 12
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EGPM_RW (0x01 << 11)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EGPM_SHIFT 11
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EDR_RW (0x01 << 10)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_EDR_SHIFT 10
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EPWR_RW (0x01 << 9)
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EPWR_SHIFT 9
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EPUNP_RW (0x01 << 8)
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EPUNP_SHIFT 8
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EPUNM_RW (0x01 << 7)
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EPUNM_SHIFT 7
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EPDP_RW (0x01 << 6)
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EPDP_SHIFT 6
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EPDM_RW (0x01 << 5)
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EPDM_SHIFT 5
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_ENZIP_RW (0x01 << 4)
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_ENZIP_SHIFT 4
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_ENZIM_RW (0x01 << 3)
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_ENZIM_SHIFT 3
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EDR_RW (0x01 << 2)
   #define GLOBALREG_GLBREG_MISC2_PIO021_DIBP_EDR_SHIFT 2
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_DSP5_RW (0x01 << 1)
   #define GLOBALREG_GLBREG_MISC2_PIO022_DIBN_DSP5_SHIFT 1
   #define GLOBALREG_GLBREG_MISC2_AO_HDMI_CEC_EF_RW (0x01 << 0)
   #define GLOBALREG_GLBREG_MISC2_AO_HDMI_CEC_EF_SHIFT 0
   /*
   * Spare Control
   */
   #define GLOBALREG_GLBREG_MISC3_REG  (GLOBALREG_BASE_UNIT1 + 0x508)
   /*
   * Reserved
   */
   #define GLOBALREG_GLBREG_MISC3_GLBREG_MISC3_RW (0x01ffff << 15)
   #define GLOBALREG_GLBREG_MISC3_GLBREG_MISC3_SHIFT 15
   /*
   * Selects the output for Ethernet LED 2
   */
   #define GLOBALREG_GLBREG_MISC3_ETHLED2_SEL_RW (0x01f << 10)
   #define GLOBALREG_GLBREG_MISC3_ETHLED2_SEL_SHIFT 10
   /*
   * Selects the output for Ethernet LED 1
   */
   #define GLOBALREG_GLBREG_MISC3_ETHLED1_SEL_RW (0x01f << 5)
   #define GLOBALREG_GLBREG_MISC3_ETHLED1_SEL_SHIFT 5
   /*
   * Selects the output for Ethernet LED 0 (description needs to be copied from wiki)
   * 
   */
   #define GLOBALREG_GLBREG_MISC3_ETHLED0_SEL_RW (0x01f << 0)
   #define GLOBALREG_GLBREG_MISC3_ETHLED0_SEL_SHIFT 0
   /*
   * Spare Control
   */
   #define GLOBALREG_GLBREG_MISC4_REG  (GLOBALREG_BASE_UNIT1 + 0x50c)
   #define GLOBALREG_GLBREG_MISC4_AOD_SGPIO6_FP0G2_EHS1_RW (0x01 << 31)
   #define GLOBALREG_GLBREG_MISC4_AOD_SGPIO6_FP0G2_EHS1_SHIFT 31
   #define GLOBALREG_GLBREG_MISC4_AOD_SGPIO6_FP0G2_EHS0_RW (0x01 << 30)
   #define GLOBALREG_GLBREG_MISC4_AOD_SGPIO6_FP0G2_EHS0_SHIFT 30
   #define GLOBALREG_GLBREG_MISC4_AO_PIO191_RGMII1COL_FP1DEN_EHS1_RW (0x01 << 29)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO191_RGMII1COL_FP1DEN_EHS1_SHIFT 29
   #define GLOBALREG_GLBREG_MISC4_AO_PIO191_RGMII1COL_FP1DEN_EHS0_RW (0x01 << 28)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO191_RGMII1COL_FP1DEN_EHS0_SHIFT 28
   #define GLOBALREG_GLBREG_MISC4_AO_PIO190_RGMII1CRS_FP0DEN_EHS1_RW (0x01 << 27)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO190_RGMII1CRS_FP0DEN_EHS1_SHIFT 27
   #define GLOBALREG_GLBREG_MISC4_AO_PIO190_RGMII1CRS_FP0DEN_EHS0_RW (0x01 << 26)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO190_RGMII1CRS_FP0DEN_EHS0_SHIFT 26
   #define GLOBALREG_GLBREG_MISC4_AO_PIO189_RGMII1MDC_EHS1_RW (0x01 << 25)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO189_RGMII1MDC_EHS1_SHIFT 25
   #define GLOBALREG_GLBREG_MISC4_AO_PIO189_RGMII1MDC_EHS0_RW (0x01 << 24)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO189_RGMII1MDC_EHS0_SHIFT 24
   #define GLOBALREG_GLBREG_MISC4_AO_PIO188_RGMII1MDIO_EHS1_RW (0x01 << 23)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO188_RGMII1MDIO_EHS1_SHIFT 23
   #define GLOBALREG_GLBREG_MISC4_AO_PIO188_RGMII1MDIO_EHS0_RW (0x01 << 22)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO188_RGMII1MDIO_EHS0_SHIFT 22
   #define GLOBALREG_GLBREG_MISC4_AO_PIO187_RGMII1RXCK_FP1CLK_EHS1_RW (0x01 << 21)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO187_RGMII1RXCK_FP1CLK_EHS1_SHIFT 21
   #define GLOBALREG_GLBREG_MISC4_AO_PIO187_RGMII1RXCK_FP1CLK_EHS0_RW (0x01 << 20)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO187_RGMII1RXCK_FP1CLK_EHS0_SHIFT 20
   #define GLOBALREG_GLBREG_MISC4_AO_PIO186_RGMII1RXD0_EHS1_RW (0x01 << 19)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO186_RGMII1RXD0_EHS1_SHIFT 19
   #define GLOBALREG_GLBREG_MISC4_AO_PIO186_RGMII1RXD0_EHS0_RW (0x01 << 18)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO186_RGMII1RXD0_EHS0_SHIFT 18
   #define GLOBALREG_GLBREG_MISC4_AO_PIO185_RGMII1RXD1_EHS1_RW (0x01 << 17)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO185_RGMII1RXD1_EHS1_SHIFT 17
   #define GLOBALREG_GLBREG_MISC4_AO_PIO185_RGMII1RXD1_EHS0_RW (0x01 << 16)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO185_RGMII1RXD1_EHS0_SHIFT 16
   #define GLOBALREG_GLBREG_MISC4_AO_PIO184_RGMII1RXD2_EHS1_RW (0x01 << 15)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO184_RGMII1RXD2_EHS1_SHIFT 15
   #define GLOBALREG_GLBREG_MISC4_AO_PIO184_RGMII1RXD2_EHS0_RW (0x01 << 14)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO184_RGMII1RXD2_EHS0_SHIFT 14
   #define GLOBALREG_GLBREG_MISC4_AO_PIO183_RGMII1RXD3_FP0CLK_EHS1_RW (0x01 << 13)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO183_RGMII1RXD3_FP0CLK_EHS1_SHIFT 13
   #define GLOBALREG_GLBREG_MISC4_AO_PIO183_RGMII1RXD3_FP0CLK_EHS0_RW (0x01 << 12)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO183_RGMII1RXD3_FP0CLK_EHS0_SHIFT 12
   #define GLOBALREG_GLBREG_MISC4_AO_PIO182_RGMII1RXDV_SDCRDWP_EHS1_RW (0x01 << 11)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO182_RGMII1RXDV_SDCRDWP_EHS1_SHIFT 11
   #define GLOBALREG_GLBREG_MISC4_AO_PIO182_RGMII1RXDV_SDCRDWP_EHS0_RW (0x01 << 10)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO182_RGMII1RXDV_SDCRDWP_EHS0_SHIFT 10
   #define GLOBALREG_GLBREG_MISC4_AO_PIO181_RGMII1RXER_SDCRDETECT_EHS1_RW (0x01 << 9)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO181_RGMII1RXER_SDCRDETECT_EHS1_SHIFT 9
   #define GLOBALREG_GLBREG_MISC4_AO_PIO181_RGMII1RXER_SDCRDETECT_EHS0_RW (0x01 << 8)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO181_RGMII1RXER_SDCRDETECT_EHS0_SHIFT 8
   #define GLOBALREG_GLBREG_MISC4_AO_PIO161_RGMII1TXER_SDLED_EHS1_RW (0x01 << 7)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO161_RGMII1TXER_SDLED_EHS1_SHIFT 7
   #define GLOBALREG_GLBREG_MISC4_AO_PIO161_RGMII1TXER_SDLED_EHS0_RW (0x01 << 6)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO161_RGMII1TXER_SDLED_EHS0_SHIFT 6
   #define GLOBALREG_GLBREG_MISC4_AO_PIO149_HS4CLK_EHS1_RW (0x01 << 5)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO149_HS4CLK_EHS1_SHIFT 5
   #define GLOBALREG_GLBREG_MISC4_AO_PIO149_HS4CLK_EHS0_RW (0x01 << 4)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO149_HS4CLK_EHS0_SHIFT 4
   #define GLOBALREG_GLBREG_MISC4_AO_PIO144_HS5CLK_I2SINOSCLK_EHS1_RW (0x01 << 3)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO144_HS5CLK_I2SINOSCLK_EHS1_SHIFT 3
   #define GLOBALREG_GLBREG_MISC4_AO_PIO144_HS5CLK_I2SINOSCLK_EHS0_RW (0x01 << 2)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO144_HS5CLK_I2SINOSCLK_EHS0_SHIFT 2
   #define GLOBALREG_GLBREG_MISC4_AO_PIO089_HS3CLK_656CLK_EHS1_RW (0x01 << 1)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO089_HS3CLK_656CLK_EHS1_SHIFT 1
   #define GLOBALREG_GLBREG_MISC4_AO_PIO089_HS3CLK_656CLK_EHS0_RW (0x01 << 0)
   #define GLOBALREG_GLBREG_MISC4_AO_PIO089_HS3CLK_656CLK_EHS0_SHIFT 0
   /*
   * Lock command register
   */
   #define GLOBALREG_LOCK_CMD_REG1  (GLOBALREG_BASE_UNIT1 + 0x510)
   /*
   * The LOCKCMD register controls write access to the LOCKSTAT register. The LOCKSTA
   * T register must be unlocked before write operations are accepted. The LOCKSTAT r
   * egister is unlocked by performing two back-to-back writes to the LOCKCMD registe
   * r using write data of 0xF8 for the first write and 0x2B for the second write. Th
   * e LOCKSTAT register is unlocked only for the next write operation and then goes 
   * back to the locked state
   */
   #define GLOBALREG_LOCK_CMD_UNLOCK_DATA_W (0x0ffffffff << 0)
   #define GLOBALREG_LOCK_CMD_UNLOCK_DATA_SHIFT 0
   /*
   * Lock status register
   */
   #define GLOBALREG_LOCK_STATUS_REG1  (GLOBALREG_BASE_UNIT1 + 0x514)
   /*
   * Reserved
   */
   #define GLOBALREG_LOCK_STATUS_RESERVED_RW (0x0ff << 24)
   #define GLOBALREG_LOCK_STATUS_RESERVED_SHIFT 24
   /*
   * The LOCKSTAT register allows access to system critical registers to be controlle
   * d. The register is reset at power-on, to enable write access to the controlled r
   * egisters. The listed system registers may be protected from accidental change by
   *  setting the corresponding bit in this register. The Resource Lock Register can 
   * not be written until access is enabled through the Resource Lock Enable register
   * . For each of the entries, a 1 indicates the resource has been locked (cannot be
   *  written), and 0 indicates the resource is open (can be written). lock for timer
   *  registers
   */
   #define GLOBALREG_LOCK_STATUS_TIMER_LOCK_RW (0x0ffffff << 0)
   #define GLOBALREG_LOCK_STATUS_TIMER_LOCK_SHIFT 0
   /*
   * AFE Top control
   */
   #define GLOBALREG_AFE_CTRL0_REG1  (GLOBALREG_BASE_UNIT1 + 0x800)
   /*
   * Reserved
   */
   #define GLOBALREG_AFE_CTRL0_RESERVED_RW (0x01ffff << 15)
   #define GLOBALREG_AFE_CTRL0_RESERVED_SHIFT 15
   /*
   * bypass test mode input
   */
   #define GLOBALREG_AFE_CTRL0_XTAL_XTM_RW (0x01 << 14)
   #define GLOBALREG_AFE_CTRL0_XTAL_XTM_SHIFT 14
   /*
   * power down input
   */
   #define GLOBALREG_AFE_CTRL0_XTAL_PD_RW (0x01 << 13)
   #define GLOBALREG_AFE_CTRL0_XTAL_PD_SHIFT 13
   /*
   * oscillator low / high transconductance selection inputs
   */
   #define GLOBALREG_AFE_CTRL0_XTAL_HF0_RW (0x01 << 12)
   #define GLOBALREG_AFE_CTRL0_XTAL_HF0_SHIFT 12
   /*
   * oscillator low / high transconductance selection inputs
   */
   #define GLOBALREG_AFE_CTRL0_XTAL_HF1_RW (0x01 << 11)
   #define GLOBALREG_AFE_CTRL0_XTAL_HF1_SHIFT 11
   /*
   * oscillator low / high transconductance selection inputs
   */
   #define GLOBALREG_AFE_CTRL0_XTAL_HF2_RW (0x01 << 10)
   #define GLOBALREG_AFE_CTRL0_XTAL_HF2_SHIFT 10
   /*
   * low jitter mode input
   */
   #define GLOBALREG_AFE_CTRL0_XTAL_HP_RW (0x01 << 9)
   #define GLOBALREG_AFE_CTRL0_XTAL_HP_SHIFT 9
   /*
   * Reserved
   */
   #define GLOBALREG_AFE_CTRL0_RESERVED7_RW (0x01ff << 0)
   #define GLOBALREG_AFE_CTRL0_RESERVED7_SHIFT 0
   /*
   * Left and Right Channel Audio DAC Control
   */
   #define GLOBALREG_ADAC_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x804)
   /*
   * Reserved
   */
   #define GLOBALREG_ADAC_CTRL_RESERVED_RW (0x07fffffff << 1)
   #define GLOBALREG_ADAC_CTRL_RESERVED_SHIFT 1
   /*
   * ADAC SW reset active low
   */
   #define GLOBALREG_ADAC_CTRL_ADAC_RESET_N_RW (0x01 << 0)
   #define GLOBALREG_ADAC_CTRL_ADAC_RESET_N_SHIFT 0
   /*
   * AFE spare inputs (reserved for future use)
   */
   #define GLOBALREG_AFE_SPARE_IN_REG1  (GLOBALREG_BASE_UNIT1 + 0x824)
   /*
   * Reserved
   */
   #define GLOBALREG_AFE_SPARE_IN_RESERVED_RW (0x0ff << 24)
   #define GLOBALREG_AFE_SPARE_IN_RESERVED_SHIFT 24
   /*
   * Spare control inputs for IPs through vdac_routing for general use
   */
   #define GLOBALREG_AFE_SPARE_IN_VDAC_ROUTING_SPARE_IN_RW (0x0ff << 16)
   #define GLOBALREG_AFE_SPARE_IN_VDAC_ROUTING_SPARE_IN_SHIFT 16
   /*
   * Spare control inputs for IPs through afe_routing1 for general use
   */
   #define GLOBALREG_AFE_SPARE_IN_AFE_ROUTING1_SPARE_IN_RW (0x0ff << 8)
   #define GLOBALREG_AFE_SPARE_IN_AFE_ROUTING1_SPARE_IN_SHIFT 8
   /*
   * Spare control inputs for IPs through afe_routing0 for general use
   */
   #define GLOBALREG_AFE_SPARE_IN_AFE_ROUTING0_SPARE_IN_RW (0x0ff << 0)
   #define GLOBALREG_AFE_SPARE_IN_AFE_ROUTING0_SPARE_IN_SHIFT 0
   /*
   * AFE spare outputs (reserved for future use)
   */
   #define GLOBALREG_AFE_SPARE_OUT_REG1  (GLOBALREG_BASE_UNIT1 + 0x828)
   /*
   * Reserved
   */
   #define GLOBALREG_AFE_SPARE_OUT_RESERVED_R (0x0ff << 24)
   #define GLOBALREG_AFE_SPARE_OUT_RESERVED_SHIFT 24
   /*
   * Spare control outputs for IPs through vdac_routing for general use
   */
   #define GLOBALREG_AFE_SPARE_OUT_VDAC_ROUTING_SPARE_OUT_R (0x0ff << 16)
   #define GLOBALREG_AFE_SPARE_OUT_VDAC_ROUTING_SPARE_OUT_SHIFT 16
   /*
   * Spare control outputs for IPs through afe_routing1 for general use
   */
   #define GLOBALREG_AFE_SPARE_OUT_AFE_ROUTING1_SPARE_OUT_R (0x0ff << 8)
   #define GLOBALREG_AFE_SPARE_OUT_AFE_ROUTING1_SPARE_OUT_SHIFT 8
   /*
   * Spare control outputs for IPs through afe_routing0 for general use
   */
   #define GLOBALREG_AFE_SPARE_OUT_AFE_ROUTING0_SPARE_OUT_R (0x0ff << 0)
   #define GLOBALREG_AFE_SPARE_OUT_AFE_ROUTING0_SPARE_OUT_SHIFT 0
   /*
   * FADC Status
   */
   #define GLOBALREG_FADC_STAT_REG1  (GLOBALREG_BASE_UNIT1 + 0x834)
   /*
   * Reserved
   */
   #define GLOBALREG_FADC_STAT_RESERVED_R (0x0ffffff << 8)
   #define GLOBALREG_FADC_STAT_RESERVED_SHIFT 8
   /*
   * Spare bits used for status
   */
   #define GLOBALREG_FADC_STAT_FDAC_SPARE_OUT_R (0x0ff << 0)
   #define GLOBALREG_FADC_STAT_FDAC_SPARE_OUT_SHIFT 0
   /*
   * AFE Status
   */
   #define GLOBALREG_AFE_STAT_REG1  (GLOBALREG_BASE_UNIT1 + 0x8a8)
   /*
   * Reserved
   */
   #define GLOBALREG_AFE_STAT_RESERVED_R (0x01fffffff << 3)
   #define GLOBALREG_AFE_STAT_RESERVED_SHIFT 3
   /*
   * power on reset low voltage test output
   */
   #define GLOBALREG_AFE_STAT_PORTAP_R (0x01 << 2)
   #define GLOBALREG_AFE_STAT_PORTAP_SHIFT 2
   /*
   * power on reset test output
   */
   #define GLOBALREG_AFE_STAT_PORTEST_R (0x01 << 1)
   #define GLOBALREG_AFE_STAT_PORTEST_SHIFT 1
   /*
   * power on reset constant output
   */
   #define GLOBALREG_AFE_STAT_PORCONST_R (0x01 << 0)
   #define GLOBALREG_AFE_STAT_PORCONST_SHIFT 0
   /*
   * RFDAC REF control
   */
   #define GLOBALREG_REF_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x8ac)
   /*
   * Reserved
   */
   #define GLOBALREG_REF_CTRL_RESERVED_RW (0x07fff << 17)
   #define GLOBALREG_REF_CTRL_RESERVED_SHIFT 17
   /*
   * Set internal reference resistor
   */
   #define GLOBALREG_REF_CTRL_REF_SET_RINT_RW (0x01f << 12)
   #define GLOBALREG_REF_CTRL_REF_SET_RINT_SHIFT 12
   /*
   * Coarse current control inputs (coarse[5] = MSB)
   */
   #define GLOBALREG_REF_CTRL_REF_COARSE_RW (0x03f << 6)
   #define GLOBALREG_REF_CTRL_REF_COARSE_SHIFT 6
   /*
   * Fine current control input, two’s complement
   */
   #define GLOBALREG_REF_CTRL_REF_FINE_RW (0x0f << 2)
   #define GLOBALREG_REF_CTRL_REF_FINE_SHIFT 2
   /*
   * Select bandgap voltage input level (0: 0.7 V or 1: 1.2 V)
   */
   #define GLOBALREG_REF_CTRL_REF_SEL_BG_RW (0x01 << 1)
   #define GLOBALREG_REF_CTRL_REF_SEL_BG_SHIFT 1
   /*
   * Power-down (asynchronous)
   */
   #define GLOBALREG_REF_CTRL_REF_PD_RW (0x01 << 0)
   #define GLOBALREG_REF_CTRL_REF_PD_SHIFT 0
   /*
   * Regulator control
   */
   #define GLOBALREG_REGU_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x8b0)
   /*
   * Reserved
   */
   #define GLOBALREG_REGU_CTRL_RESERVED_RW (0x0fffff << 12)
   #define GLOBALREG_REGU_CTRL_RESERVED_SHIFT 12
   /*
   * regu_vbg_ctrl
   */
   #define GLOBALREG_REGU_CTRL_REGU_VBG_CTRL_RW (0x07 << 9)
   #define GLOBALREG_REGU_CTRL_REGU_VBG_CTRL_SHIFT 9
   /*
   * 3 Bit Control signals. Bits [1:0] for Programming the 1.0 V Regulator. Signal Le
   * vel for HIGH = ‘1 V’ and LOW = ‘0V’ and Bit 2 for adacl_power_enable and adacr_p
   * ower_enable control.
   */
   #define GLOBALREG_REGU_CTRL_REGU_VREG1V_CTRL_RW (0x07 << 6)
   #define GLOBALREG_REGU_CTRL_REGU_VREG1V_CTRL_SHIFT 6
   /*
   * 3 Bit Control signals for Programming the 2.5 V Regulator. Signal Level for HIGH
   *  = ‘1 V’ and LOW = ‘0V’.
   */
   #define GLOBALREG_REGU_CTRL_REGU_VREG2P5V_CTRL_RW (0x07 << 3)
   #define GLOBALREG_REGU_CTRL_REGU_VREG2P5V_CTRL_SHIFT 3
   /*
   * Enable signal for 2.5 V Regulator.
   * Signal Level for Enable = ‘1 V’ and for Disable = ‘0 V’
   */
   #define GLOBALREG_REGU_CTRL_REGU_ENABLE_REG2V5_RW (0x01 << 2)
   #define GLOBALREG_REGU_CTRL_REGU_ENABLE_REG2V5_SHIFT 2
   /*
   * Enable signal for 1.0V regulator. Signal Level for Enable = ‘1 V’ and for Disabl
   * e = ‘0 V’
   */
   #define GLOBALREG_REGU_CTRL_REGU_ENABLE_REG1V0_RW (0x01 << 1)
   #define GLOBALREG_REGU_CTRL_REGU_ENABLE_REG1V0_SHIFT 1
   /*
   * Enable signal for band gap reference. Signal level for Enable = ‘1 V’, For Disab
   * le = ‘0 V’
   */
   #define GLOBALREG_REGU_CTRL_REGU_ENABLE_BGR_RW (0x01 << 0)
   #define GLOBALREG_REGU_CTRL_REGU_ENABLE_BGR_SHIFT 0
   /*
   * Regulator control
   */
   #define GLOBALREG_RFDAC_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x8b4)
   /*
   * Reserved
   */
   #define GLOBALREG_RFDAC_CTRL_RESERVED_RW (0x07fffffff << 1)
   #define GLOBALREG_RFDAC_CTRL_RESERVED_SHIFT 1
   /*
   * SW reset active low
   */
   #define GLOBALREG_RFDAC_CTRL_RFDAC_RESET_N_RW (0x01 << 0)
   #define GLOBALREG_RFDAC_CTRL_RFDAC_RESET_N_SHIFT 0
   /*
   * VDAC0 Control0
   */
   #define GLOBALREG_VDAC0_CTRL0_REG1  (GLOBALREG_BASE_UNIT1 + 0x8fc)
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC0_CTRL0_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_VDAC0_CTRL0_RESERVED_SHIFT 27
   /*
   * Value is added to / subtracted from internally generated filter calibration code
   * 
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_F_OFFSET_RW (0x03f << 21)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_F_OFFSET_SHIFT 21
   /*
   * Resets the digital portion of VDAC
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_RESET_N_RW (0x01 << 20)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_RESET_N_SHIFT 20
   /*
   * Spare input bits
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_SPARE_IN_RW (0x03 << 18)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_SPARE_IN_SHIFT 18
   /*
   * Set common mode voltage for the filter. High-> 750mV Low->650mV
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_BUFFER_SEL_1P0_RW (0x01 << 17)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_BUFFER_SEL_1P0_SHIFT 17
   /*
   * Program slope and value of bandgap voltage
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_BG_RW (0x07 << 14)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_BG_SHIFT 14
   /*
   * Set High to increase the bias current of the related block as follows:
   * <5> Not used
   * <4> Driver (1.5x)
   * <3> D2S (1.5x)
   * <2> Driver regulator (2x)
   * <1> D2S regulator (2x)
   * <0> Filter (2x)
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_ADJ_IBIAS_RW (0x03f << 8)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_ADJ_IBIAS_SHIFT 8
   /*
   * Power down Bandgap
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_BG_PD_RW (0x01 << 7)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_BG_PD_SHIFT 7
   /*
   * Power down filter/driver for channel A
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_A_RW (0x01 << 6)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_A_SHIFT 6
   /*
   * Power down filter/driver for channel B
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_B_RW (0x01 << 5)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_B_SHIFT 5
   /*
   * Power down filter/driver for channel C
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_C_RW (0x01 << 4)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_C_SHIFT 4
   /*
   * Enable DAC channel A
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_A_RW (0x01 << 3)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_A_SHIFT 3
   /*
   * Enable DAC channel B
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_B_RW (0x01 << 2)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_B_SHIFT 2
   /*
   * Enable DAC channel C
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_C_RW (0x01 << 1)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_C_SHIFT 1
   /*
   * Power down reference loop
   */
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_REF_RW (0x01 << 0)
   #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_REF_SHIFT 0
   /*
   * VDAC0 Control1
   */
   #define GLOBALREG_VDAC0_CTRL1_REG1  (GLOBALREG_BASE_UNIT1 + 0x900)
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC0_CTRL1_RESERVED_RW (0x01 << 31)
   #define GLOBALREG_VDAC0_CTRL1_RESERVED_SHIFT 31
   /*
   * Program reference loop voltage. Full scale output voltage changes as follows:
   * 000 0.9v
   * 001 0.95v
   * 010 1.0v
   * 011 1.05v
   * 100 1.25v
   * 101 1.3v
   * 110 1.35v
   * 111 1.4v
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_VREF_SEL_RW (0x07 << 28)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_VREF_SEL_SHIFT 28
   /*
   * Enable override for compensation capacitor calibration code
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_CCAL_OVRD_RW (0x01 << 27)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_CCAL_OVRD_SHIFT 27
   /*
   * Calibration code used for compensation capacitors when ccal_ovrd is High
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_CCODE_OVRD_RW (0x07 << 24)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_CCODE_OVRD_SHIFT 24
   /*
   * Low: c_offset is added to internally generated capacitor calibration code
   * High: c_offset is subtracted from internally generated capacitor calibration cod
   * e
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_C_OFFSET_SUBTRACT_RW (0x01 << 23)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_C_OFFSET_SUBTRACT_SHIFT 23
   /*
   * Value is added to / subtracted from internally generated capacitor calibration c
   * ode
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_C_OFFSET_RW (0x07 << 20)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_C_OFFSET_SHIFT 20
   /*
   * Low: f_offset is added to internally generated filter calibration code
   * High: f_offset is subtracted from internally generated filter calibration code
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FOFFSET_SUBTRACT_RW (0x01 << 19)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FOFFSET_SUBTRACT_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC0_CTRL1_RESERVED7_RW (0x01f << 14)
   #define GLOBALREG_VDAC0_CTRL1_RESERVED7_SHIFT 14
   /*
   * Calibration code used for filter calibration when flt_ovrd is High
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLTCODE_OVRD_RW (0x03f << 8)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLTCODE_OVRD_SHIFT 8
   /*
   * Enable override for filter calibration code
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_OVRD_RW (0x01 << 7)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_OVRD_SHIFT 7
   /*
   * Enables filter calibration
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_EN_CAL_RW (0x01 << 6)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_EN_CAL_SHIFT 6
   /*
   * Sets the reference voltage for the filter calibration comparator. "010" sets 1V 
   * as the reference
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_CAL_SEL_RW (0x07 << 3)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_CAL_SEL_SHIFT 3
   /*
   * Powers down the filter calibration block
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_CAL_PD_RW (0x01 << 2)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_CAL_PD_SHIFT 2
   /*
   * Resets filter calibration circuit. Active Low
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_CAL_NRESET_RW (0x01 << 1)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_CAL_NRESET_SHIFT 1
   /*
   * Doubles filter tuning comparator bias current
   */
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_CAL_DOUB_RW (0x01 << 0)
   #define GLOBALREG_VDAC0_CTRL1_VDAC0_FLT_CAL_DOUB_SHIFT 0
   /*
   * VDAC0 Control2
   */
   #define GLOBALREG_VDAC0_CTRL2_REG1  (GLOBALREG_BASE_UNIT1 + 0x904)
   /*
   * Configures the clksync4x_8x module to be 1080p60Hz mode.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SEL_CLK4X_0_RW (0x01 << 31)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SEL_CLK4X_0_SHIFT 31
   /*
   * Configures the clksync4x_8x module to be 1080p60Hz mode.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SEL_CLK4X_1_RW (0x01 << 30)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SEL_CLK4X_1_SHIFT 30
   /*
   * Configures the clksync4x_8x module to be 1080p60Hz mode.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SEL_CLK4X_2_RW (0x01 << 29)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SEL_CLK4X_2_SHIFT 29
   /*
   * Configures the clksync4x_8x module to be 1080p60Hz mode.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SEL_CLK4X_3_RW (0x01 << 28)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SEL_CLK4X_3_SHIFT 28
   /*
   * Sync counter value used within clk4x_8x module. Sync pulse is generated when the
   *  internal counter reaches this value.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SYNCOUT_CNT0_RW (0x07 << 25)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SYNCOUT_CNT0_SHIFT 25
   /*
   * Sync counter value used within clk4x_8x module. Sync pulse is generated when the
   *  internal counter reaches this value.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SYNCOUT_CNT1_RW (0x07 << 22)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SYNCOUT_CNT1_SHIFT 22
   /*
   * Sync counter value used within clk4x_8x module. Sync pulse is generated when the
   *  internal counter reaches this value.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SYNCOUT_CNT2_RW (0x07 << 19)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SYNCOUT_CNT2_SHIFT 19
   /*
   * Sync counter value used within clk4x_8x module. Sync pulse is generated when the
   *  internal counter reaches this value.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SYNCOUT_CNT3_RW (0x07 << 16)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_SYNCOUT_CNT3_SHIFT 16
   /*
   * Enables the adjustment of sync_out position when clock is detected at its counte
   * r value of 2 or 0 for 128 consecutive times. Active low.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_EN_EQ2FIX_N0_RW (0x01 << 15)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_EN_EQ2FIX_N0_SHIFT 15
   /*
   * Enables the adjustment of sync_out position when clock is detected at its counte
   * r value of 2 or 0 for 128 consecutive times. Active low.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_EN_EQ2FIX_N1_RW (0x01 << 14)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_EN_EQ2FIX_N1_SHIFT 14
   /*
   * Enables the adjustment of sync_out position when clock is detected at its counte
   * r value of 2 or 0 for 128 consecutive times. Active low.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_EN_EQ2FIX_N2_RW (0x01 << 13)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_EN_EQ2FIX_N2_SHIFT 13
   /*
   * Enables the adjustment of sync_out position when clock is detected at its counte
   * r value of 2 or 0 for 128 consecutive times. Active low.
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_EN_EQ2FIX_N3_RW (0x01 << 12)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_EN_EQ2FIX_N3_SHIFT 12
   /*
   * Selects clock sync mode. clk_sync signal is generated accordingly:
   * 2’b00: sync_in0, sync_in1, sync_in2, sync_in3
   * 2’b01: bypass clksync4x_8x and use active edge detected clock sync
   * 2’b10: bypass clksync4x_8x and use falling edge detected clock sync
   * 2’b11: bypass clksync4x_8x and use active edge detected clock sync but with use 
   * of negedge sync flops
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLK_SYNC_ALT_0_RW (0x03 << 10)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLK_SYNC_ALT_0_SHIFT 10
   /*
   * Selects clock sync mode. clk_sync signal is generated accordingly:
   * 2’b00: sync_in0, sync_in1, sync_in2, sync_in3
   * 2’b01: bypass clksync4x_8x and use active edge detected clock sync
   * 2’b10: bypass clksync4x_8x and use falling edge detected clock sync
   * 2’b11: bypass clksync4x_8x and use active edge detected clock sync but with use 
   * of negedge sync flops
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLK_SYNC_ALT_1_RW (0x03 << 8)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLK_SYNC_ALT_1_SHIFT 8
   /*
   * Selects clock sync mode. clk_sync signal is generated accordingly:
   * 2’b00: sync_in0, sync_in1, sync_in2, sync_in3
   * 2’b01: bypass clksync4x_8x and use active edge detected clock sync
   * 2’b10: bypass clksync4x_8x and use falling edge detected clock sync
   * 2’b11: bypass clksync4x_8x and use active edge detected clock sync but with use 
   * of negedge sync flops
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLK_SYNC_ALT_2_RW (0x03 << 6)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLK_SYNC_ALT_2_SHIFT 6
   /*
   * Selects clock sync mode. clk_sync signal is generated accordingly:
   * 2’b00: sync_in0, sync_in1, sync_in2, sync_in3
   * 2’b01: bypass clksync4x_8x and use active edge detected clock sync
   * 2’b10: bypass clksync4x_8x and use falling edge detected clock sync
   * 2’b11: bypass clksync4x_8x and use active edge detected clock sync but with use 
   * of negedge sync flops
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLK_SYNC_ALT_3_RW (0x03 << 4)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLK_SYNC_ALT_3_SHIFT 4
   /*
   * Selects the PLL clock used in waveform generator.
   * 2’b00: clk0
   * 2’b01: clk1
   * 2’b10: clk2
   * 2’b11: clk3
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLKSEL_WG_RW (0x03 << 2)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLKSEL_WG_SHIFT 2
   /*
   * Selects the PLL clock used in analog calibration.
   * 2’b00: clk0
   * 2’b01: clk1
   * 2’b10: clk2
   * 2’b11: clk3
   */
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLKSEL_TUNE_RW (0x03 << 0)
   #define GLOBALREG_VDAC0_CTRL2_VDAC0_CLKSEL_TUNE_SHIFT 0
   /*
   * VDAC0 Control3
   */
   #define GLOBALREG_VDAC0_CTRL3_REG1  (GLOBALREG_BASE_UNIT1 + 0x908)
   #define GLOBALREG_VDAC0_CTRL3_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_VDAC0_CTRL3_RESERVED_SHIFT 27
   /*
   * Register field to control the upsampling filter mode when in 1080p60Hz.
   * 2’b00: 4x to 8x upsampling filter is bypassed
   * 2’b01: 1x to 2x upsampling filter is bypassed
   * 2’b10: 2x to 4x upsampling filter is bypassed
   * 2’b11: 4x to 8x upsampling filter is bypassed
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_FLT_4X_CNFG_A_RW (0x03 << 25)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_FLT_4X_CNFG_A_SHIFT 25
   /*
   * Register field to control the upsampling filter mode when in 1080p60Hz.
   * 2’b00: 4x to 8x upsampling filter is bypassed
   * 2’b01: 1x to 2x upsampling filter is bypassed
   * 2’b10: 2x to 4x upsampling filter is bypassed
   * 2’b11: 4x to 8x upsampling filter is bypassed
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_FLT_4X_CNFG_B_RW (0x01 << 23)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_FLT_4X_CNFG_B_SHIFT 23
   /*
   * Register field to control the upsampling filter mode when in 1080p60Hz.
   * 2’b00: 4x to 8x upsampling filter is bypassed
   * 2’b01: 1x to 2x upsampling filter is bypassed
   * 2’b10: 2x to 4x upsampling filter is bypassed
   * 2’b11: 4x to 8x upsampling filter is bypassed
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_FLT_4X_CNFG_C_RW (0x03 << 21)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_FLT_4X_CNFG_C_SHIFT 21
   /*
   * Register control bit to enable monitor status check. When set to 1, 10’d533 is f
   * orced into the VDAC
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_EN_STAT_A_RW (0x01 << 20)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_EN_STAT_A_SHIFT 20
   /*
   * Register control bit to enable monitor status check. When set to 1, 10’d533 is f
   * orced into the VDAC
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_EN_STAT_B_RW (0x01 << 19)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_EN_STAT_B_SHIFT 19
   /*
   * Register control bit to enable monitor status check. When set to 1, 10’d533 is f
   * orced into the VDAC
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_EN_STAT_C_RW (0x01 << 18)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_EN_STAT_C_SHIFT 18
   /*
   * Register control bit to enable 1080p60Hz mode. When asserted, enables operation 
   * with 148.5MHz data and clock from the DENC
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SEL_CLK4X_A_RW (0x01 << 17)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SEL_CLK4X_A_SHIFT 17
   /*
   * Register control bit to enable 1080p60Hz mode. When asserted, enables operation 
   * with 148.5MHz data and clock from the DENC
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SEL_CLK4X_B_RW (0x01 << 16)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SEL_CLK4X_B_SHIFT 16
   /*
   * Register control bit to enable 1080p60Hz mode. When asserted, enables operation 
   * with 148.5MHz data and clock from the DENC
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SEL_CLK4X_C_RW (0x01 << 15)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SEL_CLK4X_C_SHIFT 15
   /*
   * Selects the PLL clock used in channel A, B or C.
   * 2’b00: clk0
   * 2’b01: clk1
   * 2’b10: clk2
   * 2’b11: clk3
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_CLKSEL_A_RW (0x03 << 13)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_CLKSEL_A_SHIFT 13
   /*
   * Selects the PLL clock used in channel A, B or C.
   * 2’b00: clk0
   * 2’b01: clk1
   * 2’b10: clk2
   * 2’b11: clk3
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_CLKSEL_B_RW (0x03 << 11)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_CLKSEL_B_SHIFT 11
   /*
   * Selects the PLL clock used in channel A, B or C.
   * 2’b00: clk0
   * 2’b01: clk1
   * 2’b10: clk2
   * 2’b11: clk3
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_CLKSEL_C_RW (0x03 << 9)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_CLKSEL_C_SHIFT 9
   /*
   * Sync counter value used for internal Alpha channel clock sync when clksync4x_8x 
   * module is in bypass mode or used in series. Bit 0 and 1 are used when in 1080p60
   * Hz mode.
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SYNCOUT_CNT_A_RW (0x07 << 6)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SYNCOUT_CNT_A_SHIFT 6
   /*
   * Sync counter value used for internal Alpha channel clock sync when clksync4x_8x 
   * module is in bypass mode or used in series. Bit 0 and 1 are used when in 1080p60
   * Hz mode.
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SYNCOUT_CNT_B_RW (0x07 << 3)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SYNCOUT_CNT_B_SHIFT 3
   /*
   * Sync counter value used for internal Alpha channel clock sync when clksync4x_8x 
   * module is in bypass mode or used in series. Bit 0 and 1 are used when in 1080p60
   * Hz mode.
   */
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SYNCOUT_CNT_C_RW (0x07 << 0)
   #define GLOBALREG_VDAC0_CTRL3_VDAC0_SYNCOUT_CNT_C_SHIFT 0
   /*
   * VDAC0 Control4
   */
   #define GLOBALREG_VDAC0_CTRL4_REG1  (GLOBALREG_BASE_UNIT1 + 0x90c)
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC0_CTRL4_RESERVED_RW (0x03 << 30)
   #define GLOBALREG_VDAC0_CTRL4_RESERVED_SHIFT 30
   /*
   * Register field to select the bypass mode of the “latched” version of the clock s
   * ync pulse used in DAC channel A.
   * 2’b00: Use one of the clock sync pulse generated by clksync4x_8x module
   * 2’b01: Use “latched” version of the clock sync pulse generated by clksync4x_8x m
   * odule
   * 2’b10: Use the internal sync counter to generate the clock pulse along with one 
   * of the clock sync pulses generated by clksync4x_8x module with the “latch”
   * 2’b11: Use the internal sync counter to generate the clock pulse along with one 
   * of the clock sync pulses generated by clksync4x_8x module without the “latch”
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_SYNC_LAT_A_RW (0x03 << 28)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_SYNC_LAT_A_SHIFT 28
   /*
   * See vdac0_bypass_sync_lat_a
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_SYNC_LAT_B_RW (0x03 << 26)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_SYNC_LAT_B_SHIFT 26
   /*
   * See vdac0_bypass_sync_lat_a
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_SYNC_LAT_C_RW (0x03 << 24)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_SYNC_LAT_C_SHIFT 24
   /*
   * Register field to bypass the upsample filters.
   * [0]: Bypass 1x to 2x upsample filter
   * [1]: Bypass 2x to 4x upsample filter
   * [2]: Bypass 4x to 8x upsample filter
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_FILTER_A_RW (0x07 << 21)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_FILTER_A_SHIFT 21
   /*
   * See vdac0_bypass_filter_a
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_FILTER_B_RW (0x07 << 18)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_FILTER_B_SHIFT 18
   /*
   * See vdac0_bypass_filter_a
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_FILTER_C_RW (0x07 << 15)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_BYPASS_FILTER_C_SHIFT 15
   /*
   * Low: r_offset is added to internally generated filter calibration code
   * High: r_offset is subtracted from internally generated filter calibration code
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_ROFFSET_SUBTRACT_RW (0x01 << 14)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_ROFFSET_SUBTRACT_SHIFT 14
   /*
   * Value is added to / subtracted from internally generated resistor calibration co
   * de
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_R_OFFSET_RW (0x03f << 8)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_R_OFFSET_SHIFT 8
   /*
   * Calibration code used for resistor calibration when rcal_ovrd is High
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_RCODE_OVD_RW (0x01f << 3)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_RCODE_OVD_SHIFT 3
   /*
   * Powers down the resistor calibration block.
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_RCAL_PD_RW (0x01 << 2)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_RCAL_PD_SHIFT 2
   /*
   * Enable override for resistor calibration code
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_RCAL_OVRD_RW (0x01 << 1)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_RCAL_OVRD_SHIFT 1
   /*
   * Resets resistor calibration circuit. Active Low.
   */
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_RCAL_NRESET_RW (0x01 << 0)
   #define GLOBALREG_VDAC0_CTRL4_VDAC0_RCAL_NRESET_SHIFT 0
   /*
   * VDAC0 Test Control
   */
   #define GLOBALREG_VDAC0_TEST_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x910)
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC0_TEST_CTRL_RESERVED_RW (0x01fffff << 11)
   #define GLOBALREG_VDAC0_TEST_CTRL_RESERVED_SHIFT 11
   /*
   * Gain value of the wave generator.
   * 2’b00: Full scale
   * 2’b01: 1/2 scale
   * 2’b10: 1/4 scale
   * 2’b11: 1/8 scale
   */
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_WAV_GAIN_RW (0x03 << 9)
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_WAV_GAIN_SHIFT 9
   /*
   * Offset value for the wave generator:
   * 3’b000: No offset
   * 3’b001: +128
   * 3’b010: +256
   * 3’b011: +384
   * 3’b100: -512
   * 3’b101: -384
   * 3’b110: -256
   * 3’b111: -128
   */
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_WAV_OFFSET_RW (0x07 << 6)
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_WAV_OFFSET_SHIFT 6
   /*
   * Selects waveform gen mode for channel A
   * When test_en_a is High, clksel_a<1:0> and clksel_wg<1:0> MUST have the same sett
   * ing
   */
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_TEST_EN_A_RW (0x01 << 5)
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_TEST_EN_A_SHIFT 5
   /*
   * Selects waveform gen mode for channel B
   * When test_en_b is High, clksel_b<1:0> and clksel_wg<1:0> MUST have the same sett
   * ing
   */
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_TEST_EN_B_RW (0x01 << 4)
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_TEST_EN_B_SHIFT 4
   /*
   * Selects waveform gen mode for channel C
   * When test_en_c is High, clksel_c<1:0> and clksel_wg<1:0> MUST have the same sett
   * ing
   */
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_TEST_EN_C_RW (0x01 << 3)
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_TEST_EN_C_SHIFT 3
   /*
   * Bit [1:0] selects the wave mode:
   * 2’b00: Sine wave
   * 2’b01: Ramp
   * 2’b10: Square wave
   * 2’b11: Chirp
   * Bit 2 selects the bypass upsample filter mode when wave generator is used:
   * 1’b0: Bypass upsample filters
   * 1’b1: Use upsample filters
   */
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_TEST_MODE_RW (0x07 << 0)
   #define GLOBALREG_VDAC0_TEST_CTRL_VDAC0_TEST_MODE_SHIFT 0
   /*
   * VDAC0 DTO Increment Value0
   */
   #define GLOBALREG_VDAC0_DTO_INCR0_REG1  (GLOBALREG_BASE_UNIT1 + 0x914)
   /*
   * DTO increment value for the sine wave generator for wave0
   */
   #define GLOBALREG_VDAC0_DTO_INCR0_VDAC0_DTO_INCR0_RW (0x0ffffffff << 0)
   #define GLOBALREG_VDAC0_DTO_INCR0_VDAC0_DTO_INCR0_SHIFT 0
   /*
   * VDAC0 DTO Increment Value0
   */
   #define GLOBALREG_VDAC0_DTO_INCR1_REG1  (GLOBALREG_BASE_UNIT1 + 0x918)
   /*
   * DTO increment value for the sine wave generator for wave1
   */
   #define GLOBALREG_VDAC0_DTO_INCR1_VDAC0_DTO_INCR1_RW (0x0ffffffff << 0)
   #define GLOBALREG_VDAC0_DTO_INCR1_VDAC0_DTO_INCR1_SHIFT 0
   /*
   * VDAC0 STATUS
   */
   #define GLOBALREG_VDAC0_STAT_REG1  (GLOBALREG_BASE_UNIT1 + 0x91c)
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC0_STAT_RESERVED_R (0x01f << 27)
   #define GLOBALREG_VDAC0_STAT_RESERVED_SHIFT 27
   /*
   * Capacitor codes obtained from calibration circuitry
   */
   #define GLOBALREG_VDAC0_STAT_VDAC0_CCODE_DRV_R (0x07 << 24)
   #define GLOBALREG_VDAC0_STAT_VDAC0_CCODE_DRV_SHIFT 24
   /*
   * Output code obtained from RC calibration
   */
   #define GLOBALREG_VDAC0_STAT_VDAC0_FLT_CAL_CODE_R (0x03f << 18)
   #define GLOBALREG_VDAC0_STAT_VDAC0_FLT_CAL_CODE_SHIFT 18
   /*
   * Indicates completion of filter calibration.
   */
   #define GLOBALREG_VDAC0_STAT_VDAC0_FLT_DONE_R (0x01 << 17)
   #define GLOBALREG_VDAC0_STAT_VDAC0_FLT_DONE_SHIFT 17
   /*
   * Indicates completion of resistor calibration.
   */
   #define GLOBALREG_VDAC0_STAT_VDAC0_RCAL_DONE_R (0x01 << 16)
   #define GLOBALREG_VDAC0_STAT_VDAC0_RCAL_DONE_SHIFT 16
   /*
   * Output code obtained from resistor calibration
   */
   #define GLOBALREG_VDAC0_STAT_VDAC0_RCODE_DRV_R (0x01f << 11)
   #define GLOBALREG_VDAC0_STAT_VDAC0_RCODE_DRV_SHIFT 11
   /*
   * Spare output bits
   */
   #define GLOBALREG_VDAC0_STAT_VDAC0_SPARE_OUT_R (0x0ff << 3)
   #define GLOBALREG_VDAC0_STAT_VDAC0_SPARE_OUT_SHIFT 3
   /*
   * Monitor Status output for channel A
   */
   #define GLOBALREG_VDAC0_STAT_VDAC0_STAT_OUT_A_R (0x01 << 2)
   #define GLOBALREG_VDAC0_STAT_VDAC0_STAT_OUT_A_SHIFT 2
   /*
   * Monitor Status output for channel B
   */
   #define GLOBALREG_VDAC0_STAT_VDAC0_STAT_OUT_B_R (0x01 << 1)
   #define GLOBALREG_VDAC0_STAT_VDAC0_STAT_OUT_B_SHIFT 1
   /*
   * Monitor Status output for channel C
   */
   #define GLOBALREG_VDAC0_STAT_VDAC0_STAT_OUT_C_R (0x01 << 0)
   #define GLOBALREG_VDAC0_STAT_VDAC0_STAT_OUT_C_SHIFT 0
   /*
   * VDAC1 Control0
   */
   #define GLOBALREG_VDAC1_CTRL0_REG1  (GLOBALREG_BASE_UNIT1 + 0x920)
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC1_CTRL0_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_VDAC1_CTRL0_RESERVED_SHIFT 27
   /*
   * Value is added to / subtracted from internally generated filter calibration code
   * 
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_F_OFFSET_RW (0x03f << 21)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_F_OFFSET_SHIFT 21
   /*
   * Resets the digital portion of VDAC
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_RESET_N_RW (0x01 << 20)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_RESET_N_SHIFT 20
   /*
   * Spare input bits
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_SPARE_IN_RW (0x03 << 18)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_SPARE_IN_SHIFT 18
   /*
   * Set common mode voltage for the filter. High-> 750mV Low->650mV
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_BUFFER_SEL_1P0_RW (0x01 << 17)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_BUFFER_SEL_1P0_SHIFT 17
   /*
   * Program slope and value of bandgap voltage
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_BG_RW (0x07 << 14)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_BG_SHIFT 14
   /*
   * Set High to increase the bias current of the related block as follows:
   * <5> Not used
   * <4> Driver (1.5x)
   * <3> D2S (1.5x)
   * <2> Driver regulator (2x)
   * <1> D2S regulator (2x)
   * <0> Filter (2x)
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_ADJ_IBIAS_RW (0x03f << 8)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_ADJ_IBIAS_SHIFT 8
   /*
   * Power down Bandgap
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_BG_PD_RW (0x01 << 7)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_BG_PD_SHIFT 7
   /*
   * Power down filter/driver for channel A
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_A_RW (0x01 << 6)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_A_SHIFT 6
   /*
   * Power down filter/driver for channel B
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_B_RW (0x01 << 5)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_B_SHIFT 5
   /*
   * Power down filter/driver for channel C
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_C_RW (0x01 << 4)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_C_SHIFT 4
   /*
   * Enable DAC channel A
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_A_RW (0x01 << 3)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_A_SHIFT 3
   /*
   * Enable DAC channel B
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_B_RW (0x01 << 2)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_B_SHIFT 2
   /*
   * Enable DAC channel C
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_C_RW (0x01 << 1)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_C_SHIFT 1
   /*
   * Power down reference loop
   */
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_REF_RW (0x01 << 0)
   #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_REF_SHIFT 0
   /*
   * VDAC1 Control1
   */
   #define GLOBALREG_VDAC1_CTRL1_REG1  (GLOBALREG_BASE_UNIT1 + 0x924)
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC1_CTRL1_RESERVED_RW (0x01 << 31)
   #define GLOBALREG_VDAC1_CTRL1_RESERVED_SHIFT 31
   /*
   * Program reference loop voltage. Full scale output voltage changes as follows:
   * 000 0.9v
   * 001 0.95v
   * 010 1.0v
   * 011 1.05v
   * 100 1.25v
   * 101 1.3v
   * 110 1.35v
   * 111 1.4v
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_VREF_SEL_RW (0x07 << 28)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_VREF_SEL_SHIFT 28
   /*
   * Enable override for compensation capacitor calibration code
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_CCAL_OVRD_RW (0x01 << 27)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_CCAL_OVRD_SHIFT 27
   /*
   * Calibration code used for compensation capacitors when ccal_ovrd is High
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_CCODE_OVRD_RW (0x07 << 24)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_CCODE_OVRD_SHIFT 24
   /*
   * Low: c_offset is added to internally generated capacitor calibration code
   * High: c_offset is subtracted from internally generated capacitor calibration cod
   * e
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_C_OFFSET_SUBTRACT_RW (0x01 << 23)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_C_OFFSET_SUBTRACT_SHIFT 23
   /*
   * Value is added to / subtracted from internally generated capacitor calibration c
   * ode
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_C_OFFSET_RW (0x07 << 20)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_C_OFFSET_SHIFT 20
   /*
   * Low: f_offset is added to internally generated filter calibration code
   * High: f_offset is subtracted from internally generated filter calibration code
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FOFFSET_SUBTRACT_RW (0x01 << 19)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FOFFSET_SUBTRACT_SHIFT 19
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC1_CTRL1_RESERVED7_RW (0x01f << 14)
   #define GLOBALREG_VDAC1_CTRL1_RESERVED7_SHIFT 14
   /*
   * Calibration code used for filter calibration when flt_ovrd is High
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLTCODE_OVRD_RW (0x03f << 8)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLTCODE_OVRD_SHIFT 8
   /*
   * Enable override for filter calibration code
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_OVRD_RW (0x01 << 7)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_OVRD_SHIFT 7
   /*
   * Enables filter calibration
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_EN_CAL_RW (0x01 << 6)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_EN_CAL_SHIFT 6
   /*
   * Sets the reference voltage for the filter calibration comparator. "010" sets 1V 
   * as the reference
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_SEL_RW (0x07 << 3)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_SEL_SHIFT 3
   /*
   * Powers down the filter calibration block
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_PD_RW (0x01 << 2)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_PD_SHIFT 2
   /*
   * Resets filter calibration circuit. Active Low
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_NRESET_RW (0x01 << 1)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_NRESET_SHIFT 1
   /*
   * Doubles filter tuning comparator bias current
   */
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_DOUB_RW (0x01 << 0)
   #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_DOUB_SHIFT 0
   /*
   * VDAC1 Control2
   */
   #define GLOBALREG_VDAC1_CTRL2_REG1  (GLOBALREG_BASE_UNIT1 + 0x928)
   /*
   * Configures the clksync4x_8x module to be 1080p60Hz mode.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SEL_CLK4X_0_RW (0x01 << 31)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SEL_CLK4X_0_SHIFT 31
   /*
   * Configures the clksync4x_8x module to be 1080p60Hz mode.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SEL_CLK4X_1_RW (0x01 << 30)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SEL_CLK4X_1_SHIFT 30
   /*
   * Configures the clksync4x_8x module to be 1080p60Hz mode.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SEL_CLK4X_2_RW (0x01 << 29)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SEL_CLK4X_2_SHIFT 29
   /*
   * Configures the clksync4x_8x module to be 1080p60Hz mode.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SEL_CLK4X_3_RW (0x01 << 28)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SEL_CLK4X_3_SHIFT 28
   /*
   * Sync counter value used within clk4x_8x module. Sync pulse is generated when the
   *  internal counter reaches this value.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SYNCOUT_CNT0_RW (0x07 << 25)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SYNCOUT_CNT0_SHIFT 25
   /*
   * Sync counter value used within clk4x_8x module. Sync pulse is generated when the
   *  internal counter reaches this value.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SYNCOUT_CNT1_RW (0x07 << 22)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SYNCOUT_CNT1_SHIFT 22
   /*
   * Sync counter value used within clk4x_8x module. Sync pulse is generated when the
   *  internal counter reaches this value.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SYNCOUT_CNT2_RW (0x07 << 19)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SYNCOUT_CNT2_SHIFT 19
   /*
   * Sync counter value used within clk4x_8x module. Sync pulse is generated when the
   *  internal counter reaches this value.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SYNCOUT_CNT3_RW (0x07 << 16)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_SYNCOUT_CNT3_SHIFT 16
   /*
   * Enables the adjustment of sync_out position when clock is detected at its counte
   * r value of 2 or 0 for 128 consecutive times. Active low.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_EN_EQ2FIX_N0_RW (0x01 << 15)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_EN_EQ2FIX_N0_SHIFT 15
   /*
   * Enables the adjustment of sync_out position when clock is detected at its counte
   * r value of 2 or 0 for 128 consecutive times. Active low.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_EN_EQ2FIX_N1_RW (0x01 << 14)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_EN_EQ2FIX_N1_SHIFT 14
   /*
   * Enables the adjustment of sync_out position when clock is detected at its counte
   * r value of 2 or 0 for 128 consecutive times. Active low.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_EN_EQ2FIX_N2_RW (0x01 << 13)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_EN_EQ2FIX_N2_SHIFT 13
   /*
   * Enables the adjustment of sync_out position when clock is detected at its counte
   * r value of 2 or 0 for 128 consecutive times. Active low.
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_EN_EQ2FIX_N3_RW (0x01 << 12)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_EN_EQ2FIX_N3_SHIFT 12
   /*
   * Selects clock sync mode. clk_sync signal is generated accordingly:
   * 2’b00: sync_in0, sync_in1, sync_in2, sync_in3
   * 2’b01: bypass clksync4x_8x and use active edge detected clock sync
   * 2’b10: bypass clksync4x_8x and use falling edge detected clock sync
   * 2’b11: bypass clksync4x_8x and use active edge detected clock sync but with use 
   * of negedge sync flops
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLK_SYNC_ALT_0_RW (0x03 << 10)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLK_SYNC_ALT_0_SHIFT 10
   /*
   * Selects clock sync mode. clk_sync signal is generated accordingly:
   * 2’b00: sync_in0, sync_in1, sync_in2, sync_in3
   * 2’b01: bypass clksync4x_8x and use active edge detected clock sync
   * 2’b10: bypass clksync4x_8x and use falling edge detected clock sync
   * 2’b11: bypass clksync4x_8x and use active edge detected clock sync but with use 
   * of negedge sync flops
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLK_SYNC_ALT_1_RW (0x03 << 8)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLK_SYNC_ALT_1_SHIFT 8
   /*
   * Selects clock sync mode. clk_sync signal is generated accordingly:
   * 2’b00: sync_in0, sync_in1, sync_in2, sync_in3
   * 2’b01: bypass clksync4x_8x and use active edge detected clock sync
   * 2’b10: bypass clksync4x_8x and use falling edge detected clock sync
   * 2’b11: bypass clksync4x_8x and use active edge detected clock sync but with use 
   * of negedge sync flops
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLK_SYNC_ALT_2_RW (0x03 << 6)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLK_SYNC_ALT_2_SHIFT 6
   /*
   * Selects clock sync mode. clk_sync signal is generated accordingly:
   * 2’b00: sync_in0, sync_in1, sync_in2, sync_in3
   * 2’b01: bypass clksync4x_8x and use active edge detected clock sync
   * 2’b10: bypass clksync4x_8x and use falling edge detected clock sync
   * 2’b11: bypass clksync4x_8x and use active edge detected clock sync but with use 
   * of negedge sync flops
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLK_SYNC_ALT_3_RW (0x03 << 4)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLK_SYNC_ALT_3_SHIFT 4
   /*
   * Selects the PLL clock used in waveform generator.
   * 2’b00: clk0
   * 2’b01: clk1
   * 2’b10: clk2
   * 2’b11: clk3
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLKSEL_WG_RW (0x03 << 2)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLKSEL_WG_SHIFT 2
   /*
   * Selects the PLL clock used in analog calibration.
   * 2’b00: clk0
   * 2’b01: clk1
   * 2’b10: clk2
   * 2’b11: clk3
   */
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLKSEL_TUNE_RW (0x03 << 0)
   #define GLOBALREG_VDAC1_CTRL2_VDAC1_CLKSEL_TUNE_SHIFT 0
   /*
   * VDAC1 Control3
   */
   #define GLOBALREG_VDAC1_CTRL3_REG1  (GLOBALREG_BASE_UNIT1 + 0x92c)
   #define GLOBALREG_VDAC1_CTRL3_RESERVED_RW (0x01f << 27)
   #define GLOBALREG_VDAC1_CTRL3_RESERVED_SHIFT 27
   /*
   * Register field to control the upsampling filter mode when in 1080p60Hz.
   * 2’b00: 4x to 8x upsampling filter is bypassed
   * 2’b01: 1x to 2x upsampling filter is bypassed
   * 2’b10: 2x to 4x upsampling filter is bypassed
   * 2’b11: 4x to 8x upsampling filter is bypassed
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_FLT_4X_CNFG_A_RW (0x03 << 25)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_FLT_4X_CNFG_A_SHIFT 25
   /*
   * Register field to control the upsampling filter mode when in 1080p60Hz.
   * 2’b00: 4x to 8x upsampling filter is bypassed
   * 2’b01: 1x to 2x upsampling filter is bypassed
   * 2’b10: 2x to 4x upsampling filter is bypassed
   * 2’b11: 4x to 8x upsampling filter is bypassed
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_FLT_4X_CNFG_B_RW (0x03 << 23)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_FLT_4X_CNFG_B_SHIFT 23
   /*
   * Register field to control the upsampling filter mode when in 1080p60Hz.
   * 2’b00: 4x to 8x upsampling filter is bypassed
   * 2’b01: 1x to 2x upsampling filter is bypassed
   * 2’b10: 2x to 4x upsampling filter is bypassed
   * 2’b11: 4x to 8x upsampling filter is bypassed
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_FLT_4X_CNFG_C_RW (0x03 << 21)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_FLT_4X_CNFG_C_SHIFT 21
   /*
   * Register control bit to enable monitor status check. When set to 1, 10’d533 is f
   * orced into the VDAC
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_EN_STAT_A_RW (0x01 << 20)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_EN_STAT_A_SHIFT 20
   /*
   * Register control bit to enable monitor status check. When set to 1, 10’d533 is f
   * orced into the VDAC
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_EN_STAT_B_RW (0x01 << 19)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_EN_STAT_B_SHIFT 19
   /*
   * Register control bit to enable monitor status check. When set to 1, 10’d533 is f
   * orced into the VDAC
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_EN_STAT_C_RW (0x01 << 18)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_EN_STAT_C_SHIFT 18
   /*
   * Register control bit to enable 1080p60Hz mode. When asserted, enables operation 
   * with 148.5MHz data and clock from the DENC
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SEL_CLK4X_A_RW (0x01 << 17)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SEL_CLK4X_A_SHIFT 17
   /*
   * Register control bit to enable 1080p60Hz mode. When asserted, enables operation 
   * with 148.5MHz data and clock from the DENC
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SEL_CLK4X_B_RW (0x01 << 16)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SEL_CLK4X_B_SHIFT 16
   /*
   * Register control bit to enable 1080p60Hz mode. When asserted, enables operation 
   * with 148.5MHz data and clock from the DENC
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SEL_CLK4X_C_RW (0x01 << 15)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SEL_CLK4X_C_SHIFT 15
   /*
   * Selects the PLL clock used in channel A, B or C.
   * 2’b00: clk0
   * 2’b01: clk1
   * 2’b10: clk2
   * 2’b11: clk3
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_CLKSEL_A_RW (0x03 << 13)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_CLKSEL_A_SHIFT 13
   /*
   * Selects the PLL clock used in channel A, B or C.
   * 2’b00: clk0
   * 2’b01: clk1
   * 2’b10: clk2
   * 2’b11: clk3
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_CLKSEL_B_RW (0x03 << 11)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_CLKSEL_B_SHIFT 11
   /*
   * Selects the PLL clock used in channel A, B or C.
   * 2’b00: clk0
   * 2’b01: clk1
   * 2’b10: clk2
   * 2’b11: clk3
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_CLKSEL_C_RW (0x03 << 9)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_CLKSEL_C_SHIFT 9
   /*
   * Sync counter value used for internal Alpha channel clock sync when clksync4x_8x 
   * module is in bypass mode or used in series. Bit 0 and 1 are used when in 1080p60
   * Hz mode.
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SYNCOUT_CNT_A_RW (0x07 << 6)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SYNCOUT_CNT_A_SHIFT 6
   /*
   * Sync counter value used for internal Alpha channel clock sync when clksync4x_8x 
   * module is in bypass mode or used in series. Bit 0 and 1 are used when in 1080p60
   * Hz mode.
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SYNCOUT_CNT_B_RW (0x07 << 3)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SYNCOUT_CNT_B_SHIFT 3
   /*
   * Sync counter value used for internal Alpha channel clock sync when clksync4x_8x 
   * module is in bypass mode or used in series. Bit 0 and 1 are used when in 1080p60
   * Hz mode.
   */
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SYNCOUT_CNT_C_RW (0x07 << 0)
   #define GLOBALREG_VDAC1_CTRL3_VDAC1_SYNCOUT_CNT_C_SHIFT 0
   /*
   * VDAC1 Control4
   */
   #define GLOBALREG_VDAC1_CTRL4_REG1  (GLOBALREG_BASE_UNIT1 + 0x930)
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC1_CTRL4_RESERVED_RW (0x03 << 30)
   #define GLOBALREG_VDAC1_CTRL4_RESERVED_SHIFT 30
   /*
   * Register field to select the bypass mode of the “latched” version of the clock s
   * ync pulse used in DAC channel A.
   * 2’b00: Use one of the clock sync pulse generated by clksync4x_8x module
   * 2’b01: Use “latched” version of the clock sync pulse generated by clksync4x_8x m
   * odule
   * 2’b10: Use the internal sync counter to generate the clock pulse along with one 
   * of the clock sync pulses generated by clksync4x_8x module with the “latch”
   * 2’b11: Use the internal sync counter to generate the clock pulse along with one 
   * of the clock sync pulses generated by clksync4x_8x module without the “latch”
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_SYNC_LAT_A_RW (0x03 << 28)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_SYNC_LAT_A_SHIFT 28
   /*
   * See vdac1_bypass_sync_lat_a
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_SYNC_LAT_B_RW (0x03 << 26)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_SYNC_LAT_B_SHIFT 26
   /*
   * See vdac1_bypass_sync_lat_a
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_SYNC_LAT_C_RW (0x03 << 24)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_SYNC_LAT_C_SHIFT 24
   /*
   * Register field to bypass the upsample filters.
   * [0]: Bypass 1x to 2x upsample filter
   * [1]: Bypass 2x to 4x upsample filter
   * [2]: Bypass 4x to 8x upsample filter
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_FILTER_A_RW (0x07 << 21)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_FILTER_A_SHIFT 21
   /*
   * See vdac1_bypass_filter_a
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_FILTER_B_RW (0x07 << 18)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_FILTER_B_SHIFT 18
   /*
   * See vdac1_bypass_filter_a
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_FILTER_C_RW (0x07 << 15)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_BYPASS_FILTER_C_SHIFT 15
   /*
   * Low: r_offset is added to internally generated filter calibration code
   * High: r_offset is subtracted from internally generated filter calibration code
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_ROFFSET_SUBTRACT_RW (0x01 << 14)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_ROFFSET_SUBTRACT_SHIFT 14
   /*
   * Value is added to / subtracted from internally generated resistor calibration co
   * de
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_R_OFFSET_RW (0x03f << 8)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_R_OFFSET_SHIFT 8
   /*
   * Calibration code used for resistor calibration when rcal_ovrd is High
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_RCODE_OVD_RW (0x01f << 3)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_RCODE_OVD_SHIFT 3
   /*
   * Powers down the resistor calibration block.
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_RCAL_PD_RW (0x01 << 2)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_RCAL_PD_SHIFT 2
   /*
   * Enable override for resistor calibration code
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_RCAL_OVRD_RW (0x01 << 1)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_RCAL_OVRD_SHIFT 1

   /*
   * Resets resistor calibration circuit. Active Low.
   */
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_RCAL_NRESET_RW (0x01 << 0)
   #define GLOBALREG_VDAC1_CTRL4_VDAC1_RCAL_NRESET_SHIFT 0
   /*
   * VDAC1 Test Control
   */
   #define GLOBALREG_VDAC1_TEST_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x934)
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC1_TEST_CTRL_RESERVED_RW (0x01fffff << 11)
   #define GLOBALREG_VDAC1_TEST_CTRL_RESERVED_SHIFT 11
   /*
   * Gain value of the wave generator.
   * 2’b00: Full scale
   * 2’b01: 1/2 scale
   * 2’b10: 1/4 scale
   * 2’b11: 1/8 scale
   */
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_WAV_GAIN_RW (0x03 << 9)
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_WAV_GAIN_SHIFT 9
   /*
   * Offset value for the wave generator:
   * 3’b000: No offset
   * 3’b001: +128
   * 3’b010: +256
   * 3’b011: +384
   * 3’b100: -512
   * 3’b101: -384
   * 3’b110: -256
   * 3’b111: -128
   */
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_WAV_OFFSET_RW (0x07 << 6)
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_WAV_OFFSET_SHIFT 6
   /*
   * Selects waveform gen mode for channel A
   * When test_en_a is High, clksel_a<1:0> and clksel_wg<1:0> MUST have the same sett
   * ing
   */
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_TEST_EN_A_RW (0x01 << 5)
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_TEST_EN_A_SHIFT 5
   /*
   * Selects waveform gen mode for channel B
   * When test_en_b is High, clksel_b<1:0> and clksel_wg<1:0> MUST have the same sett
   * ing
   */
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_TEST_EN_B_RW (0x01 << 4)
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_TEST_EN_B_SHIFT 4
   /*
   * Selects waveform gen mode for channel C
   * When test_en_c is High, clksel_c<1:0> and clksel_wg<1:0> MUST have the same sett
   * ing
   */
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_TEST_EN_C_RW (0x01 << 3)
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_TEST_EN_C_SHIFT 3
   /*
   * Bit [1:0] selects the wave mode:
   * 2’b00: Sine wave
   * 2’b01: Ramp
   * 2’b10: Square wave
   * 2’b11: Chirp
   * Bit 2 selects the bypass upsample filter mode when wave generator is used:
   * 1’b0: Bypass upsample filters
   * 1’b1: Use upsample filters
   */
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_TEST_MODE_RW (0x07 << 0)
   #define GLOBALREG_VDAC1_TEST_CTRL_VDAC1_TEST_MODE_SHIFT 0
   /*
   * VDAC1 DTO Increment Value0
   */
   #define GLOBALREG_VDAC1_DTO_INCR0_REG1  (GLOBALREG_BASE_UNIT1 + 0x938)
   /*
   * DTO increment value for the sine wave generator for wave0
   */
   #define GLOBALREG_VDAC1_DTO_INCR0_VDAC1_DTO_INCR0_RW (0x0ffffffff << 0)
   #define GLOBALREG_VDAC1_DTO_INCR0_VDAC1_DTO_INCR0_SHIFT 0
   /*
   * VDAC1 DTO Increment Value0
   */
   #define GLOBALREG_VDAC1_DTO_INCR1_REG1  (GLOBALREG_BASE_UNIT1 + 0x93c)
   /*
   * DTO increment value for the sine wave generator for wave1
   */
   #define GLOBALREG_VDAC1_DTO_INCR1_VDAC1_DTO_INCR1_RW (0x0ffffffff << 0)
   #define GLOBALREG_VDAC1_DTO_INCR1_VDAC1_DTO_INCR1_SHIFT 0
   /*
   * VDAC1 STATUS
   */
   #define GLOBALREG_VDAC1_STAT_REG1  (GLOBALREG_BASE_UNIT1 + 0x940)
   /*
   * Reserved
   */
   #define GLOBALREG_VDAC1_STAT_RESERVED_R (0x01f << 27)
   #define GLOBALREG_VDAC1_STAT_RESERVED_SHIFT 27
   /*
   * Capacitor codes obtained from calibration circuitry
   */
   #define GLOBALREG_VDAC1_STAT_VDAC1_CCODE_DRV_R (0x07 << 24)
   #define GLOBALREG_VDAC1_STAT_VDAC1_CCODE_DRV_SHIFT 24
   /*
   * Output code obtained from RC calibration
   */
   #define GLOBALREG_VDAC1_STAT_VDAC1_FLT_CAL_CODE_R (0x03f << 18)
   #define GLOBALREG_VDAC1_STAT_VDAC1_FLT_CAL_CODE_SHIFT 18
   /*
   * Indicates completion of filter calibration.
   */
   #define GLOBALREG_VDAC1_STAT_VDAC1_FLT_DONE_R (0x01 << 17)
   #define GLOBALREG_VDAC1_STAT_VDAC1_FLT_DONE_SHIFT 17
   /*
   * Indicates completion of resistor calibration.
   */
   #define GLOBALREG_VDAC1_STAT_VDAC1_RCAL_DONE_R (0x01 << 16)
   #define GLOBALREG_VDAC1_STAT_VDAC1_RCAL_DONE_SHIFT 16
   /*
   * Output code obtained from resistor calibration
   */
   #define GLOBALREG_VDAC1_STAT_VDAC1_RCODE_DRV_R (0x01f << 11)
   #define GLOBALREG_VDAC1_STAT_VDAC1_RCODE_DRV_SHIFT 11
   /*
   * Spare output bits
   */
   #define GLOBALREG_VDAC1_STAT_VDAC1_SPARE_OUT_R (0x0ff << 3)
   #define GLOBALREG_VDAC1_STAT_VDAC1_SPARE_OUT_SHIFT 3
   /*
   * Monitor Status output for channel A
   */
   #define GLOBALREG_VDAC1_STAT_VDAC1_STAT_OUT_A_R (0x01 << 2)
   #define GLOBALREG_VDAC1_STAT_VDAC1_STAT_OUT_A_SHIFT 2
   /*
   * Monitor Status output for channel B
   */
   #define GLOBALREG_VDAC1_STAT_VDAC1_STAT_OUT_B_R (0x01 << 1)
   #define GLOBALREG_VDAC1_STAT_VDAC1_STAT_OUT_B_SHIFT 1
   /*
   * Monitor Status output for channel C
   */
   #define GLOBALREG_VDAC1_STAT_VDAC1_STAT_OUT_C_R (0x01 << 0)
   #define GLOBALREG_VDAC1_STAT_VDAC1_STAT_OUT_C_SHIFT 0
   /*
   * General purpose (32 scratch pad registers, n = 0-31)
   */
   #define GLOBALREG_SCRATCH_REG(n) (GLOBALREG_BASE_UNIT1 + 0xd00 + ((n)*4))
   /*
   * 32bit writable and readable register.They are not supposed to be reset, so that 
   * their values survive a reset and allow passing of info through a reset .
   */
   #define GLOBALREG_SCRATCH_VAL_RW    (0xffffffff << 0)
   #define GLOBALREG_SCRATCH_VAL_SHIFT 0

   /*
   * 12bit semaphore (16 semaphores, n = 0-15)
   */
   #define GLOBALREG_SEMAPHORE_REG(n)  (GLOBALREG_BASE_UNIT1 + 0xe00 + ((n)*4))
   /*
   * Reserved
   */
   #define GLOBALREG_SEMAPHORE_RESERVED_RW    (0x000fffff << 12)
   #define GLOBALREG_SEMAPHORE_RESERVED_SHIFT 12
   /*
   * Writing to this field is only accepted when its current content is zero or when 
   * the data to be written is zero.
   */
   #define GLOBALREG_SEMAPHORE_VAL_RW    (0xfff << 0)
   #define GLOBALREG_SEMAPHORE_VAL_SHIFT 0

   /* 8 IPC registers, n = 0-7 */
   #define GLOBALREG_IPC_BASE(n) (GLOBALREG_BASE_UNIT1 + 0xf00 + ((n)*0x20))
   /*
   * Interrupt clear enable for first IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_CLR_ENABLE_REG(n) (GLOBALREG_IPC_BASE(n) + 0x00)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_CLR_ENABLE_RESERVED_W (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_CLR_ENABLE_RESERVED_SHIFT 8
   /*
   * IPC: clear interrupt enable bits of 8 interrupt bits; bits are under SW control
   *  for inter processor communication (IPC)
   */
   #define GLOBALREG_IPC_INTERRUPT_CLR_ENABLE_VAL_W     (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_CLR_ENABLE_VAL_SHIFT 0
   /*
   * Interrupt set enable for IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_ENABLE_REG(n) (GLOBALREG_IPC_BASE(n) + 0x04)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_ENABLE_RESERVED_W (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_SET_ENABLE_RESERVED_SHIFT 8
   /*
   * IPC: set interrupt enable bits of 8 interrupt bits
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_ENABLE_VAL_W      (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_SET_ENABLE_VAL_SHIFT  0
   /*
   * Interrupt status for IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_STATUS_REG(n)  (GLOBALREG_IPC_BASE(n) + 0x08)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_STATUS_RESERVED_R (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_STATUS_RESERVED_SHIFT 8
   /*
   * IPC: interrupt status of the 8 interrupt bits
   */
   #define GLOBALREG_IPC_INTERRUPT_STATUS_VAL_R      (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_STATUS_VAL_SHIFT  0
   /*
   * Interrupt enable for IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_ENABLE_REG(n) (GLOBALREG_IPC_BASE(n) + 0x0c)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_ENABLE_RESERVED_R (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_ENABLE_RESERVED_SHIFT 8
   /*
   * IPC: enable up to 8 interrupt bits
   */
   #define GLOBALREG_IPC_INTERRUPT_ENABLE_VAL_R     (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_ENABLE_VAL_SHIFT 0
   /*
   * Interrupt clear for IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_CLEAR_REG(n)  (GLOBALREG_IPC_BASE(n) + 0x10)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_CLEAR_RESERVED_W (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_CLEAR_RESERVED_SHIFT 8
   /*
   * IPC: clear up to 8 interrupt bits
   */
   #define GLOBALREG_IPC_INTERRUPT_CLEAR_VAL_W      (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_CLEAR_VAL_SHIFT  0
   /*
   * Interrupt set for IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_REG(n)  (GLOBALREG_IPC_BASE(n) + 0x14)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_RESERVED_W (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_SET_RESERVED_SHIFT 8
   /*
   * IPC: set up to 8 interrupt bits
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_VAL_W      (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_SET_VAL_SHIFT  0

   /*
   * Memory Size Select
   */
   #define GLOBALREG_MEM_SIZE_SEL_REG1  (GLOBALREG_BASE_UNIT1 + 0xff8)
   /*
   * Memory Size Select (no output)
   */
   #define GLOBALREG_MEM_SIZE_SEL_MEM_SIZE_SEL_RW (0x0ffffffff << 0)
   #define GLOBALREG_MEM_SIZE_SEL_MEM_SIZE_SEL_SHIFT 0
   /*
   * Global register module identification
   */
   #define GLOBALREG_MODULE_ID_REG1  (GLOBALREG_BASE_UNIT1 + 0xffc)
   /*
   * Unique 16-bit code.
   * This is 0xA150 for PNX85500.
   * Variants identified by minor revision bit.
   */
   #define GLOBALREG_MODULE_ID_MODULE_ID_R (0x0ffff << 16)
   #define GLOBALREG_MODULE_ID_MODULE_ID_SHIFT 16
   /*
   * Major Revision Number
   */
   #define GLOBALREG_MODULE_ID_MAJOR_REV_R (0x0f << 12)
   #define GLOBALREG_MODULE_ID_MAJOR_REV_SHIFT 12
   /*
   * Minor Revision Number
   */
   #define GLOBALREG_MODULE_ID_MINOR_REV_R (0x0f << 8)
   #define GLOBALREG_MODULE_ID_MINOR_REV_SHIFT 8
   /*
   * Encoded as: Aperture size = 4K*(bit_value+1). The bit value is reset to 0 meanin
   * g a 4K aperture for the global register
   * module according to the formula above.
   */
   #define GLOBALREG_MODULE_ID_MODULE_APERTURE_SIZE_R (0x0ff << 0)
   #define GLOBALREG_MODULE_ID_MODULE_APERTURE_SIZE_SHIFT 0

#endif // PHMODIPGLOBALREG_H
