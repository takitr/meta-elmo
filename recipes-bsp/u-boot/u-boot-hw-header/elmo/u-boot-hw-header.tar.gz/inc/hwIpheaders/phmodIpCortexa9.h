 ///////////////////////////////////////////////////////////////////// 
//                                                                  / 
// (c) NXP B.V 2009                                                / 
//                                                                  / 
// All rights are reserved. Reproduction in whole or in part is     / 
// prohibited without the prior written consent of the copy-right   / 
// owner.                                                           / 
// The information presented in this document does not form part of / 
// any quotation or contract, is believed to be accurate and        / 
// reliable and may be changed without notice. No liability will be / 
// accepted by the publisher for any consequence of its use.        / 
// Publication thereof does not convey nor imply any license under  / 
// patent- or other industrial or intellectual property rights.     / 
 ///////////////////////////////////////////////////////////////////// 
 
/*! 
 *  @brief Header file for 
CortexA9 *  @file phmodIpCortexa9.h *
 *  <pre>
 *  $Author: gargn $
 *  $Revision: 99754 $
 *  $Date: 2009-06-25 17:40:42 -0500 (Thu, 25 Jun 2009) $
 *
 *  Revision history
 *  $Log: $
 *  
 *
 *  $KeysEnd$
 *  </pre>
 *
 */ 


#ifndef PHMODIPCORTEXA9_H
#define PHMODIPCORTEXA9_H
	
	
	/*
	* Debug ID Register
	*/
	#define CORTEXA9_DBGDIDR_REG  (CORTEXA9_BASE + 0x8000)
	/*
	* The number of Watchpoint Register Pairs (WRPs) implemented
	*/
	#define CORTEXA9_DBGDIDR_WRPS_R (0x07 << 28)
	#define CORTEXA9_DBGDIDR_WRPS_SHIFT 28
	#define CORTEXA9_DBGDIDR_WRPS_VAL0 0x00
	#define CORTEXA9_DBGDIDR_WRPS_VAL1 0x01
	#define CORTEXA9_DBGDIDR_WRPS_VAL2 0x02
	#define CORTEXA9_DBGDIDR_WRPS_VAL3 0x03
	#define CORTEXA9_DBGDIDR_WRPS_VAL4 0x04
	#define CORTEXA9_DBGDIDR_WRPS_VAL5 0x05
	#define CORTEXA9_DBGDIDR_WRPS_VAL6 0x06
	#define CORTEXA9_DBGDIDR_WRPS_VAL7 0x07
	/*
	* The number of Breakpoint Register Pairs (BRPs) implemented
	*/
	#define CORTEXA9_DBGDIDR_BRPS_R (0x07 << 24)
	#define CORTEXA9_DBGDIDR_BRPS_SHIFT 24
	#define CORTEXA9_DBGDIDR_BRPS_VAL0 0x00
	#define CORTEXA9_DBGDIDR_BRPS_VAL1 0x01
	#define CORTEXA9_DBGDIDR_BRPS_VAL2 0x02
	#define CORTEXA9_DBGDIDR_BRPS_VAL3 0x03
	#define CORTEXA9_DBGDIDR_BRPS_VAL4 0x04
	#define CORTEXA9_DBGDIDR_BRPS_VAL5 0x05
	#define CORTEXA9_DBGDIDR_BRPS_VAL6 0x06
	#define CORTEXA9_DBGDIDR_BRPS_VAL7 0x07
	/*
	* The number of BRPs that can be used for Context ID comparison
	*/
	#define CORTEXA9_DBGDIDR_CTX_CMPS_R (0x07 << 20)
	#define CORTEXA9_DBGDIDR_CTX_CMPS_SHIFT 20
	#define CORTEXA9_DBGDIDR_CTX_CMPS_VAL0 0x00
	#define CORTEXA9_DBGDIDR_CTX_CMPS_VAL1 0x01
	#define CORTEXA9_DBGDIDR_CTX_CMPS_VAL2 0x02
	#define CORTEXA9_DBGDIDR_CTX_CMPS_VAL3 0x03
	#define CORTEXA9_DBGDIDR_CTX_CMPS_VAL4 0x04
	#define CORTEXA9_DBGDIDR_CTX_CMPS_VAL5 0x05
	#define CORTEXA9_DBGDIDR_CTX_CMPS_VAL6 0x06
	#define CORTEXA9_DBGDIDR_CTX_CMPS_VAL7 0x07
	/*
	* The Debug architecture version
	*/
	#define CORTEXA9_DBGDIDR_VERSION_R (0x07 << 16)
	#define CORTEXA9_DBGDIDR_VERSION_SHIFT 16
	#define CORTEXA9_DBGDIDR_VERSION_VAL0 0x00
	#define CORTEXA9_DBGDIDR_VERSION_VAL1 0x01
	#define CORTEXA9_DBGDIDR_VERSION_VAL2 0x02
	#define CORTEXA9_DBGDIDR_VERSION_VAL3 0x03
	#define CORTEXA9_DBGDIDR_VERSION_VAL4 0x04
	#define CORTEXA9_DBGDIDR_VERSION_VAL5 0x05
	#define CORTEXA9_DBGDIDR_VERSION_VAL6 0x06
	#define CORTEXA9_DBGDIDR_VERSION_VAL7 0x07
	/*
	* Debug Device ID Register, DBGDEVID, implemented bit.
	*/
	#define CORTEXA9_DBGDIDR_DEVID_IMP_R (0x01 << 15)
	#define CORTEXA9_DBGDIDR_DEVID_IMP_SHIFT 15
	#define CORTEXA9_DBGDIDR_DEVID_IMP_VAL0 0x00
	#define CORTEXA9_DBGDIDR_DEVID_IMP_VAL1 0x01
	/*
	* Secure User halting debug not implemented bit
	*/
	#define CORTEXA9_DBGDIDR_NSUHD_IMP_R (0x01 << 14)
	#define CORTEXA9_DBGDIDR_NSUHD_IMP_SHIFT 14
	#define CORTEXA9_DBGDIDR_NSUHD_IMP_VAL0 0x00
	#define CORTEXA9_DBGDIDR_NSUHD_IMP_VAL1 0x01
	/*
	* Program Counter Sampling Register (DBGPCSR) implemented as register 33 bit
	*/
	#define CORTEXA9_DBGDIDR_PCSR_IMP_R (0x01 << 13)
	#define CORTEXA9_DBGDIDR_PCSR_IMP_SHIFT 13
	#define CORTEXA9_DBGDIDR_PCSR_IMP_VAL0 0x00
	#define CORTEXA9_DBGDIDR_PCSR_IMP_VAL1 0x01
	/*
	* Security Extensions implemented bit
	*/
	#define CORTEXA9_DBGDIDR_SE_IMP_R (0x01 << 12)
	#define CORTEXA9_DBGDIDR_SE_IMP_SHIFT 12
	#define CORTEXA9_DBGDIDR_SE_IMP_VAL0 0x00
	#define CORTEXA9_DBGDIDR_SE_IMP_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGDIDR_RESERVED_RES (0x07 << 8)
	#define CORTEXA9_DBGDIDR_RESERVED_SHIFT 8
	#define CORTEXA9_DBGDIDR_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGDIDR_RESERVED_VAL1 0x01
	#define CORTEXA9_DBGDIDR_RESERVED_VAL2 0x02
	#define CORTEXA9_DBGDIDR_RESERVED_VAL3 0x03
	#define CORTEXA9_DBGDIDR_RESERVED_VAL4 0x04
	#define CORTEXA9_DBGDIDR_RESERVED_VAL5 0x05
	#define CORTEXA9_DBGDIDR_RESERVED_VAL6 0x06
	#define CORTEXA9_DBGDIDR_RESERVED_VAL7 0x07
	/*
	* This field holds an IMPLEMENTATION DEFINED variant number
	*/
	#define CORTEXA9_DBGDIDR_VARIANT_R (0x07 << 4)
	#define CORTEXA9_DBGDIDR_VARIANT_SHIFT 4
	#define CORTEXA9_DBGDIDR_VARIANT_VAL0 0x00
	#define CORTEXA9_DBGDIDR_VARIANT_VAL1 0x01
	#define CORTEXA9_DBGDIDR_VARIANT_VAL2 0x02
	#define CORTEXA9_DBGDIDR_VARIANT_VAL3 0x03
	#define CORTEXA9_DBGDIDR_VARIANT_VAL4 0x04
	#define CORTEXA9_DBGDIDR_VARIANT_VAL5 0x05
	#define CORTEXA9_DBGDIDR_VARIANT_VAL6 0x06
	#define CORTEXA9_DBGDIDR_VARIANT_VAL7 0x07
	/*
	* This field holds an IMPLEMENTATION DEFINED revision number
	*/
	#define CORTEXA9_DBGDIDR_REVISION_R (0x0f << 0)
	#define CORTEXA9_DBGDIDR_REVISION_SHIFT 0
	#define CORTEXA9_DBGDIDR_REVISION_VAL0 0x00
	#define CORTEXA9_DBGDIDR_REVISION_VAL1 0x01
	#define CORTEXA9_DBGDIDR_REVISION_VAL2 0x02
	#define CORTEXA9_DBGDIDR_REVISION_VAL3 0x03
	#define CORTEXA9_DBGDIDR_REVISION_VAL4 0x04
	#define CORTEXA9_DBGDIDR_REVISION_VAL5 0x05
	#define CORTEXA9_DBGDIDR_REVISION_VAL6 0x06
	#define CORTEXA9_DBGDIDR_REVISION_VAL7 0x07
	#define CORTEXA9_DBGDIDR_REVISION_VAL8 0x08
	#define CORTEXA9_DBGDIDR_REVISION_VAL9 0x09
	#define CORTEXA9_DBGDIDR_REVISION_VAL10 0x0a
	#define CORTEXA9_DBGDIDR_REVISION_VAL11 0x0b
	#define CORTEXA9_DBGDIDR_REVISION_VAL12 0x0c
	#define CORTEXA9_DBGDIDR_REVISION_VAL13 0x0d
	#define CORTEXA9_DBGDIDR_REVISION_VAL14 0x0e
	#define CORTEXA9_DBGDIDR_REVISION_VAL15 0x0f
	/*
	* Watchpoint Fault Address Register
	* Returns information about the address of the instruction that accessed a watchpo
	* inted address.
	*/
	#define CORTEXA9_DBGWFAR_REG  (CORTEXA9_BASE + 0x8018)
	/*
	* (Instruction address) + offset
	*/
	#define CORTEXA9_DBGWFAR_INSTRUCTIONOFFSET_RW (0x07fffffff << 0)
	#define CORTEXA9_DBGWFAR_INSTRUCTIONOFFSET_SHIFT 0
	/*
	* Vector Catch Register
	* Enables Vector Catch debug events
	*/
	#define CORTEXA9_DBGVCR_REG  (CORTEXA9_BASE + 0x801c)
	/*
	* FIQ vector catch enable in Non-secure state
	*/
	#define CORTEXA9_DBGVCR_FIQ_NS_RW (0x01 << 31)
	#define CORTEXA9_DBGVCR_FIQ_NS_SHIFT 31
	#define CORTEXA9_DBGVCR_FIQ_NS_VAL0 0x00
	#define CORTEXA9_DBGVCR_FIQ_NS_VAL1 0x01
	/*
	* IRQ vector catch enable in Non-secure state
	*/
	#define CORTEXA9_DBGVCR_IRQ_NS_RW (0x01 << 30)
	#define CORTEXA9_DBGVCR_IRQ_NS_SHIFT 30
	#define CORTEXA9_DBGVCR_IRQ_NS_VAL0 0x00
	#define CORTEXA9_DBGVCR_IRQ_NS_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGVCR_RESERVED_RES (0x01 << 29)
	#define CORTEXA9_DBGVCR_RESERVED_SHIFT 29
	#define CORTEXA9_DBGVCR_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGVCR_RESERVED_VAL1 0x01
	/*
	* Data Abort vector catch enable in Non-secure state
	*/
	#define CORTEXA9_DBGVCR_DATA_ABORT_NS_RW (0x01 << 28)
	#define CORTEXA9_DBGVCR_DATA_ABORT_NS_SHIFT 28
	#define CORTEXA9_DBGVCR_DATA_ABORT_NS_VAL0 0x00
	#define CORTEXA9_DBGVCR_DATA_ABORT_NS_VAL1 0x01
	/*
	* Prefetch Abort vector catch enable in Non-secure state
	*/
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_NS_RW (0x01 << 27)
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_NS_SHIFT 27
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_NS_VAL0 0x00
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_NS_VAL1 0x01
	/*
	* SVC vector catch enable in Non-secure state
	*/
	#define CORTEXA9_DBGVCR_SVC_NS_RW (0x01 << 26)
	#define CORTEXA9_DBGVCR_SVC_NS_SHIFT 26
	#define CORTEXA9_DBGVCR_SVC_NS_VAL0 0x00
	#define CORTEXA9_DBGVCR_SVC_NS_VAL1 0x01
	/*
	* Undefined Instruction vector catch enable in Non-secure state
	*/
	#define CORTEXA9_DBGVCR_UNDEFINED_INSTRUCTION_NS_RW (0x01 << 25)
	#define CORTEXA9_DBGVCR_UNDEFINED_INSTRUCTION_NS_SHIFT 25
	#define CORTEXA9_DBGVCR_UNDEFINED_INSTRUCTION_NS_VAL0 0x00
	#define CORTEXA9_DBGVCR_UNDEFINED_INSTRUCTION_NS_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGVCR_RESERVED7_RES (0x0ff << 16)
	#define CORTEXA9_DBGVCR_RESERVED7_SHIFT 16
	/*
	* FIQ vector catch enable in Secure state on Monitor mode vector
	*/
	#define CORTEXA9_DBGVCR_FIQ_RW (0x01 << 15)
	#define CORTEXA9_DBGVCR_FIQ_SHIFT 15
	#define CORTEXA9_DBGVCR_FIQ_VAL0 0x00
	#define CORTEXA9_DBGVCR_FIQ_VAL1 0x01
	/*
	* IRQ vector catch enable in in Secure state on Monitor mode vector
	*/
	#define CORTEXA9_DBGVCR_IRQ_RW (0x01 << 14)
	#define CORTEXA9_DBGVCR_IRQ_SHIFT 14
	#define CORTEXA9_DBGVCR_IRQ_VAL0 0x00
	#define CORTEXA9_DBGVCR_IRQ_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGVCR_RESERVED10_RES (0x01 << 13)
	#define CORTEXA9_DBGVCR_RESERVED10_SHIFT 13
	#define CORTEXA9_DBGVCR_RESERVED10_VAL0 0x00
	#define CORTEXA9_DBGVCR_RESERVED10_VAL1 0x01
	/*
	* Data Abort vector catch enable in Secure state on Monitor mode vector
	*/
	#define CORTEXA9_DBGVCR_DATA_ABORT_RW (0x01 << 12)
	#define CORTEXA9_DBGVCR_DATA_ABORT_SHIFT 12
	#define CORTEXA9_DBGVCR_DATA_ABORT_VAL0 0x00
	#define CORTEXA9_DBGVCR_DATA_ABORT_VAL1 0x01
	/*
	* Prefetch Abort vector catch enable in Secure state on Monitor mode vector
	*/
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_RW (0x01 << 11)
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_SHIFT 11
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_VAL0 0x00
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_VAL1 0x01
	/*
	* SVC vector catch enable in Secure state on Monitor mode vector
	*/
	#define CORTEXA9_DBGVCR_SVC_RW (0x01 << 10)
	#define CORTEXA9_DBGVCR_SVC_SHIFT 10
	#define CORTEXA9_DBGVCR_SVC_VAL0 0x00
	#define CORTEXA9_DBGVCR_SVC_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGVCR_RESERVED14_RES (0x01 << 8)
	#define CORTEXA9_DBGVCR_RESERVED14_SHIFT 8
	#define CORTEXA9_DBGVCR_RESERVED14_VAL0 0x00
	#define CORTEXA9_DBGVCR_RESERVED14_VAL1 0x01
	/*
	* FIQ vector catch enable in Secure state
	*/
	#define CORTEXA9_DBGVCR_FIQ_S_RW (0x01 << 7)
	#define CORTEXA9_DBGVCR_FIQ_S_SHIFT 7
	#define CORTEXA9_DBGVCR_FIQ_S_VAL0 0x00
	#define CORTEXA9_DBGVCR_FIQ_S_VAL1 0x01
	/*
	* IRQ vector catch enable in Secure state
	*/
	#define CORTEXA9_DBGVCR_IRQ_S_RW (0x01 << 6)
	#define CORTEXA9_DBGVCR_IRQ_S_SHIFT 6
	#define CORTEXA9_DBGVCR_IRQ_S_VAL0 0x00
	#define CORTEXA9_DBGVCR_IRQ_S_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGVCR_RESERVED17_RES (0x01 << 5)
	#define CORTEXA9_DBGVCR_RESERVED17_SHIFT 5
	#define CORTEXA9_DBGVCR_RESERVED17_VAL0 0x00
	#define CORTEXA9_DBGVCR_RESERVED17_VAL1 0x01
	/*
	* Data Abort vector catch enable in Secure state
	*/
	#define CORTEXA9_DBGVCR_DATA_ABORT_S_RW (0x01 << 4)
	#define CORTEXA9_DBGVCR_DATA_ABORT_S_SHIFT 4
	#define CORTEXA9_DBGVCR_DATA_ABORT_S_VAL0 0x00
	#define CORTEXA9_DBGVCR_DATA_ABORT_S_VAL1 0x01
	/*
	* Prefetch Abort vector catch enable in Secure state
	*/
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_S_RW (0x01 << 3)
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_S_SHIFT 3
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_S_VAL0 0x00
	#define CORTEXA9_DBGVCR_PREFETCH_ABORT_S_VAL1 0x01
	/*
	* SVC vector catch enable in Secure state
	*/
	#define CORTEXA9_DBGVCR_SVC_S_RW (0x01 << 2)
	#define CORTEXA9_DBGVCR_SVC_S_SHIFT 2
	#define CORTEXA9_DBGVCR_SVC_S_VAL0 0x00
	#define CORTEXA9_DBGVCR_SVC_S_VAL1 0x01
	/*
	* Undefined Instruction vector catch enable in Secure state
	*/
	#define CORTEXA9_DBGVCR_UNDEFINED_INSTRUCTION_S_RW (0x01 << 1)
	#define CORTEXA9_DBGVCR_UNDEFINED_INSTRUCTION_S_SHIFT 1
	#define CORTEXA9_DBGVCR_UNDEFINED_INSTRUCTION_S_VAL0 0x00
	#define CORTEXA9_DBGVCR_UNDEFINED_INSTRUCTION_S_VAL1 0x01
	/*
	* Reset vector catch enable
	*/
	#define CORTEXA9_DBGVCR_RESET_VECTOR_CATCH_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGVCR_RESET_VECTOR_CATCH_ENABLE_SHIFT 0
	#define CORTEXA9_DBGVCR_RESET_VECTOR_CATCH_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGVCR_RESET_VECTOR_CATCH_ENABLE_VAL1 0x01
	/*
	* The Host to Target Data Transfer Register, DBGDTRRX, is used by an external host
	*  to transfer data to the ARM processor
	*/
	#define CORTEXA9_DBGDTRRX_REG  (CORTEXA9_BASE + 0x8080)
	/*
	* One word of data for transfer from the debug host to the debug target
	*/
	#define CORTEXA9_DBGDTRRX_HOST_TO_TARGET_DATA_RW (0x07fffffff << 0)
	#define CORTEXA9_DBGDTRRX_HOST_TO_TARGET_DATA_SHIFT 0
	/*
	* The Instruction Transfer Register, DBGITR, enables external debugger to transfer
	*  ARM instructions to the processor for execution when the processor is in Debug 
	* state.
	*/
	#define CORTEXA9_DBGITR_REG  (CORTEXA9_BASE + 0x8084)
	/*
	* ARM instruction to execute on the processor
	*/
	#define CORTEXA9_DBGITR_ARM_INSTRUCTION_W (0x07fffffff << 0)
	#define CORTEXA9_DBGITR_ARM_INSTRUCTION_SHIFT 0
	/*
	* The Debug Status and Control Register, DBGDSCR, provides the main control regist
	* er for the debug facilities in the ARM architecture.
	*/
	#define CORTEXA9_DBGDSCR_REG  (CORTEXA9_BASE + 0x8088)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGDSCR_RESERVED_RES (0x01 << 31)
	#define CORTEXA9_DBGDSCR_RESERVED_SHIFT 31
	#define CORTEXA9_DBGDSCR_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGDSCR_RESERVED_VAL1 0x01
	/*
	* The DBGDTRRX Register full bit
	*/
	#define CORTEXA9_DBGDSCR_RXFULL_RW (0x01 << 30)
	#define CORTEXA9_DBGDSCR_RXFULL_SHIFT 30
	#define CORTEXA9_DBGDSCR_RXFULL_VAL0 0x00
	#define CORTEXA9_DBGDSCR_RXFULL_VAL1 0x01
	/*
	* The DBGDTRTX Register full bit
	*/
	#define CORTEXA9_DBGDSCR_TXFULL_RW (0x01 << 29)
	#define CORTEXA9_DBGDSCR_TXFULL_SHIFT 29
	#define CORTEXA9_DBGDSCR_TXFULL_VAL0 0x00
	#define CORTEXA9_DBGDSCR_TXFULL_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGDSCR_RESERVED3_RES (0x01 << 28)
	#define CORTEXA9_DBGDSCR_RESERVED3_SHIFT 28
	#define CORTEXA9_DBGDSCR_RESERVED3_VAL0 0x00
	#define CORTEXA9_DBGDSCR_RESERVED3_VAL1 0x01
	/*
	* The latched RXfull bit
	*/
	#define CORTEXA9_DBGDSCR_RXFULL_L_RW (0x01 << 27)
	#define CORTEXA9_DBGDSCR_RXFULL_L_SHIFT 27
	#define CORTEXA9_DBGDSCR_RXFULL_L_VAL0 0x00
	#define CORTEXA9_DBGDSCR_RXFULL_L_VAL1 0x01
	/*
	* The latched TXfull bit
	*/
	#define CORTEXA9_DBGDSCR_TXFULL_L_RW (0x01 << 26)
	#define CORTEXA9_DBGDSCR_TXFULL_L_SHIFT 26
	#define CORTEXA9_DBGDSCR_TXFULL_L_VAL0 0x00
	#define CORTEXA9_DBGDSCR_TXFULL_L_VAL1 0x01
	/*
	* Sticky Pipeline Advance bit
	*/
	#define CORTEXA9_DBGDSCR_PIPEADV_RW (0x01 << 25)
	#define CORTEXA9_DBGDSCR_PIPEADV_SHIFT 25
	#define CORTEXA9_DBGDSCR_PIPEADV_VAL0 0x00
	#define CORTEXA9_DBGDSCR_PIPEADV_VAL1 0x01
	/*
	* The latched Instruction Complete bit
	*/
	#define CORTEXA9_DBGDSCR_INSTRCOMPL_L_RW (0x01 << 24)
	#define CORTEXA9_DBGDSCR_INSTRCOMPL_L_SHIFT 24
	#define CORTEXA9_DBGDSCR_INSTRCOMPL_L_VAL0 0x00
	#define CORTEXA9_DBGDSCR_INSTRCOMPL_L_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGDSCR_RESERVED8_RES (0x01 << 22)
	#define CORTEXA9_DBGDSCR_RESERVED8_SHIFT 22
	#define CORTEXA9_DBGDSCR_RESERVED8_VAL0 0x00
	#define CORTEXA9_DBGDSCR_RESERVED8_VAL1 0x01
	/*
	* The External DCC access mode field. This field controls the access mode for the 
	* external views of the DCC registers and the Instruction Transfer Register (DBGIT
	* R).
	*/
	#define CORTEXA9_DBGDSCR_EXTDCCMODE_RW (0x01 << 20)
	#define CORTEXA9_DBGDSCR_EXTDCCMODE_SHIFT 20
	#define CORTEXA9_DBGDSCR_EXTDCCMODE_VAL0 0x00
	#define CORTEXA9_DBGDSCR_EXTDCCMODE_VAL1 0x01
	/*
	* Asynchronous Data Aborts Discarded bit
	*/
	#define CORTEXA9_DBGDSCR_ADADISCARD_RW (0x01 << 19)
	#define CORTEXA9_DBGDSCR_ADADISCARD_SHIFT 19
	#define CORTEXA9_DBGDSCR_ADADISCARD_VAL0 0x00
	#define CORTEXA9_DBGDSCR_ADADISCARD_VAL1 0x01
	/*
	* Non-secure state status bit.
	*/
	#define CORTEXA9_DBGDSCR_NS_RW (0x01 << 18)
	#define CORTEXA9_DBGDSCR_NS_SHIFT 18
	#define CORTEXA9_DBGDSCR_NS_VAL0 0x00
	#define CORTEXA9_DBGDSCR_NS_VAL1 0x01
	/*
	* Secure Privileged Non-Invasive Debug Disabled bit
	*/
	#define CORTEXA9_DBGDSCR_SPNIDDIS_RW (0x01 << 17)
	#define CORTEXA9_DBGDSCR_SPNIDDIS_SHIFT 17
	#define CORTEXA9_DBGDSCR_SPNIDDIS_VAL0 0x00
	#define CORTEXA9_DBGDSCR_SPNIDDIS_VAL1 0x01
	/*
	* Secure Privileged Invasive Debug Disabled bit
	*/
	#define CORTEXA9_DBGDSCR_SPIDDIS_RW (0x01 << 16)
	#define CORTEXA9_DBGDSCR_SPIDDIS_SHIFT 16
	#define CORTEXA9_DBGDSCR_SPIDDIS_VAL0 0x00
	#define CORTEXA9_DBGDSCR_SPIDDIS_VAL1 0x01
	/*
	* Monitor debug-mode enable bit
	*/
	#define CORTEXA9_DBGDSCR_MDBGEN_RW (0x01 << 15)
	#define CORTEXA9_DBGDSCR_MDBGEN_SHIFT 15
	#define CORTEXA9_DBGDSCR_MDBGEN_VAL0 0x00
	#define CORTEXA9_DBGDSCR_MDBGEN_VAL1 0x01
	/*
	* Halting debug-mode enable bit
	*/
	#define CORTEXA9_DBGDSCR_HDBGEN_RW (0x01 << 14)
	#define CORTEXA9_DBGDSCR_HDBGEN_SHIFT 14
	#define CORTEXA9_DBGDSCR_HDBGEN_VAL0 0x00
	#define CORTEXA9_DBGDSCR_HDBGEN_VAL1 0x01
	/*
	* Execute ARM instruction enable bit. This bit enables the execution of ARM instru
	* ctions through the DBGITR
	*/
	#define CORTEXA9_DBGDSCR_ITREN_RW (0x01 << 13)
	#define CORTEXA9_DBGDSCR_ITREN_SHIFT 13
	#define CORTEXA9_DBGDSCR_ITREN_VAL0 0x00
	#define CORTEXA9_DBGDSCR_ITREN_VAL1 0x01
	/*
	* User mode access to Communications Channel disable bit
	*/
	#define CORTEXA9_DBGDSCR_UDCCDIS_RW (0x01 << 12)
	#define CORTEXA9_DBGDSCR_UDCCDIS_SHIFT 12
	#define CORTEXA9_DBGDSCR_UDCCDIS_VAL0 0x00
	#define CORTEXA9_DBGDSCR_UDCCDIS_VAL1 0x01
	/*
	* Interrupts Disable bit. This bit can be used to mask the taking of IRQs and FIQs
	* 
	*/
	#define CORTEXA9_DBGDSCR_INTDIS_RW (0x01 << 11)
	#define CORTEXA9_DBGDSCR_INTDIS_SHIFT 11
	#define CORTEXA9_DBGDSCR_INTDIS_VAL0 0x00
	#define CORTEXA9_DBGDSCR_INTDIS_VAL1 0x01
	/*
	* Force Debug Acknowledge bit. A debugger can use this bit to force any implemente
	* d debug acknowledge output signals to be asserted
	*/
	#define CORTEXA9_DBGDSCR_DBGACK_RW (0x01 << 10)
	#define CORTEXA9_DBGDSCR_DBGACK_SHIFT 10
	#define CORTEXA9_DBGDSCR_DBGACK_VAL0 0x00
	#define CORTEXA9_DBGDSCR_DBGACK_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGDSCR_RESERVED20_RES (0x01 << 9)
	#define CORTEXA9_DBGDSCR_RESERVED20_SHIFT 9
	#define CORTEXA9_DBGDSCR_RESERVED20_VAL0 0x00
	#define CORTEXA9_DBGDSCR_RESERVED20_VAL1 0x01
	/*
	* Sticky Undefined Instruction bit. This flag is set to 1 by any Undefined Instruc
	* tion exceptions generated by instructions issued to the processor while in Debug
	*  state
	*/
	#define CORTEXA9_DBGDSCR_UND_L_RW (0x01 << 8)
	#define CORTEXA9_DBGDSCR_UND_L_SHIFT 8
	#define CORTEXA9_DBGDSCR_UND_L_VAL0 0x00
	#define CORTEXA9_DBGDSCR_UND_L_VAL1 0x01
	/*
	* Sticky Asynchronous Data Abort bit. This flag is set to 1 by any asynchronous ab
	* ort that occurs when the processor is in Debug state and is discarded because th
	* e ADAdiscard bit, bit [19], is set to 1
	*/
	#define CORTEXA9_DBGDSCR_ADABORT_L_RW (0x01 << 7)
	#define CORTEXA9_DBGDSCR_ADABORT_L_SHIFT 7
	#define CORTEXA9_DBGDSCR_ADABORT_L_VAL0 0x00
	#define CORTEXA9_DBGDSCR_ADABORT_L_VAL1 0x01
	/*
	* Sticky Synchronous Data Abort bit. This flag is set to 1 by any Data Abort excep
	* tion that is generated by a synchronous data abort when the processor is in Debu
	* g state
	*/
	#define CORTEXA9_DBGDSCR_SDABORT_L_RW (0x01 << 6)
	#define CORTEXA9_DBGDSCR_SDABORT_L_SHIFT 6
	#define CORTEXA9_DBGDSCR_SDABORT_L_VAL0 0x00
	#define CORTEXA9_DBGDSCR_SDABORT_L_VAL1 0x01
	/*
	* Method of Debug Entry field
	*/
	#define CORTEXA9_DBGDSCR_MOE_RW (0x07 << 2)
	#define CORTEXA9_DBGDSCR_MOE_SHIFT 2
	#define CORTEXA9_DBGDSCR_MOE_VAL0 0x00
	#define CORTEXA9_DBGDSCR_MOE_VAL1 0x01
	#define CORTEXA9_DBGDSCR_MOE_VAL2 0x02
	#define CORTEXA9_DBGDSCR_MOE_VAL3 0x03
	#define CORTEXA9_DBGDSCR_MOE_VAL4 0x04
	#define CORTEXA9_DBGDSCR_MOE_VAL5 0x05
	#define CORTEXA9_DBGDSCR_MOE_VAL6 0x06
	#define CORTEXA9_DBGDSCR_MOE_VAL7 0x07
	/*
	* Processor Restarted bit
	*/
	#define CORTEXA9_DBGDSCR_RESTARTED_RW (0x01 << 1)
	#define CORTEXA9_DBGDSCR_RESTARTED_SHIFT 1
	#define CORTEXA9_DBGDSCR_RESTARTED_VAL0 0x00
	#define CORTEXA9_DBGDSCR_RESTARTED_VAL1 0x01
	/*
	* Processor Halted bit
	*/
	#define CORTEXA9_DBGDSCR_HALTED_RW (0x01 << 0)
	#define CORTEXA9_DBGDSCR_HALTED_SHIFT 0
	#define CORTEXA9_DBGDSCR_HALTED_VAL0 0x00
	#define CORTEXA9_DBGDSCR_HALTED_VAL1 0x01
	/*
	* The Target to Host Data Transfer Register, DBGDTRTX, is used by the ARM processo
	* r to transfer data to an external host
	*/
	#define CORTEXA9_DBGDTRTX_REG  (CORTEXA9_BASE + 0x808c)
	/*
	* One word of data for transfer from the debug target to the debug host
	*/
	#define CORTEXA9_DBGDTRTX_TARGET_TO_HOST_DATA_RW (0x07fffffff << 0)
	#define CORTEXA9_DBGDTRTX_TARGET_TO_HOST_DATA_SHIFT 0
	/*
	* The Debug Run Control Register, DBGDRCR, requests the processor to enter or leav
	* e Debug state. It is also used to clear to 0 the sticky exception bits in the DB
	* GDSCR.
	*/
	#define CORTEXA9_DBGDRCR_REG  (CORTEXA9_BASE + 0x8090)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGDRCR_RESERVED_RES (0x01ffffff << 5)
	#define CORTEXA9_DBGDRCR_RESERVED_SHIFT 5
	/*
	* Cancel Bus Interface Unit Requests bit
	*/
	#define CORTEXA9_DBGDRCR_CBIUR_W (0x01 << 4)
	#define CORTEXA9_DBGDRCR_CBIUR_SHIFT 4
	#define CORTEXA9_DBGDRCR_CBIUR_VAL0 0x00
	#define CORTEXA9_DBGDRCR_CBIUR_VAL1 0x01
	/*
	* Clear Sticky Pipeline Advance flag
	*/
	#define CORTEXA9_DBGDRCR_CSPA_FLAG_W (0x01 << 3)
	#define CORTEXA9_DBGDRCR_CSPA_FLAG_SHIFT 3
	#define CORTEXA9_DBGDRCR_CSPA_FLAG_VAL0 0x00
	#define CORTEXA9_DBGDRCR_CSPA_FLAG_VAL1 0x01
	/*
	* Clear Sticky Exceptions flags
	*/
	#define CORTEXA9_DBGDRCR_CSE_FLAGS_W (0x01 << 2)
	#define CORTEXA9_DBGDRCR_CSE_FLAGS_SHIFT 2
	#define CORTEXA9_DBGDRCR_CSE_FLAGS_VAL0 0x00
	#define CORTEXA9_DBGDRCR_CSE_FLAGS_VAL1 0x01
	/*
	* Restart request bit
	*/
	#define CORTEXA9_DBGDRCR_RESTART_REQUEST_W (0x01 << 1)
	#define CORTEXA9_DBGDRCR_RESTART_REQUEST_SHIFT 1
	#define CORTEXA9_DBGDRCR_RESTART_REQUEST_VAL0 0x00
	#define CORTEXA9_DBGDRCR_RESTART_REQUEST_VAL1 0x01
	/*
	* Halt request bit
	*/
	#define CORTEXA9_DBGDRCR_HALT_REQUEST_W (0x01 << 0)
	#define CORTEXA9_DBGDRCR_HALT_REQUEST_SHIFT 0
	#define CORTEXA9_DBGDRCR_HALT_REQUEST_VAL0 0x00
	#define CORTEXA9_DBGDRCR_HALT_REQUEST_VAL1 0x01
	/*
	* A Breakpoint Value Register, DBGBVR, holds a value for use in breakpoint matchin
	* g
	*/
	#define CORTEXA9_DBGBVR0_REG  (CORTEXA9_BASE + 0x8100)
	/*
	* Bits [31:2] of the value for comparison
	*/
	#define CORTEXA9_DBGBVR0_BREAKPOINT_ADDRESS_RW (0x01fffffff << 2)
	#define CORTEXA9_DBGBVR0_BREAKPOINT_ADDRESS_SHIFT 2
	/*
	* Bits [1:0], when register used for IVA comparison
	*/
	#define CORTEXA9_DBGBVR0_BITS_1_0_IVA_RW (0x03 << 0)
	#define CORTEXA9_DBGBVR0_BITS_1_0_IVA_SHIFT 0
	#define CORTEXA9_DBGBVR0_BITS_1_0_IVA_VAL0 0x00
	#define CORTEXA9_DBGBVR0_BITS_1_0_IVA_VAL1 0x01
	#define CORTEXA9_DBGBVR0_BITS_1_0_IVA_VAL2 0x02
	#define CORTEXA9_DBGBVR0_BITS_1_0_IVA_VAL3 0x03
	/*
	* A Breakpoint Value Register, DBGBVR, holds a value for use in breakpoint matchin
	* g
	*/
	#define CORTEXA9_DBGBVR1_REG  (CORTEXA9_BASE + 0x8104)
	/*
	* Bits [31:2] of the value for comparison
	*/
	#define CORTEXA9_DBGBVR1_BREAKPOINT_ADDRESS_RW (0x01fffffff << 2)
	#define CORTEXA9_DBGBVR1_BREAKPOINT_ADDRESS_SHIFT 2
	/*
	* Bits [1:0], when register used for IVA comparison
	*/
	#define CORTEXA9_DBGBVR1_BITS_1_0_IVA_RW (0x03 << 0)
	#define CORTEXA9_DBGBVR1_BITS_1_0_IVA_SHIFT 0
	#define CORTEXA9_DBGBVR1_BITS_1_0_IVA_VAL0 0x00
	#define CORTEXA9_DBGBVR1_BITS_1_0_IVA_VAL1 0x01
	#define CORTEXA9_DBGBVR1_BITS_1_0_IVA_VAL2 0x02
	#define CORTEXA9_DBGBVR1_BITS_1_0_IVA_VAL3 0x03
	/*
	* A Breakpoint Value Register, DBGBVR, holds a value for use in breakpoint matchin
	* g
	*/
	#define CORTEXA9_DBGBVR2_REG  (CORTEXA9_BASE + 0x8108)
	/*
	* Bits [31:2] of the value for comparison
	*/
	#define CORTEXA9_DBGBVR2_BREAKPOINT_ADDRESS_RW (0x01fffffff << 2)
	#define CORTEXA9_DBGBVR2_BREAKPOINT_ADDRESS_SHIFT 2
	/*
	* Bits [1:0], when register used for IVA comparison
	*/
	#define CORTEXA9_DBGBVR2_BITS_1_0_IVA_RW (0x03 << 0)
	#define CORTEXA9_DBGBVR2_BITS_1_0_IVA_SHIFT 0
	#define CORTEXA9_DBGBVR2_BITS_1_0_IVA_VAL0 0x00
	#define CORTEXA9_DBGBVR2_BITS_1_0_IVA_VAL1 0x01
	#define CORTEXA9_DBGBVR2_BITS_1_0_IVA_VAL2 0x02
	#define CORTEXA9_DBGBVR2_BITS_1_0_IVA_VAL3 0x03
	/*
	* A Breakpoint Value Register, DBGBVR, holds a value for use in breakpoint matchin
	* g
	*/
	#define CORTEXA9_DBGBVR3_REG  (CORTEXA9_BASE + 0x810c)
	/*
	* Bits [31:2] of the value for comparison
	*/
	#define CORTEXA9_DBGBVR3_BREAKPOINT_ADDRESS_RW (0x01fffffff << 2)
	#define CORTEXA9_DBGBVR3_BREAKPOINT_ADDRESS_SHIFT 2
	/*
	* Bits [1:0], when register used for IVA comparison
	*/
	#define CORTEXA9_DBGBVR3_BITS_1_0_IVA_RW (0x03 << 0)
	#define CORTEXA9_DBGBVR3_BITS_1_0_IVA_SHIFT 0
	#define CORTEXA9_DBGBVR3_BITS_1_0_IVA_VAL0 0x00
	#define CORTEXA9_DBGBVR3_BITS_1_0_IVA_VAL1 0x01
	#define CORTEXA9_DBGBVR3_BITS_1_0_IVA_VAL2 0x02
	#define CORTEXA9_DBGBVR3_BITS_1_0_IVA_VAL3 0x03
	/*
	* A Breakpoint Value Register, DBGBVR, holds a value for use in breakpoint matchin
	* g
	*/
	#define CORTEXA9_DBGBVR4_REG  (CORTEXA9_BASE + 0x8110)
	/*
	* Bits [31:0] of the value for comparison
	*/
	#define CORTEXA9_DBGBVR4_CONTEXT_ID_RW (0x07fffffff << 0)
	#define CORTEXA9_DBGBVR4_CONTEXT_ID_SHIFT 0
	/*
	* A Breakpoint Value Register, DBGBVR, holds a value for use in breakpoint matchin
	* g
	*/
	#define CORTEXA9_DBGBVR5_REG  (CORTEXA9_BASE + 0x8114)
	/*
	* Bits [31:0] of the value for comparison
	*/
	#define CORTEXA9_DBGBVR5_CONTEXT_ID_RW (0x07fffffff << 0)
	#define CORTEXA9_DBGBVR5_CONTEXT_ID_SHIFT 0
	/*
	* A Breakpoint Control Register, DBGBCR, holds control information for a breakpoin
	* t. Each DBGBCR is associated with a DBGBVR to form a Breakpoint Register Pair (B
	* RP)
	*/
	#define CORTEXA9_DBGBCR0_REG  (CORTEXA9_BASE + 0x8140)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR0_RESERVED_RES (0x01 << 29)
	#define CORTEXA9_DBGBCR0_RESERVED_SHIFT 29
	#define CORTEXA9_DBGBCR0_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGBCR0_RESERVED_VAL1 0x01
	/*
	* In v7 Debug, whether address range masking is supported is IMPLEMENTATION DEFINE
	* D. If it is not supported these bits are RAZ/WI.
	* If address range masking is supported, this field can be used to break on a rang
	* e of addresses by masking lower order address bits out of the breakpoint compari
	* son
	*/
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_RW (0x0f << 24)
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_SHIFT 24
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL0 0x00
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL1 0x01
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL2 0x02
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL3 0x03
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL4 0x04
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL5 0x05
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL6 0x06
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL7 0x07
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL8 0x08
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL9 0x09
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL10 0x0a
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL11 0x0b
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL12 0x0c
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL13 0x0d
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL14 0x0e
	#define CORTEXA9_DBGBCR0_ADDRESS_RANGE_MASK_VAL15 0x0f
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR0_RESERVED2_RES (0x01 << 23)
	#define CORTEXA9_DBGBCR0_RESERVED2_SHIFT 23
	#define CORTEXA9_DBGBCR0_RESERVED2_VAL0 0x00
	#define CORTEXA9_DBGBCR0_RESERVED2_VAL1 0x01
	/*
	* This field controls the behavior of Breakpoint debug event generation. This incl
	* udes the meaning of the value held in the associated DBGBVR, whether it is an IV
	* A or a Context ID.
	*/
	#define CORTEXA9_DBGBCR0_DBGBVR_MEANING_RW (0x03 << 20)
	#define CORTEXA9_DBGBCR0_DBGBVR_MEANING_SHIFT 20
	#define CORTEXA9_DBGBCR0_DBGBVR_MEANING_VAL0 0x00
	#define CORTEXA9_DBGBCR0_DBGBVR_MEANING_VAL1 0x01
	#define CORTEXA9_DBGBCR0_DBGBVR_MEANING_VAL2 0x02
	#define CORTEXA9_DBGBCR0_DBGBVR_MEANING_VAL3 0x03
	/*
	* If this BRP is programmed for Linked IVA match or mismatch then this field must 
	* be programmed with the number of the BRP that holds the Context ID to be used fo
	* r the combined IVA and Context ID comparison, otherwise, this field must be prog
	* rammed to 0b0000.
	*/
	#define CORTEXA9_DBGBCR0_LINKED_BRP_NUMBER_RW (0x07 << 16)
	#define CORTEXA9_DBGBCR0_LINKED_BRP_NUMBER_SHIFT 16
	#define CORTEXA9_DBGBCR0_LINKED_BRP_NUMBER_VAL0 0x00
	#define CORTEXA9_DBGBCR0_LINKED_BRP_NUMBER_VAL1 0x01
	#define CORTEXA9_DBGBCR0_LINKED_BRP_NUMBER_VAL2 0x02
	#define CORTEXA9_DBGBCR0_LINKED_BRP_NUMBER_VAL3 0x03
	#define CORTEXA9_DBGBCR0_LINKED_BRP_NUMBER_VAL4 0x04
	#define CORTEXA9_DBGBCR0_LINKED_BRP_NUMBER_VAL5 0x05
	#define CORTEXA9_DBGBCR0_LINKED_BRP_NUMBER_VAL6 0x06
	#define CORTEXA9_DBGBCR0_LINKED_BRP_NUMBER_VAL7 0x07
	/*
	* Security state control
	*/
	#define CORTEXA9_DBGBCR0_SSC_RW (0x01 << 14)
	#define CORTEXA9_DBGBCR0_SSC_SHIFT 14
	#define CORTEXA9_DBGBCR0_SSC_VAL0 0x00
	#define CORTEXA9_DBGBCR0_SSC_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR0_RESERVED6_RES (0x0f << 9)
	#define CORTEXA9_DBGBCR0_RESERVED6_SHIFT 9
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL0 0x00
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL1 0x01
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL2 0x02
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL3 0x03
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL4 0x04
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL5 0x05
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL6 0x06
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL7 0x07
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL8 0x08
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL9 0x09
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL10 0x0a
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL11 0x0b
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL12 0x0c
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL13 0x0d
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL14 0x0e
	#define CORTEXA9_DBGBCR0_RESERVED6_VAL15 0x0f
	/*
	* Byte address select
	*/
	#define CORTEXA9_DBGBCR0_BYTE_ADDRESS_SELECT_RW (0x07 << 5)
	#define CORTEXA9_DBGBCR0_BYTE_ADDRESS_SELECT_SHIFT 5
	#define CORTEXA9_DBGBCR0_BYTE_ADDRESS_SELECT_VAL0 0x00
	#define CORTEXA9_DBGBCR0_BYTE_ADDRESS_SELECT_VAL1 0x01
	#define CORTEXA9_DBGBCR0_BYTE_ADDRESS_SELECT_VAL2 0x02
	#define CORTEXA9_DBGBCR0_BYTE_ADDRESS_SELECT_VAL3 0x03
	#define CORTEXA9_DBGBCR0_BYTE_ADDRESS_SELECT_VAL4 0x04
	#define CORTEXA9_DBGBCR0_BYTE_ADDRESS_SELECT_VAL5 0x05
	#define CORTEXA9_DBGBCR0_BYTE_ADDRESS_SELECT_VAL6 0x06
	#define CORTEXA9_DBGBCR0_BYTE_ADDRESS_SELECT_VAL7 0x07
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR0_RESERVED8_RES (0x01 << 3)
	#define CORTEXA9_DBGBCR0_RESERVED8_SHIFT 3
	#define CORTEXA9_DBGBCR0_RESERVED8_VAL0 0x00
	#define CORTEXA9_DBGBCR0_RESERVED8_VAL1 0x01
	/*
	* Privileged mode control
	*/
	#define CORTEXA9_DBGBCR0_PRIVILEGED_MODE_CONTROL_RW (0x01 << 1)
	#define CORTEXA9_DBGBCR0_PRIVILEGED_MODE_CONTROL_SHIFT 1
	#define CORTEXA9_DBGBCR0_PRIVILEGED_MODE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGBCR0_PRIVILEGED_MODE_CONTROL_VAL1 0x01
	/*
	* This bit enables the BRP.
	*/
	#define CORTEXA9_DBGBCR0_BREAKPOINT_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGBCR0_BREAKPOINT_ENABLE_SHIFT 0
	#define CORTEXA9_DBGBCR0_BREAKPOINT_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGBCR0_BREAKPOINT_ENABLE_VAL1 0x01
	/*
	* A Breakpoint Control Register, DBGBCR, holds control information for a breakpoin
	* t. Each DBGBCR is associated with a DBGBVR to form a Breakpoint Register Pair (B
	* RP)
	*/
	#define CORTEXA9_DBGBCR1_REG  (CORTEXA9_BASE + 0x8140)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR1_RESERVED_RES (0x01 << 29)
	#define CORTEXA9_DBGBCR1_RESERVED_SHIFT 29
	#define CORTEXA9_DBGBCR1_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGBCR1_RESERVED_VAL1 0x01
	/*
	* In v7 Debug, whether address range masking is supported is IMPLEMENTATION DEFINE
	* D. If it is not supported these bits are RAZ/WI.
	* If address range masking is supported, this field can be used to break on a rang
	* e of addresses by masking lower order address bits out of the breakpoint compari
	* son
	*/
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_RW (0x0f << 24)
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_SHIFT 24
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL0 0x00
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL1 0x01
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL2 0x02
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL3 0x03
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL4 0x04
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL5 0x05
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL6 0x06
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL7 0x07
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL8 0x08
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL9 0x09
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL10 0x0a
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL11 0x0b
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL12 0x0c
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL13 0x0d
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL14 0x0e
	#define CORTEXA9_DBGBCR1_ADDRESS_RANGE_MASK_VAL15 0x0f
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR1_RESERVED2_RES (0x01 << 23)
	#define CORTEXA9_DBGBCR1_RESERVED2_SHIFT 23
	#define CORTEXA9_DBGBCR1_RESERVED2_VAL0 0x00
	#define CORTEXA9_DBGBCR1_RESERVED2_VAL1 0x01
	/*
	* This field controls the behavior of Breakpoint debug event generation. This incl
	* udes the meaning of the value held in the associated DBGBVR, whether it is an IV
	* A or a Context ID.
	*/
	#define CORTEXA9_DBGBCR1_DBGBVR_MEANING_RW (0x03 << 20)
	#define CORTEXA9_DBGBCR1_DBGBVR_MEANING_SHIFT 20
	#define CORTEXA9_DBGBCR1_DBGBVR_MEANING_VAL0 0x00
	#define CORTEXA9_DBGBCR1_DBGBVR_MEANING_VAL1 0x01
	#define CORTEXA9_DBGBCR1_DBGBVR_MEANING_VAL2 0x02
	#define CORTEXA9_DBGBCR1_DBGBVR_MEANING_VAL3 0x03
	/*
	* If this BRP is programmed for Linked IVA match or mismatch then this field must 
	* be programmed with the number of the BRP that holds the Context ID to be used fo
	* r the combined IVA and Context ID comparison, otherwise, this field must be prog
	* rammed to 0b0000.
	*/
	#define CORTEXA9_DBGBCR1_LINKED_BRP_NUMBER_RW (0x07 << 16)
	#define CORTEXA9_DBGBCR1_LINKED_BRP_NUMBER_SHIFT 16
	#define CORTEXA9_DBGBCR1_LINKED_BRP_NUMBER_VAL0 0x00
	#define CORTEXA9_DBGBCR1_LINKED_BRP_NUMBER_VAL1 0x01
	#define CORTEXA9_DBGBCR1_LINKED_BRP_NUMBER_VAL2 0x02
	#define CORTEXA9_DBGBCR1_LINKED_BRP_NUMBER_VAL3 0x03
	#define CORTEXA9_DBGBCR1_LINKED_BRP_NUMBER_VAL4 0x04
	#define CORTEXA9_DBGBCR1_LINKED_BRP_NUMBER_VAL5 0x05
	#define CORTEXA9_DBGBCR1_LINKED_BRP_NUMBER_VAL6 0x06
	#define CORTEXA9_DBGBCR1_LINKED_BRP_NUMBER_VAL7 0x07
	/*
	* Security state control
	*/
	#define CORTEXA9_DBGBCR1_SSC_RW (0x01 << 14)
	#define CORTEXA9_DBGBCR1_SSC_SHIFT 14
	#define CORTEXA9_DBGBCR1_SSC_VAL0 0x00
	#define CORTEXA9_DBGBCR1_SSC_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR1_RESERVED6_RES (0x0f << 9)
	#define CORTEXA9_DBGBCR1_RESERVED6_SHIFT 9
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL0 0x00
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL1 0x01
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL2 0x02
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL3 0x03
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL4 0x04
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL5 0x05
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL6 0x06
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL7 0x07
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL8 0x08
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL9 0x09
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL10 0x0a
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL11 0x0b
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL12 0x0c
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL13 0x0d
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL14 0x0e
	#define CORTEXA9_DBGBCR1_RESERVED6_VAL15 0x0f
	/*
	* Byte address select
	*/
	#define CORTEXA9_DBGBCR1_BYTE_ADDRESS_SELECT_RW (0x07 << 5)
	#define CORTEXA9_DBGBCR1_BYTE_ADDRESS_SELECT_SHIFT 5
	#define CORTEXA9_DBGBCR1_BYTE_ADDRESS_SELECT_VAL0 0x00
	#define CORTEXA9_DBGBCR1_BYTE_ADDRESS_SELECT_VAL1 0x01
	#define CORTEXA9_DBGBCR1_BYTE_ADDRESS_SELECT_VAL2 0x02
	#define CORTEXA9_DBGBCR1_BYTE_ADDRESS_SELECT_VAL3 0x03
	#define CORTEXA9_DBGBCR1_BYTE_ADDRESS_SELECT_VAL4 0x04
	#define CORTEXA9_DBGBCR1_BYTE_ADDRESS_SELECT_VAL5 0x05
	#define CORTEXA9_DBGBCR1_BYTE_ADDRESS_SELECT_VAL6 0x06
	#define CORTEXA9_DBGBCR1_BYTE_ADDRESS_SELECT_VAL7 0x07
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR1_RESERVED8_RES (0x01 << 3)
	#define CORTEXA9_DBGBCR1_RESERVED8_SHIFT 3
	#define CORTEXA9_DBGBCR1_RESERVED8_VAL0 0x00
	#define CORTEXA9_DBGBCR1_RESERVED8_VAL1 0x01
	/*
	* Privileged mode control
	*/
	#define CORTEXA9_DBGBCR1_PRIVILEGED_MODE_CONTROL_RW (0x01 << 1)
	#define CORTEXA9_DBGBCR1_PRIVILEGED_MODE_CONTROL_SHIFT 1
	#define CORTEXA9_DBGBCR1_PRIVILEGED_MODE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGBCR1_PRIVILEGED_MODE_CONTROL_VAL1 0x01
	/*
	* This bit enables the BRP.
	*/
	#define CORTEXA9_DBGBCR1_BREAKPOINT_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGBCR1_BREAKPOINT_ENABLE_SHIFT 0
	#define CORTEXA9_DBGBCR1_BREAKPOINT_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGBCR1_BREAKPOINT_ENABLE_VAL1 0x01
	/*
	* A Breakpoint Control Register, DBGBCR, holds control information for a breakpoin
	* t. Each DBGBCR is associated with a DBGBVR to form a Breakpoint Register Pair (B
	* RP)
	*/
	#define CORTEXA9_DBGBCR2_REG  (CORTEXA9_BASE + 0x8148)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR2_RESERVED_RES (0x01 << 29)
	#define CORTEXA9_DBGBCR2_RESERVED_SHIFT 29
	#define CORTEXA9_DBGBCR2_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGBCR2_RESERVED_VAL1 0x01
	/*
	* In v7 Debug, whether address range masking is supported is IMPLEMENTATION DEFINE
	* D. If it is not supported these bits are RAZ/WI.
	* If address range masking is supported, this field can be used to break on a rang
	* e of addresses by masking lower order address bits out of the breakpoint compari
	* son
	*/
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_RW (0x0f << 24)
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_SHIFT 24
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL0 0x00
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL1 0x01
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL2 0x02
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL3 0x03
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL4 0x04
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL5 0x05
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL6 0x06
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL7 0x07
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL8 0x08
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL9 0x09
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL10 0x0a
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL11 0x0b
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL12 0x0c
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL13 0x0d
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL14 0x0e
	#define CORTEXA9_DBGBCR2_ADDRESS_RANGE_MASK_VAL15 0x0f
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR2_RESERVED2_RES (0x01 << 23)
	#define CORTEXA9_DBGBCR2_RESERVED2_SHIFT 23
	#define CORTEXA9_DBGBCR2_RESERVED2_VAL0 0x00
	#define CORTEXA9_DBGBCR2_RESERVED2_VAL1 0x01
	/*
	* This field controls the behavior of Breakpoint debug event generation. This incl
	* udes the meaning of the value held in the associated DBGBVR, whether it is an IV
	* A or a Context ID.
	*/
	#define CORTEXA9_DBGBCR2_DBGBVR_MEANING_RW (0x03 << 20)
	#define CORTEXA9_DBGBCR2_DBGBVR_MEANING_SHIFT 20
	#define CORTEXA9_DBGBCR2_DBGBVR_MEANING_VAL0 0x00
	#define CORTEXA9_DBGBCR2_DBGBVR_MEANING_VAL1 0x01
	#define CORTEXA9_DBGBCR2_DBGBVR_MEANING_VAL2 0x02
	#define CORTEXA9_DBGBCR2_DBGBVR_MEANING_VAL3 0x03
	/*
	* If this BRP is programmed for Linked IVA match or mismatch then this field must 
	* be programmed with the number of the BRP that holds the Context ID to be used fo
	* r the combined IVA and Context ID comparison, otherwise, this field must be prog
	* rammed to 0b0000.
	*/
	#define CORTEXA9_DBGBCR2_LINKED_BRP_NUMBER_RW (0x07 << 16)
	#define CORTEXA9_DBGBCR2_LINKED_BRP_NUMBER_SHIFT 16
	#define CORTEXA9_DBGBCR2_LINKED_BRP_NUMBER_VAL0 0x00
	#define CORTEXA9_DBGBCR2_LINKED_BRP_NUMBER_VAL1 0x01
	#define CORTEXA9_DBGBCR2_LINKED_BRP_NUMBER_VAL2 0x02
	#define CORTEXA9_DBGBCR2_LINKED_BRP_NUMBER_VAL3 0x03
	#define CORTEXA9_DBGBCR2_LINKED_BRP_NUMBER_VAL4 0x04
	#define CORTEXA9_DBGBCR2_LINKED_BRP_NUMBER_VAL5 0x05
	#define CORTEXA9_DBGBCR2_LINKED_BRP_NUMBER_VAL6 0x06
	#define CORTEXA9_DBGBCR2_LINKED_BRP_NUMBER_VAL7 0x07
	/*
	* Security state control
	*/
	#define CORTEXA9_DBGBCR2_SSC_RW (0x01 << 14)
	#define CORTEXA9_DBGBCR2_SSC_SHIFT 14
	#define CORTEXA9_DBGBCR2_SSC_VAL0 0x00
	#define CORTEXA9_DBGBCR2_SSC_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR2_RESERVED6_RES (0x0f << 9)
	#define CORTEXA9_DBGBCR2_RESERVED6_SHIFT 9
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL0 0x00
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL1 0x01
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL2 0x02
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL3 0x03
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL4 0x04
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL5 0x05
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL6 0x06
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL7 0x07
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL8 0x08
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL9 0x09
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL10 0x0a
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL11 0x0b
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL12 0x0c
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL13 0x0d
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL14 0x0e
	#define CORTEXA9_DBGBCR2_RESERVED6_VAL15 0x0f
	/*
	* Byte address select
	*/
	#define CORTEXA9_DBGBCR2_BYTE_ADDRESS_SELECT_RW (0x07 << 5)
	#define CORTEXA9_DBGBCR2_BYTE_ADDRESS_SELECT_SHIFT 5
	#define CORTEXA9_DBGBCR2_BYTE_ADDRESS_SELECT_VAL0 0x00
	#define CORTEXA9_DBGBCR2_BYTE_ADDRESS_SELECT_VAL1 0x01
	#define CORTEXA9_DBGBCR2_BYTE_ADDRESS_SELECT_VAL2 0x02
	#define CORTEXA9_DBGBCR2_BYTE_ADDRESS_SELECT_VAL3 0x03
	#define CORTEXA9_DBGBCR2_BYTE_ADDRESS_SELECT_VAL4 0x04
	#define CORTEXA9_DBGBCR2_BYTE_ADDRESS_SELECT_VAL5 0x05
	#define CORTEXA9_DBGBCR2_BYTE_ADDRESS_SELECT_VAL6 0x06
	#define CORTEXA9_DBGBCR2_BYTE_ADDRESS_SELECT_VAL7 0x07
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR2_RESERVED8_RES (0x01 << 3)
	#define CORTEXA9_DBGBCR2_RESERVED8_SHIFT 3
	#define CORTEXA9_DBGBCR2_RESERVED8_VAL0 0x00
	#define CORTEXA9_DBGBCR2_RESERVED8_VAL1 0x01
	/*
	* Privileged mode control
	*/
	#define CORTEXA9_DBGBCR2_PRIVILEGED_MODE_CONTROL_RW (0x01 << 1)
	#define CORTEXA9_DBGBCR2_PRIVILEGED_MODE_CONTROL_SHIFT 1
	#define CORTEXA9_DBGBCR2_PRIVILEGED_MODE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGBCR2_PRIVILEGED_MODE_CONTROL_VAL1 0x01
	/*
	* This bit enables the BRP.
	*/
	#define CORTEXA9_DBGBCR2_BREAKPOINT_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGBCR2_BREAKPOINT_ENABLE_SHIFT 0
	#define CORTEXA9_DBGBCR2_BREAKPOINT_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGBCR2_BREAKPOINT_ENABLE_VAL1 0x01
	/*
	* A Breakpoint Control Register, DBGBCR, holds control information for a breakpoin
	* t. Each DBGBCR is associated with a DBGBVR to form a Breakpoint Register Pair (B
	* RP)
	*/
	#define CORTEXA9_DBGBCR3_REG  (CORTEXA9_BASE + 0x814c)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR3_RESERVED_RES (0x01 << 29)
	#define CORTEXA9_DBGBCR3_RESERVED_SHIFT 29
	#define CORTEXA9_DBGBCR3_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGBCR3_RESERVED_VAL1 0x01
	/*
	* In v7 Debug, whether address range masking is supported is IMPLEMENTATION DEFINE
	* D. If it is not supported these bits are RAZ/WI.
	* If address range masking is supported, this field can be used to break on a rang
	* e of addresses by masking lower order address bits out of the breakpoint compari
	* son
	*/
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_RW (0x0f << 24)
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_SHIFT 24
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL0 0x00
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL1 0x01
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL2 0x02
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL3 0x03
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL4 0x04
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL5 0x05
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL6 0x06
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL7 0x07
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL8 0x08
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL9 0x09
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL10 0x0a
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL11 0x0b
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL12 0x0c
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL13 0x0d
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL14 0x0e
	#define CORTEXA9_DBGBCR3_ADDRESS_RANGE_MASK_VAL15 0x0f
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR3_RESERVED2_RES (0x01 << 23)
	#define CORTEXA9_DBGBCR3_RESERVED2_SHIFT 23
	#define CORTEXA9_DBGBCR3_RESERVED2_VAL0 0x00
	#define CORTEXA9_DBGBCR3_RESERVED2_VAL1 0x01
	/*
	* This field controls the behavior of Breakpoint debug event generation. This incl
	* udes the meaning of the value held in the associated DBGBVR, whether it is an IV
	* A or a Context ID.
	*/
	#define CORTEXA9_DBGBCR3_DBGBVR_MEANING_RW (0x03 << 20)
	#define CORTEXA9_DBGBCR3_DBGBVR_MEANING_SHIFT 20
	#define CORTEXA9_DBGBCR3_DBGBVR_MEANING_VAL0 0x00
	#define CORTEXA9_DBGBCR3_DBGBVR_MEANING_VAL1 0x01
	#define CORTEXA9_DBGBCR3_DBGBVR_MEANING_VAL2 0x02
	#define CORTEXA9_DBGBCR3_DBGBVR_MEANING_VAL3 0x03
	/*
	* If this BRP is programmed for Linked IVA match or mismatch then this field must 
	* be programmed with the number of the BRP that holds the Context ID to be used fo
	* r the combined IVA and Context ID comparison, otherwise, this field must be prog
	* rammed to 0b0000.
	*/
	#define CORTEXA9_DBGBCR3_LINKED_BRP_NUMBER_RW (0x07 << 16)
	#define CORTEXA9_DBGBCR3_LINKED_BRP_NUMBER_SHIFT 16
	#define CORTEXA9_DBGBCR3_LINKED_BRP_NUMBER_VAL0 0x00
	#define CORTEXA9_DBGBCR3_LINKED_BRP_NUMBER_VAL1 0x01
	#define CORTEXA9_DBGBCR3_LINKED_BRP_NUMBER_VAL2 0x02
	#define CORTEXA9_DBGBCR3_LINKED_BRP_NUMBER_VAL3 0x03
	#define CORTEXA9_DBGBCR3_LINKED_BRP_NUMBER_VAL4 0x04
	#define CORTEXA9_DBGBCR3_LINKED_BRP_NUMBER_VAL5 0x05
	#define CORTEXA9_DBGBCR3_LINKED_BRP_NUMBER_VAL6 0x06
	#define CORTEXA9_DBGBCR3_LINKED_BRP_NUMBER_VAL7 0x07
	/*
	* Security state control
	*/
	#define CORTEXA9_DBGBCR3_SSC_RW (0x01 << 14)
	#define CORTEXA9_DBGBCR3_SSC_SHIFT 14
	#define CORTEXA9_DBGBCR3_SSC_VAL0 0x00
	#define CORTEXA9_DBGBCR3_SSC_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR3_RESERVED6_RES (0x0f << 9)
	#define CORTEXA9_DBGBCR3_RESERVED6_SHIFT 9
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL0 0x00
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL1 0x01
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL2 0x02
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL3 0x03
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL4 0x04
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL5 0x05
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL6 0x06
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL7 0x07
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL8 0x08
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL9 0x09
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL10 0x0a
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL11 0x0b
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL12 0x0c
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL13 0x0d
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL14 0x0e
	#define CORTEXA9_DBGBCR3_RESERVED6_VAL15 0x0f
	/*
	* Byte address select
	*/
	#define CORTEXA9_DBGBCR3_BYTE_ADDRESS_SELECT_RW (0x07 << 5)
	#define CORTEXA9_DBGBCR3_BYTE_ADDRESS_SELECT_SHIFT 5
	#define CORTEXA9_DBGBCR3_BYTE_ADDRESS_SELECT_VAL0 0x00
	#define CORTEXA9_DBGBCR3_BYTE_ADDRESS_SELECT_VAL1 0x01
	#define CORTEXA9_DBGBCR3_BYTE_ADDRESS_SELECT_VAL2 0x02
	#define CORTEXA9_DBGBCR3_BYTE_ADDRESS_SELECT_VAL3 0x03
	#define CORTEXA9_DBGBCR3_BYTE_ADDRESS_SELECT_VAL4 0x04
	#define CORTEXA9_DBGBCR3_BYTE_ADDRESS_SELECT_VAL5 0x05
	#define CORTEXA9_DBGBCR3_BYTE_ADDRESS_SELECT_VAL6 0x06
	#define CORTEXA9_DBGBCR3_BYTE_ADDRESS_SELECT_VAL7 0x07
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR3_RESERVED8_RES (0x01 << 3)
	#define CORTEXA9_DBGBCR3_RESERVED8_SHIFT 3
	#define CORTEXA9_DBGBCR3_RESERVED8_VAL0 0x00
	#define CORTEXA9_DBGBCR3_RESERVED8_VAL1 0x01
	/*
	* Privileged mode control
	*/
	#define CORTEXA9_DBGBCR3_PRIVILEGED_MODE_CONTROL_RW (0x01 << 1)
	#define CORTEXA9_DBGBCR3_PRIVILEGED_MODE_CONTROL_SHIFT 1
	#define CORTEXA9_DBGBCR3_PRIVILEGED_MODE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGBCR3_PRIVILEGED_MODE_CONTROL_VAL1 0x01
	/*
	* This bit enables the BRP.
	*/
	#define CORTEXA9_DBGBCR3_BREAKPOINT_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGBCR3_BREAKPOINT_ENABLE_SHIFT 0
	#define CORTEXA9_DBGBCR3_BREAKPOINT_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGBCR3_BREAKPOINT_ENABLE_VAL1 0x01
	/*
	* A Breakpoint Control Register, DBGBCR, holds control information for a breakpoin
	* t. Each DBGBCR is associated with a DBGBVR to form a Breakpoint Register Pair (B
	* RP)
	*/
	#define CORTEXA9_DBGBCR4_REG  (CORTEXA9_BASE + 0x8150)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR4_RESERVED_RES (0x01 << 29)
	#define CORTEXA9_DBGBCR4_RESERVED_SHIFT 29
	#define CORTEXA9_DBGBCR4_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGBCR4_RESERVED_VAL1 0x01
	/*
	* In v7 Debug, whether address range masking is supported is IMPLEMENTATION DEFINE
	* D. If it is not supported these bits are RAZ/WI.
	* If address range masking is supported, this field can be used to break on a rang
	* e of addresses by masking lower order address bits out of the breakpoint compari
	* son
	*/
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_RW (0x0f << 24)
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_SHIFT 24
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL0 0x00
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL1 0x01
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL2 0x02
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL3 0x03
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL4 0x04
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL5 0x05
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL6 0x06
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL7 0x07
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL8 0x08
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL9 0x09
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL10 0x0a
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL11 0x0b
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL12 0x0c
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL13 0x0d
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL14 0x0e
	#define CORTEXA9_DBGBCR4_ADDRESS_RANGE_MASK_VAL15 0x0f
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR4_RESERVED2_RES (0x01 << 23)
	#define CORTEXA9_DBGBCR4_RESERVED2_SHIFT 23
	#define CORTEXA9_DBGBCR4_RESERVED2_VAL0 0x00
	#define CORTEXA9_DBGBCR4_RESERVED2_VAL1 0x01
	/*
	* This field controls the behavior of Breakpoint debug event generation. This incl
	* udes the meaning of the value held in the associated DBGBVR, whether it is an IV
	* A or a Context ID.
	*/
	#define CORTEXA9_DBGBCR4_DBGBVR_MEANING_RW (0x03 << 20)
	#define CORTEXA9_DBGBCR4_DBGBVR_MEANING_SHIFT 20
	#define CORTEXA9_DBGBCR4_DBGBVR_MEANING_VAL0 0x00
	#define CORTEXA9_DBGBCR4_DBGBVR_MEANING_VAL1 0x01
	#define CORTEXA9_DBGBCR4_DBGBVR_MEANING_VAL2 0x02
	#define CORTEXA9_DBGBCR4_DBGBVR_MEANING_VAL3 0x03
	/*
	* If this BRP is programmed for Linked IVA match or mismatch then this field must 
	* be programmed with the number of the BRP that holds the Context ID to be used fo
	* r the combined IVA and Context ID comparison, otherwise, this field must be prog
	* rammed to 0b0000.
	*/
	#define CORTEXA9_DBGBCR4_LINKED_BRP_NUMBER_RW (0x07 << 16)
	#define CORTEXA9_DBGBCR4_LINKED_BRP_NUMBER_SHIFT 16
	#define CORTEXA9_DBGBCR4_LINKED_BRP_NUMBER_VAL0 0x00
	#define CORTEXA9_DBGBCR4_LINKED_BRP_NUMBER_VAL1 0x01
	#define CORTEXA9_DBGBCR4_LINKED_BRP_NUMBER_VAL2 0x02
	#define CORTEXA9_DBGBCR4_LINKED_BRP_NUMBER_VAL3 0x03
	#define CORTEXA9_DBGBCR4_LINKED_BRP_NUMBER_VAL4 0x04
	#define CORTEXA9_DBGBCR4_LINKED_BRP_NUMBER_VAL5 0x05
	#define CORTEXA9_DBGBCR4_LINKED_BRP_NUMBER_VAL6 0x06
	#define CORTEXA9_DBGBCR4_LINKED_BRP_NUMBER_VAL7 0x07
	/*
	* Security state control
	*/
	#define CORTEXA9_DBGBCR4_SSC_RW (0x01 << 14)
	#define CORTEXA9_DBGBCR4_SSC_SHIFT 14
	#define CORTEXA9_DBGBCR4_SSC_VAL0 0x00
	#define CORTEXA9_DBGBCR4_SSC_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR4_RESERVED6_RES (0x0f << 9)
	#define CORTEXA9_DBGBCR4_RESERVED6_SHIFT 9
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL0 0x00
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL1 0x01
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL2 0x02
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL3 0x03
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL4 0x04
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL5 0x05
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL6 0x06
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL7 0x07
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL8 0x08
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL9 0x09
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL10 0x0a
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL11 0x0b
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL12 0x0c
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL13 0x0d
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL14 0x0e
	#define CORTEXA9_DBGBCR4_RESERVED6_VAL15 0x0f
	/*
	* Byte address select
	*/
	#define CORTEXA9_DBGBCR4_BYTE_ADDRESS_SELECT_RW (0x07 << 5)
	#define CORTEXA9_DBGBCR4_BYTE_ADDRESS_SELECT_SHIFT 5
	#define CORTEXA9_DBGBCR4_BYTE_ADDRESS_SELECT_VAL0 0x00
	#define CORTEXA9_DBGBCR4_BYTE_ADDRESS_SELECT_VAL1 0x01
	#define CORTEXA9_DBGBCR4_BYTE_ADDRESS_SELECT_VAL2 0x02
	#define CORTEXA9_DBGBCR4_BYTE_ADDRESS_SELECT_VAL3 0x03
	#define CORTEXA9_DBGBCR4_BYTE_ADDRESS_SELECT_VAL4 0x04
	#define CORTEXA9_DBGBCR4_BYTE_ADDRESS_SELECT_VAL5 0x05
	#define CORTEXA9_DBGBCR4_BYTE_ADDRESS_SELECT_VAL6 0x06
	#define CORTEXA9_DBGBCR4_BYTE_ADDRESS_SELECT_VAL7 0x07
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR4_RESERVED8_RES (0x01 << 3)
	#define CORTEXA9_DBGBCR4_RESERVED8_SHIFT 3
	#define CORTEXA9_DBGBCR4_RESERVED8_VAL0 0x00
	#define CORTEXA9_DBGBCR4_RESERVED8_VAL1 0x01
	/*
	* Privileged mode control
	*/
	#define CORTEXA9_DBGBCR4_PRIVILEGED_MODE_CONTROL_RW (0x01 << 1)
	#define CORTEXA9_DBGBCR4_PRIVILEGED_MODE_CONTROL_SHIFT 1
	#define CORTEXA9_DBGBCR4_PRIVILEGED_MODE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGBCR4_PRIVILEGED_MODE_CONTROL_VAL1 0x01
	/*
	* This bit enables the BRP.
	*/
	#define CORTEXA9_DBGBCR4_BREAKPOINT_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGBCR4_BREAKPOINT_ENABLE_SHIFT 0
	#define CORTEXA9_DBGBCR4_BREAKPOINT_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGBCR4_BREAKPOINT_ENABLE_VAL1 0x01
	/*
	* A Breakpoint Control Register, DBGBCR, holds control information for a breakpoin
	* t. Each DBGBCR is associated with a DBGBVR to form a Breakpoint Register Pair (B
	* RP)
	*/
	#define CORTEXA9_DBGBCR5_REG  (CORTEXA9_BASE + 0x8154)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR5_RESERVED_RES (0x01 << 29)
	#define CORTEXA9_DBGBCR5_RESERVED_SHIFT 29
	#define CORTEXA9_DBGBCR5_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGBCR5_RESERVED_VAL1 0x01
	/*
	* In v7 Debug, whether address range masking is supported is IMPLEMENTATION DEFINE
	* D. If it is not supported these bits are RAZ/WI.
	* If address range masking is supported, this field can be used to break on a rang
	* e of addresses by masking lower order address bits out of the breakpoint compari
	* son
	*/
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_RW (0x0f << 24)
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_SHIFT 24
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL0 0x00
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL1 0x01
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL2 0x02
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL3 0x03
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL4 0x04
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL5 0x05
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL6 0x06
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL7 0x07
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL8 0x08
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL9 0x09
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL10 0x0a
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL11 0x0b
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL12 0x0c
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL13 0x0d
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL14 0x0e
	#define CORTEXA9_DBGBCR5_ADDRESS_RANGE_MASK_VAL15 0x0f
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR5_RESERVED2_RES (0x01 << 23)
	#define CORTEXA9_DBGBCR5_RESERVED2_SHIFT 23
	#define CORTEXA9_DBGBCR5_RESERVED2_VAL0 0x00
	#define CORTEXA9_DBGBCR5_RESERVED2_VAL1 0x01
	/*
	* This field controls the behavior of Breakpoint debug event generation. This incl
	* udes the meaning of the value held in the associated DBGBVR, whether it is an IV
	* A or a Context ID.
	*/
	#define CORTEXA9_DBGBCR5_DBGBVR_MEANING_RW (0x03 << 20)
	#define CORTEXA9_DBGBCR5_DBGBVR_MEANING_SHIFT 20
	#define CORTEXA9_DBGBCR5_DBGBVR_MEANING_VAL0 0x00
	#define CORTEXA9_DBGBCR5_DBGBVR_MEANING_VAL1 0x01
	#define CORTEXA9_DBGBCR5_DBGBVR_MEANING_VAL2 0x02
	#define CORTEXA9_DBGBCR5_DBGBVR_MEANING_VAL3 0x03
	/*
	* If this BRP is programmed for Linked IVA match or mismatch then this field must 
	* be programmed with the number of the BRP that holds the Context ID to be used fo
	* r the combined IVA and Context ID comparison, otherwise, this field must be prog
	* rammed to 0b0000.
	*/
	#define CORTEXA9_DBGBCR5_LINKED_BRP_NUMBER_RW (0x07 << 16)
	#define CORTEXA9_DBGBCR5_LINKED_BRP_NUMBER_SHIFT 16
	#define CORTEXA9_DBGBCR5_LINKED_BRP_NUMBER_VAL0 0x00
	#define CORTEXA9_DBGBCR5_LINKED_BRP_NUMBER_VAL1 0x01
	#define CORTEXA9_DBGBCR5_LINKED_BRP_NUMBER_VAL2 0x02
	#define CORTEXA9_DBGBCR5_LINKED_BRP_NUMBER_VAL3 0x03
	#define CORTEXA9_DBGBCR5_LINKED_BRP_NUMBER_VAL4 0x04
	#define CORTEXA9_DBGBCR5_LINKED_BRP_NUMBER_VAL5 0x05
	#define CORTEXA9_DBGBCR5_LINKED_BRP_NUMBER_VAL6 0x06
	#define CORTEXA9_DBGBCR5_LINKED_BRP_NUMBER_VAL7 0x07
	/*
	* Security state control
	*/
	#define CORTEXA9_DBGBCR5_SSC_RW (0x01 << 14)
	#define CORTEXA9_DBGBCR5_SSC_SHIFT 14
	#define CORTEXA9_DBGBCR5_SSC_VAL0 0x00
	#define CORTEXA9_DBGBCR5_SSC_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR5_RESERVED6_RES (0x0f << 9)
	#define CORTEXA9_DBGBCR5_RESERVED6_SHIFT 9
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL0 0x00
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL1 0x01
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL2 0x02
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL3 0x03
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL4 0x04
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL5 0x05
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL6 0x06
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL7 0x07
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL8 0x08
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL9 0x09
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL10 0x0a
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL11 0x0b
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL12 0x0c
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL13 0x0d
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL14 0x0e
	#define CORTEXA9_DBGBCR5_RESERVED6_VAL15 0x0f
	/*
	* Byte address select
	*/
	#define CORTEXA9_DBGBCR5_BYTE_ADDRESS_SELECT_RW (0x07 << 5)
	#define CORTEXA9_DBGBCR5_BYTE_ADDRESS_SELECT_SHIFT 5
	#define CORTEXA9_DBGBCR5_BYTE_ADDRESS_SELECT_VAL0 0x00
	#define CORTEXA9_DBGBCR5_BYTE_ADDRESS_SELECT_VAL1 0x01
	#define CORTEXA9_DBGBCR5_BYTE_ADDRESS_SELECT_VAL2 0x02
	#define CORTEXA9_DBGBCR5_BYTE_ADDRESS_SELECT_VAL3 0x03
	#define CORTEXA9_DBGBCR5_BYTE_ADDRESS_SELECT_VAL4 0x04
	#define CORTEXA9_DBGBCR5_BYTE_ADDRESS_SELECT_VAL5 0x05
	#define CORTEXA9_DBGBCR5_BYTE_ADDRESS_SELECT_VAL6 0x06
	#define CORTEXA9_DBGBCR5_BYTE_ADDRESS_SELECT_VAL7 0x07
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGBCR5_RESERVED8_RES (0x01 << 3)
	#define CORTEXA9_DBGBCR5_RESERVED8_SHIFT 3
	#define CORTEXA9_DBGBCR5_RESERVED8_VAL0 0x00
	#define CORTEXA9_DBGBCR5_RESERVED8_VAL1 0x01
	/*
	* Privileged mode control
	*/
	#define CORTEXA9_DBGBCR5_PRIVILEGED_MODE_CONTROL_RW (0x01 << 1)
	#define CORTEXA9_DBGBCR5_PRIVILEGED_MODE_CONTROL_SHIFT 1
	#define CORTEXA9_DBGBCR5_PRIVILEGED_MODE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGBCR5_PRIVILEGED_MODE_CONTROL_VAL1 0x01
	/*
	* This bit enables the BRP.
	*/
	#define CORTEXA9_DBGBCR5_BREAKPOINT_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGBCR5_BREAKPOINT_ENABLE_SHIFT 0
	#define CORTEXA9_DBGBCR5_BREAKPOINT_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGBCR5_BREAKPOINT_ENABLE_VAL1 0x01
	/*
	* A Watchpoint Value Register, DBGWVR, holds a Data Virtual Address (DVA) value fo
	* r use in watchpoint matching. Each DBGWVR is associated with a DBGWCR to form a 
	* Watchpoint Register Pair (WRP).
	*/
	#define CORTEXA9_DBGWVR0_REG  (CORTEXA9_BASE + 0x8180)
	/*
	* Bits [31:2] of the value for comparison, DVA[31:2].
	*/
	#define CORTEXA9_DBGWVR0_WATCHPOINT_ADDRESS_RW (0x01fffffff << 2)
	#define CORTEXA9_DBGWVR0_WATCHPOINT_ADDRESS_SHIFT 2
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWVR0_RESERVED_RES (0x03 << 0)
	#define CORTEXA9_DBGWVR0_RESERVED_SHIFT 0
	#define CORTEXA9_DBGWVR0_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGWVR0_RESERVED_VAL1 0x01
	#define CORTEXA9_DBGWVR0_RESERVED_VAL2 0x02
	#define CORTEXA9_DBGWVR0_RESERVED_VAL3 0x03
	/*
	* A Watchpoint Value Register, DBGWVR, holds a Data Virtual Address (DVA) value fo
	* r use in watchpoint matching. Each DBGWVR is associated with a DBGWCR to form a 
	* Watchpoint Register Pair (WRP).
	*/
	#define CORTEXA9_DBGWVR1_REG  (CORTEXA9_BASE + 0x8184)
	/*
	* Bits [31:2] of the value for comparison, DVA[31:2].
	*/
	#define CORTEXA9_DBGWVR1_WATCHPOINT_ADDRESS_RW (0x01fffffff << 2)
	#define CORTEXA9_DBGWVR1_WATCHPOINT_ADDRESS_SHIFT 2
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWVR1_RESERVED_RES (0x03 << 0)
	#define CORTEXA9_DBGWVR1_RESERVED_SHIFT 0
	#define CORTEXA9_DBGWVR1_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGWVR1_RESERVED_VAL1 0x01
	#define CORTEXA9_DBGWVR1_RESERVED_VAL2 0x02
	#define CORTEXA9_DBGWVR1_RESERVED_VAL3 0x03
	/*
	* A Watchpoint Value Register, DBGWVR, holds a Data Virtual Address (DVA) value fo
	* r use in watchpoint matching. Each DBGWVR is associated with a DBGWCR to form a 
	* Watchpoint Register Pair (WRP).
	*/
	#define CORTEXA9_DBGWVR2_REG  (CORTEXA9_BASE + 0x8188)
	/*
	* Bits [31:2] of the value for comparison, DVA[31:2].
	*/
	#define CORTEXA9_DBGWVR2_WATCHPOINT_ADDRESS_RW (0x01fffffff << 2)
	#define CORTEXA9_DBGWVR2_WATCHPOINT_ADDRESS_SHIFT 2
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWVR2_RESERVED_RES (0x03 << 0)
	#define CORTEXA9_DBGWVR2_RESERVED_SHIFT 0
	#define CORTEXA9_DBGWVR2_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGWVR2_RESERVED_VAL1 0x01
	#define CORTEXA9_DBGWVR2_RESERVED_VAL2 0x02
	#define CORTEXA9_DBGWVR2_RESERVED_VAL3 0x03
	/*
	* A Watchpoint Value Register, DBGWVR, holds a Data Virtual Address (DVA) value fo
	* r use in watchpoint matching. Each DBGWVR is associated with a DBGWCR to form a 
	* Watchpoint Register Pair (WRP).
	*/
	#define CORTEXA9_DBGWVR3_REG  (CORTEXA9_BASE + 0x818c)
	/*
	* Bits [31:2] of the value for comparison, DVA[31:2].
	*/
	#define CORTEXA9_DBGWVR3_WATCHPOINT_ADDRESS_RW (0x01fffffff << 2)
	#define CORTEXA9_DBGWVR3_WATCHPOINT_ADDRESS_SHIFT 2
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWVR3_RESERVED_RES (0x03 << 0)
	#define CORTEXA9_DBGWVR3_RESERVED_SHIFT 0
	#define CORTEXA9_DBGWVR3_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGWVR3_RESERVED_VAL1 0x01
	#define CORTEXA9_DBGWVR3_RESERVED_VAL2 0x02
	#define CORTEXA9_DBGWVR3_RESERVED_VAL3 0x03
	/*
	* A Watchpoint Control Register, DBGWCR, holds control information for a watchpoin
	* t. Each DBGWCR is associated with a DBGWVR to form a Watchpoint Register Pair (W
	* RP).
	*/
	#define CORTEXA9_DBGWCR0_REG  (CORTEXA9_BASE + 0x81c0)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR0_RESERVED_RES (0x03 << 29)
	#define CORTEXA9_DBGWCR0_RESERVED_SHIFT 29
	#define CORTEXA9_DBGWCR0_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGWCR0_RESERVED_VAL1 0x01
	#define CORTEXA9_DBGWCR0_RESERVED_VAL2 0x02
	#define CORTEXA9_DBGWCR0_RESERVED_VAL3 0x03
	/*
	* In v7 Debug, support for watchpoint address range masking is optional. If it is 
	* not supported these bits are RAZ/WI.
	* If watchpoint address range masking is supported, this field can be used to watc
	* h a range of addresses by masking lower order address bits out of the watchpoint
	*  comparison.
	*/
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_RW (0x0f << 24)
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_SHIFT 24
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL0 0x00
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL1 0x01
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL2 0x02
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL3 0x03
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL4 0x04
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL5 0x05
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL6 0x06
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL7 0x07
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL8 0x08
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL9 0x09
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL10 0x0a
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL11 0x0b
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL12 0x0c
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL13 0x0d
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL14 0x0e
	#define CORTEXA9_DBGWCR0_ADDRESS_RANGE_MASK_VAL15 0x0f
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR0_RESERVED2_RES (0x03 << 21)
	#define CORTEXA9_DBGWCR0_RESERVED2_SHIFT 21
	#define CORTEXA9_DBGWCR0_RESERVED2_VAL0 0x00
	#define CORTEXA9_DBGWCR0_RESERVED2_VAL1 0x01
	#define CORTEXA9_DBGWCR0_RESERVED2_VAL2 0x02
	#define CORTEXA9_DBGWCR0_RESERVED2_VAL3 0x03
	/*
	* This bit is set to 1 if this WRP is linked to a BRP to set a linked watchpoint t
	* hat requires both DVA and Context ID comparison
	*/
	#define CORTEXA9_DBGWCR0_ENABLE_LINKING_RW (0x01 << 20)
	#define CORTEXA9_DBGWCR0_ENABLE_LINKING_SHIFT 20
	#define CORTEXA9_DBGWCR0_ENABLE_LINKING_VAL0 0x00
	#define CORTEXA9_DBGWCR0_ENABLE_LINKING_VAL1 0x01
	/*
	* If this WRP is programmed with linking enabled then this field must be programme
	* d with the number of the BRP that holds the Context ID to be used for the combin
	* ed DVA and Context ID comparison, otherwise, this field must be programmed to 0b
	* 0000
	*/
	#define CORTEXA9_DBGWCR0_LINKED_BRP_NUMBER_RW (0x07 << 16)
	#define CORTEXA9_DBGWCR0_LINKED_BRP_NUMBER_SHIFT 16
	#define CORTEXA9_DBGWCR0_LINKED_BRP_NUMBER_VAL0 0x00
	#define CORTEXA9_DBGWCR0_LINKED_BRP_NUMBER_VAL1 0x01
	#define CORTEXA9_DBGWCR0_LINKED_BRP_NUMBER_VAL2 0x02
	#define CORTEXA9_DBGWCR0_LINKED_BRP_NUMBER_VAL3 0x03
	#define CORTEXA9_DBGWCR0_LINKED_BRP_NUMBER_VAL4 0x04
	#define CORTEXA9_DBGWCR0_LINKED_BRP_NUMBER_VAL5 0x05
	#define CORTEXA9_DBGWCR0_LINKED_BRP_NUMBER_VAL6 0x06
	#define CORTEXA9_DBGWCR0_LINKED_BRP_NUMBER_VAL7 0x07
	/*
	* Security state control
	*/
	#define CORTEXA9_DBGWCR0_SECURITY_STATE_CONTROL_RW (0x01 << 14)
	#define CORTEXA9_DBGWCR0_SECURITY_STATE_CONTROL_SHIFT 14
	#define CORTEXA9_DBGWCR0_SECURITY_STATE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGWCR0_SECURITY_STATE_CONTROL_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR0_RESERVED6_RES (0x0f << 9)
	#define CORTEXA9_DBGWCR0_RESERVED6_SHIFT 9
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL0 0x00
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL1 0x01
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL2 0x02
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL3 0x03
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL4 0x04
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL5 0x05
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL6 0x06
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL7 0x07
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL8 0x08
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL9 0x09
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL10 0x0a
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL11 0x0b
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL12 0x0c
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL13 0x0d
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL14 0x0e
	#define CORTEXA9_DBGWCR0_RESERVED6_VAL15 0x0f
	#define CORTEXA9_DBGWCR0_BYTE_ADDRESS_SELECT_RW (0x07 << 5)
	#define CORTEXA9_DBGWCR0_BYTE_ADDRESS_SELECT_SHIFT 5
	#define CORTEXA9_DBGWCR0_BYTE_ADDRESS_SELECT_VAL0 0x00
	#define CORTEXA9_DBGWCR0_BYTE_ADDRESS_SELECT_VAL1 0x01
	#define CORTEXA9_DBGWCR0_BYTE_ADDRESS_SELECT_VAL2 0x02
	#define CORTEXA9_DBGWCR0_BYTE_ADDRESS_SELECT_VAL3 0x03
	#define CORTEXA9_DBGWCR0_BYTE_ADDRESS_SELECT_VAL4 0x04
	#define CORTEXA9_DBGWCR0_BYTE_ADDRESS_SELECT_VAL5 0x05
	#define CORTEXA9_DBGWCR0_BYTE_ADDRESS_SELECT_VAL6 0x06
	#define CORTEXA9_DBGWCR0_BYTE_ADDRESS_SELECT_VAL7 0x07
	/*
	* Load/store access control
	* This field enables watchpoint matching conditional on the type of access being m
	* ade
	*/
	#define CORTEXA9_DBGWCR0_LSAC_RW (0x01 << 3)
	#define CORTEXA9_DBGWCR0_LSAC_SHIFT 3
	#define CORTEXA9_DBGWCR0_LSAC_VAL0 0x00
	#define CORTEXA9_DBGWCR0_LSAC_VAL1 0x01
	/*
	* Privileged mode control
	*/
	#define CORTEXA9_DBGWCR0_PRIVILEGED_MODE_CONTROL_RW (0x01 << 1)
	#define CORTEXA9_DBGWCR0_PRIVILEGED_MODE_CONTROL_SHIFT 1
	#define CORTEXA9_DBGWCR0_PRIVILEGED_MODE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGWCR0_PRIVILEGED_MODE_CONTROL_VAL1 0x01
	/*
	* This bit enables the WRP
	*/
	#define CORTEXA9_DBGWCR0_WATCHPOINT_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGWCR0_WATCHPOINT_ENABLE_SHIFT 0
	#define CORTEXA9_DBGWCR0_WATCHPOINT_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGWCR0_WATCHPOINT_ENABLE_VAL1 0x01
	/*
	* A Watchpoint Control Register, DBGWCR, holds control information for a watchpoin
	* t. Each DBGWCR is associated with a DBGWVR to form a Watchpoint Register Pair (W
	* RP).
	*/
	#define CORTEXA9_DBGWCR1_REG  (CORTEXA9_BASE + 0x81c4)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR1_RESERVED_RES (0x03 << 29)
	#define CORTEXA9_DBGWCR1_RESERVED_SHIFT 29
	#define CORTEXA9_DBGWCR1_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGWCR1_RESERVED_VAL1 0x01
	#define CORTEXA9_DBGWCR1_RESERVED_VAL2 0x02
	#define CORTEXA9_DBGWCR1_RESERVED_VAL3 0x03
	/*
	* In v7 Debug, support for watchpoint address range masking is optional. If it is 
	* not supported these bits are RAZ/WI.
	* If watchpoint address range masking is supported, this field can be used to watc
	* h a range of addresses by masking lower order address bits out of the watchpoint
	*  comparison.
	*/
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_RW (0x0f << 24)
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_SHIFT 24
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL0 0x00
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL1 0x01
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL2 0x02
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL3 0x03
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL4 0x04
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL5 0x05
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL6 0x06
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL7 0x07
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL8 0x08
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL9 0x09
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL10 0x0a
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL11 0x0b
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL12 0x0c
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL13 0x0d
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL14 0x0e
	#define CORTEXA9_DBGWCR1_ADDRESS_RANGE_MASK_VAL15 0x0f
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR1_RESERVED2_RES (0x03 << 21)
	#define CORTEXA9_DBGWCR1_RESERVED2_SHIFT 21
	#define CORTEXA9_DBGWCR1_RESERVED2_VAL0 0x00
	#define CORTEXA9_DBGWCR1_RESERVED2_VAL1 0x01
	#define CORTEXA9_DBGWCR1_RESERVED2_VAL2 0x02
	#define CORTEXA9_DBGWCR1_RESERVED2_VAL3 0x03
	/*
	* This bit is set to 1 if this WRP is linked to a BRP to set a linked watchpoint t
	* hat requires both DVA and Context ID comparison
	*/
	#define CORTEXA9_DBGWCR1_ENABLE_LINKING_RW (0x01 << 20)
	#define CORTEXA9_DBGWCR1_ENABLE_LINKING_SHIFT 20
	#define CORTEXA9_DBGWCR1_ENABLE_LINKING_VAL0 0x00
	#define CORTEXA9_DBGWCR1_ENABLE_LINKING_VAL1 0x01
	/*
	* If this WRP is programmed with linking enabled then this field must be programme
	* d with the number of the BRP that holds the Context ID to be used for the combin
	* ed DVA and Context ID comparison, otherwise, this field must be programmed to 0b
	* 0000
	*/
	#define CORTEXA9_DBGWCR1_LINKED_BRP_NUMBER_RW (0x07 << 16)
	#define CORTEXA9_DBGWCR1_LINKED_BRP_NUMBER_SHIFT 16
	#define CORTEXA9_DBGWCR1_LINKED_BRP_NUMBER_VAL0 0x00
	#define CORTEXA9_DBGWCR1_LINKED_BRP_NUMBER_VAL1 0x01
	#define CORTEXA9_DBGWCR1_LINKED_BRP_NUMBER_VAL2 0x02
	#define CORTEXA9_DBGWCR1_LINKED_BRP_NUMBER_VAL3 0x03
	#define CORTEXA9_DBGWCR1_LINKED_BRP_NUMBER_VAL4 0x04
	#define CORTEXA9_DBGWCR1_LINKED_BRP_NUMBER_VAL5 0x05
	#define CORTEXA9_DBGWCR1_LINKED_BRP_NUMBER_VAL6 0x06
	#define CORTEXA9_DBGWCR1_LINKED_BRP_NUMBER_VAL7 0x07
	/*
	* Security state control
	*/
	#define CORTEXA9_DBGWCR1_SECURITY_STATE_CONTROL_RW (0x01 << 14)
	#define CORTEXA9_DBGWCR1_SECURITY_STATE_CONTROL_SHIFT 14
	#define CORTEXA9_DBGWCR1_SECURITY_STATE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGWCR1_SECURITY_STATE_CONTROL_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR1_RESERVED6_RES (0x0f << 9)
	#define CORTEXA9_DBGWCR1_RESERVED6_SHIFT 9
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL0 0x00
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL1 0x01
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL2 0x02
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL3 0x03
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL4 0x04
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL5 0x05
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL6 0x06
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL7 0x07
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL8 0x08
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL9 0x09
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL10 0x0a
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL11 0x0b
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL12 0x0c
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL13 0x0d
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL14 0x0e
	#define CORTEXA9_DBGWCR1_RESERVED6_VAL15 0x0f
	#define CORTEXA9_DBGWCR1_BYTE_ADDRESS_SELECT_RW (0x07 << 5)
	#define CORTEXA9_DBGWCR1_BYTE_ADDRESS_SELECT_SHIFT 5
	#define CORTEXA9_DBGWCR1_BYTE_ADDRESS_SELECT_VAL0 0x00
	#define CORTEXA9_DBGWCR1_BYTE_ADDRESS_SELECT_VAL1 0x01
	#define CORTEXA9_DBGWCR1_BYTE_ADDRESS_SELECT_VAL2 0x02
	#define CORTEXA9_DBGWCR1_BYTE_ADDRESS_SELECT_VAL3 0x03
	#define CORTEXA9_DBGWCR1_BYTE_ADDRESS_SELECT_VAL4 0x04
	#define CORTEXA9_DBGWCR1_BYTE_ADDRESS_SELECT_VAL5 0x05
	#define CORTEXA9_DBGWCR1_BYTE_ADDRESS_SELECT_VAL6 0x06
	#define CORTEXA9_DBGWCR1_BYTE_ADDRESS_SELECT_VAL7 0x07
	/*
	* Load/store access control
	* This field enables watchpoint matching conditional on the type of access being m
	* ade
	*/
	#define CORTEXA9_DBGWCR1_LSAC_RW (0x01 << 3)
	#define CORTEXA9_DBGWCR1_LSAC_SHIFT 3
	#define CORTEXA9_DBGWCR1_LSAC_VAL0 0x00
	#define CORTEXA9_DBGWCR1_LSAC_VAL1 0x01
	/*
	* Privileged mode control
	*/
	#define CORTEXA9_DBGWCR1_PRIVILEGED_MODE_CONTROL_RW (0x01 << 1)
	#define CORTEXA9_DBGWCR1_PRIVILEGED_MODE_CONTROL_SHIFT 1
	#define CORTEXA9_DBGWCR1_PRIVILEGED_MODE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGWCR1_PRIVILEGED_MODE_CONTROL_VAL1 0x01
	/*
	* This bit enables the WRP
	*/
	#define CORTEXA9_DBGWCR1_WATCHPOINT_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGWCR1_WATCHPOINT_ENABLE_SHIFT 0
	#define CORTEXA9_DBGWCR1_WATCHPOINT_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGWCR1_WATCHPOINT_ENABLE_VAL1 0x01
	/*
	* A Watchpoint Control Register, DBGWCR, holds control information for a watchpoin
	* t. Each DBGWCR is associated with a DBGWVR to form a Watchpoint Register Pair (W
	* RP).
	*/
	#define CORTEXA9_DBGWCR2_REG  (CORTEXA9_BASE + 0x81c8)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR2_RESERVED_RES (0x03 << 29)
	#define CORTEXA9_DBGWCR2_RESERVED_SHIFT 29
	#define CORTEXA9_DBGWCR2_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGWCR2_RESERVED_VAL1 0x01
	#define CORTEXA9_DBGWCR2_RESERVED_VAL2 0x02
	#define CORTEXA9_DBGWCR2_RESERVED_VAL3 0x03
	/*
	* In v7 Debug, support for watchpoint address range masking is optional. If it is 
	* not supported these bits are RAZ/WI.
	* If watchpoint address range masking is supported, this field can be used to watc
	* h a range of addresses by masking lower order address bits out of the watchpoint
	*  comparison.
	*/
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_RW (0x0f << 24)
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_SHIFT 24
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL0 0x00
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL1 0x01
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL2 0x02
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL3 0x03
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL4 0x04
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL5 0x05
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL6 0x06
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL7 0x07
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL8 0x08
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL9 0x09
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL10 0x0a
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL11 0x0b
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL12 0x0c
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL13 0x0d
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL14 0x0e
	#define CORTEXA9_DBGWCR2_ADDRESS_RANGE_MASK_VAL15 0x0f
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR2_RESERVED2_RES (0x03 << 21)
	#define CORTEXA9_DBGWCR2_RESERVED2_SHIFT 21
	#define CORTEXA9_DBGWCR2_RESERVED2_VAL0 0x00
	#define CORTEXA9_DBGWCR2_RESERVED2_VAL1 0x01
	#define CORTEXA9_DBGWCR2_RESERVED2_VAL2 0x02
	#define CORTEXA9_DBGWCR2_RESERVED2_VAL3 0x03
	/*
	* This bit is set to 1 if this WRP is linked to a BRP to set a linked watchpoint t
	* hat requires both DVA and Context ID comparison
	*/
	#define CORTEXA9_DBGWCR2_ENABLE_LINKING_RW (0x01 << 20)
	#define CORTEXA9_DBGWCR2_ENABLE_LINKING_SHIFT 20
	#define CORTEXA9_DBGWCR2_ENABLE_LINKING_VAL0 0x00
	#define CORTEXA9_DBGWCR2_ENABLE_LINKING_VAL1 0x01
	/*
	* If this WRP is programmed with linking enabled then this field must be programme
	* d with the number of the BRP that holds the Context ID to be used for the combin
	* ed DVA and Context ID comparison, otherwise, this field must be programmed to 0b
	* 0000
	*/
	#define CORTEXA9_DBGWCR2_LINKED_BRP_NUMBER_RW (0x07 << 16)
	#define CORTEXA9_DBGWCR2_LINKED_BRP_NUMBER_SHIFT 16
	#define CORTEXA9_DBGWCR2_LINKED_BRP_NUMBER_VAL0 0x00
	#define CORTEXA9_DBGWCR2_LINKED_BRP_NUMBER_VAL1 0x01
	#define CORTEXA9_DBGWCR2_LINKED_BRP_NUMBER_VAL2 0x02
	#define CORTEXA9_DBGWCR2_LINKED_BRP_NUMBER_VAL3 0x03
	#define CORTEXA9_DBGWCR2_LINKED_BRP_NUMBER_VAL4 0x04
	#define CORTEXA9_DBGWCR2_LINKED_BRP_NUMBER_VAL5 0x05
	#define CORTEXA9_DBGWCR2_LINKED_BRP_NUMBER_VAL6 0x06
	#define CORTEXA9_DBGWCR2_LINKED_BRP_NUMBER_VAL7 0x07
	/*
	* Security state control
	*/
	#define CORTEXA9_DBGWCR2_SECURITY_STATE_CONTROL_RW (0x01 << 14)
	#define CORTEXA9_DBGWCR2_SECURITY_STATE_CONTROL_SHIFT 14
	#define CORTEXA9_DBGWCR2_SECURITY_STATE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGWCR2_SECURITY_STATE_CONTROL_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR2_RESERVED6_RES (0x0f << 9)
	#define CORTEXA9_DBGWCR2_RESERVED6_SHIFT 9
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL0 0x00
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL1 0x01
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL2 0x02
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL3 0x03
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL4 0x04
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL5 0x05
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL6 0x06
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL7 0x07
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL8 0x08
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL9 0x09
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL10 0x0a
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL11 0x0b
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL12 0x0c
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL13 0x0d
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL14 0x0e
	#define CORTEXA9_DBGWCR2_RESERVED6_VAL15 0x0f
	#define CORTEXA9_DBGWCR2_BYTE_ADDRESS_SELECT_RW (0x07 << 5)
	#define CORTEXA9_DBGWCR2_BYTE_ADDRESS_SELECT_SHIFT 5
	#define CORTEXA9_DBGWCR2_BYTE_ADDRESS_SELECT_VAL0 0x00
	#define CORTEXA9_DBGWCR2_BYTE_ADDRESS_SELECT_VAL1 0x01
	#define CORTEXA9_DBGWCR2_BYTE_ADDRESS_SELECT_VAL2 0x02
	#define CORTEXA9_DBGWCR2_BYTE_ADDRESS_SELECT_VAL3 0x03
	#define CORTEXA9_DBGWCR2_BYTE_ADDRESS_SELECT_VAL4 0x04
	#define CORTEXA9_DBGWCR2_BYTE_ADDRESS_SELECT_VAL5 0x05
	#define CORTEXA9_DBGWCR2_BYTE_ADDRESS_SELECT_VAL6 0x06
	#define CORTEXA9_DBGWCR2_BYTE_ADDRESS_SELECT_VAL7 0x07
	/*
	* Load/store access control
	* This field enables watchpoint matching conditional on the type of access being m
	* ade
	*/
	#define CORTEXA9_DBGWCR2_LSAC_RW (0x01 << 3)
	#define CORTEXA9_DBGWCR2_LSAC_SHIFT 3
	#define CORTEXA9_DBGWCR2_LSAC_VAL0 0x00
	#define CORTEXA9_DBGWCR2_LSAC_VAL1 0x01
	/*
	* Privileged mode control
	*/
	#define CORTEXA9_DBGWCR2_PRIVILEGED_MODE_CONTROL_RW (0x01 << 1)
	#define CORTEXA9_DBGWCR2_PRIVILEGED_MODE_CONTROL_SHIFT 1
	#define CORTEXA9_DBGWCR2_PRIVILEGED_MODE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGWCR2_PRIVILEGED_MODE_CONTROL_VAL1 0x01
	/*
	* This bit enables the WRP
	*/
	#define CORTEXA9_DBGWCR2_WATCHPOINT_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGWCR2_WATCHPOINT_ENABLE_SHIFT 0
	#define CORTEXA9_DBGWCR2_WATCHPOINT_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGWCR2_WATCHPOINT_ENABLE_VAL1 0x01
	/*
	* A Watchpoint Control Register, DBGWCR, holds control information for a watchpoin
	* t. Each DBGWCR is associated with a DBGWVR to form a Watchpoint Register Pair (W
	* RP).
	*/
	#define CORTEXA9_DBGWCR3_REG  (CORTEXA9_BASE + 0x81cc)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR3_RESERVED_RES (0x03 << 29)
	#define CORTEXA9_DBGWCR3_RESERVED_SHIFT 29
	#define CORTEXA9_DBGWCR3_RESERVED_VAL0 0x00
	#define CORTEXA9_DBGWCR3_RESERVED_VAL1 0x01
	#define CORTEXA9_DBGWCR3_RESERVED_VAL2 0x02
	#define CORTEXA9_DBGWCR3_RESERVED_VAL3 0x03
	/*
	* In v7 Debug, support for watchpoint address range masking is optional. If it is 
	* not supported these bits are RAZ/WI.
	* If watchpoint address range masking is supported, this field can be used to watc
	* h a range of addresses by masking lower order address bits out of the watchpoint
	*  comparison.
	*/
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_RW (0x0f << 24)
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_SHIFT 24
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL0 0x00
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL1 0x01
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL2 0x02
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL3 0x03
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL4 0x04
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL5 0x05
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL6 0x06
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL7 0x07
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL8 0x08
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL9 0x09
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL10 0x0a
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL11 0x0b
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL12 0x0c
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL13 0x0d
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL14 0x0e
	#define CORTEXA9_DBGWCR3_ADDRESS_RANGE_MASK_VAL15 0x0f
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR3_RESERVED2_RES (0x03 << 21)
	#define CORTEXA9_DBGWCR3_RESERVED2_SHIFT 21
	#define CORTEXA9_DBGWCR3_RESERVED2_VAL0 0x00
	#define CORTEXA9_DBGWCR3_RESERVED2_VAL1 0x01
	#define CORTEXA9_DBGWCR3_RESERVED2_VAL2 0x02
	#define CORTEXA9_DBGWCR3_RESERVED2_VAL3 0x03
	/*
	* This bit is set to 1 if this WRP is linked to a BRP to set a linked watchpoint t
	* hat requires both DVA and Context ID comparison
	*/
	#define CORTEXA9_DBGWCR3_ENABLE_LINKING_RW (0x01 << 20)
	#define CORTEXA9_DBGWCR3_ENABLE_LINKING_SHIFT 20
	#define CORTEXA9_DBGWCR3_ENABLE_LINKING_VAL0 0x00
	#define CORTEXA9_DBGWCR3_ENABLE_LINKING_VAL1 0x01
	/*
	* If this WRP is programmed with linking enabled then this field must be programme
	* d with the number of the BRP that holds the Context ID to be used for the combin
	* ed DVA and Context ID comparison, otherwise, this field must be programmed to 0b
	* 0000
	*/
	#define CORTEXA9_DBGWCR3_LINKED_BRP_NUMBER_RW (0x07 << 16)
	#define CORTEXA9_DBGWCR3_LINKED_BRP_NUMBER_SHIFT 16
	#define CORTEXA9_DBGWCR3_LINKED_BRP_NUMBER_VAL0 0x00
	#define CORTEXA9_DBGWCR3_LINKED_BRP_NUMBER_VAL1 0x01
	#define CORTEXA9_DBGWCR3_LINKED_BRP_NUMBER_VAL2 0x02
	#define CORTEXA9_DBGWCR3_LINKED_BRP_NUMBER_VAL3 0x03
	#define CORTEXA9_DBGWCR3_LINKED_BRP_NUMBER_VAL4 0x04
	#define CORTEXA9_DBGWCR3_LINKED_BRP_NUMBER_VAL5 0x05
	#define CORTEXA9_DBGWCR3_LINKED_BRP_NUMBER_VAL6 0x06
	#define CORTEXA9_DBGWCR3_LINKED_BRP_NUMBER_VAL7 0x07
	/*
	* Security state control
	*/
	#define CORTEXA9_DBGWCR3_SECURITY_STATE_CONTROL_RW (0x01 << 14)
	#define CORTEXA9_DBGWCR3_SECURITY_STATE_CONTROL_SHIFT 14
	#define CORTEXA9_DBGWCR3_SECURITY_STATE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGWCR3_SECURITY_STATE_CONTROL_VAL1 0x01
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGWCR3_RESERVED6_RES (0x0f << 9)
	#define CORTEXA9_DBGWCR3_RESERVED6_SHIFT 9
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL0 0x00
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL1 0x01
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL2 0x02
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL3 0x03
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL4 0x04
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL5 0x05
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL6 0x06
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL7 0x07
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL8 0x08
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL9 0x09
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL10 0x0a
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL11 0x0b
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL12 0x0c
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL13 0x0d
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL14 0x0e
	#define CORTEXA9_DBGWCR3_RESERVED6_VAL15 0x0f
	#define CORTEXA9_DBGWCR3_BYTE_ADDRESS_SELECT_RW (0x07 << 5)
	#define CORTEXA9_DBGWCR3_BYTE_ADDRESS_SELECT_SHIFT 5
	#define CORTEXA9_DBGWCR3_BYTE_ADDRESS_SELECT_VAL0 0x00
	#define CORTEXA9_DBGWCR3_BYTE_ADDRESS_SELECT_VAL1 0x01
	#define CORTEXA9_DBGWCR3_BYTE_ADDRESS_SELECT_VAL2 0x02
	#define CORTEXA9_DBGWCR3_BYTE_ADDRESS_SELECT_VAL3 0x03
	#define CORTEXA9_DBGWCR3_BYTE_ADDRESS_SELECT_VAL4 0x04
	#define CORTEXA9_DBGWCR3_BYTE_ADDRESS_SELECT_VAL5 0x05
	#define CORTEXA9_DBGWCR3_BYTE_ADDRESS_SELECT_VAL6 0x06
	#define CORTEXA9_DBGWCR3_BYTE_ADDRESS_SELECT_VAL7 0x07
	/*
	* Load/store access control
	* This field enables watchpoint matching conditional on the type of access being m
	* ade
	*/
	#define CORTEXA9_DBGWCR3_LSAC_RW (0x01 << 3)
	#define CORTEXA9_DBGWCR3_LSAC_SHIFT 3
	#define CORTEXA9_DBGWCR3_LSAC_VAL0 0x00
	#define CORTEXA9_DBGWCR3_LSAC_VAL1 0x01
	/*
	* Privileged mode control
	*/
	#define CORTEXA9_DBGWCR3_PRIVILEGED_MODE_CONTROL_RW (0x01 << 1)
	#define CORTEXA9_DBGWCR3_PRIVILEGED_MODE_CONTROL_SHIFT 1
	#define CORTEXA9_DBGWCR3_PRIVILEGED_MODE_CONTROL_VAL0 0x00
	#define CORTEXA9_DBGWCR3_PRIVILEGED_MODE_CONTROL_VAL1 0x01
	/*
	* This bit enables the WRP
	*/
	#define CORTEXA9_DBGWCR3_WATCHPOINT_ENABLE_RW (0x01 << 0)
	#define CORTEXA9_DBGWCR3_WATCHPOINT_ENABLE_SHIFT 0
	#define CORTEXA9_DBGWCR3_WATCHPOINT_ENABLE_VAL0 0x00
	#define CORTEXA9_DBGWCR3_WATCHPOINT_ENABLE_VAL1 0x01
	/*
	* Device Power-down and Reset Control Register
	*/
	#define CORTEXA9_DBGPRCR_REG  (CORTEXA9_BASE + 0x8310)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGPRCR_RESERVED_RES (0x0fffffff << 3)
	#define CORTEXA9_DBGPRCR_RESERVED_SHIFT 3
	/*
	* Hold non-debug logic reset
	*/
	#define CORTEXA9_DBGPRCR_HNDLR_RW (0x01 << 2)
	#define CORTEXA9_DBGPRCR_HNDLR_SHIFT 2
	#define CORTEXA9_DBGPRCR_HNDLR_VAL0 0x00
	#define CORTEXA9_DBGPRCR_HNDLR_VAL1 0x01
	/*
	* Warm reset request
	*/
	#define CORTEXA9_DBGPRCR_WRR_RW (0x01 << 1)
	#define CORTEXA9_DBGPRCR_WRR_SHIFT 1
	#define CORTEXA9_DBGPRCR_WRR_VAL0 0x00
	#define CORTEXA9_DBGPRCR_WRR_VAL1 0x01
	/*
	* No power-down bit
	* This bit controls the DBGNOPWRDWN signal, if it is implemented
	*/
	#define CORTEXA9_DBGPRCR_DBGNOPWRDWN_RW (0x01 << 0)
	#define CORTEXA9_DBGPRCR_DBGNOPWRDWN_SHIFT 0
	#define CORTEXA9_DBGPRCR_DBGNOPWRDWN_VAL0 0x00
	#define CORTEXA9_DBGPRCR_DBGNOPWRDWN_VAL1 0x01
	/*
	* The Device Power-down and Reset Status Register, DBGPRSR, holds information abou
	* t the reset and power-down state of the processor.
	*/
	#define CORTEXA9_DBGPRSR_REG  (CORTEXA9_BASE + 0x8314)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGPRSR_RESERVED_RES (0x07ffffff << 4)
	#define CORTEXA9_DBGPRSR_RESERVED_SHIFT 4
	/*
	* Sticky Reset status
	*/
	#define CORTEXA9_DBGPRSR_SRS_R (0x01 << 3)
	#define CORTEXA9_DBGPRSR_SRS_SHIFT 3
	#define CORTEXA9_DBGPRSR_SRS_VAL0 0x00
	#define CORTEXA9_DBGPRSR_SRS_VAL1 0x01
	/*
	* Reset status
	*/
	#define CORTEXA9_DBGPRSR_RS_R (0x01 << 2)
	#define CORTEXA9_DBGPRSR_RS_SHIFT 2
	#define CORTEXA9_DBGPRSR_RS_VAL0 0x00
	#define CORTEXA9_DBGPRSR_RS_VAL1 0x01
	/*
	* Sticky Power-down status
	*/
	#define CORTEXA9_DBGPRSR_SPDS_R (0x01 << 1)
	#define CORTEXA9_DBGPRSR_SPDS_SHIFT 1
	#define CORTEXA9_DBGPRSR_SPDS_VAL0 0x00
	#define CORTEXA9_DBGPRSR_SPDS_VAL1 0x01
	/*
	* Power-up status
	*/
	#define CORTEXA9_DBGPRSR_PUS_R (0x01 << 0)
	#define CORTEXA9_DBGPRSR_PUS_SHIFT 0
	#define CORTEXA9_DBGPRSR_PUS_VAL0 0x00
	#define CORTEXA9_DBGPRSR_PUS_VAL1 0x01
	/*
	* The Claim Tag Set Register, DBGCLAIMSET, enables the CLAIM bits, bits [7:0] of t
	* he register, to be set to 1. CLAIM bits do not have any specific functionality
	*/
	#define CORTEXA9_DBGCLAIMSET_REG  (CORTEXA9_BASE + 0x8fa0)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGCLAIMSET_RESERVED_RES (0x07fffff << 8)
	#define CORTEXA9_DBGCLAIMSET_RESERVED_SHIFT 8
	/*
	* Writing a 1 to one of these bits sets the corresponding CLAIM bit to 1. Multiple
	*  bits can be set to 1 in a single write operation.
	* These bits are always RAO
	*/
	#define CORTEXA9_DBGCLAIMSET_CLAIM_BITS_RW (0x0ff << 0)
	#define CORTEXA9_DBGCLAIMSET_CLAIM_BITS_SHIFT 0
	/*
	* The Claim Tag Clear Register, DBGCLAIMCLR, enables the values of the CLAIM bits,
	*  bits [7:0] of the register, to be:
	* • read
	* • cleared to 0.
	*/
	#define CORTEXA9_DBGCLAIMCLR_REG  (CORTEXA9_BASE + 0x8fa4)
	/*
	* reserved for future use
	*/
	#define CORTEXA9_DBGCLAIMCLR_RESERVED_RES (0x07fffff << 8)
	#define CORTEXA9_DBGCLAIMCLR_RESERVED_SHIFT 8
	/*
	* Writing a 1 to one of these bits clears the corresponding CLAIM bit to 0. Multip
	* le bits can be cleared to 0 in a single write operation.
	* Writing 0 to one of these bits has no effect.
	* Reading the register returns the current values of these bits.
	* The debug logic reset value of each of these bits is 0.
	*/
	#define CORTEXA9_DBGCLAIMCLR_CLAIM_BITS_RW (0x0ff << 0)
	#define CORTEXA9_DBGCLAIMCLR_CLAIM_BITS_SHIFT 0
	/*
	* The Lock Access Register, DBGLAR, provides a lock on writes to the debug registe
	* rs through the memory-mapped interface
	*/
	#define CORTEXA9_DBGLAR_REG  (CORTEXA9_BASE + 0x8fb0)
	/*
	* Writing the key value 0xC5ACCE55 to this field clears the lock, enabling write a
	* ccesses to the debug registers through the memory-mapped interface.
	* Writing any other value to this register sets the lock, disabling write accesses
	*  to the debug registers through the memory-mapped interface.
	*/
	#define CORTEXA9_DBGLAR_LOCK_ACCESS_CONTROL_W (0x07fffffff << 0)
	#define CORTEXA9_DBGLAR_LOCK_ACCESS_CONTROL_SHIFT 0

#endif // PHMODIPCORTEXA9_H
