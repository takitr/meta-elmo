/*-------------------------------------------------------------------------*/
/* Copyright 2011 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef PHMODIPGPIO_H
#define PHMODIPGPIO_H
	
	
	/*
	* The Mode Control (MC) bit pairs control the mode of the corresponding GPIO pin. 
	* The number portion of MCxx identifies the
	* GPIO number. The following values apply to writing to all of the bit pairs:
	* 00 - retain current GPIO Mode of operation (will not overwrite
	* current mode). Not readable
	* 01 - place Pin in primary function mode (see MUX table)
	* 10 - place Pin in GPIO function mode (see MUX table)
	* 11 - place Pin in GPIO function with Open-Drain Output mode
	*/
	#define GPIO_MODE_CTRL0_REG(n)  (GPIO_BASE_UNIT##n + 0x0)
	/*
	* MC for GPIO number 15
	*/
	#define GPIO_MODE_CTRL0_MC_15_RW (0x03 << 30)
	#define GPIO_MODE_CTRL0_MC_15_SHIFT 30
	#define GPIO_MODE_CTRL0_MC_15_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_15_VAL1 0x01
	/*
	* MC for GPIO number 14
	*/
	#define GPIO_MODE_CTRL0_MC_14_RW (0x03 << 28)
	#define GPIO_MODE_CTRL0_MC_14_SHIFT 28
	#define GPIO_MODE_CTRL0_MC_14_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_14_VAL1 0x01
	/*
	* MC for GPIO number 13
	*/
	#define GPIO_MODE_CTRL0_MC_13_RW (0x03 << 26)
	#define GPIO_MODE_CTRL0_MC_13_SHIFT 26
	#define GPIO_MODE_CTRL0_MC_13_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_13_VAL1 0x01
	/*
	* MC for GPIO number 12
	*/
	#define GPIO_MODE_CTRL0_MC_12_RW (0x03 << 24)
	#define GPIO_MODE_CTRL0_MC_12_SHIFT 24
	#define GPIO_MODE_CTRL0_MC_12_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_12_VAL1 0x01
	/*
	* MC for GPIO number 11
	*/
	#define GPIO_MODE_CTRL0_MC_11_RW (0x03 << 22)
	#define GPIO_MODE_CTRL0_MC_11_SHIFT 22
	#define GPIO_MODE_CTRL0_MC_11_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_11_VAL1 0x01
	/*
	* MC for GPIO number 10
	*/
	#define GPIO_MODE_CTRL0_MC_10_RW (0x03 << 20)
	#define GPIO_MODE_CTRL0_MC_10_SHIFT 20
	#define GPIO_MODE_CTRL0_MC_10_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_10_VAL1 0x01
	/*
	* MC for GPIO number 09
	*/
	#define GPIO_MODE_CTRL0_MC_09_RW (0x03 << 18)
	#define GPIO_MODE_CTRL0_MC_09_SHIFT 18
	#define GPIO_MODE_CTRL0_MC_09_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_09_VAL1 0x01
	/*
	* MC for GPIO number 08
	*/
	#define GPIO_MODE_CTRL0_MC_08_RW (0x03 << 16)
	#define GPIO_MODE_CTRL0_MC_08_SHIFT 16
	#define GPIO_MODE_CTRL0_MC_08_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_08_VAL1 0x01
	/*
	* MC for GPIO number 07
	*/
	#define GPIO_MODE_CTRL0_MC_07_RW (0x03 << 14)
	#define GPIO_MODE_CTRL0_MC_07_SHIFT 14
	#define GPIO_MODE_CTRL0_MC_07_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_07_VAL1 0x01
	/*
	* MC for GPIO number 06
	*/
	#define GPIO_MODE_CTRL0_MC_06_RW (0x03 << 12)
	#define GPIO_MODE_CTRL0_MC_06_SHIFT 12
	#define GPIO_MODE_CTRL0_MC_06_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_06_VAL1 0x01
	/*
	* MC for GPIO number 05
	*/
	#define GPIO_MODE_CTRL0_MC_05_RW (0x03 << 10)
	#define GPIO_MODE_CTRL0_MC_05_SHIFT 10
	#define GPIO_MODE_CTRL0_MC_05_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_05_VAL1 0x01
	/*
	* MC for GPIO number 04
	*/
	#define GPIO_MODE_CTRL0_MC_04_RW (0x03 << 8)
	#define GPIO_MODE_CTRL0_MC_04_SHIFT 8
	#define GPIO_MODE_CTRL0_MC_04_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_04_VAL1 0x01
	/*
	* MC for GPIO number 03
	*/
	#define GPIO_MODE_CTRL0_MC_03_RW (0x03 << 6)
	#define GPIO_MODE_CTRL0_MC_03_SHIFT 6
	#define GPIO_MODE_CTRL0_MC_03_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_03_VAL1 0x01
	/*
	* MC for GPIO number 02
	*/
	#define GPIO_MODE_CTRL0_MC_02_RW (0x03 << 4)
	#define GPIO_MODE_CTRL0_MC_02_SHIFT 4
	#define GPIO_MODE_CTRL0_MC_02_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_02_VAL1 0x01
	/*
	* MC for GPIO number 01
	*/
	#define GPIO_MODE_CTRL0_MC_01_RW (0x03 << 2)
	#define GPIO_MODE_CTRL0_MC_01_SHIFT 2
	#define GPIO_MODE_CTRL0_MC_01_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_01_VAL1 0x01
	/*
	* MC for GPIO number 00
	*/
	#define GPIO_MODE_CTRL0_MC_00_RW (0x03 << 0)
	#define GPIO_MODE_CTRL0_MC_00_SHIFT 0
	#define GPIO_MODE_CTRL0_MC_00_VAL0 0x00
	#define GPIO_MODE_CTRL0_MC_00_VAL1 0x01
	#define GPIO_MODE_CTRL0_MC_00_VAL2 0x02
	#define GPIO_MODE_CTRL0_MC_00_VAL3 0x03
	/*
	* The Mode Control (MC) bit pairs control the mode of the corresponding GPIO pin. 
	* The number portion of MCxx identifies the
	* GPIO number. The following values apply to writing to all of the bit pairs:
	* 00 - retain current GPIO Mode of operation (will not overwrite
	* current mode). Not readable
	* 01 - place Pin in primary function mode (see MUX table)
	* 10 - place Pin in GPIO function mode (see MUX table)
	* 11 - place Pin in GPIO function with Open-Drain Output mode
	*/
	#define GPIO_MODE_CTRL1_REG(n)  (GPIO_BASE_UNIT##n + 0x4)
	/*
	* MC for GPIO number 31
	*/
	#define GPIO_MODE_CTRL1_MC_31_RW (0x03 << 30)
	#define GPIO_MODE_CTRL1_MC_31_SHIFT 30
	#define GPIO_MODE_CTRL1_MC_31_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_31_VAL1 0x01
	/*
	* MC for GPIO number 30
	*/
	#define GPIO_MODE_CTRL1_MC_30_RW (0x03 << 28)
	#define GPIO_MODE_CTRL1_MC_30_SHIFT 28
	#define GPIO_MODE_CTRL1_MC_30_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_30_VAL1 0x01
	/*
	* MC for GPIO number 29
	*/
	#define GPIO_MODE_CTRL1_MC_29_RW (0x03 << 26)
	#define GPIO_MODE_CTRL1_MC_29_SHIFT 26
	#define GPIO_MODE_CTRL1_MC_29_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_29_VAL1 0x01
	/*
	* MC for GPIO number 28
	*/
	#define GPIO_MODE_CTRL1_MC_28_RW (0x03 << 24)
	#define GPIO_MODE_CTRL1_MC_28_SHIFT 24
	#define GPIO_MODE_CTRL1_MC_28_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_28_VAL1 0x01
	/*
	* MC for GPIO number 27
	*/
	#define GPIO_MODE_CTRL1_MC_27_RW (0x03 << 22)
	#define GPIO_MODE_CTRL1_MC_27_SHIFT 22
	#define GPIO_MODE_CTRL1_MC_27_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_27_VAL1 0x01
	/*
	* MC for GPIO number 26
	*/
	#define GPIO_MODE_CTRL1_MC_26_RW (0x03 << 20)
	#define GPIO_MODE_CTRL1_MC_26_SHIFT 20
	#define GPIO_MODE_CTRL1_MC_26_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_26_VAL1 0x01
	/*
	* MC for GPIO number 25
	*/
	#define GPIO_MODE_CTRL1_MC_25_RW (0x03 << 18)
	#define GPIO_MODE_CTRL1_MC_25_SHIFT 18
	#define GPIO_MODE_CTRL1_MC_25_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_25_VAL1 0x01
	/*
	* MC for GPIO number 24
	*/
	#define GPIO_MODE_CTRL1_MC_24_RW (0x03 << 16)
	#define GPIO_MODE_CTRL1_MC_24_SHIFT 16
	#define GPIO_MODE_CTRL1_MC_24_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_24_VAL1 0x01
	/*
	* MC for GPIO number 23
	*/
	#define GPIO_MODE_CTRL1_MC_23_RW (0x03 << 14)
	#define GPIO_MODE_CTRL1_MC_23_SHIFT 14
	#define GPIO_MODE_CTRL1_MC_23_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_23_VAL1 0x01
	/*
	* MC for GPIO number 22
	*/
	#define GPIO_MODE_CTRL1_MC_22_RW (0x03 << 12)
	#define GPIO_MODE_CTRL1_MC_22_SHIFT 12
	#define GPIO_MODE_CTRL1_MC_22_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_22_VAL1 0x01
	/*
	* MC for GPIO number 21
	*/
	#define GPIO_MODE_CTRL1_MC_21_RW (0x03 << 10)
	#define GPIO_MODE_CTRL1_MC_21_SHIFT 10
	#define GPIO_MODE_CTRL1_MC_21_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_21_VAL1 0x01
	/*
	* MC for GPIO number 20
	*/
	#define GPIO_MODE_CTRL1_MC_20_RW (0x03 << 8)
	#define GPIO_MODE_CTRL1_MC_20_SHIFT 8
	#define GPIO_MODE_CTRL1_MC_20_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_20_VAL1 0x01
	/*
	* MC for GPIO number 19
	*/
	#define GPIO_MODE_CTRL1_MC_19_RW (0x03 << 6)
	#define GPIO_MODE_CTRL1_MC_19_SHIFT 6
	#define GPIO_MODE_CTRL1_MC_19_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_19_VAL1 0x01
	/*
	* MC for GPIO number 18
	*/
	#define GPIO_MODE_CTRL1_MC_18_RW (0x03 << 4)
	#define GPIO_MODE_CTRL1_MC_18_SHIFT 4
	#define GPIO_MODE_CTRL1_MC_18_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_18_VAL1 0x01
	/*
	* MC for GPIO number 17
	*/
	#define GPIO_MODE_CTRL1_MC_17_RW (0x03 << 2)
	#define GPIO_MODE_CTRL1_MC_17_SHIFT 2
	#define GPIO_MODE_CTRL1_MC_17_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_17_VAL1 0x01
	/*
	* MC for GPIO number 16
	*/
	#define GPIO_MODE_CTRL1_MC_16_RW (0x03 << 0)
	#define GPIO_MODE_CTRL1_MC_16_SHIFT 0
	#define GPIO_MODE_CTRL1_MC_16_VAL0 0x00
	#define GPIO_MODE_CTRL1_MC_16_VAL1 0x01
	#define GPIO_MODE_CTRL1_MC_16_VAL2 0x02
	#define GPIO_MODE_CTRL1_MC_16_VAL3 0x03
	/*
	* The Mode Control (MC) bit pairs control the mode of the corresponding GPIO pin. 
	* The number portion of MCxx identifies the
	* GPIO number. The following values apply to writing to all of the bit pairs:
	* 00 - retain current GPIO Mode of operation (will not overwrite
	* current mode). Not readable
	* 01 - place Pin in primary function mode (see MUX table)
	* 10 - place Pin in GPIO function mode (see MUX table)
	* 11 - place Pin in GPIO function with Open-Drain Output mode
	*/
	#define GPIO_MODE_CTRL2_REG(n)  (GPIO_BASE_UNIT##n + 0x8)
	/*
	* MC for GPIO number 47
	*/
	#define GPIO_MODE_CTRL2_MC_47_RW (0x03 << 30)
	#define GPIO_MODE_CTRL2_MC_47_SHIFT 30
	#define GPIO_MODE_CTRL2_MC_47_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_47_VAL1 0x01
	/*
	* MC for GPIO number 46
	*/
	#define GPIO_MODE_CTRL2_MC_46_RW (0x03 << 28)
	#define GPIO_MODE_CTRL2_MC_46_SHIFT 28
	#define GPIO_MODE_CTRL2_MC_46_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_46_VAL1 0x01
	/*
	* MC for GPIO number 45
	*/
	#define GPIO_MODE_CTRL2_MC_45_RW (0x03 << 26)
	#define GPIO_MODE_CTRL2_MC_45_SHIFT 26
	#define GPIO_MODE_CTRL2_MC_45_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_45_VAL1 0x01
	/*
	* MC for GPIO number 44
	*/
	#define GPIO_MODE_CTRL2_MC_44_RW (0x03 << 24)
	#define GPIO_MODE_CTRL2_MC_44_SHIFT 24
	#define GPIO_MODE_CTRL2_MC_44_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_44_VAL1 0x01
	/*
	* MC for GPIO number 43
	*/
	#define GPIO_MODE_CTRL2_MC_43_RW (0x03 << 22)
	#define GPIO_MODE_CTRL2_MC_43_SHIFT 22
	#define GPIO_MODE_CTRL2_MC_43_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_43_VAL1 0x01
	/*
	* MC for GPIO number 42
	*/
	#define GPIO_MODE_CTRL2_MC_42_RW (0x03 << 20)
	#define GPIO_MODE_CTRL2_MC_42_SHIFT 20
	#define GPIO_MODE_CTRL2_MC_42_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_42_VAL1 0x01
	/*
	* MC for GPIO number 41
	*/
	#define GPIO_MODE_CTRL2_MC_41_RW (0x03 << 18)
	#define GPIO_MODE_CTRL2_MC_41_SHIFT 18
	#define GPIO_MODE_CTRL2_MC_41_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_41_VAL1 0x01
	/*
	* MC for GPIO number 40
	*/
	#define GPIO_MODE_CTRL2_MC_40_RW (0x03 << 16)
	#define GPIO_MODE_CTRL2_MC_40_SHIFT 16
	#define GPIO_MODE_CTRL2_MC_40_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_40_VAL1 0x01
	/*
	* MC for GPIO number 39
	*/
	#define GPIO_MODE_CTRL2_MC_39_RW (0x03 << 14)
	#define GPIO_MODE_CTRL2_MC_39_SHIFT 14
	#define GPIO_MODE_CTRL2_MC_39_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_39_VAL1 0x01
	/*
	* MC for GPIO number 38
	*/
	#define GPIO_MODE_CTRL2_MC_38_RW (0x03 << 12)
	#define GPIO_MODE_CTRL2_MC_38_SHIFT 12
	#define GPIO_MODE_CTRL2_MC_38_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_38_VAL1 0x01
	/*
	* MC for GPIO number 37
	*/
	#define GPIO_MODE_CTRL2_MC_37_RW (0x03 << 10)
	#define GPIO_MODE_CTRL2_MC_37_SHIFT 10
	#define GPIO_MODE_CTRL2_MC_37_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_37_VAL1 0x01
	/*
	* MC for GPIO number 36
	*/
	#define GPIO_MODE_CTRL2_MC_36_RW (0x03 << 8)
	#define GPIO_MODE_CTRL2_MC_36_SHIFT 8
	#define GPIO_MODE_CTRL2_MC_36_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_36_VAL1 0x01
	/*
	* MC for GPIO number 35
	*/
	#define GPIO_MODE_CTRL2_MC_35_RW (0x03 << 6)
	#define GPIO_MODE_CTRL2_MC_35_SHIFT 6
	#define GPIO_MODE_CTRL2_MC_35_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_35_VAL1 0x01
	/*
	* MC for GPIO number 34
	*/
	#define GPIO_MODE_CTRL2_MC_34_RW (0x03 << 4)
	#define GPIO_MODE_CTRL2_MC_34_SHIFT 4
	#define GPIO_MODE_CTRL2_MC_34_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_34_VAL1 0x01
	/*
	* MC for GPIO number 33
	*/
	#define GPIO_MODE_CTRL2_MC_33_RW (0x03 << 2)
	#define GPIO_MODE_CTRL2_MC_33_SHIFT 2
	#define GPIO_MODE_CTRL2_MC_33_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_33_VAL1 0x01
	/*
	* MC for GPIO number 32
	*/
	#define GPIO_MODE_CTRL2_MC_32_RW (0x03 << 0)
	#define GPIO_MODE_CTRL2_MC_32_SHIFT 0
	#define GPIO_MODE_CTRL2_MC_32_VAL0 0x00
	#define GPIO_MODE_CTRL2_MC_32_VAL1 0x01
	#define GPIO_MODE_CTRL2_MC_32_VAL2 0x02
	#define GPIO_MODE_CTRL2_MC_32_VAL3 0x03
	/*
	* The Mode Control (MC) bit pairs control the mode of the corresponding GPIO pin. 
	* The number portion of MCxx identifies the
	* GPIO number. The following values apply to writing to all of the bit pairs:
	* 00 - retain current GPIO Mode of operation (will not overwrite
	* current mode). Not readable
	* 01 - place Pin in primary function mode (see MUX table)
	* 10 - place Pin in GPIO function mode (see MUX table)
	* 11 - place Pin in GPIO function with Open-Drain Output mode
	*/
	#define GPIO_MODE_CTRL3_REG(n)  (GPIO_BASE_UNIT##n + 0xc)
	/*
	* MC for GPIO number 63
	*/
	#define GPIO_MODE_CTRL3_MC_63_RW (0x03 << 30)
	#define GPIO_MODE_CTRL3_MC_63_SHIFT 30
	#define GPIO_MODE_CTRL3_MC_63_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_63_VAL1 0x01
	/*
	* MC for GPIO number 62
	*/
	#define GPIO_MODE_CTRL3_MC_62_RW (0x03 << 28)
	#define GPIO_MODE_CTRL3_MC_62_SHIFT 28
	#define GPIO_MODE_CTRL3_MC_62_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_62_VAL1 0x01
	/*
	* MC for GPIO number 61
	*/
	#define GPIO_MODE_CTRL3_MC_61_RW (0x03 << 26)
	#define GPIO_MODE_CTRL3_MC_61_SHIFT 26
	#define GPIO_MODE_CTRL3_MC_61_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_61_VAL1 0x01
	/*
	* MC for GPIO number 60
	*/
	#define GPIO_MODE_CTRL3_MC_60_RW (0x03 << 24)
	#define GPIO_MODE_CTRL3_MC_60_SHIFT 24
	#define GPIO_MODE_CTRL3_MC_60_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_60_VAL1 0x01
	/*
	* MC for GPIO number 59
	*/
	#define GPIO_MODE_CTRL3_MC_59_RW (0x03 << 22)
	#define GPIO_MODE_CTRL3_MC_59_SHIFT 22
	#define GPIO_MODE_CTRL3_MC_59_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_59_VAL1 0x01
	/*
	* MC for GPIO number 58
	*/
	#define GPIO_MODE_CTRL3_MC_58_RW (0x03 << 20)
	#define GPIO_MODE_CTRL3_MC_58_SHIFT 20
	#define GPIO_MODE_CTRL3_MC_58_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_58_VAL1 0x01
	/*
	* MC for GPIO number 57
	*/
	#define GPIO_MODE_CTRL3_MC_57_RW (0x03 << 18)
	#define GPIO_MODE_CTRL3_MC_57_SHIFT 18
	#define GPIO_MODE_CTRL3_MC_57_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_57_VAL1 0x01
	/*
	* MC for GPIO number 56
	*/
	#define GPIO_MODE_CTRL3_MC_56_RW (0x03 << 16)
	#define GPIO_MODE_CTRL3_MC_56_SHIFT 16
	#define GPIO_MODE_CTRL3_MC_56_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_56_VAL1 0x01
	/*
	* MC for GPIO number 55
	*/
	#define GPIO_MODE_CTRL3_MC_55_RW (0x03 << 14)
	#define GPIO_MODE_CTRL3_MC_55_SHIFT 14
	#define GPIO_MODE_CTRL3_MC_55_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_55_VAL1 0x01
	/*
	* MC for GPIO number 54
	*/
	#define GPIO_MODE_CTRL3_MC_54_RW (0x03 << 12)
	#define GPIO_MODE_CTRL3_MC_54_SHIFT 12
	#define GPIO_MODE_CTRL3_MC_54_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_54_VAL1 0x01
	/*
	* MC for GPIO number 53
	*/
	#define GPIO_MODE_CTRL3_MC_53_RW (0x03 << 10)
	#define GPIO_MODE_CTRL3_MC_53_SHIFT 10
	#define GPIO_MODE_CTRL3_MC_53_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_53_VAL1 0x01
	/*
	* MC for GPIO number 52
	*/
	#define GPIO_MODE_CTRL3_MC_52_RW (0x03 << 8)
	#define GPIO_MODE_CTRL3_MC_52_SHIFT 8
	#define GPIO_MODE_CTRL3_MC_52_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_52_VAL1 0x01
	/*
	* MC for GPIO number 51
	*/
	#define GPIO_MODE_CTRL3_MC_51_RW (0x03 << 6)
	#define GPIO_MODE_CTRL3_MC_51_SHIFT 6
	#define GPIO_MODE_CTRL3_MC_51_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_51_VAL1 0x01
	/*
	* MC for GPIO number 50
	*/
	#define GPIO_MODE_CTRL3_MC_50_RW (0x03 << 4)
	#define GPIO_MODE_CTRL3_MC_50_SHIFT 4
	#define GPIO_MODE_CTRL3_MC_50_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_50_VAL1 0x01
	/*
	* MC for GPIO number 49
	*/
	#define GPIO_MODE_CTRL3_MC_49_RW (0x03 << 2)
	#define GPIO_MODE_CTRL3_MC_49_SHIFT 2
	#define GPIO_MODE_CTRL3_MC_49_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_49_VAL1 0x01
	/*
	* MC for GPIO number 48
	*/
	#define GPIO_MODE_CTRL3_MC_48_RW (0x03 << 0)
	#define GPIO_MODE_CTRL3_MC_48_SHIFT 0
	#define GPIO_MODE_CTRL3_MC_48_VAL0 0x00
	#define GPIO_MODE_CTRL3_MC_48_VAL1 0x01
	#define GPIO_MODE_CTRL3_MC_48_VAL2 0x02
	#define GPIO_MODE_CTRL3_MC_48_VAL3 0x03
	/*
	* The Mode Control (MC) bit pairs control the mode of the corresponding GPIO pin. 
	* The number portion of MCxx identifies the
	* GPIO number. The following values apply to writing to all of the bit pairs:
	* 00 - retain current GPIO Mode of operation (will not overwrite
	* current mode). Not readable
	* 01 - place Pin in primary function mode (see MUX table)
	* 10 - place Pin in GPIO function mode (see MUX table)
	* 11 - place Pin in GPIO function with Open-Drain Output mode
	*/
	#define GPIO_MODE_CTRL4_REG(n)  (GPIO_BASE_UNIT##n + 0x10)
	/*
	* MC for GPIO number 74
	*/
	#define GPIO_MODE_CTRL4_MC_74_RW (0x03 << 20)
	#define GPIO_MODE_CTRL4_MC_74_SHIFT 20
	#define GPIO_MODE_CTRL4_MC_74_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_74_VAL1 0x01
	/*
	* MC for GPIO number 73
	*/
	#define GPIO_MODE_CTRL4_MC_73_RW (0x03 << 18)
	#define GPIO_MODE_CTRL4_MC_73_SHIFT 18
	#define GPIO_MODE_CTRL4_MC_73_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_73_VAL1 0x01
	/*
	* MC for GPIO number 72
	*/
	#define GPIO_MODE_CTRL4_MC_72_RW (0x03 << 16)
	#define GPIO_MODE_CTRL4_MC_72_SHIFT 16
	#define GPIO_MODE_CTRL4_MC_72_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_72_VAL1 0x01
	/*
	* MC for GPIO number 71
	*/
	#define GPIO_MODE_CTRL4_MC_71_RW (0x03 << 14)
	#define GPIO_MODE_CTRL4_MC_71_SHIFT 14
	#define GPIO_MODE_CTRL4_MC_71_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_71_VAL1 0x01
	/*
	* MC for GPIO number 70
	*/
	#define GPIO_MODE_CTRL4_MC_70_RW (0x03 << 12)
	#define GPIO_MODE_CTRL4_MC_70_SHIFT 12
	#define GPIO_MODE_CTRL4_MC_70_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_70_VAL1 0x01
	/*
	* MC for GPIO number 69
	*/
	#define GPIO_MODE_CTRL4_MC_69_RW (0x03 << 10)
	#define GPIO_MODE_CTRL4_MC_69_SHIFT 10
	#define GPIO_MODE_CTRL4_MC_69_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_69_VAL1 0x01
	/*
	* MC for GPIO number 68
	*/
	#define GPIO_MODE_CTRL4_MC_68_RW (0x03 << 8)
	#define GPIO_MODE_CTRL4_MC_68_SHIFT 8
	#define GPIO_MODE_CTRL4_MC_68_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_68_VAL1 0x01
	/*
	* MC for GPIO number 67
	*/
	#define GPIO_MODE_CTRL4_MC_67_RW (0x03 << 6)
	#define GPIO_MODE_CTRL4_MC_67_SHIFT 6
	#define GPIO_MODE_CTRL4_MC_67_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_67_VAL1 0x01
	/*
	* MC for GPIO number 66
	*/
	#define GPIO_MODE_CTRL4_MC_66_RW (0x03 << 4)
	#define GPIO_MODE_CTRL4_MC_66_SHIFT 4
	#define GPIO_MODE_CTRL4_MC_66_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_66_VAL1 0x01
	/*
	* MC for GPIO number 65
	*/
	#define GPIO_MODE_CTRL4_MC_65_RW (0x03 << 2)
	#define GPIO_MODE_CTRL4_MC_65_SHIFT 2
	#define GPIO_MODE_CTRL4_MC_65_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_65_VAL1 0x01
	/*
	* MC for GPIO number 64
	*/
	#define GPIO_MODE_CTRL4_MC_64_RW (0x03 << 0)
	#define GPIO_MODE_CTRL4_MC_64_SHIFT 0
	#define GPIO_MODE_CTRL4_MC_64_VAL0 0x00
	#define GPIO_MODE_CTRL4_MC_64_VAL1 0x01
	#define GPIO_MODE_CTRL4_MC_64_VAL2 0x02
	#define GPIO_MODE_CTRL4_MC_64_VAL3 0x03
	/*
	* Mask and I/0 Registers 00 - Retain current setting (will not overwrite current d
	* ata). Not Readable.
	* 01 - Set the corresponding GPIO Pin in tri-state mode, allowing the Pin to be us
	* ed as Data Input
	* 10 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘0’ in thi
	* s case) onto the corresponding GPIO Pin.
	* 11 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘1’ in thi
	* s case) onto the corresponding GPIO Pin. Note: if open-drain mode is selected, d
	* rive to ‘1’ is disabled.
	*/
	#define GPIO_DATA_REG0_REG(n)  (GPIO_BASE_UNIT##n + 0x38)
	#define GPIO_DATA_MASK_15_0_RW (0x0ffff << 16)
	#define GPIO_DATA_MASK_15_0_SHIFT 16
	#define GPIO_DATA_IOD_15_0_RW (0x0ffff << 0)
	#define GPIO_DATA_IOD_15_0_SHIFT 0
	/*
	* Mask and I/0 Registers 00 - Retain current setting (will not overwrite current d
	* ata). Not Readable.
	* 01 - Set the corresponding GPIO Pin in tri-state mode, allowing the Pin to be us
	* ed as Data Input
	* 10 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘0’ in thi
	* s case) onto the corresponding GPIO Pin.
	* 11 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘1’ in thi
	* s case) onto the corresponding GPIO Pin. Note: if open-drain mode is selected, d
	* rive to ‘1’ is disabled.
	*/
	#define GPIO_DATA_REG1_REG(n)  (GPIO_BASE_UNIT##n + 0x3c)
	#define GPIO_DATA_MASK_31_16_RW (0x0ffff << 16)
	#define GPIO_DATA_MASK_31_16_SHIFT 16
	#define GPIO_DATA_IOD_31_16_RW (0x0ffff << 0)
	#define GPIO_DATA_IOD_31_16_SHIFT 0
	/*
	* Mask and I/0 Registers 00 - Retain current setting (will not overwrite current d
	* ata). Not Readable.
	* 01 - Set the corresponding GPIO Pin in tri-state mode, allowing the Pin to be us
	* ed as Data Input
	* 10 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘0’ in thi
	* s case) onto the corresponding GPIO Pin.
	* 11 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘1’ in thi
	* s case) onto the corresponding GPIO Pin. Note: if open-drain mode is selected, d
	* rive to ‘1’ is disabled.
	*/
	#define GPIO_DATA_REG2_REG(n)  (GPIO_BASE_UNIT##n + 0x40)
	#define GPIO_DATA_MASK_47_32_RW (0x0ffff << 16)
	#define GPIO_DATA_MASK_47_32_SHIFT 16
	#define GPIO_DATA_IOD_47_32_RW (0x0ffff << 0)
	#define GPIO_DATA_IOD_47_32_SHIFT 0
	/*
	* Mask and I/0 Registers 00 - Retain current setting (will not overwrite current d
	* ata). Not Readable.
	* 01 - Set the corresponding GPIO Pin in tri-state mode, allowing the Pin to be us
	* ed as Data Input
	* 10 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘0’ in thi
	* s case) onto the corresponding GPIO Pin.
	* 11 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘1’ in thi
	* s case) onto the corresponding GPIO Pin. Note: if open-drain mode is selected, d
	* rive to ‘1’ is disabled.
	*/
	#define GPIO_DATA_REG3_REG(n)  (GPIO_BASE_UNIT##n + 0x44)
	#define GPIO_DATA_MASK_63_48_RW (0x0ffff << 16)
	#define GPIO_DATA_MASK_63_48_SHIFT 16
	#define GPIO_DATA_IOD_63_48_RW (0x0ffff << 0)
	#define GPIO_DATA_IOD_63_48_SHIFT 0
	/*
	* Mask and I/0 Registers 00 - Retain current setting (will not overwrite current d
	* ata). Not Readable.
	* 01 - Set the corresponding GPIO Pin in tri-state mode, allowing the Pin to be us
	* ed as Data Input
	* 10 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘0’ in thi
	* s case) onto the corresponding GPIO Pin.
	* 11 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘1’ in thi
	* s case) onto the corresponding GPIO Pin. Note: if open-drain mode is selected, d
	* rive to ‘1’ is disabled.
	*/
	#define GPIO_DATA_REG4_REG(n)  (GPIO_BASE_UNIT##n + 0x48)
	/*
	* Mask and I/0 Registers 00 - Retain current setting (will not overwrite current d
	* ata). Not Readable.
	* 01 - Set the corresponding GPIO Pin in tri-state mode, allowing the Pin to be us
	* ed as Data Input
	* 10 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘0’ in thi
	* s case) onto the corresponding GPIO Pin.
	* 11 - GPIO output mode. Drive a generated pattern (if enabled) OR IOD (‘1’ in thi
	* s case) onto the corresponding GPIO Pin. Note: if open-drain mode is selected, d
	* rive to ‘1’ is disabled.
	*/
	#define GPIO_DATA_MASK_74_64_RW (0x0ffff << 16)
	#define GPIO_DATA_MASK_74_64_SHIFT 16
	/*
	* Reserved
	*/
	#define GPIO_DATA_RESERVED_RES (0x01f << 11)
	#define GPIO_DATA_RESERVED_SHIFT 11
	#define GPIO_DATA_RESERVED_VAL0 0x00
	#define GPIO_DATA_RESERVED_VAL1 0x01
	#define GPIO_DATA_RESERVED_VAL2 0x02
	#define GPIO_DATA_RESERVED_VAL3 0x03
	#define GPIO_DATA_RESERVED_VAL4 0x04
	#define GPIO_DATA_RESERVED_VAL5 0x05
	#define GPIO_DATA_RESERVED_VAL6 0x06
	#define GPIO_DATA_RESERVED_VAL7 0x07
	#define GPIO_DATA_RESERVED_VAL8 0x08
	#define GPIO_DATA_RESERVED_VAL9 0x09
	#define GPIO_DATA_RESERVED_VAL10 0x0a
	#define GPIO_DATA_RESERVED_VAL11 0x0b
	#define GPIO_DATA_RESERVED_VAL12 0x0c
	#define GPIO_DATA_RESERVED_VAL13 0x0d
	#define GPIO_DATA_RESERVED_VAL14 0x0e
	#define GPIO_DATA_RESERVED_VAL15 0x0f
	#define GPIO_DATA_IOD_74_64_RW (0x07ff << 0)
	#define GPIO_DATA_IOD_74_64_SHIFT 0
	/*
	* Control bits to detect rising/falling edge of GPIO pins
	*/
	#define GPIO_CTRL_REG0_REG(n)  (GPIO_BASE_UNIT##n + 0x70)
	/*
	* Detect gpio pin 15 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_31_RW (0x01 << 31)
	#define GPIO_CTRL_GPIO_CTRL_31_SHIFT 31
	#define GPIO_CTRL_GPIO_CTRL_31_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_31_VAL1 0x01
	/*
	* Detect gpio pin 15 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_30_RW (0x01 << 30)
	#define GPIO_CTRL_GPIO_CTRL_30_SHIFT 30
	#define GPIO_CTRL_GPIO_CTRL_30_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_30_VAL1 0x01
	/*
	* Detect gpio pin 14 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_29_RW (0x01 << 29)
	#define GPIO_CTRL_GPIO_CTRL_29_SHIFT 29
	#define GPIO_CTRL_GPIO_CTRL_29_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_29_VAL1 0x01
	/*
	* Detect gpio pin 14 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_28_RW (0x01 << 28)
	#define GPIO_CTRL_GPIO_CTRL_28_SHIFT 28
	#define GPIO_CTRL_GPIO_CTRL_28_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_28_VAL1 0x01
	/*
	* Detect gpio pin 13 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_27_RW (0x01 << 27)
	#define GPIO_CTRL_GPIO_CTRL_27_SHIFT 27
	#define GPIO_CTRL_GPIO_CTRL_27_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_27_VAL1 0x01
	/*
	* Detect gpio pin 13 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_26_RW (0x01 << 26)
	#define GPIO_CTRL_GPIO_CTRL_26_SHIFT 26
	#define GPIO_CTRL_GPIO_CTRL_26_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_26_VAL1 0x01
	/*
	* Detect gpio pin 12 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_25_RW (0x01 << 25)
	#define GPIO_CTRL_GPIO_CTRL_25_SHIFT 25
	#define GPIO_CTRL_GPIO_CTRL_25_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_25_VAL1 0x01
	/*
	* Detect gpio pin 12 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_24_RW (0x01 << 24)
	#define GPIO_CTRL_GPIO_CTRL_24_SHIFT 24
	#define GPIO_CTRL_GPIO_CTRL_24_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_24_VAL1 0x01
	/*
	* Detect gpio pin 11 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_23_RW (0x01 << 23)
	#define GPIO_CTRL_GPIO_CTRL_23_SHIFT 23
	#define GPIO_CTRL_GPIO_CTRL_23_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_23_VAL1 0x01
	/*
	* Detect gpio pin 11 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_22_RW (0x01 << 22)
	#define GPIO_CTRL_GPIO_CTRL_22_SHIFT 22
	#define GPIO_CTRL_GPIO_CTRL_22_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_22_VAL1 0x01
	/*
	* Detect gpio pin 10 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_21_RW (0x01 << 21)
	#define GPIO_CTRL_GPIO_CTRL_21_SHIFT 21
	#define GPIO_CTRL_GPIO_CTRL_21_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_21_VAL1 0x01
	/*
	* Detect gpio pin 10 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_20_RW (0x01 << 20)
	#define GPIO_CTRL_GPIO_CTRL_20_SHIFT 20
	#define GPIO_CTRL_GPIO_CTRL_20_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_20_VAL1 0x01
	/*
	* Detect gpio pin 9 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_19_RW (0x01 << 19)
	#define GPIO_CTRL_GPIO_CTRL_19_SHIFT 19
	#define GPIO_CTRL_GPIO_CTRL_19_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_19_VAL1 0x01
	/*
	* Detect gpio pin 9 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_18_RW (0x01 << 18)
	#define GPIO_CTRL_GPIO_CTRL_18_SHIFT 18
	#define GPIO_CTRL_GPIO_CTRL_18_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_18_VAL1 0x01
	/*
	* Detect gpio pin 8 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_17_RW (0x01 << 17)
	#define GPIO_CTRL_GPIO_CTRL_17_SHIFT 17
	#define GPIO_CTRL_GPIO_CTRL_17_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_17_VAL1 0x01
	/*
	* Detect gpio pin 8 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_16_RW (0x01 << 16)
	#define GPIO_CTRL_GPIO_CTRL_16_SHIFT 16
	#define GPIO_CTRL_GPIO_CTRL_16_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_16_VAL1 0x01
	/*
	* Detect gpio pin 7 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_15_RW (0x01 << 15)
	#define GPIO_CTRL_GPIO_CTRL_15_SHIFT 15
	#define GPIO_CTRL_GPIO_CTRL_15_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_15_VAL1 0x01
	/*
	* Detect gpio pin 7 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_14_RW (0x01 << 14)
	#define GPIO_CTRL_GPIO_CTRL_14_SHIFT 14
	#define GPIO_CTRL_GPIO_CTRL_14_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_14_VAL1 0x01
	/*
	* Detect gpio pin 6 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_13_RW (0x01 << 13)
	#define GPIO_CTRL_GPIO_CTRL_13_SHIFT 13
	#define GPIO_CTRL_GPIO_CTRL_13_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_13_VAL1 0x01
	/*
	* Detect gpio pin 6 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_12_RW (0x01 << 12)
	#define GPIO_CTRL_GPIO_CTRL_12_SHIFT 12
	#define GPIO_CTRL_GPIO_CTRL_12_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_12_VAL1 0x01
	/*
	* Detect gpio pin 5 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_11_RW (0x01 << 11)
	#define GPIO_CTRL_GPIO_CTRL_11_SHIFT 11
	#define GPIO_CTRL_GPIO_CTRL_11_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_11_VAL1 0x01
	/*
	* Detect gpio pin 5 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_10_RW (0x01 << 10)
	#define GPIO_CTRL_GPIO_CTRL_10_SHIFT 10
	#define GPIO_CTRL_GPIO_CTRL_10_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_10_VAL1 0x01
	/*
	* Detect gpio pin 4 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_09_RW (0x01 << 9)
	#define GPIO_CTRL_GPIO_CTRL_09_SHIFT 9
	#define GPIO_CTRL_GPIO_CTRL_09_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_09_VAL1 0x01
	/*
	* Detect gpio pin 4 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_08_RW (0x01 << 8)
	#define GPIO_CTRL_GPIO_CTRL_08_SHIFT 8
	#define GPIO_CTRL_GPIO_CTRL_08_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_08_VAL1 0x01
	/*
	* Detect gpio pin 3 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_07_RW (0x01 << 7)
	#define GPIO_CTRL_GPIO_CTRL_07_SHIFT 7
	#define GPIO_CTRL_GPIO_CTRL_07_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_07_VAL1 0x01
	/*
	* Detect gpio pin 3 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_06_RW (0x01 << 6)
	#define GPIO_CTRL_GPIO_CTRL_06_SHIFT 6
	#define GPIO_CTRL_GPIO_CTRL_06_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_06_VAL1 0x01
	/*
	* Detect gpio pin 2 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_05_RW (0x01 << 5)
	#define GPIO_CTRL_GPIO_CTRL_05_SHIFT 5
	#define GPIO_CTRL_GPIO_CTRL_05_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_05_VAL1 0x01
	/*
	* Detect gpio pin 2 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_04_RW (0x01 << 4)
	#define GPIO_CTRL_GPIO_CTRL_04_SHIFT 4
	#define GPIO_CTRL_GPIO_CTRL_04_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_04_VAL1 0x01
	/*
	* Detect gpio pin 1 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_03_RW (0x01 << 3)
	#define GPIO_CTRL_GPIO_CTRL_03_SHIFT 3
	#define GPIO_CTRL_GPIO_CTRL_03_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_03_VAL1 0x01
	/*
	* Detect gpio pin 1 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_02_RW (0x01 << 2)
	#define GPIO_CTRL_GPIO_CTRL_02_SHIFT 2
	#define GPIO_CTRL_GPIO_CTRL_02_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_02_VAL1 0x01
	/*
	* Detect gpio pin 0 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_01_RW (0x01 << 1)
	#define GPIO_CTRL_GPIO_CTRL_01_SHIFT 1
	#define GPIO_CTRL_GPIO_CTRL_01_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_01_VAL1 0x01
	/*
	* Detect gpio pin 0 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_00_RW (0x01 << 0)
	#define GPIO_CTRL_GPIO_CTRL_00_SHIFT 0
	#define GPIO_CTRL_GPIO_CTRL_00_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_00_VAL1 0x01
	/*
	* Control bits to detect rising/falling edge of GPIO pins
	*/
	#define GPIO_CTRL_REG1_REG(n)  (GPIO_BASE_UNIT##n + 0x74)
	/*
	* Detect gpio pin 31 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_63_RW (0x01 << 31)
	#define GPIO_CTRL_GPIO_CTRL_63_SHIFT 31
	#define GPIO_CTRL_GPIO_CTRL_63_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_63_VAL1 0x01
	/*
	* Detect gpio pin 31 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_62_RW (0x01 << 30)
	#define GPIO_CTRL_GPIO_CTRL_62_SHIFT 30
	#define GPIO_CTRL_GPIO_CTRL_62_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_62_VAL1 0x01
	/*
	* Detect gpio pin 30 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_61_RW (0x01 << 29)
	#define GPIO_CTRL_GPIO_CTRL_61_SHIFT 29
	#define GPIO_CTRL_GPIO_CTRL_61_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_61_VAL1 0x01
	/*
	* Detect gpio pin 30 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_60_RW (0x01 << 28)
	#define GPIO_CTRL_GPIO_CTRL_60_SHIFT 28
	#define GPIO_CTRL_GPIO_CTRL_60_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_60_VAL1 0x01
	/*
	* Detect gpio pin 29 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_59_RW (0x01 << 27)
	#define GPIO_CTRL_GPIO_CTRL_59_SHIFT 27
	#define GPIO_CTRL_GPIO_CTRL_59_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_59_VAL1 0x01
	/*
	* Detect gpio pin 29 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_58_RW (0x01 << 26)
	#define GPIO_CTRL_GPIO_CTRL_58_SHIFT 26
	#define GPIO_CTRL_GPIO_CTRL_58_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_58_VAL1 0x01
	/*
	* Detect gpio pin 28 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_57_RW (0x01 << 25)
	#define GPIO_CTRL_GPIO_CTRL_57_SHIFT 25
	#define GPIO_CTRL_GPIO_CTRL_57_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_57_VAL1 0x01
	/*
	* Detect gpio pin 28 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_56_RW (0x01 << 24)
	#define GPIO_CTRL_GPIO_CTRL_56_SHIFT 24
	#define GPIO_CTRL_GPIO_CTRL_56_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_56_VAL1 0x01
	/*
	* Detect gpio pin 27 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_55_RW (0x01 << 23)
	#define GPIO_CTRL_GPIO_CTRL_55_SHIFT 23
	#define GPIO_CTRL_GPIO_CTRL_55_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_55_VAL1 0x01
	/*
	* Detect gpio pin 27 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_54_RW (0x01 << 22)
	#define GPIO_CTRL_GPIO_CTRL_54_SHIFT 22
	#define GPIO_CTRL_GPIO_CTRL_54_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_54_VAL1 0x01
	/*
	* Detect gpio pin 26 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_53_RW (0x01 << 21)
	#define GPIO_CTRL_GPIO_CTRL_53_SHIFT 21
	#define GPIO_CTRL_GPIO_CTRL_53_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_53_VAL1 0x01
	/*
	* Detect gpio pin 26 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_52_RW (0x01 << 20)
	#define GPIO_CTRL_GPIO_CTRL_52_SHIFT 20
	#define GPIO_CTRL_GPIO_CTRL_52_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_52_VAL1 0x01
	/*
	* Detect gpio pin 25 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_51_RW (0x01 << 19)
	#define GPIO_CTRL_GPIO_CTRL_51_SHIFT 19
	#define GPIO_CTRL_GPIO_CTRL_51_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_51_VAL1 0x01
	/*
	* Detect gpio pin 25 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_50_RW (0x01 << 18)
	#define GPIO_CTRL_GPIO_CTRL_50_SHIFT 18
	#define GPIO_CTRL_GPIO_CTRL_50_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_50_VAL1 0x01
	/*
	* Detect gpio pin 24 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_49_RW (0x01 << 17)
	#define GPIO_CTRL_GPIO_CTRL_49_SHIFT 17
	#define GPIO_CTRL_GPIO_CTRL_49_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_49_VAL1 0x01
	/*
	* Detect gpio pin 24 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_48_RW (0x01 << 16)
	#define GPIO_CTRL_GPIO_CTRL_48_SHIFT 16
	#define GPIO_CTRL_GPIO_CTRL_48_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_48_VAL1 0x01
	/*
	* Detect gpio pin 23 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_47_RW (0x01 << 15)
	#define GPIO_CTRL_GPIO_CTRL_47_SHIFT 15
	#define GPIO_CTRL_GPIO_CTRL_47_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_47_VAL1 0x01
	/*
	* Detect gpio pin 23 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_46_RW (0x01 << 14)
	#define GPIO_CTRL_GPIO_CTRL_46_SHIFT 14
	#define GPIO_CTRL_GPIO_CTRL_46_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_46_VAL1 0x01
	/*
	* Detect gpio pin 22 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_45_RW (0x01 << 13)
	#define GPIO_CTRL_GPIO_CTRL_45_SHIFT 13
	#define GPIO_CTRL_GPIO_CTRL_45_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_45_VAL1 0x01
	/*
	* Detect gpio pin 22 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_44_RW (0x01 << 12)
	#define GPIO_CTRL_GPIO_CTRL_44_SHIFT 12
	#define GPIO_CTRL_GPIO_CTRL_44_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_44_VAL1 0x01
	/*
	* Detect gpio pin 21Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_43_RW (0x01 << 11)
	#define GPIO_CTRL_GPIO_CTRL_43_SHIFT 11
	#define GPIO_CTRL_GPIO_CTRL_43_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_43_VAL1 0x01
	/*
	* Detect gpio pin 21 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_42_RW (0x01 << 10)
	#define GPIO_CTRL_GPIO_CTRL_42_SHIFT 10
	#define GPIO_CTRL_GPIO_CTRL_42_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_42_VAL1 0x01
	/*
	* Detect gpio pin 20 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_41_RW (0x01 << 9)
	#define GPIO_CTRL_GPIO_CTRL_41_SHIFT 9
	#define GPIO_CTRL_GPIO_CTRL_41_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_41_VAL1 0x01
	/*
	* Detect gpio pin 20 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_40_RW (0x01 << 8)
	#define GPIO_CTRL_GPIO_CTRL_40_SHIFT 8
	#define GPIO_CTRL_GPIO_CTRL_40_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_40_VAL1 0x01
	/*
	* Detect gpio pin 19 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_39_RW (0x01 << 7)
	#define GPIO_CTRL_GPIO_CTRL_39_SHIFT 7
	#define GPIO_CTRL_GPIO_CTRL_39_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_39_VAL1 0x01
	/*
	* Detect gpio pin 19 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_38_RW (0x01 << 6)
	#define GPIO_CTRL_GPIO_CTRL_38_SHIFT 6
	#define GPIO_CTRL_GPIO_CTRL_38_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_38_VAL1 0x01
	/*
	* Detect gpio pin 18 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_37_RW (0x01 << 5)
	#define GPIO_CTRL_GPIO_CTRL_37_SHIFT 5
	#define GPIO_CTRL_GPIO_CTRL_37_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_37_VAL1 0x01
	/*
	* Detect gpio pin 18 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_36_RW (0x01 << 4)
	#define GPIO_CTRL_GPIO_CTRL_36_SHIFT 4
	#define GPIO_CTRL_GPIO_CTRL_36_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_36_VAL1 0x01
	/*
	* Detect gpio pin 17 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_35_RW (0x01 << 3)
	#define GPIO_CTRL_GPIO_CTRL_35_SHIFT 3
	#define GPIO_CTRL_GPIO_CTRL_35_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_35_VAL1 0x01
	/*
	* Detect gpio pin 17 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_34_RW (0x01 << 2)
	#define GPIO_CTRL_GPIO_CTRL_34_SHIFT 2
	#define GPIO_CTRL_GPIO_CTRL_34_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_34_VAL1 0x01
	/*
	* Detect gpio pin 16 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_33_RW (0x01 << 1)
	#define GPIO_CTRL_GPIO_CTRL_33_SHIFT 1
	#define GPIO_CTRL_GPIO_CTRL_33_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_33_VAL1 0x01
	/*
	* Detect gpio pin 16 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_32_RW (0x01 << 0)
	#define GPIO_CTRL_GPIO_CTRL_32_SHIFT 0
	#define GPIO_CTRL_GPIO_CTRL_32_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_32_VAL1 0x01
	/*
	* Control bits to detect rising/falling edge of GPIO pins
	*/
	#define GPIO_CTRL_REG2_REG(n)  (GPIO_BASE_UNIT##n + 0x78)
	/*
	* Detect gpio pin 47 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_95_RW (0x01 << 31)
	#define GPIO_CTRL_GPIO_CTRL_95_SHIFT 31
	#define GPIO_CTRL_GPIO_CTRL_95_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_95_VAL1 0x01
	/*
	* Detect gpio pin 47 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_94_RW (0x01 << 30)
	#define GPIO_CTRL_GPIO_CTRL_94_SHIFT 30
	#define GPIO_CTRL_GPIO_CTRL_94_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_94_VAL1 0x01
	/*
	* Detect gpio pin 46 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_93_RW (0x01 << 29)
	#define GPIO_CTRL_GPIO_CTRL_93_SHIFT 29
	#define GPIO_CTRL_GPIO_CTRL_93_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_93_VAL1 0x01
	/*
	* Detect gpio pin 46 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_92_RW (0x01 << 28)
	#define GPIO_CTRL_GPIO_CTRL_92_SHIFT 28
	#define GPIO_CTRL_GPIO_CTRL_92_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_92_VAL1 0x01
	/*
	* Detect gpio pin 45 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_91_RW (0x01 << 27)
	#define GPIO_CTRL_GPIO_CTRL_91_SHIFT 27
	#define GPIO_CTRL_GPIO_CTRL_91_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_91_VAL1 0x01
	/*
	* Detect gpio pin 45 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_90_RW (0x01 << 26)
	#define GPIO_CTRL_GPIO_CTRL_90_SHIFT 26
	#define GPIO_CTRL_GPIO_CTRL_90_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_90_VAL1 0x01
	/*
	* Detect gpio pin 44 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_89_RW (0x01 << 25)
	#define GPIO_CTRL_GPIO_CTRL_89_SHIFT 25
	#define GPIO_CTRL_GPIO_CTRL_89_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_89_VAL1 0x01
	/*
	* Detect gpio pin 44 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_88_RW (0x01 << 24)
	#define GPIO_CTRL_GPIO_CTRL_88_SHIFT 24
	#define GPIO_CTRL_GPIO_CTRL_88_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_88_VAL1 0x01
	/*
	* Detect gpio pin 43 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_87_RW (0x01 << 23)
	#define GPIO_CTRL_GPIO_CTRL_87_SHIFT 23
	#define GPIO_CTRL_GPIO_CTRL_87_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_87_VAL1 0x01
	/*
	* Detect gpio pin 43 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_86_RW (0x01 << 22)
	#define GPIO_CTRL_GPIO_CTRL_86_SHIFT 22
	#define GPIO_CTRL_GPIO_CTRL_86_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_86_VAL1 0x01
	/*
	* Detect gpio pin 42 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_85_RW (0x01 << 21)
	#define GPIO_CTRL_GPIO_CTRL_85_SHIFT 21
	#define GPIO_CTRL_GPIO_CTRL_85_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_85_VAL1 0x01
	/*
	* Detect gpio pin 42 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_84_RW (0x01 << 20)
	#define GPIO_CTRL_GPIO_CTRL_84_SHIFT 20
	#define GPIO_CTRL_GPIO_CTRL_84_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_84_VAL1 0x01
	/*
	* Detect gpio pin 41 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_83_RW (0x01 << 19)
	#define GPIO_CTRL_GPIO_CTRL_83_SHIFT 19
	#define GPIO_CTRL_GPIO_CTRL_83_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_83_VAL1 0x01
	/*
	* Detect gpio pin 41 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_82_RW (0x01 << 18)
	#define GPIO_CTRL_GPIO_CTRL_82_SHIFT 18
	#define GPIO_CTRL_GPIO_CTRL_82_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_82_VAL1 0x01
	/*
	* Detect gpio pin 40 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_81_RW (0x01 << 17)
	#define GPIO_CTRL_GPIO_CTRL_81_SHIFT 17
	#define GPIO_CTRL_GPIO_CTRL_81_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_81_VAL1 0x01
	/*
	* Detect gpio pin 40 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_80_RW (0x01 << 16)
	#define GPIO_CTRL_GPIO_CTRL_80_SHIFT 16
	#define GPIO_CTRL_GPIO_CTRL_80_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_80_VAL1 0x01
	/*
	* Detect gpio pin 39 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_79_RW (0x01 << 15)
	#define GPIO_CTRL_GPIO_CTRL_79_SHIFT 15
	#define GPIO_CTRL_GPIO_CTRL_79_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_79_VAL1 0x01
	/*
	* Detect gpio pin 39 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_78_RW (0x01 << 14)
	#define GPIO_CTRL_GPIO_CTRL_78_SHIFT 14
	#define GPIO_CTRL_GPIO_CTRL_78_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_78_VAL1 0x01
	/*
	* Detect gpio pin 38 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_77_RW (0x01 << 13)
	#define GPIO_CTRL_GPIO_CTRL_77_SHIFT 13
	#define GPIO_CTRL_GPIO_CTRL_77_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_77_VAL1 0x01
	/*
	* Detect gpio pin 38 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_76_RW (0x01 << 12)
	#define GPIO_CTRL_GPIO_CTRL_76_SHIFT 12
	#define GPIO_CTRL_GPIO_CTRL_76_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_76_VAL1 0x01
	/*
	* Detect gpio pin 37 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_75_RW (0x01 << 11)
	#define GPIO_CTRL_GPIO_CTRL_75_SHIFT 11
	#define GPIO_CTRL_GPIO_CTRL_75_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_75_VAL1 0x01
	/*
	* Detect gpio pin 37 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_74_RW (0x01 << 10)
	#define GPIO_CTRL_GPIO_CTRL_74_SHIFT 10
	#define GPIO_CTRL_GPIO_CTRL_74_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_74_VAL1 0x01
	/*
	* Detect gpio pin 36 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_73_RW (0x01 << 9)
	#define GPIO_CTRL_GPIO_CTRL_73_SHIFT 9
	#define GPIO_CTRL_GPIO_CTRL_73_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_73_VAL1 0x01
	/*
	* Detect gpio pin 36 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_72_RW (0x01 << 8)
	#define GPIO_CTRL_GPIO_CTRL_72_SHIFT 8
	#define GPIO_CTRL_GPIO_CTRL_72_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_72_VAL1 0x01
	/*
	* Detect gpio pin 35 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_71_RW (0x01 << 7)
	#define GPIO_CTRL_GPIO_CTRL_71_SHIFT 7
	#define GPIO_CTRL_GPIO_CTRL_71_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_71_VAL1 0x01
	/*
	* Detect gpio pin 35 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_70_RW (0x01 << 6)
	#define GPIO_CTRL_GPIO_CTRL_70_SHIFT 6
	#define GPIO_CTRL_GPIO_CTRL_70_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_70_VAL1 0x01
	/*
	* Detect gpio pin 34 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_69_RW (0x01 << 5)
	#define GPIO_CTRL_GPIO_CTRL_69_SHIFT 5
	#define GPIO_CTRL_GPIO_CTRL_69_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_69_VAL1 0x01
	/*
	* Detect gpio pin 34 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_68_RW (0x01 << 4)
	#define GPIO_CTRL_GPIO_CTRL_68_SHIFT 4
	#define GPIO_CTRL_GPIO_CTRL_68_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_68_VAL1 0x01
	/*
	* Detect gpio pin 33 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_67_RW (0x01 << 3)
	#define GPIO_CTRL_GPIO_CTRL_67_SHIFT 3
	#define GPIO_CTRL_GPIO_CTRL_67_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_67_VAL1 0x01
	/*
	* Detect gpio pin 33 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_66_RW (0x01 << 2)
	#define GPIO_CTRL_GPIO_CTRL_66_SHIFT 2
	#define GPIO_CTRL_GPIO_CTRL_66_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_66_VAL1 0x01
	/*
	* Detect gpio pin 32 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_65_RW (0x01 << 1)
	#define GPIO_CTRL_GPIO_CTRL_65_SHIFT 1
	#define GPIO_CTRL_GPIO_CTRL_65_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_65_VAL1 0x01
	/*
	* Detect gpio pin 32 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_64_RW (0x01 << 0)
	#define GPIO_CTRL_GPIO_CTRL_64_SHIFT 0
	#define GPIO_CTRL_GPIO_CTRL_64_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_64_VAL1 0x01
	/*
	* Control bits to detect rising/falling edge of GPIO pins
	*/
	#define GPIO_CTRL_REG3_REG(n)  (GPIO_BASE_UNIT##n + 0x7c)
	/*
	* Detect gpio pin 63 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_127_RW (0x01 << 31)
	#define GPIO_CTRL_GPIO_CTRL_127_SHIFT 31
	#define GPIO_CTRL_GPIO_CTRL_127_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_127_VAL1 0x01
	/*
	* Detect gpio pin 63 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_126_RW (0x01 << 30)
	#define GPIO_CTRL_GPIO_CTRL_126_SHIFT 30
	#define GPIO_CTRL_GPIO_CTRL_126_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_126_VAL1 0x01
	/*
	* Detect gpio pin 62 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_125_RW (0x01 << 29)
	#define GPIO_CTRL_GPIO_CTRL_125_SHIFT 29
	#define GPIO_CTRL_GPIO_CTRL_125_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_125_VAL1 0x01
	/*
	* Detect gpio pin 62 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_124_RW (0x01 << 28)
	#define GPIO_CTRL_GPIO_CTRL_124_SHIFT 28
	#define GPIO_CTRL_GPIO_CTRL_124_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_124_VAL1 0x01
	/*
	* Detect gpio pin 61 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_123_RW (0x01 << 27)
	#define GPIO_CTRL_GPIO_CTRL_123_SHIFT 27
	#define GPIO_CTRL_GPIO_CTRL_123_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_123_VAL1 0x01
	/*
	* Detect gpio pin 61 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_122_RW (0x01 << 26)
	#define GPIO_CTRL_GPIO_CTRL_122_SHIFT 26
	#define GPIO_CTRL_GPIO_CTRL_122_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_122_VAL1 0x01
	/*
	* Detect gpio pin 60 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_121_RW (0x01 << 25)
	#define GPIO_CTRL_GPIO_CTRL_121_SHIFT 25
	#define GPIO_CTRL_GPIO_CTRL_121_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_121_VAL1 0x01
	/*
	* Detect gpio pin 60 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_120_RW (0x01 << 24)
	#define GPIO_CTRL_GPIO_CTRL_120_SHIFT 24
	#define GPIO_CTRL_GPIO_CTRL_120_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_120_VAL1 0x01
	/*
	* Detect gpio pin 59 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_119_RW (0x01 << 23)
	#define GPIO_CTRL_GPIO_CTRL_119_SHIFT 23
	#define GPIO_CTRL_GPIO_CTRL_119_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_119_VAL1 0x01
	/*
	* Detect gpio pin 59 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_118_RW (0x01 << 22)
	#define GPIO_CTRL_GPIO_CTRL_118_SHIFT 22
	#define GPIO_CTRL_GPIO_CTRL_118_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_118_VAL1 0x01
	/*
	* Detect gpio pin 58 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_117_RW (0x01 << 21)
	#define GPIO_CTRL_GPIO_CTRL_117_SHIFT 21
	#define GPIO_CTRL_GPIO_CTRL_117_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_117_VAL1 0x01
	/*
	* Detect gpio pin 58 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_116_RW (0x01 << 20)
	#define GPIO_CTRL_GPIO_CTRL_116_SHIFT 20
	#define GPIO_CTRL_GPIO_CTRL_116_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_116_VAL1 0x01
	/*
	* Detect gpio pin 57 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_115_RW (0x01 << 19)
	#define GPIO_CTRL_GPIO_CTRL_115_SHIFT 19
	#define GPIO_CTRL_GPIO_CTRL_115_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_115_VAL1 0x01
	/*
	* Detect gpio pin 57 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_114_RW (0x01 << 18)
	#define GPIO_CTRL_GPIO_CTRL_114_SHIFT 18
	#define GPIO_CTRL_GPIO_CTRL_114_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_114_VAL1 0x01
	/*
	* Detect gpio pin 56 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_113_RW (0x01 << 17)
	#define GPIO_CTRL_GPIO_CTRL_113_SHIFT 17
	#define GPIO_CTRL_GPIO_CTRL_113_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_113_VAL1 0x01
	/*
	* Detect gpio pin 56 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_112_RW (0x01 << 16)
	#define GPIO_CTRL_GPIO_CTRL_112_SHIFT 16
	#define GPIO_CTRL_GPIO_CTRL_112_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_112_VAL1 0x01
	/*
	* Detect gpio pin 55 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_111_RW (0x01 << 15)
	#define GPIO_CTRL_GPIO_CTRL_111_SHIFT 15
	#define GPIO_CTRL_GPIO_CTRL_111_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_111_VAL1 0x01
	/*
	* Detect gpio pin 55 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_110_RW (0x01 << 14)
	#define GPIO_CTRL_GPIO_CTRL_110_SHIFT 14
	#define GPIO_CTRL_GPIO_CTRL_110_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_110_VAL1 0x01
	/*
	* Detect gpio pin 54 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_109_RW (0x01 << 13)
	#define GPIO_CTRL_GPIO_CTRL_109_SHIFT 13
	#define GPIO_CTRL_GPIO_CTRL_109_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_109_VAL1 0x01
	/*
	* Detect gpio pin 54 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_108_RW (0x01 << 12)
	#define GPIO_CTRL_GPIO_CTRL_108_SHIFT 12
	#define GPIO_CTRL_GPIO_CTRL_108_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_108_VAL1 0x01
	/*
	* Detect gpio pin 53 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_107_RW (0x01 << 11)
	#define GPIO_CTRL_GPIO_CTRL_107_SHIFT 11
	#define GPIO_CTRL_GPIO_CTRL_107_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_107_VAL1 0x01
	/*
	* Detect gpio pin 53 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_106_RW (0x01 << 10)
	#define GPIO_CTRL_GPIO_CTRL_106_SHIFT 10
	#define GPIO_CTRL_GPIO_CTRL_106_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_106_VAL1 0x01
	/*
	* Detect gpio pin 52 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_105_RW (0x01 << 9)
	#define GPIO_CTRL_GPIO_CTRL_105_SHIFT 9
	#define GPIO_CTRL_GPIO_CTRL_105_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_105_VAL1 0x01
	/*
	* Detect gpio pin 52 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_104_RW (0x01 << 8)
	#define GPIO_CTRL_GPIO_CTRL_104_SHIFT 8
	#define GPIO_CTRL_GPIO_CTRL_104_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_104_VAL1 0x01
	/*
	* Detect gpio pin 51 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_103_RW (0x01 << 7)
	#define GPIO_CTRL_GPIO_CTRL_103_SHIFT 7
	#define GPIO_CTRL_GPIO_CTRL_103_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_103_VAL1 0x01
	/*
	* Detect gpio pin 51 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_102_RW (0x01 << 6)
	#define GPIO_CTRL_GPIO_CTRL_102_SHIFT 6
	#define GPIO_CTRL_GPIO_CTRL_102_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_102_VAL1 0x01
	/*
	* Detect gpio pin 50 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_101_RW (0x01 << 5)
	#define GPIO_CTRL_GPIO_CTRL_101_SHIFT 5
	#define GPIO_CTRL_GPIO_CTRL_101_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_101_VAL1 0x01
	/*
	* Detect gpio pin 50 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_100_RW (0x01 << 4)
	#define GPIO_CTRL_GPIO_CTRL_100_SHIFT 4
	#define GPIO_CTRL_GPIO_CTRL_100_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_100_VAL1 0x01
	/*
	* Detect gpio pin 49 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_099_RW (0x01 << 3)
	#define GPIO_CTRL_GPIO_CTRL_099_SHIFT 3
	#define GPIO_CTRL_GPIO_CTRL_099_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_099_VAL1 0x01
	/*
	* Detect gpio pin 49 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_098_RW (0x01 << 2)
	#define GPIO_CTRL_GPIO_CTRL_098_SHIFT 2
	#define GPIO_CTRL_GPIO_CTRL_098_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_098_VAL1 0x01
	/*
	* Detect gpio pin 48 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_097_RW (0x01 << 1)
	#define GPIO_CTRL_GPIO_CTRL_097_SHIFT 1
	#define GPIO_CTRL_GPIO_CTRL_097_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_097_VAL1 0x01
	/*
	* Detect gpio pin 48 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_096_RW (0x01 << 0)
	#define GPIO_CTRL_GPIO_CTRL_096_SHIFT 0
	#define GPIO_CTRL_GPIO_CTRL_096_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_096_VAL1 0x01
	/*
	* Control bits to detect rising/falling edge of GPIO pins
	*/
	#define GPIO_CTRL_REG4_REG(n)  (GPIO_BASE_UNIT##n + 0x80)
	/*
	* Detect gpio pin 74 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_149_RW (0x01 << 21)
	#define GPIO_CTRL_GPIO_CTRL_149_SHIFT 21
	#define GPIO_CTRL_GPIO_CTRL_149_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_149_VAL1 0x01
	/*
	* Detect gpio pin 74 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_148_RW (0x01 << 20)
	#define GPIO_CTRL_GPIO_CTRL_148_SHIFT 20
	#define GPIO_CTRL_GPIO_CTRL_148_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_148_VAL1 0x01
	/*
	* Detect gpio pin 73 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_147_RW (0x01 << 19)
	#define GPIO_CTRL_GPIO_CTRL_147_SHIFT 19
	#define GPIO_CTRL_GPIO_CTRL_147_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_147_VAL1 0x01
	/*
	* Detect gpio pin 73 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_146_RW (0x01 << 18)
	#define GPIO_CTRL_GPIO_CTRL_146_SHIFT 18
	#define GPIO_CTRL_GPIO_CTRL_146_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_146_VAL1 0x01
	/*
	* Detect gpio pin 72 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_145_RW (0x01 << 17)
	#define GPIO_CTRL_GPIO_CTRL_145_SHIFT 17
	#define GPIO_CTRL_GPIO_CTRL_145_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_145_VAL1 0x01
	/*
	* Detect gpio pin 72 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_144_RW (0x01 << 16)
	#define GPIO_CTRL_GPIO_CTRL_144_SHIFT 16
	#define GPIO_CTRL_GPIO_CTRL_144_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_144_VAL1 0x01
	/*
	* Detect gpio pin 71 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_143_RW (0x01 << 15)
	#define GPIO_CTRL_GPIO_CTRL_143_SHIFT 15
	#define GPIO_CTRL_GPIO_CTRL_143_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_143_VAL1 0x01
	/*
	* Detect gpio pin 71 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_142_RW (0x01 << 14)
	#define GPIO_CTRL_GPIO_CTRL_142_SHIFT 14
	#define GPIO_CTRL_GPIO_CTRL_142_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_142_VAL1 0x01
	/*
	* Detect gpio pin 70 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_141_RW (0x01 << 13)
	#define GPIO_CTRL_GPIO_CTRL_141_SHIFT 13
	#define GPIO_CTRL_GPIO_CTRL_141_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_141_VAL1 0x01
	/*
	* Detect gpio pin 70 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_140_RW (0x01 << 12)
	#define GPIO_CTRL_GPIO_CTRL_140_SHIFT 12
	#define GPIO_CTRL_GPIO_CTRL_140_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_140_VAL1 0x01
	/*
	* Detect gpio pin 69 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_139_RW (0x01 << 11)
	#define GPIO_CTRL_GPIO_CTRL_139_SHIFT 11
	#define GPIO_CTRL_GPIO_CTRL_139_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_139_VAL1 0x01
	/*
	* Detect gpio pin 69 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_138_RW (0x01 << 10)
	#define GPIO_CTRL_GPIO_CTRL_138_SHIFT 10
	#define GPIO_CTRL_GPIO_CTRL_138_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_138_VAL1 0x01
	/*
	* Detect gpio pin 68 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_137_RW (0x01 << 9)
	#define GPIO_CTRL_GPIO_CTRL_137_SHIFT 9
	#define GPIO_CTRL_GPIO_CTRL_137_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_137_VAL1 0x01
	/*
	* Detect gpio pin 68 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_136_RW (0x01 << 8)
	#define GPIO_CTRL_GPIO_CTRL_136_SHIFT 8
	#define GPIO_CTRL_GPIO_CTRL_136_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_136_VAL1 0x01
	/*
	* Detect gpio pin 67 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_135_RW (0x01 << 7)
	#define GPIO_CTRL_GPIO_CTRL_135_SHIFT 7
	#define GPIO_CTRL_GPIO_CTRL_135_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_135_VAL1 0x01
	/*
	* Detect gpio pin 67 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_134_RW (0x01 << 6)
	#define GPIO_CTRL_GPIO_CTRL_134_SHIFT 6
	#define GPIO_CTRL_GPIO_CTRL_134_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_134_VAL1 0x01
	/*
	* Detect gpio pin 66 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_133_RW (0x01 << 5)
	#define GPIO_CTRL_GPIO_CTRL_133_SHIFT 5
	#define GPIO_CTRL_GPIO_CTRL_133_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_133_VAL1 0x01
	/*
	* Detect gpio pin 66 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_132_RW (0x01 << 4)
	#define GPIO_CTRL_GPIO_CTRL_132_SHIFT 4
	#define GPIO_CTRL_GPIO_CTRL_132_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_132_VAL1 0x01
	/*
	* Detect gpio pin 65 Rising_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_131_RW (0x01 << 3)
	#define GPIO_CTRL_GPIO_CTRL_131_SHIFT 3
	#define GPIO_CTRL_GPIO_CTRL_131_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_131_VAL1 0x01
	/*
	* Detect gpio pin 65 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_130_RW (0x01 << 2)
	#define GPIO_CTRL_GPIO_CTRL_130_SHIFT 2
	#define GPIO_CTRL_GPIO_CTRL_130_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_130_VAL1 0x01
	/*
	* Detect gpio pin 64 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_129_RW (0x01 << 1)
	#define GPIO_CTRL_GPIO_CTRL_129_SHIFT 1
	#define GPIO_CTRL_GPIO_CTRL_129_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_129_VAL1 0x01
	/*
	* Detect gpio pin 64 falling_edge [ 0 disabled, 1 enabled ]
	*/
	#define GPIO_CTRL_GPIO_CTRL_128_RW (0x01 << 0)
	#define GPIO_CTRL_GPIO_CTRL_128_SHIFT 0
	#define GPIO_CTRL_GPIO_CTRL_128_VAL0 0x00
	#define GPIO_CTRL_GPIO_CTRL_128_VAL1 0x01
	/*
	* GPIO Interrupt Status Register
	*/
	#define GPIO_INT_STATUS0_REG(n)  (GPIO_BASE_UNIT##n + 0xa8)
	/*
	* Internal overrun error in gpio_in [15]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_15_R (0x01 << 31)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_15_SHIFT 31
	#define GPIO_INT_STATUS0_GPIO_INT_OE_15_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_15_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [14]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_14_R (0x01 << 30)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_14_SHIFT 30
	#define GPIO_INT_STATUS0_GPIO_INT_OE_14_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_14_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [13]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_13_R (0x01 << 29)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_13_SHIFT 29
	#define GPIO_INT_STATUS0_GPIO_INT_OE_13_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_13_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [12]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_12_R (0x01 << 28)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_12_SHIFT 28
	#define GPIO_INT_STATUS0_GPIO_INT_OE_12_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_12_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [11]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_11_R (0x01 << 27)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_11_SHIFT 27
	#define GPIO_INT_STATUS0_GPIO_INT_OE_11_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_11_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [10]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_10_R (0x01 << 26)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_10_SHIFT 26
	#define GPIO_INT_STATUS0_GPIO_INT_OE_10_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_10_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [9]. GPIO pin transition occurred before read 
	* by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_09_R (0x01 << 25)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_09_SHIFT 25
	#define GPIO_INT_STATUS0_GPIO_INT_OE_09_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_09_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [8]. GPIO pin transition occurred before read 
	* by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_08_R (0x01 << 24)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_08_SHIFT 24
	#define GPIO_INT_STATUS0_GPIO_INT_OE_08_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_08_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [7]. GPIO pin transition occurred before read 
	* by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_07_R (0x01 << 23)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_07_SHIFT 23
	#define GPIO_INT_STATUS0_GPIO_INT_OE_07_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_07_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [6]. GPIO pin transition occurred before read 
	* by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_06_R (0x01 << 22)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_06_SHIFT 22
	#define GPIO_INT_STATUS0_GPIO_INT_OE_06_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_06_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [5]. GPIO pin transition occurred before read 
	* by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_05_R (0x01 << 21)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_05_SHIFT 21
	#define GPIO_INT_STATUS0_GPIO_INT_OE_05_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_05_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [4]. GPIO pin transition occurred before read 
	* by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_04_R (0x01 << 20)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_04_SHIFT 20
	#define GPIO_INT_STATUS0_GPIO_INT_OE_04_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_04_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [3]. GPIO pin transition occurred before read 
	* by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_03_R (0x01 << 19)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_03_SHIFT 19
	#define GPIO_INT_STATUS0_GPIO_INT_OE_03_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_03_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [2]. GPIO pin transition occurred before read 
	* by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_02_R (0x01 << 18)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_02_SHIFT 18
	#define GPIO_INT_STATUS0_GPIO_INT_OE_02_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_02_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [1]. GPIO pin transition occurred before read 
	* by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_01_R (0x01 << 17)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_01_SHIFT 17
	#define GPIO_INT_STATUS0_GPIO_INT_OE_01_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_01_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [0]. GPIO pin transition occurred before read 
	* by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS0_GPIO_INT_OE_00_R (0x01 << 16)
	#define GPIO_INT_STATUS0_GPIO_INT_OE_00_SHIFT 16
	#define GPIO_INT_STATUS0_GPIO_INT_OE_00_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_INT_OE_00_VAL1 0x01
	/*
	* Data transition on GPIO PIN 15 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_15_R (0x01 << 15)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_15_SHIFT 15
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_15_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_15_VAL1 0x01
	/*
	* Data transition on GPIO PIN 14 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_14_R (0x01 << 14)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_14_SHIFT 14
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_14_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_14_VAL1 0x01
	/*
	* Data transition on GPIO PIN13 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_13_R (0x01 << 13)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_13_SHIFT 13
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_13_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_13_VAL1 0x01
	/*
	* Data transition on GPIO PIN 12 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_12_R (0x01 << 12)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_12_SHIFT 12
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_12_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_12_VAL1 0x01
	/*
	* Data transition on GPIO PIN 11 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_11_R (0x01 << 11)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_11_SHIFT 11
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_11_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_11_VAL1 0x01
	/*
	* Data transition on GPIO PIN 10 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_10_R (0x01 << 10)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_10_SHIFT 10
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_10_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_10_VAL1 0x01
	/*
	* Data transition on GPIO PIN 9 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_09_R (0x01 << 9)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_09_SHIFT 9
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_09_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_09_VAL1 0x01
	/*
	* Data transition on GPIO PIN 8 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_08_R (0x01 << 8)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_08_SHIFT 8
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_08_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_08_VAL1 0x01
	/*
	* Data transition on GPIO PIN 7 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_07_R (0x01 << 7)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_07_SHIFT 7
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_07_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_07_VAL1 0x01
	/*
	* Data transition on GPIO PIN 6 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_06_R (0x01 << 6)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_06_SHIFT 6
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_06_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_06_VAL1 0x01
	/*
	* Data transition on GPIO PIN 5 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_05_R (0x01 << 5)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_05_SHIFT 5
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_05_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_05_VAL1 0x01
	/*
	* Data transition on GPIO PIN 4 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_04_R (0x01 << 4)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_04_SHIFT 4
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_04_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_04_VAL1 0x01
	/*
	* Data transition on GPIO PIN 3 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_03_R (0x01 << 3)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_03_SHIFT 3
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_03_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_03_VAL1 0x01
	/*
	* Data transition on GPIO PIN 2 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_02_R (0x01 << 2)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_02_SHIFT 2
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_02_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_02_VAL1 0x01
	/*
	* Data transition on GPIO PIN 1 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_01_R (0x01 << 1)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_01_SHIFT 1
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_01_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_01_VAL1 0x01
	/*
	* Data transition on GPIO PIN 0 has occurred.
	*/
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_00_R (0x01 << 0)
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_00_SHIFT 0
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_00_VAL0 0x00
	#define GPIO_INT_STATUS0_GPIO_DATA_VALID_00_VAL1 0x01
	/*
	* GPIO Interrupt Status Register
	*/
	#define GPIO_INT_STATUS1_REG(n)  (GPIO_BASE_UNIT##n + 0xac)
	/*
	* Internal overrun error in gpio_in [31]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_31_R (0x01 << 31)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_31_SHIFT 31
	#define GPIO_INT_STATUS1_GPIO_INT_OE_31_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_31_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [30]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_30_R (0x01 << 30)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_30_SHIFT 30
	#define GPIO_INT_STATUS1_GPIO_INT_OE_30_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_30_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [29]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_29_R (0x01 << 29)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_29_SHIFT 29
	#define GPIO_INT_STATUS1_GPIO_INT_OE_29_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_29_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [28]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_28_R (0x01 << 28)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_28_SHIFT 28
	#define GPIO_INT_STATUS1_GPIO_INT_OE_28_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_28_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [27]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_27_R (0x01 << 27)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_27_SHIFT 27
	#define GPIO_INT_STATUS1_GPIO_INT_OE_27_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_27_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [26]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_26_R (0x01 << 26)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_26_SHIFT 26
	#define GPIO_INT_STATUS1_GPIO_INT_OE_26_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_26_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [25]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_25_R (0x01 << 25)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_25_SHIFT 25
	#define GPIO_INT_STATUS1_GPIO_INT_OE_25_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_25_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [24]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_24_R (0x01 << 24)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_24_SHIFT 24
	#define GPIO_INT_STATUS1_GPIO_INT_OE_24_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_24_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [23]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_23_R (0x01 << 23)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_23_SHIFT 23
	#define GPIO_INT_STATUS1_GPIO_INT_OE_23_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_23_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [22]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_22_R (0x01 << 22)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_22_SHIFT 22
	#define GPIO_INT_STATUS1_GPIO_INT_OE_22_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_22_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [21]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_21_R (0x01 << 21)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_21_SHIFT 21
	#define GPIO_INT_STATUS1_GPIO_INT_OE_21_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_21_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [20]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_20_R (0x01 << 20)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_20_SHIFT 20
	#define GPIO_INT_STATUS1_GPIO_INT_OE_20_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_20_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [19]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_19_R (0x01 << 19)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_19_SHIFT 19
	#define GPIO_INT_STATUS1_GPIO_INT_OE_19_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_19_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [18]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_18_R (0x01 << 18)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_18_SHIFT 18
	#define GPIO_INT_STATUS1_GPIO_INT_OE_18_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_18_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [17]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_17_R (0x01 << 17)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_17_SHIFT 17
	#define GPIO_INT_STATUS1_GPIO_INT_OE_17_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_17_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [16]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS1_GPIO_INT_OE_16_R (0x01 << 16)
	#define GPIO_INT_STATUS1_GPIO_INT_OE_16_SHIFT 16
	#define GPIO_INT_STATUS1_GPIO_INT_OE_16_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_INT_OE_16_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_31
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_31_R (0x01 << 15)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_31_SHIFT 15
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_31_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_31_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_30
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_30_R (0x01 << 14)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_30_SHIFT 14
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_30_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_30_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_29
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_29_R (0x01 << 13)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_29_SHIFT 13
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_29_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_29_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_28
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_28_R (0x01 << 12)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_28_SHIFT 12
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_28_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_28_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_27
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_27_R (0x01 << 11)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_27_SHIFT 11
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_27_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_27_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_26
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_26_R (0x01 << 10)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_26_SHIFT 10
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_26_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_26_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_25
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_25_R (0x01 << 9)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_25_SHIFT 9
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_25_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_25_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_24
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_24_R (0x01 << 8)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_24_SHIFT 8
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_24_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_24_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_23
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_23_R (0x01 << 7)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_23_SHIFT 7
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_23_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_23_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_22
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_22_R (0x01 << 6)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_22_SHIFT 6
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_22_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_22_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_21
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_21_R (0x01 << 5)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_21_SHIFT 5
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_21_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_21_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_20
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_20_R (0x01 << 4)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_20_SHIFT 4
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_20_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_20_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_19
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_19_R (0x01 << 3)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_19_SHIFT 3
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_19_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_19_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_18
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_18_R (0x01 << 2)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_18_SHIFT 2
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_18_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_18_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_17
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_17_R (0x01 << 1)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_17_SHIFT 1
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_17_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_17_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_16
	*/
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_16_R (0x01 << 0)
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_16_SHIFT 0
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_16_VAL0 0x00
	#define GPIO_INT_STATUS1_GPIO_DATA_VALID_16_VAL1 0x01
	/*
	* GPIO Interrupt Status Register
	*/
	#define GPIO_INT_STATUS2_REG(n)  (GPIO_BASE_UNIT##n + 0xb0)
	/*
	* Internal overrun error in gpio_in [47]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_47_R (0x01 << 31)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_47_SHIFT 31
	#define GPIO_INT_STATUS2_GPIO_INT_OE_47_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_47_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [46]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_46_R (0x01 << 30)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_46_SHIFT 30
	#define GPIO_INT_STATUS2_GPIO_INT_OE_46_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_46_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [45]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_45_R (0x01 << 29)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_45_SHIFT 29
	#define GPIO_INT_STATUS2_GPIO_INT_OE_45_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_45_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [44]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_44_R (0x01 << 28)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_44_SHIFT 28
	#define GPIO_INT_STATUS2_GPIO_INT_OE_44_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_44_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [43]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_43_R (0x01 << 27)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_43_SHIFT 27
	#define GPIO_INT_STATUS2_GPIO_INT_OE_43_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_43_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [42]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_42_R (0x01 << 26)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_42_SHIFT 26
	#define GPIO_INT_STATUS2_GPIO_INT_OE_42_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_42_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [41]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_41_R (0x01 << 25)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_41_SHIFT 25
	#define GPIO_INT_STATUS2_GPIO_INT_OE_41_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_41_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [40]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_40_R (0x01 << 24)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_40_SHIFT 24
	#define GPIO_INT_STATUS2_GPIO_INT_OE_40_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_40_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [39]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_39_R (0x01 << 23)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_39_SHIFT 23
	#define GPIO_INT_STATUS2_GPIO_INT_OE_39_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_39_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [38]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_38_R (0x01 << 22)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_38_SHIFT 22
	#define GPIO_INT_STATUS2_GPIO_INT_OE_38_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_38_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [37]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_37_R (0x01 << 21)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_37_SHIFT 21
	#define GPIO_INT_STATUS2_GPIO_INT_OE_37_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_37_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [36]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_36_R (0x01 << 20)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_36_SHIFT 20
	#define GPIO_INT_STATUS2_GPIO_INT_OE_36_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_36_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [35]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_35_R (0x01 << 19)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_35_SHIFT 19
	#define GPIO_INT_STATUS2_GPIO_INT_OE_35_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_35_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [34]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_34_R (0x01 << 18)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_34_SHIFT 18
	#define GPIO_INT_STATUS2_GPIO_INT_OE_34_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_34_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [33]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_33_R (0x01 << 17)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_33_SHIFT 17
	#define GPIO_INT_STATUS2_GPIO_INT_OE_33_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_33_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [32]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS2_GPIO_INT_OE_32_R (0x01 << 16)
	#define GPIO_INT_STATUS2_GPIO_INT_OE_32_SHIFT 16
	#define GPIO_INT_STATUS2_GPIO_INT_OE_32_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_INT_OE_32_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_47
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_47_R (0x01 << 15)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_47_SHIFT 15
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_47_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_47_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_46
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_46_R (0x01 << 14)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_46_SHIFT 14
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_46_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_46_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_45
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_45_R (0x01 << 13)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_45_SHIFT 13
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_45_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_45_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_44
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_44_R (0x01 << 12)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_44_SHIFT 12
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_44_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_44_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_43
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_43_R (0x01 << 11)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_43_SHIFT 11
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_43_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_43_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_42
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_42_R (0x01 << 10)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_42_SHIFT 10
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_42_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_42_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_41
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_41_R (0x01 << 9)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_41_SHIFT 9
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_41_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_41_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_40
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_40_R (0x01 << 8)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_40_SHIFT 8
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_40_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_40_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_39
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_39_R (0x01 << 7)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_39_SHIFT 7
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_39_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_39_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_38
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_38_R (0x01 << 6)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_38_SHIFT 6
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_38_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_38_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_37
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_37_R (0x01 << 5)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_37_SHIFT 5
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_37_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_37_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_36
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_36_R (0x01 << 4)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_36_SHIFT 4
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_36_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_36_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_35
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_35_R (0x01 << 3)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_35_SHIFT 3
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_35_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_35_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_34
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_34_R (0x01 << 2)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_34_SHIFT 2
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_34_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_34_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_33
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_33_R (0x01 << 1)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_33_SHIFT 1
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_33_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_33_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_32
	*/
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_32_R (0x01 << 0)
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_32_SHIFT 0
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_32_VAL0 0x00
	#define GPIO_INT_STATUS2_GPIO_DATA_VALID_32_VAL1 0x01
	/*
	* GPIO Interrupt Status Register
	*/
	#define GPIO_INT_STATUS3_REG(n)  (GPIO_BASE_UNIT##n + 0xb4)
	/*
	* Internal overrun error in gpio_in [63]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_63_R (0x01 << 31)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_63_SHIFT 31
	#define GPIO_INT_STATUS3_GPIO_INT_OE_63_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_63_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [62]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_62_R (0x01 << 30)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_62_SHIFT 30
	#define GPIO_INT_STATUS3_GPIO_INT_OE_62_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_62_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [61]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_61_R (0x01 << 29)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_61_SHIFT 29
	#define GPIO_INT_STATUS3_GPIO_INT_OE_61_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_61_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [60]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_60_R (0x01 << 28)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_60_SHIFT 28
	#define GPIO_INT_STATUS3_GPIO_INT_OE_60_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_60_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [59]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_59_R (0x01 << 27)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_59_SHIFT 27
	#define GPIO_INT_STATUS3_GPIO_INT_OE_59_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_59_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [58]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_58_R (0x01 << 26)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_58_SHIFT 26
	#define GPIO_INT_STATUS3_GPIO_INT_OE_58_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_58_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [57]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_57_R (0x01 << 25)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_57_SHIFT 25
	#define GPIO_INT_STATUS3_GPIO_INT_OE_57_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_57_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [56]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_56_R (0x01 << 24)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_56_SHIFT 24
	#define GPIO_INT_STATUS3_GPIO_INT_OE_56_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_56_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [55]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_55_R (0x01 << 23)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_55_SHIFT 23
	#define GPIO_INT_STATUS3_GPIO_INT_OE_55_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_55_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [54]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_54_R (0x01 << 22)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_54_SHIFT 22
	#define GPIO_INT_STATUS3_GPIO_INT_OE_54_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_54_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [53]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_53_R (0x01 << 21)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_53_SHIFT 21
	#define GPIO_INT_STATUS3_GPIO_INT_OE_53_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_53_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [52]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_52_R (0x01 << 20)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_52_SHIFT 20
	#define GPIO_INT_STATUS3_GPIO_INT_OE_52_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_52_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [51]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_51_R (0x01 << 19)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_51_SHIFT 19
	#define GPIO_INT_STATUS3_GPIO_INT_OE_51_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_51_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [50]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_50_R (0x01 << 18)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_50_SHIFT 18
	#define GPIO_INT_STATUS3_GPIO_INT_OE_50_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_50_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [49]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_49_R (0x01 << 17)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_49_SHIFT 17
	#define GPIO_INT_STATUS3_GPIO_INT_OE_49_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_49_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [48]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS3_GPIO_INT_OE_48_R (0x01 << 16)
	#define GPIO_INT_STATUS3_GPIO_INT_OE_48_SHIFT 16
	#define GPIO_INT_STATUS3_GPIO_INT_OE_48_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_INT_OE_48_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_63
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_63_R (0x01 << 15)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_63_SHIFT 15
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_63_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_63_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_62
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_62_R (0x01 << 14)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_62_SHIFT 14
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_62_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_62_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_61
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_61_R (0x01 << 13)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_61_SHIFT 13
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_61_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_61_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_60
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_60_R (0x01 << 12)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_60_SHIFT 12
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_60_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_60_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_59
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_59_R (0x01 << 11)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_59_SHIFT 11
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_59_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_59_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_58
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_58_R (0x01 << 10)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_58_SHIFT 10
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_58_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_58_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_57
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_57_R (0x01 << 9)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_57_SHIFT 9
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_57_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_57_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_56
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_56_R (0x01 << 8)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_56_SHIFT 8
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_56_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_56_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_55
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_55_R (0x01 << 7)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_55_SHIFT 7
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_55_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_55_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_54
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_54_R (0x01 << 6)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_54_SHIFT 6
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_54_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_54_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_53
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_53_R (0x01 << 5)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_53_SHIFT 5
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_53_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_53_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_52
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_52_R (0x01 << 4)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_52_SHIFT 4
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_52_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_52_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_51
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_51_R (0x01 << 3)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_51_SHIFT 3
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_51_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_51_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_50
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_50_R (0x01 << 2)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_50_SHIFT 2
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_50_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_50_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_49
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_49_R (0x01 << 1)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_49_SHIFT 1
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_49_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_49_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_48
	*/
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_48_R (0x01 << 0)
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_48_SHIFT 0
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_48_VAL0 0x00
	#define GPIO_INT_STATUS3_GPIO_DATA_VALID_48_VAL1 0x01
	/*
	* GPIO Interrupt Status Register
	*/
	#define GPIO_INT_STATUS4_REG(n)  (GPIO_BASE_UNIT##n + 0xb8)
	/*
	* Internal overrun error in gpio_in [74]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_74_R (0x01 << 26)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_74_SHIFT 26
	#define GPIO_INT_STATUS4_GPIO_INT_OE_74_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_74_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [73]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_73_R (0x01 << 25)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_73_SHIFT 25
	#define GPIO_INT_STATUS4_GPIO_INT_OE_73_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_73_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [72]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_72_R (0x01 << 24)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_72_SHIFT 24
	#define GPIO_INT_STATUS4_GPIO_INT_OE_72_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_72_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [71]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_71_R (0x01 << 23)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_71_SHIFT 23
	#define GPIO_INT_STATUS4_GPIO_INT_OE_71_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_71_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [70]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_70_R (0x01 << 22)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_70_SHIFT 22
	#define GPIO_INT_STATUS4_GPIO_INT_OE_70_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_70_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [69]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_69_R (0x01 << 21)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_69_SHIFT 21
	#define GPIO_INT_STATUS4_GPIO_INT_OE_69_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_69_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [68]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_68_R (0x01 << 20)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_68_SHIFT 20
	#define GPIO_INT_STATUS4_GPIO_INT_OE_68_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_68_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [67]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_67_R (0x01 << 19)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_67_SHIFT 19
	#define GPIO_INT_STATUS4_GPIO_INT_OE_67_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_67_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [66]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_66_R (0x01 << 18)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_66_SHIFT 18
	#define GPIO_INT_STATUS4_GPIO_INT_OE_66_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_66_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [65]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_65_R (0x01 << 17)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_65_SHIFT 17
	#define GPIO_INT_STATUS4_GPIO_INT_OE_65_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_65_VAL1 0x01
	/*
	* Internal overrun error in gpio_in [64]. GPIO pin transition occurred before read
	*  by CPU (i.e. before DATA_VALID interrupt was cleared).
	*/
	#define GPIO_INT_STATUS4_GPIO_INT_OE_64_R (0x01 << 16)
	#define GPIO_INT_STATUS4_GPIO_INT_OE_64_SHIFT 16
	#define GPIO_INT_STATUS4_GPIO_INT_OE_64_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_INT_OE_64_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_74
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_74_R (0x01 << 10)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_74_SHIFT 10
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_74_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_74_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_73
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_73_R (0x01 << 9)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_73_SHIFT 9
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_73_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_73_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_72
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_72_R (0x01 << 8)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_72_SHIFT 8
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_72_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_72_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_71
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_71_R (0x01 << 7)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_71_SHIFT 7
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_71_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_71_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_70
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_70_R (0x01 << 6)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_70_SHIFT 6
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_70_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_70_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_69
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_69_R (0x01 << 5)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_69_SHIFT 5
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_69_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_69_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_68
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_68_R (0x01 << 4)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_68_SHIFT 4
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_68_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_68_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_67
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_67_R (0x01 << 3)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_67_SHIFT 3
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_67_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_67_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_66
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_66_R (0x01 << 2)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_66_SHIFT 2
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_66_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_66_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_65
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_65_R (0x01 << 1)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_65_SHIFT 1
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_65_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_65_VAL1 0x01
	/*
	* Data_transition_occured_on_ GPIO _PIN_64
	*/
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_64_R (0x01 << 0)
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_64_SHIFT 0
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_64_VAL0 0x00
	#define GPIO_INT_STATUS4_GPIO_DATA_VALID_64_VAL1 0x01
	/*
	* Interrupt Enable Register 0 [0] - Interrupt disabled
	* [1] - Interrupt enabled
	*/
	#define GPIO_INT_EN0_REG(n)  (GPIO_BASE_UNIT##n + 0xe0)
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_31 
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_31_RW (0x01 << 31)
	#define GPIO_INT_EN0_GPIO_INT_EN_31_SHIFT 31
	#define GPIO_INT_EN0_GPIO_INT_EN_31_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_31_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_30
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_30_RW (0x01 << 30)
	#define GPIO_INT_EN0_GPIO_INT_EN_30_SHIFT 30
	#define GPIO_INT_EN0_GPIO_INT_EN_30_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_30_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_29
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_29_RW (0x01 << 29)
	#define GPIO_INT_EN0_GPIO_INT_EN_29_SHIFT 29
	#define GPIO_INT_EN0_GPIO_INT_EN_29_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_29_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_28
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_28_RW (0x01 << 28)
	#define GPIO_INT_EN0_GPIO_INT_EN_28_SHIFT 28
	#define GPIO_INT_EN0_GPIO_INT_EN_28_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_28_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_27
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_27_RW (0x01 << 27)
	#define GPIO_INT_EN0_GPIO_INT_EN_27_SHIFT 27
	#define GPIO_INT_EN0_GPIO_INT_EN_27_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_27_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_26
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_26_RW (0x01 << 26)
	#define GPIO_INT_EN0_GPIO_INT_EN_26_SHIFT 26
	#define GPIO_INT_EN0_GPIO_INT_EN_26_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_26_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_25
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_25_RW (0x01 << 25)
	#define GPIO_INT_EN0_GPIO_INT_EN_25_SHIFT 25
	#define GPIO_INT_EN0_GPIO_INT_EN_25_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_25_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_24
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_24_RW (0x01 << 24)
	#define GPIO_INT_EN0_GPIO_INT_EN_24_SHIFT 24
	#define GPIO_INT_EN0_GPIO_INT_EN_24_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_24_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_23
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_23_RW (0x01 << 23)
	#define GPIO_INT_EN0_GPIO_INT_EN_23_SHIFT 23
	#define GPIO_INT_EN0_GPIO_INT_EN_23_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_23_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_22
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_22_RW (0x01 << 22)
	#define GPIO_INT_EN0_GPIO_INT_EN_22_SHIFT 22
	#define GPIO_INT_EN0_GPIO_INT_EN_22_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_22_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_21
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_21_RW (0x01 << 21)
	#define GPIO_INT_EN0_GPIO_INT_EN_21_SHIFT 21
	#define GPIO_INT_EN0_GPIO_INT_EN_21_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_21_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_20
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_20_RW (0x01 << 20)
	#define GPIO_INT_EN0_GPIO_INT_EN_20_SHIFT 20
	#define GPIO_INT_EN0_GPIO_INT_EN_20_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_20_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_19
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_19_RW (0x01 << 19)
	#define GPIO_INT_EN0_GPIO_INT_EN_19_SHIFT 19
	#define GPIO_INT_EN0_GPIO_INT_EN_19_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_19_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_18
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_18_RW (0x01 << 18)
	#define GPIO_INT_EN0_GPIO_INT_EN_18_SHIFT 18
	#define GPIO_INT_EN0_GPIO_INT_EN_18_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_18_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_17
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_17_RW (0x01 << 17)
	#define GPIO_INT_EN0_GPIO_INT_EN_17_SHIFT 17
	#define GPIO_INT_EN0_GPIO_INT_EN_17_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_17_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_16
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_16_RW (0x01 << 16)
	#define GPIO_INT_EN0_GPIO_INT_EN_16_SHIFT 16
	#define GPIO_INT_EN0_GPIO_INT_EN_16_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_16_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_15
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_15_RW (0x01 << 15)
	#define GPIO_INT_EN0_GPIO_INT_EN_15_SHIFT 15
	#define GPIO_INT_EN0_GPIO_INT_EN_15_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_15_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_14
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_14_RW (0x01 << 14)
	#define GPIO_INT_EN0_GPIO_INT_EN_14_SHIFT 14
	#define GPIO_INT_EN0_GPIO_INT_EN_14_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_14_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_13
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_13_RW (0x01 << 13)
	#define GPIO_INT_EN0_GPIO_INT_EN_13_SHIFT 13
	#define GPIO_INT_EN0_GPIO_INT_EN_13_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_13_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_12
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_12_RW (0x01 << 12)
	#define GPIO_INT_EN0_GPIO_INT_EN_12_SHIFT 12
	#define GPIO_INT_EN0_GPIO_INT_EN_12_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_12_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_11
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_11_RW (0x01 << 11)
	#define GPIO_INT_EN0_GPIO_INT_EN_11_SHIFT 11
	#define GPIO_INT_EN0_GPIO_INT_EN_11_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_11_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_10
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_10_RW (0x01 << 10)
	#define GPIO_INT_EN0_GPIO_INT_EN_10_SHIFT 10
	#define GPIO_INT_EN0_GPIO_INT_EN_10_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_10_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_09
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_09_RW (0x01 << 9)
	#define GPIO_INT_EN0_GPIO_INT_EN_09_SHIFT 9
	#define GPIO_INT_EN0_GPIO_INT_EN_09_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_09_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_08
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_08_RW (0x01 << 8)
	#define GPIO_INT_EN0_GPIO_INT_EN_08_SHIFT 8
	#define GPIO_INT_EN0_GPIO_INT_EN_08_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_08_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_07
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_07_RW (0x01 << 7)
	#define GPIO_INT_EN0_GPIO_INT_EN_07_SHIFT 7
	#define GPIO_INT_EN0_GPIO_INT_EN_07_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_07_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_06
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_06_RW (0x01 << 6)
	#define GPIO_INT_EN0_GPIO_INT_EN_06_SHIFT 6
	#define GPIO_INT_EN0_GPIO_INT_EN_06_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_06_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_05
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_05_RW (0x01 << 5)
	#define GPIO_INT_EN0_GPIO_INT_EN_05_SHIFT 5
	#define GPIO_INT_EN0_GPIO_INT_EN_05_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_05_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_04
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_04_RW (0x01 << 4)
	#define GPIO_INT_EN0_GPIO_INT_EN_04_SHIFT 4
	#define GPIO_INT_EN0_GPIO_INT_EN_04_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_04_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_03
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_03_RW (0x01 << 3)
	#define GPIO_INT_EN0_GPIO_INT_EN_03_SHIFT 3
	#define GPIO_INT_EN0_GPIO_INT_EN_03_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_03_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_02
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_02_RW (0x01 << 2)
	#define GPIO_INT_EN0_GPIO_INT_EN_02_SHIFT 2
	#define GPIO_INT_EN0_GPIO_INT_EN_02_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_02_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_01
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_01_RW (0x01 << 1)
	#define GPIO_INT_EN0_GPIO_INT_EN_01_SHIFT 1
	#define GPIO_INT_EN0_GPIO_INT_EN_01_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_01_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_00
	*/
	#define GPIO_INT_EN0_GPIO_INT_EN_00_RW (0x01 << 0)
	#define GPIO_INT_EN0_GPIO_INT_EN_00_SHIFT 0
	#define GPIO_INT_EN0_GPIO_INT_EN_00_VAL0 0x00
	#define GPIO_INT_EN0_GPIO_INT_EN_00_VAL1 0x01
	/*
	* Interrupt Enable Register 1 [0] - Interrupt disabled
	* [1] - Interrupt enabled
	*/
	#define GPIO_INT_EN1_REG(n)  (GPIO_BASE_UNIT##n + 0xe4)
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_63
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_63_RW (0x01 << 31)
	#define GPIO_INT_EN1_GPIO_INT_EN_63_SHIFT 31
	#define GPIO_INT_EN1_GPIO_INT_EN_63_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_63_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_62
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_62_RW (0x01 << 30)
	#define GPIO_INT_EN1_GPIO_INT_EN_62_SHIFT 30
	#define GPIO_INT_EN1_GPIO_INT_EN_62_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_62_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_61
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_61_RW (0x01 << 29)
	#define GPIO_INT_EN1_GPIO_INT_EN_61_SHIFT 29
	#define GPIO_INT_EN1_GPIO_INT_EN_61_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_61_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_60
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_60_RW (0x01 << 28)
	#define GPIO_INT_EN1_GPIO_INT_EN_60_SHIFT 28
	#define GPIO_INT_EN1_GPIO_INT_EN_60_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_60_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_59
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_59_RW (0x01 << 27)
	#define GPIO_INT_EN1_GPIO_INT_EN_59_SHIFT 27
	#define GPIO_INT_EN1_GPIO_INT_EN_59_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_59_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_58
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_58_RW (0x01 << 26)
	#define GPIO_INT_EN1_GPIO_INT_EN_58_SHIFT 26
	#define GPIO_INT_EN1_GPIO_INT_EN_58_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_58_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_57
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_57_RW (0x01 << 25)
	#define GPIO_INT_EN1_GPIO_INT_EN_57_SHIFT 25
	#define GPIO_INT_EN1_GPIO_INT_EN_57_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_57_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_56
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_56_RW (0x01 << 24)
	#define GPIO_INT_EN1_GPIO_INT_EN_56_SHIFT 24
	#define GPIO_INT_EN1_GPIO_INT_EN_56_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_56_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_55
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_55_RW (0x01 << 23)
	#define GPIO_INT_EN1_GPIO_INT_EN_55_SHIFT 23
	#define GPIO_INT_EN1_GPIO_INT_EN_55_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_55_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_54
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_54_RW (0x01 << 22)
	#define GPIO_INT_EN1_GPIO_INT_EN_54_SHIFT 22
	#define GPIO_INT_EN1_GPIO_INT_EN_54_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_54_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_53
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_53_RW (0x01 << 21)
	#define GPIO_INT_EN1_GPIO_INT_EN_53_SHIFT 21
	#define GPIO_INT_EN1_GPIO_INT_EN_53_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_53_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_52
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_52_RW (0x01 << 20)
	#define GPIO_INT_EN1_GPIO_INT_EN_52_SHIFT 20
	#define GPIO_INT_EN1_GPIO_INT_EN_52_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_52_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_51
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_51_RW (0x01 << 19)
	#define GPIO_INT_EN1_GPIO_INT_EN_51_SHIFT 19
	#define GPIO_INT_EN1_GPIO_INT_EN_51_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_51_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_50
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_50_RW (0x01 << 18)
	#define GPIO_INT_EN1_GPIO_INT_EN_50_SHIFT 18
	#define GPIO_INT_EN1_GPIO_INT_EN_50_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_50_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_49
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_49_RW (0x01 << 17)
	#define GPIO_INT_EN1_GPIO_INT_EN_49_SHIFT 17
	#define GPIO_INT_EN1_GPIO_INT_EN_49_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_49_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_48
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_48_RW (0x01 << 16)
	#define GPIO_INT_EN1_GPIO_INT_EN_48_SHIFT 16
	#define GPIO_INT_EN1_GPIO_INT_EN_48_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_48_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_47
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_47_RW (0x01 << 15)
	#define GPIO_INT_EN1_GPIO_INT_EN_47_SHIFT 15
	#define GPIO_INT_EN1_GPIO_INT_EN_47_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_47_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_46
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_46_RW (0x01 << 14)
	#define GPIO_INT_EN1_GPIO_INT_EN_46_SHIFT 14
	#define GPIO_INT_EN1_GPIO_INT_EN_46_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_46_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_45
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_45_RW (0x01 << 13)
	#define GPIO_INT_EN1_GPIO_INT_EN_45_SHIFT 13
	#define GPIO_INT_EN1_GPIO_INT_EN_45_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_45_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_44
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_44_RW (0x01 << 12)
	#define GPIO_INT_EN1_GPIO_INT_EN_44_SHIFT 12
	#define GPIO_INT_EN1_GPIO_INT_EN_44_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_44_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_43
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_43_RW (0x01 << 11)
	#define GPIO_INT_EN1_GPIO_INT_EN_43_SHIFT 11
	#define GPIO_INT_EN1_GPIO_INT_EN_43_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_43_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_42
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_42_RW (0x01 << 10)
	#define GPIO_INT_EN1_GPIO_INT_EN_42_SHIFT 10
	#define GPIO_INT_EN1_GPIO_INT_EN_42_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_42_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_41
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_41_RW (0x01 << 9)
	#define GPIO_INT_EN1_GPIO_INT_EN_41_SHIFT 9
	#define GPIO_INT_EN1_GPIO_INT_EN_41_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_41_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_40
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_40_RW (0x01 << 8)
	#define GPIO_INT_EN1_GPIO_INT_EN_40_SHIFT 8
	#define GPIO_INT_EN1_GPIO_INT_EN_40_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_40_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_39
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_39_RW (0x01 << 7)
	#define GPIO_INT_EN1_GPIO_INT_EN_39_SHIFT 7
	#define GPIO_INT_EN1_GPIO_INT_EN_39_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_39_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_38
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_38_RW (0x01 << 6)
	#define GPIO_INT_EN1_GPIO_INT_EN_38_SHIFT 6
	#define GPIO_INT_EN1_GPIO_INT_EN_38_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_38_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_37
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_37_RW (0x01 << 5)
	#define GPIO_INT_EN1_GPIO_INT_EN_37_SHIFT 5
	#define GPIO_INT_EN1_GPIO_INT_EN_37_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_37_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_36
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_36_RW (0x01 << 4)
	#define GPIO_INT_EN1_GPIO_INT_EN_36_SHIFT 4
	#define GPIO_INT_EN1_GPIO_INT_EN_36_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_36_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_35
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_35_RW (0x01 << 3)
	#define GPIO_INT_EN1_GPIO_INT_EN_35_SHIFT 3
	#define GPIO_INT_EN1_GPIO_INT_EN_35_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_35_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_34
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_34_RW (0x01 << 2)
	#define GPIO_INT_EN1_GPIO_INT_EN_34_SHIFT 2
	#define GPIO_INT_EN1_GPIO_INT_EN_34_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_34_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_33
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_33_RW (0x01 << 1)
	#define GPIO_INT_EN1_GPIO_INT_EN_33_SHIFT 1
	#define GPIO_INT_EN1_GPIO_INT_EN_33_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_33_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_32
	*/
	#define GPIO_INT_EN1_GPIO_INT_EN_32_RW (0x01 << 0)
	#define GPIO_INT_EN1_GPIO_INT_EN_32_SHIFT 0
	#define GPIO_INT_EN1_GPIO_INT_EN_32_VAL0 0x00
	#define GPIO_INT_EN1_GPIO_INT_EN_32_VAL1 0x01
	/*
	* Interrupt Enable Register 2 [0] - Interrupt disabled
	* [1] - Interrupt enabled
	*/
	#define GPIO_INT_EN2_REG(n)  (GPIO_BASE_UNIT##n + 0xe8)
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_74
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_74_RW (0x01 << 10)
	#define GPIO_INT_EN2_GPIO_INT_EN_74_SHIFT 10
	#define GPIO_INT_EN2_GPIO_INT_EN_74_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_74_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_73
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_73_RW (0x01 << 9)
	#define GPIO_INT_EN2_GPIO_INT_EN_73_SHIFT 9
	#define GPIO_INT_EN2_GPIO_INT_EN_73_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_73_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_72
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_72_RW (0x01 << 8)
	#define GPIO_INT_EN2_GPIO_INT_EN_72_SHIFT 8
	#define GPIO_INT_EN2_GPIO_INT_EN_72_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_72_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_71
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_71_RW (0x01 << 7)
	#define GPIO_INT_EN2_GPIO_INT_EN_71_SHIFT 7
	#define GPIO_INT_EN2_GPIO_INT_EN_71_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_71_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_70
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_70_RW (0x01 << 6)
	#define GPIO_INT_EN2_GPIO_INT_EN_70_SHIFT 6
	#define GPIO_INT_EN2_GPIO_INT_EN_70_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_70_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_69
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_69_RW (0x01 << 5)
	#define GPIO_INT_EN2_GPIO_INT_EN_69_SHIFT 5
	#define GPIO_INT_EN2_GPIO_INT_EN_69_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_69_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_68
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_68_RW (0x01 << 4)
	#define GPIO_INT_EN2_GPIO_INT_EN_68_SHIFT 4
	#define GPIO_INT_EN2_GPIO_INT_EN_68_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_68_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_67
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_67_RW (0x01 << 3)
	#define GPIO_INT_EN2_GPIO_INT_EN_67_SHIFT 3
	#define GPIO_INT_EN2_GPIO_INT_EN_67_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_67_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_66
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_66_RW (0x01 << 2)
	#define GPIO_INT_EN2_GPIO_INT_EN_66_SHIFT 2
	#define GPIO_INT_EN2_GPIO_INT_EN_66_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_66_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_65
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_65_RW (0x01 << 1)
	#define GPIO_INT_EN2_GPIO_INT_EN_65_SHIFT 1
	#define GPIO_INT_EN2_GPIO_INT_EN_65_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_65_VAL1 0x01
	/*
	* Data_valid_interrupt_enable_register_for _GPIO_PIN_64
	*/
	#define GPIO_INT_EN2_GPIO_INT_EN_64_RW (0x01 << 0)
	#define GPIO_INT_EN2_GPIO_INT_EN_64_SHIFT 0
	#define GPIO_INT_EN2_GPIO_INT_EN_64_VAL0 0x00
	#define GPIO_INT_EN2_GPIO_INT_EN_64_VAL1 0x01
	/*
	* Interrupt Clear Register 0 
	*/
	#define GPIO_INT_CLR0_REG(n)  (GPIO_BASE_UNIT##n + 0xfc)
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_31
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_31_RW (0x01 << 31)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_31_SHIFT 31
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_31_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_31_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_30
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_30_RW (0x01 << 30)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_30_SHIFT 30
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_30_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_30_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_29
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_29_RW (0x01 << 29)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_29_SHIFT 29
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_29_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_29_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_28
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_28_RW (0x01 << 28)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_28_SHIFT 28
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_28_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_28_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_27
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_27_RW (0x01 << 27)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_27_SHIFT 27
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_27_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_27_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_26
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_26_RW (0x01 << 26)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_26_SHIFT 26
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_26_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_26_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_25
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_25_RW (0x01 << 25)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_25_SHIFT 25
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_25_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_25_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_24
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_24_RW (0x01 << 24)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_24_SHIFT 24
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_24_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_24_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_23
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_23_RW (0x01 << 23)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_23_SHIFT 23
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_23_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_23_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_22
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_22_RW (0x01 << 22)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_22_SHIFT 22
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_22_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_22_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_21
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_21_RW (0x01 << 21)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_21_SHIFT 21
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_21_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_21_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_20
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_20_RW (0x01 << 20)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_20_SHIFT 20
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_20_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_20_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_19
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_19_RW (0x01 << 19)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_19_SHIFT 19
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_19_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_19_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_18
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_18_RW (0x01 << 18)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_18_SHIFT 18
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_18_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_18_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_17
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_17_RW (0x01 << 17)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_17_SHIFT 17
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_17_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_17_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_16
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_16_RW (0x01 << 16)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_16_SHIFT 16
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_16_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_16_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_15
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_15_RW (0x01 << 15)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_15_SHIFT 15
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_15_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_15_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_14
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_14_RW (0x01 << 14)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_14_SHIFT 14
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_14_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_14_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_13
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_13_RW (0x01 << 13)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_13_SHIFT 13
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_13_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_13_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_12
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_12_RW (0x01 << 12)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_12_SHIFT 12
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_12_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_12_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_11
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_11_RW (0x01 << 11)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_11_SHIFT 11
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_11_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_11_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_10
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_10_RW (0x01 << 10)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_10_SHIFT 10
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_10_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_10_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_09
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_09_RW (0x01 << 9)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_09_SHIFT 9
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_09_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_09_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_08
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_08_RW (0x01 << 8)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_08_SHIFT 8
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_08_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_08_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_07
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_07_RW (0x01 << 7)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_07_SHIFT 7
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_07_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_07_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_06
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_06_RW (0x01 << 6)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_06_SHIFT 6
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_06_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_06_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_05
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_05_RW (0x01 << 5)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_05_SHIFT 5
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_05_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_05_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_04
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_04_RW (0x01 << 4)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_04_SHIFT 4
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_04_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_04_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_03
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_03_RW (0x01 << 3)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_03_SHIFT 3
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_03_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_03_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_02
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_02_RW (0x01 << 2)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_02_SHIFT 2
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_02_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_02_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_01
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_01_RW (0x01 << 1)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_01_SHIFT 1
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_01_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_01_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_00 
	*/
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_00_RW (0x01 << 0)
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_00_SHIFT 0
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_00_VAL0 0x00
	#define GPIO_INT_CLR0_GPIO_INT_CLEAR_00_VAL1 0x01
	/*
	* Interrupt Clear Register 1 
	*/
	#define GPIO_INT_CLR1_REG(n)  (GPIO_BASE_UNIT##n + 0x100)
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_63
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_63_RW (0x01 << 31)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_63_SHIFT 31
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_63_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_63_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_62
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_62_RW (0x01 << 30)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_62_SHIFT 30
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_62_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_62_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_61
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_61_RW (0x01 << 29)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_61_SHIFT 29
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_61_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_61_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_60
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_60_RW (0x01 << 28)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_60_SHIFT 28
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_60_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_60_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_59
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_59_RW (0x01 << 27)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_59_SHIFT 27
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_59_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_59_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_58
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_58_RW (0x01 << 26)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_58_SHIFT 26
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_58_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_58_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_57
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_57_RW (0x01 << 25)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_57_SHIFT 25
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_57_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_57_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_56
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_56_RW (0x01 << 24)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_56_SHIFT 24
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_56_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_56_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_55
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_55_RW (0x01 << 23)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_55_SHIFT 23
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_55_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_55_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_54
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_54_RW (0x01 << 22)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_54_SHIFT 22
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_54_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_54_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_53
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_53_RW (0x01 << 21)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_53_SHIFT 21
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_53_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_53_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_52
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_52_RW (0x01 << 20)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_52_SHIFT 20
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_52_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_52_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_51
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_51_RW (0x01 << 19)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_51_SHIFT 19
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_51_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_51_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_50
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_50_RW (0x01 << 18)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_50_SHIFT 18
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_50_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_50_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_49
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_49_RW (0x01 << 17)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_49_SHIFT 17
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_49_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_49_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_48
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_48_RW (0x01 << 16)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_48_SHIFT 16
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_48_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_48_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_47
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_47_RW (0x01 << 15)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_47_SHIFT 15
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_47_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_47_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_46
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_46_RW (0x01 << 14)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_46_SHIFT 14
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_46_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_46_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_45
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_45_RW (0x01 << 13)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_45_SHIFT 13
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_45_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_45_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_44
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_44_RW (0x01 << 12)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_44_SHIFT 12
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_44_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_44_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_43
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_43_RW (0x01 << 11)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_43_SHIFT 11
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_43_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_43_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_42
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_42_RW (0x01 << 10)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_42_SHIFT 10
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_42_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_42_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_41
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_41_RW (0x01 << 9)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_41_SHIFT 9
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_41_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_41_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_40
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_40_RW (0x01 << 8)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_40_SHIFT 8
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_40_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_40_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_39
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_39_RW (0x01 << 7)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_39_SHIFT 7
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_39_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_39_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_38
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_38_RW (0x01 << 6)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_38_SHIFT 6
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_38_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_38_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_37
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_37_RW (0x01 << 5)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_37_SHIFT 5
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_37_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_37_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_36
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_36_RW (0x01 << 4)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_36_SHIFT 4
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_36_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_36_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_35
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_35_RW (0x01 << 3)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_35_SHIFT 3
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_35_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_35_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_34
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_34_RW (0x01 << 2)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_34_SHIFT 2
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_34_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_34_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_33
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_33_RW (0x01 << 1)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_33_SHIFT 1
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_33_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_33_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_32
	*/
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_32_RW (0x01 << 0)
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_32_SHIFT 0
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_32_VAL0 0x00
	#define GPIO_INT_CLR1_GPIO_INT_CLEAR_32_VAL1 0x01
	/*
	* Interrupt Clear Register 2 
	*/
	#define GPIO_INT_CLR2_REG(n)  (GPIO_BASE_UNIT##n + 0x104)
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_74
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_74_RW (0x01 << 10)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_74_SHIFT 10
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_74_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_74_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_73
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_73_RW (0x01 << 9)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_73_SHIFT 9
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_73_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_73_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_72
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_72_RW (0x01 << 8)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_72_SHIFT 8
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_72_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_72_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_71
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_71_RW (0x01 << 7)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_71_SHIFT 7
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_71_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_71_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_70
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_70_RW (0x01 << 6)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_70_SHIFT 6
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_70_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_70_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_69
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_69_RW (0x01 << 5)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_69_SHIFT 5
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_69_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_69_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_68
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_68_RW (0x01 << 4)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_68_SHIFT 4
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_68_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_68_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_67
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_67_RW (0x01 << 3)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_67_SHIFT 3
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_67_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_67_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_66
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_66_RW (0x01 << 2)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_66_SHIFT 2
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_66_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_66_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_65
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_65_RW (0x01 << 1)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_65_SHIFT 1
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_65_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_65_VAL1 0x01
	/*
	* Active_high_clear_data_valid_interrupt_for_GPIO_PIN_64
	*/
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_64_RW (0x01 << 0)
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_64_SHIFT 0
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_64_VAL0 0x00
	#define GPIO_INT_CLR2_GPIO_INT_CLEAR_64_VAL1 0x01
	/*
	* Interrupt SET Register 0 
	*/
	#define GPIO_INT_SET0_REG(n)  (GPIO_BASE_UNIT##n + 0x118)
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_31
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_31_W (0x01 << 31)
	#define GPIO_INT_SET0_GPIO_INT_SET_31_SHIFT 31
	#define GPIO_INT_SET0_GPIO_INT_SET_31_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_31_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_30
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_30_W (0x01 << 30)
	#define GPIO_INT_SET0_GPIO_INT_SET_30_SHIFT 30
	#define GPIO_INT_SET0_GPIO_INT_SET_30_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_30_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_29
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_29_W (0x01 << 29)
	#define GPIO_INT_SET0_GPIO_INT_SET_29_SHIFT 29
	#define GPIO_INT_SET0_GPIO_INT_SET_29_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_29_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_28
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_28_W (0x01 << 28)
	#define GPIO_INT_SET0_GPIO_INT_SET_28_SHIFT 28
	#define GPIO_INT_SET0_GPIO_INT_SET_28_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_28_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_27
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_27_W (0x01 << 27)
	#define GPIO_INT_SET0_GPIO_INT_SET_27_SHIFT 27
	#define GPIO_INT_SET0_GPIO_INT_SET_27_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_27_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_26
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_26_W (0x01 << 26)
	#define GPIO_INT_SET0_GPIO_INT_SET_26_SHIFT 26
	#define GPIO_INT_SET0_GPIO_INT_SET_26_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_26_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_25
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_25_W (0x01 << 25)
	#define GPIO_INT_SET0_GPIO_INT_SET_25_SHIFT 25
	#define GPIO_INT_SET0_GPIO_INT_SET_25_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_25_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_24
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_24_W (0x01 << 24)
	#define GPIO_INT_SET0_GPIO_INT_SET_24_SHIFT 24
	#define GPIO_INT_SET0_GPIO_INT_SET_24_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_24_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_23
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_23_W (0x01 << 23)
	#define GPIO_INT_SET0_GPIO_INT_SET_23_SHIFT 23
	#define GPIO_INT_SET0_GPIO_INT_SET_23_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_23_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_22
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_22_W (0x01 << 22)
	#define GPIO_INT_SET0_GPIO_INT_SET_22_SHIFT 22
	#define GPIO_INT_SET0_GPIO_INT_SET_22_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_22_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_21
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_21_W (0x01 << 21)
	#define GPIO_INT_SET0_GPIO_INT_SET_21_SHIFT 21
	#define GPIO_INT_SET0_GPIO_INT_SET_21_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_21_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_20
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_20_W (0x01 << 20)
	#define GPIO_INT_SET0_GPIO_INT_SET_20_SHIFT 20
	#define GPIO_INT_SET0_GPIO_INT_SET_20_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_20_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_19
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_19_W (0x01 << 19)
	#define GPIO_INT_SET0_GPIO_INT_SET_19_SHIFT 19
	#define GPIO_INT_SET0_GPIO_INT_SET_19_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_19_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_18
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_18_W (0x01 << 18)
	#define GPIO_INT_SET0_GPIO_INT_SET_18_SHIFT 18
	#define GPIO_INT_SET0_GPIO_INT_SET_18_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_18_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_17
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_17_W (0x01 << 17)
	#define GPIO_INT_SET0_GPIO_INT_SET_17_SHIFT 17
	#define GPIO_INT_SET0_GPIO_INT_SET_17_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_17_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_16
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_16_W (0x01 << 16)
	#define GPIO_INT_SET0_GPIO_INT_SET_16_SHIFT 16
	#define GPIO_INT_SET0_GPIO_INT_SET_16_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_16_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_15
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_15_W (0x01 << 15)
	#define GPIO_INT_SET0_GPIO_INT_SET_15_SHIFT 15
	#define GPIO_INT_SET0_GPIO_INT_SET_15_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_15_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_14
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_14_W (0x01 << 14)
	#define GPIO_INT_SET0_GPIO_INT_SET_14_SHIFT 14
	#define GPIO_INT_SET0_GPIO_INT_SET_14_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_14_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_13
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_13_W (0x01 << 13)
	#define GPIO_INT_SET0_GPIO_INT_SET_13_SHIFT 13
	#define GPIO_INT_SET0_GPIO_INT_SET_13_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_13_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_12
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_12_W (0x01 << 12)
	#define GPIO_INT_SET0_GPIO_INT_SET_12_SHIFT 12
	#define GPIO_INT_SET0_GPIO_INT_SET_12_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_12_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_11
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_11_W (0x01 << 11)
	#define GPIO_INT_SET0_GPIO_INT_SET_11_SHIFT 11
	#define GPIO_INT_SET0_GPIO_INT_SET_11_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_11_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_10
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_10_W (0x01 << 10)
	#define GPIO_INT_SET0_GPIO_INT_SET_10_SHIFT 10
	#define GPIO_INT_SET0_GPIO_INT_SET_10_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_10_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_09
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_09_W (0x01 << 9)
	#define GPIO_INT_SET0_GPIO_INT_SET_09_SHIFT 9
	#define GPIO_INT_SET0_GPIO_INT_SET_09_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_09_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_08
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_08_W (0x01 << 8)
	#define GPIO_INT_SET0_GPIO_INT_SET_08_SHIFT 8
	#define GPIO_INT_SET0_GPIO_INT_SET_08_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_08_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_07
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_07_W (0x01 << 7)
	#define GPIO_INT_SET0_GPIO_INT_SET_07_SHIFT 7
	#define GPIO_INT_SET0_GPIO_INT_SET_07_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_07_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_06
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_06_W (0x01 << 6)
	#define GPIO_INT_SET0_GPIO_INT_SET_06_SHIFT 6
	#define GPIO_INT_SET0_GPIO_INT_SET_06_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_06_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_05
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_05_W (0x01 << 5)
	#define GPIO_INT_SET0_GPIO_INT_SET_05_SHIFT 5
	#define GPIO_INT_SET0_GPIO_INT_SET_05_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_05_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_04
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_04_W (0x01 << 4)
	#define GPIO_INT_SET0_GPIO_INT_SET_04_SHIFT 4
	#define GPIO_INT_SET0_GPIO_INT_SET_04_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_04_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_03
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_03_W (0x01 << 3)
	#define GPIO_INT_SET0_GPIO_INT_SET_03_SHIFT 3
	#define GPIO_INT_SET0_GPIO_INT_SET_03_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_03_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_02
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_02_W (0x01 << 2)
	#define GPIO_INT_SET0_GPIO_INT_SET_02_SHIFT 2
	#define GPIO_INT_SET0_GPIO_INT_SET_02_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_02_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_01
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_01_W (0x01 << 1)
	#define GPIO_INT_SET0_GPIO_INT_SET_01_SHIFT 1
	#define GPIO_INT_SET0_GPIO_INT_SET_01_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_01_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_00
	*/
	#define GPIO_INT_SET0_GPIO_INT_SET_00_W (0x01 << 0)
	#define GPIO_INT_SET0_GPIO_INT_SET_00_SHIFT 0
	#define GPIO_INT_SET0_GPIO_INT_SET_00_VAL0 0x00
	#define GPIO_INT_SET0_GPIO_INT_SET_00_VAL1 0x01
	/*
	* Interrupt SET Register 1 
	*/
	#define GPIO_INT_SET1_REG(n)  (GPIO_BASE_UNIT##n + 0x11c)
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_63
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_63_W (0x01 << 31)
	#define GPIO_INT_SET1_GPIO_INT_SET_63_SHIFT 31
	#define GPIO_INT_SET1_GPIO_INT_SET_63_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_63_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_62
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_62_W (0x01 << 30)
	#define GPIO_INT_SET1_GPIO_INT_SET_62_SHIFT 30
	#define GPIO_INT_SET1_GPIO_INT_SET_62_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_62_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_61
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_61_W (0x01 << 29)
	#define GPIO_INT_SET1_GPIO_INT_SET_61_SHIFT 29
	#define GPIO_INT_SET1_GPIO_INT_SET_61_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_61_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_60
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_60_W (0x01 << 28)
	#define GPIO_INT_SET1_GPIO_INT_SET_60_SHIFT 28
	#define GPIO_INT_SET1_GPIO_INT_SET_60_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_60_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_59
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_59_W (0x01 << 27)
	#define GPIO_INT_SET1_GPIO_INT_SET_59_SHIFT 27
	#define GPIO_INT_SET1_GPIO_INT_SET_59_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_59_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_58
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_58_W (0x01 << 26)
	#define GPIO_INT_SET1_GPIO_INT_SET_58_SHIFT 26
	#define GPIO_INT_SET1_GPIO_INT_SET_58_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_58_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_57
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_57_W (0x01 << 25)
	#define GPIO_INT_SET1_GPIO_INT_SET_57_SHIFT 25
	#define GPIO_INT_SET1_GPIO_INT_SET_57_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_57_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_56
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_56_W (0x01 << 24)
	#define GPIO_INT_SET1_GPIO_INT_SET_56_SHIFT 24
	#define GPIO_INT_SET1_GPIO_INT_SET_56_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_56_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_55
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_55_W (0x01 << 23)
	#define GPIO_INT_SET1_GPIO_INT_SET_55_SHIFT 23
	#define GPIO_INT_SET1_GPIO_INT_SET_55_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_55_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_54
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_54_W (0x01 << 22)
	#define GPIO_INT_SET1_GPIO_INT_SET_54_SHIFT 22
	#define GPIO_INT_SET1_GPIO_INT_SET_54_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_54_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_53
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_53_W (0x01 << 21)
	#define GPIO_INT_SET1_GPIO_INT_SET_53_SHIFT 21
	#define GPIO_INT_SET1_GPIO_INT_SET_53_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_53_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_52
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_52_W (0x01 << 20)
	#define GPIO_INT_SET1_GPIO_INT_SET_52_SHIFT 20
	#define GPIO_INT_SET1_GPIO_INT_SET_52_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_52_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_51
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_51_W (0x01 << 19)
	#define GPIO_INT_SET1_GPIO_INT_SET_51_SHIFT 19
	#define GPIO_INT_SET1_GPIO_INT_SET_51_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_51_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_50
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_50_W (0x01 << 18)
	#define GPIO_INT_SET1_GPIO_INT_SET_50_SHIFT 18
	#define GPIO_INT_SET1_GPIO_INT_SET_50_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_50_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_49
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_49_W (0x01 << 17)
	#define GPIO_INT_SET1_GPIO_INT_SET_49_SHIFT 17
	#define GPIO_INT_SET1_GPIO_INT_SET_49_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_49_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_48
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_48_W (0x01 << 16)
	#define GPIO_INT_SET1_GPIO_INT_SET_48_SHIFT 16
	#define GPIO_INT_SET1_GPIO_INT_SET_48_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_48_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_47
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_47_W (0x01 << 15)
	#define GPIO_INT_SET1_GPIO_INT_SET_47_SHIFT 15
	#define GPIO_INT_SET1_GPIO_INT_SET_47_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_47_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_46
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_46_W (0x01 << 14)
	#define GPIO_INT_SET1_GPIO_INT_SET_46_SHIFT 14
	#define GPIO_INT_SET1_GPIO_INT_SET_46_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_46_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_45
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_45_W (0x01 << 13)
	#define GPIO_INT_SET1_GPIO_INT_SET_45_SHIFT 13
	#define GPIO_INT_SET1_GPIO_INT_SET_45_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_45_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_44
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_44_W (0x01 << 12)
	#define GPIO_INT_SET1_GPIO_INT_SET_44_SHIFT 12
	#define GPIO_INT_SET1_GPIO_INT_SET_44_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_44_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_43
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_43_W (0x01 << 11)
	#define GPIO_INT_SET1_GPIO_INT_SET_43_SHIFT 11
	#define GPIO_INT_SET1_GPIO_INT_SET_43_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_43_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_42
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_42_W (0x01 << 10)
	#define GPIO_INT_SET1_GPIO_INT_SET_42_SHIFT 10
	#define GPIO_INT_SET1_GPIO_INT_SET_42_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_42_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_41
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_41_W (0x01 << 9)
	#define GPIO_INT_SET1_GPIO_INT_SET_41_SHIFT 9
	#define GPIO_INT_SET1_GPIO_INT_SET_41_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_41_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_40
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_40_W (0x01 << 8)
	#define GPIO_INT_SET1_GPIO_INT_SET_40_SHIFT 8
	#define GPIO_INT_SET1_GPIO_INT_SET_40_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_40_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_39
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_39_W (0x01 << 7)
	#define GPIO_INT_SET1_GPIO_INT_SET_39_SHIFT 7
	#define GPIO_INT_SET1_GPIO_INT_SET_39_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_39_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_38
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_38_W (0x01 << 6)
	#define GPIO_INT_SET1_GPIO_INT_SET_38_SHIFT 6
	#define GPIO_INT_SET1_GPIO_INT_SET_38_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_38_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_37
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_37_W (0x01 << 5)
	#define GPIO_INT_SET1_GPIO_INT_SET_37_SHIFT 5
	#define GPIO_INT_SET1_GPIO_INT_SET_37_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_37_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_36
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_36_W (0x01 << 4)
	#define GPIO_INT_SET1_GPIO_INT_SET_36_SHIFT 4
	#define GPIO_INT_SET1_GPIO_INT_SET_36_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_36_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_35
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_35_W (0x01 << 3)
	#define GPIO_INT_SET1_GPIO_INT_SET_35_SHIFT 3
	#define GPIO_INT_SET1_GPIO_INT_SET_35_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_35_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_34
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_34_W (0x01 << 2)
	#define GPIO_INT_SET1_GPIO_INT_SET_34_SHIFT 2
	#define GPIO_INT_SET1_GPIO_INT_SET_34_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_34_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_33
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_33_W (0x01 << 1)
	#define GPIO_INT_SET1_GPIO_INT_SET_33_SHIFT 1
	#define GPIO_INT_SET1_GPIO_INT_SET_33_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_33_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_32
	*/
	#define GPIO_INT_SET1_GPIO_INT_SET_32_W (0x01 << 0)
	#define GPIO_INT_SET1_GPIO_INT_SET_32_SHIFT 0
	#define GPIO_INT_SET1_GPIO_INT_SET_32_VAL0 0x00
	#define GPIO_INT_SET1_GPIO_INT_SET_32_VAL1 0x01
	/*
	* Interrupt SET Register 2 
	*/
	#define GPIO_INT_SET2_REG(n)  (GPIO_BASE_UNIT##n + 0x120)
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_74
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_74_W (0x01 << 10)
	#define GPIO_INT_SET2_GPIO_INT_SET_74_SHIFT 10
	#define GPIO_INT_SET2_GPIO_INT_SET_74_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_74_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_73
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_73_W (0x01 << 9)
	#define GPIO_INT_SET2_GPIO_INT_SET_73_SHIFT 9
	#define GPIO_INT_SET2_GPIO_INT_SET_73_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_73_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_72
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_72_W (0x01 << 8)
	#define GPIO_INT_SET2_GPIO_INT_SET_72_SHIFT 8
	#define GPIO_INT_SET2_GPIO_INT_SET_72_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_72_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_71
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_71_W (0x01 << 7)
	#define GPIO_INT_SET2_GPIO_INT_SET_71_SHIFT 7
	#define GPIO_INT_SET2_GPIO_INT_SET_71_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_71_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_70
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_70_W (0x01 << 6)
	#define GPIO_INT_SET2_GPIO_INT_SET_70_SHIFT 6
	#define GPIO_INT_SET2_GPIO_INT_SET_70_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_70_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_69
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_69_W (0x01 << 5)
	#define GPIO_INT_SET2_GPIO_INT_SET_69_SHIFT 5
	#define GPIO_INT_SET2_GPIO_INT_SET_69_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_69_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_68
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_68_W (0x01 << 4)
	#define GPIO_INT_SET2_GPIO_INT_SET_68_SHIFT 4
	#define GPIO_INT_SET2_GPIO_INT_SET_68_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_68_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_67
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_67_W (0x01 << 3)
	#define GPIO_INT_SET2_GPIO_INT_SET_67_SHIFT 3
	#define GPIO_INT_SET2_GPIO_INT_SET_67_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_67_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_66
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_66_W (0x01 << 2)
	#define GPIO_INT_SET2_GPIO_INT_SET_66_SHIFT 2
	#define GPIO_INT_SET2_GPIO_INT_SET_66_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_66_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_65
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_65_W (0x01 << 1)
	#define GPIO_INT_SET2_GPIO_INT_SET_65_SHIFT 1
	#define GPIO_INT_SET2_GPIO_INT_SET_65_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_65_VAL1 0x01
	/*
	* Active_high_set_for_data_valid_interrupt_for_GPIO_PIN_64
	*/
	#define GPIO_INT_SET2_GPIO_INT_SET_64_W (0x01 << 0)
	#define GPIO_INT_SET2_GPIO_INT_SET_64_SHIFT 0
	#define GPIO_INT_SET2_GPIO_INT_SET_64_VAL0 0x00
	#define GPIO_INT_SET2_GPIO_INT_SET_64_VAL1 0x01
	/*
	* Power down Register
	*/
	#define GPIO_POWERDOWN_REG(n)  (GPIO_BASE_UNIT##n + 0xff4)
	/*
	* 0 = Normal operation of peripheral. This is the reset value.
	* 1 = Module is powerdown and module clock can be removed. Module must respond to 
	* all reads. Generate e.g. DEADABBA(except for reads of the powerdown bit!). Modul
	* e should generate ERR ack on writes (except for writes to the powerdown bit!).
	*/
	#define GPIO_POWERDOWN_POWERDOWN_RW (0x01 << 31)
	#define GPIO_POWERDOWN_POWERDOWN_SHIFT 31
	#define GPIO_POWERDOWN_POWERDOWN_VAL0 0x00
	#define GPIO_POWERDOWN_POWERDOWN_VAL1 0x01
	/*
	* Reserved
	*/
	#define GPIO_POWERDOWN_RESERVED_RES (0x07fffffff << 0)
	#define GPIO_POWERDOWN_RESERVED_SHIFT 0
	/*
	* Module ID register
	*/
	#define GPIO_MODULEID_REG(n)  (GPIO_BASE_UNIT##n + 0xffc)
	/*
	* 32-bit Module Identification ID Value is 0xa0943000
	*/
	#define GPIO_MODULEID_MODULEID_RW (0x0ffffffff << 0)
	#define GPIO_MODULEID_MODULEID_SHIFT 0

#endif // PHMODIPGPIO_H
