/****************************************************************************/
/*                   NXP PROPRIETARY AND CONFIDENTIAL                       */
/*                       SOFTWARE FILE/MODULE HEADER                        */
/*                    Copyright NXP Systems Inc. 2008                       */
/*                            All Rights Reserved                           */
/****************************************************************************/
/*
 * Filename:        tmmodIpTsaGlobalReg.h
 *
 *
 * Description:     Public header file defines register addresses and bit 
 *                  definition for TSA Global configuration Registers such as 
 *                  MCX configuration register and MMIO configuration register.
 *
 *
 * Author:          Suvarna Prasad
 *
 ******************************************************************************/
/* $Id:
 ******************************************************************************/

#ifndef _TMMODIPTSAGLOBALREG_H_
#define _TMMODIPTSAGLOBALREG_H_

/****************************************************************************/
/*                           MCX Configuration Registers                    */
/****************************************************************************/

/* TO define if needed */

/****************************************************************************/
/*                         TSA MMIO Configuration Registers                 */
/****************************************************************************/

/*******************************************/
/* TSA Global Interrupt control registers. */
/*******************************************/

/* This is write only register used to atomically clear a bit in the internal 
 * interrupt enable register. */
#define TSA_INT_CLR_ENABLE                       (TEMPEST_COMMON_MAP + 0x00FD8)

   /* Bit definition */
#define    TSA_MCX_INT_DISABLE                      (1UL<<0)
#define    TSA_TSX_INT_DISABLE                      (1UL<<1)
#define    TSA_TSR_INT_DISABLE                      (1UL<<2)
#define    TSA_TSP_INT_DISABLE                      (1UL<<3)
#define    TSA_VSM_DMA_0_INT_DISABLE                (1UL<<4)
#define    TSA_VSM_DMA_1_INT_DISABLE                (1UL<<5)
#define    TSA_VSM_DMA_2_INT_DISABLE                (1UL<<6)


/* This is write only register used to atomically set a bit in the internal 
 * interrupt enable register. */
#define TSA_INT_SET_ENABLE                       (TEMPEST_COMMON_MAP + 0x00FDC)

   /* Bit definition */
#define    TSA_MCX_INT_ENABLE                       (1UL<<0)
#define    TSA_TSX_INT_ENABLE                       (1UL<<1)
#define    TSA_TSR_INT_ENABLE                       (1UL<<2)
#define    TSA_TSP_INT_ENABLE                       (1UL<<3)
#define    TSA_VSM_DMA_0_INT_ENABLE                 (1UL<<4)
#define    TSA_VSM_DMA_1_INT_ENABLE                 (1UL<<5)
#define    TSA_VSM_DMA_2_INT_ENABLE                 (1UL<<6)


/* This is a read only register used to find the actual interrupt. */ 
#define TSA_INT_STATUS                           (TEMPEST_COMMON_MAP + 0x00FE0)

/* This is a read only register used to find what interrupts are enabled. 
 * Use the TSA_INT_SET_ENABLE and TSA_INT_CLR_ENABLE to alter the internal 
 * interrupt enable register. */
#define TSA_INT_ENABLE                           (TEMPEST_COMMON_MAP + 0x00FE4)

/* This is a write only register used to atomically clear a bit in the internal
 * interrupt status register */
#define TSA_INT_CLR_STATUS                       (TEMPEST_COMMON_MAP + 0x00FE8)


   /* Bit Mask */
#define    TSA_MCX_INT_MASK                         (1UL<<0)
#define    TSA_TSX_INT_MASK                         (1UL<<1)
#define    TSA_TSR_INT_MASK                         (1UL<<2)
#define    TSA_TSP_INT_MASK                         (1UL<<3)
#define    TSA_VSM_DMA_0_INT_MASK                   (1UL<<4)
#define    TSA_VSM_DMA_1_INT_MASK                   (1UL<<5)
#define    TSA_VSM_DMA_2_INT_MASK                   (1UL<<6)
   
#endif /*_TMMODIPTSAGLOBALREG_H_*/
