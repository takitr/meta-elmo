/******************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                    */
/*                        SOFTWARE FILE/MODULE HEADER                         */
/*                    Copyright Conexant Systems Inc. 2006                    */
/*                                 Austin, TX                                 */
/*                            All Rights Reserved                             */
/******************************************************************************/
/*
 * Filename:        tmmodIpStc.h
 *
 *
 * Description:     Public header file defining hardware-specific values (such
 *                  as register addresses, bit definitions, etc.) for the STC
 *                  module.
 *
 *
 * Author:          Srinivasan Venkataraman
 *
 ******************************************************************************/
/* $Id: tmmodIpStc.h 143558 2010-01-30 02:36:12Z gargn $
 ******************************************************************************/

#ifndef _TMMODIPSTC_H_
#define _TMMODIPSTC_H_

/****************************/
/* STC Register Definitions */
/****************************/
#define STC_A                 0
#define STC_B                 1

#define STC_CONTROL_REG(block)      (STC_1W_BASE + ((block)*SIZE_STC_BLOCK) + 0x00)
#define     STC_CONTROL_DIVIDER_MASK            0x0000000E
#define     STC_CONTROL_DIVIDER_SHIFT           1
#define         STC_CONTROL_DIVIDE_27MHZ        (0UL<<1)
#define         STC_CONTROL_DIVIDE_54MHZ        (1UL<<1)
#define     STC_CONTROL_RESET_MASK              0x00000010
#define     STC_CONTROL_RESET_SHIFT             4
#define         STC_CONTROL_NOT_RESET           (0UL<<4)
#define         STC_CONTROL_RESET               (1UL<<4)
#define     STC_CONTROL_PAUSE_MASK              0x00000020
#define     STC_CONTROL_PAUSE_SHIFT             5
#define         STC_CONTROL_RUN                 (0UL<<5)
#define         STC_CONTROL_PAUSE               (1UL<<5)
#define     STC_CONTROL_DIRECTION_MASK          0x00000040
#define     STC_CONTROL_DIRECTION_SHIFT         6
#define         STC_CONTROL_DIRECTION_FORWARD   (0UL<<6)
#define         STC_CONTROL_DIRECTION_REVERSE   (1UL<<6)
#define     STC_CONTROL_FRAC_MODE_MASK          0x00000080
#define     STC_CONTROL_FRAC_MODE_SHIFT         7
#define         STC_CONTROL_FRAC_MODE_INTEGER   (0UL<<7)
#define         STC_CONTROL_FRAC_MODE_FRACTION  (1UL<<7)
#define     STC_CONTROL_INCREMENT_MASK          0x0000FF00
#define     STC_CONTROL_INCREMENT_SHIFT         8
#define     STC_CONTROL_ROLLOVER_MASK           0xFFFF0000
#define     STC_CONTROL_ROLLOVER_SHIFT          16

#define STC_COMMAND_REG(block)      (STC_1W_BASE + ((block)*SIZE_STC_BLOCK) + 0x0C)
#define     STC_COMMAND_VALIDATE_A_MASK          0x00000001
#define     STC_COMMAND_VALIDATE_A_SHIFT         0
#define         STC_VALIDATE_A                   (1UL<<0)
#define     STC_COMMAND_VALIDATE_B_MASK          0x00000002
#define     STC_COMMAND_VALIDATE_B_SHIFT         1
#define         STC_VALIDATE_B                   (1UL<<1)
#define     STC_COMMAND_INVALIDATE_A_MASK        0x00000004
#define     STC_COMMAND_INVALIDATE_A_SHIFT       2
#define         STC_INVALIDATE_A                 (1UL<<2)
#define     STC_COMMAND_INVALIDATE_B_MASK        0x00000008
#define     STC_COMMAND_INVALIDATE_B_SHIFT       3
#define         STC_INVALIDATE_B                 (1UL<<3)
#define     STC_COMMAND_A_CURRENT_MASK           0x00000010
#define     STC_COMMAND_A_CURRENT_SHIFT          4
#define         STC_A_CURRENT                    (1UL<<4)
#define     STC_COMMAND_B_CURRENT_MASK           0x00000020
#define     STC_COMMAND_B_CURRENT_SHIFT          5
#define         STC_B_CURRENT                    (1UL<<5)
#define     STC_COMMAND_VALIDATE_CURRENT_MASK    0x00000040
#define     STC_COMMAND_VALIDATE_CURRENT_SHIFT   6
#define         STC_VALIDATE_CURRENT             (1UL<<6)
#define     STC_COMMAND_INVALIDATE_CURRENT_MASK  0x00000080
#define     STC_COMMAND_INVALIDATE_CURRENT_SHIFT 7
#define         STC_INVALIDATE_CURRENT           (1UL<<7)
#define     STC_COMMAND_VALIDATE_BACKUP_MASK     0x00000100
#define     STC_COMMAND_VALIDATE_BACKUP_SHIFT    8
#define         STC_VALIDATE_BACKUP              (1UL<<9)
#define     STC_COMMAND_INVALIDATE_BACKUP_MASK   0x00000200
#define     STC_COMMAND_INVALIDATE_BACKUP_SHIFT  9
#define         STC_INVALIDATE_BACKUP            (1UL<<9)
#define     STC_COMMAND_VALIDATE_MASK            0x00000400
#define     STC_COMMAND_VALIDATE_SHIFT           10
#define         STC_VALIDATE                     (1UL<<10)
#define     STC_COMMAND_INVALIDATE_MASK          0x00000800
#define     STC_COMMAND_INVALIDATE_SHIFT         11
#define         STC_INVALIDATE                   (1UL<<11)
#define     STC_COMMAND_TOGGLE_CURRENT_MASK      0x00001000
#define     STC_COMMAND_TOGGLE_CURRENT_SHIFT     12
#define         STC_TOGGLE_CURRENT               (1UL<<12)
#define     STC_COMMAND_SET_TIMEBASE_ID_MASK     0x00002000
#define     STC_COMMAND_SET_TIMEBASE_ID_SHIFT    13
#define         STC_SET_TIMEBASE                 (1UL<<13)
#define     STC_COMMAND_BEGIN_DISCONT_MASK       0x00004000
#define     STC_COMMAND_BEGIN_DISCONT_SHIFT      14
#define         STC_BEGIN_DISCONTINUITY          (1UL<<14)
#define     STC_COMMAND_END_DISCONT_MASK         0x00008000
#define     STC_COMMAND_END_DISCONT_SHIFT        15
#define         STC_END_DISCONTINUITY            (1UL<<15)
#define     STC_COMMAND_TIMEBASE_ID_MASK         0x000F0000
#define     STC_COMMAND_TIMEBASE_ID_SHIFT        16

#define STC_STATUS_REG(block)       (STC_1W_BASE + ((block)*SIZE_STC_BLOCK) + 0x0C)
#define     STC_STATUS_VALID_A_MASK              0x00000001
#define     STC_STATUS_VALID_A_SHIFT             0
#define         STC_VALID_A                      (1UL<<0)
#define     STC_STATUS_VALID_B_MASK              0x00000002
#define     STC_STATUS_VALID_B_SHIFT             1
#define         STC_VALID_B                      (1UL<<1)
#define     STC_STATUS_CURRENT_MASK              0x00000004
#define     STC_STATUS_CURRENT_SHIFT             2
#define         STC_STATUS_A_CURRENT             (0UL<<2)
#define         STC_STATUS_B_CURRENT             (1UL<<2)
#define     STC_STATUS_CURRENT_VALID_MASK        0x00000008
#define     STC_STATUS_CURRENT_VALID_SHIFT       3
#define         STC_STATUS_CURRENT_INVALID       (0UL<<3)
#define         STC_STATUS_CURRENT_VALID         (1UL<<3)
#define     STC_STATUS_DISCONTINUITY_MASK        0x00000020
#define     STC_STATUS_DISCONTINUITY_SHIFT       5
#define         STC_DISCONTINUITY_COMPLETE       (0UL<<5)
#define         STC_DISCONTINUITY_VALID          (1UL<<5)
#define     STC_STATUS_TIMEBASE_ID_MASK          0x000F0000
#define     STC_STATUS_TIMEBASE_ID_SHIFT         16

#define STC_A_LOW_REG(block)        (STC_4W_BASE + ((block)*SIZE_STC_BLOCK) + 0x10)
#define     STC_LOW_MASK                         0xFFFFFFFF
#define     STC_LOW_SHIFT                        0
#define STC_A_HIGH_REG(block)       (STC_4W_BASE + ((block)*SIZE_STC_BLOCK) + 0x14)
#define     STC_HIGH_MASK                        0x00000001
#define     STC_HIGH_SHIFT                       0
#define STC_A_EXT_REG(block)        (STC_4W_BASE + ((block)*SIZE_STC_BLOCK) + 0x18)
#define     STC_EXT_MASK                         0x000001FF
#define     STC_EXT_SHIFT                        0

/* Following is an alias for STC_COMMAND_REG (write) and STC_STATUS_REG (read) but contains
   one additional bit to indicate whether this particular STC is valid or not */
#define STC_A_CMD_STATUS_REG(block) (STC_4W_BASE + ((block)*SIZE_STC_BLOCK) + 0x1C)
#define     STC_STATUS_VALID_MASK                0x00000010
#define     STC_STATUS_VALID_SHIFT               4
#define         STC_STATUS_INVALID               (0UL<<4)
#define         STC_STATUS_VALID                 (1UL<<4)

#define STC_B_LOW_REG(block)        (STC_4W_BASE + ((block)*SIZE_STC_BLOCK) + 0x20)
#define STC_B_HIGH_REG(block)       (STC_4W_BASE + ((block)*SIZE_STC_BLOCK) + 0x24)
#define STC_B_EXT_REG(block)        (STC_4W_BASE + ((block)*SIZE_STC_BLOCK) + 0x28)

#define STC_A_LOW_REG_1W(block)        (STC_1W_BASE + ((block)*SIZE_STC_BLOCK) + 0x10)
#define STC_A_HIGH_REG_1W(block)       (STC_1W_BASE + ((block)*SIZE_STC_BLOCK) + 0x14)
#define STC_A_EXT_REG_1W(block)        (STC_1W_BASE + ((block)*SIZE_STC_BLOCK) + 0x18)


#define STC_B_LOW_REG_1W(block)        (STC_1W_BASE + ((block)*SIZE_STC_BLOCK) + 0x20)
#define STC_B_HIGH_REG_1W(block)       (STC_1W_BASE + ((block)*SIZE_STC_BLOCK) + 0x24)
#define STC_B_EXT_REG_1W(block)        (STC_1W_BASE + ((block)*SIZE_STC_BLOCK) + 0x28)

/* Following is an alias for STC_COMMAND_REG (write) and STC_STATUS_REG (read). As for
   STC_A_CMD_STATUS_REG, this register also contains the additional valid/invalid
   status bit */
#define STC_B_CMD_STATUS_REG(block) (STC_4W_BASE + ((block)*SIZE_STC_BLOCK) + 0x2C)

/* Alternative register address definitions containing A/B parameter */
#define STC_LOW_REG(block, stc)        (STC_4W_BASE + ((stc)*STC_A_B_REG_OFFSET) + ((block)*SIZE_STC_BLOCK) + 0x10)
#define STC_HIGH_REG(block, stc)       (STC_4W_BASE + ((stc)*STC_A_B_REG_OFFSET) + ((block)*SIZE_STC_BLOCK) + 0x14)
#define STC_EXT_REG(block, stc)        (STC_4W_BASE + ((stc)*STC_A_B_REG_OFFSET) + ((block)*SIZE_STC_BLOCK) + 0x18)
#define STC_CMD_STATUS_REG(block, stc) (STC_4W_BASE + ((stc)*STC_A_B_REG_OFFSET) + ((block)*SIZE_STC_BLOCK) + 0x1C)

#define STC_DESC_USAGE_VAL_NOT_IN_USE               0 /*STC not in use*/
#define STC_DESC_USAGE_VAL_UPDATE                   1 /*Update STC, but do not send snapshot to host*/ 
#define STC_DESC_USAGE_VAL_SEND_SNAPSHOT            2 /*Do not update STC, but send snapshot to host*/
#define STC_DESC_USAGE_VAL_UPDATE_SEND_SNAPSHOT     3 /*Update STC and send snapshot to host*/
#define STC_DESC_USAGE_MASK                         0x3
#define STC_DESC_USAGE_SHIFT                        0
#define STC_DESC_STC_INDEX_MASK                     0x1C
#define STC_DESC_STC_INDEX_SHIFT                    2
#define STC_DESC_PCR_INDEX_MASK                     0xE0
#define STC_DESC_PCR_INDEX_SHIFT                    5
#define STC_DESC_N0_BITS_PER_STC_SETUP              8
#define STC_CMD_MASK                                0xFFFFFFFF
#define STC_DESC_MASK                               0xFFFFFFFF
#endif /* _TMMODIPSTC_H_ */

/*******************************************************************************
 * Modifications:
 * $Log$
 *
 ******************************************************************************/

