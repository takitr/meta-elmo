/******************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                    */
/*                        SOFTWARE FILE/MODULE HEADER                         */
/*                Copyright Conexant Systems, Inc. 2006-2008                  */
/*                                 Austin, TX                                 */
/*                            All Rights Reserved                             */
/******************************************************************************/
/*
 * Filename:        tmmodIpTspKT.h
 *
 *
 * Description:     Public header file defining hardware-specific values (such
 *                  as register addresses, bit definitions, etc.) for TSP 
 *                  KEY TABLE Unit.
 *
 *
 * Author:          Srinivasan Venkataraman
 *
 ******************************************************************************/
/* $Id: tmmodIpTspKT.h 196285 2011-03-07 11:52:32Z guduruj $
 ******************************************************************************/

#ifndef _TMMODIPTSPKT_H_
#define _TMMODIPTSPKT_H_


/*********************/
/* TSP Key Table definitions   */
/*********************/

#define TSA_KT_NUM_KEY_FOBS            192
#define TSA_KT_NUM_KEY_TAGS            384

#define TSA_KEY_TABLE_CTRL_BASE        (TSA_KEY_TABLE_BASE + 0x4000)

#define TSA_KEY_TABLE_FOB_BASE         (0)
#define TSA_KEY_TABLE_TAG_BASE         (0x800)
#define TSA_KEY_TABLE_DATUM_BASE       (0x1000)

/* TSA KT Control Register */
#define TSA_KT_CTRL_REG              ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE  + 0x00))
#define    TSA_KT_ENABLE                     (1UL << 0)  /*     0 = Disable. The Key Table is held in reset; the entire host interface 
                                                                    is still active but the other interfaces are disabled. Disabling will 
                                                                    not take effect until any outstanding requests are completed. 
                                                                1 = Enable TSA Key Table*/
#define    TSA_KT_HIF_ERROR_MODE             (1UL << 1)  /*     0 = Disable host interface bus errors
                                                                1 = Enable host interface bus errors (e.g. attempted access to registers 
                                                                    that disabled by DIS_MMIO) */
#define    TSA_KT_TKW_ERROR_MODE             (1UL << 2)  /*     Trusted Key Write Interface Error Mode
                                                                0 = Ignore illegal TKW writes and return dummy data for illegal TKW reads.
                                                                1 = Assert error signal on bus for illegal accesses */
#define    TSA_KT_TKR_ERROR_MODE             (1UL << 3)  /*     Trusted Key Read Interface Error Mode
                                                                0 = Return dummy data for illegal TKR reads.
                                                                1 = Assert error signal on bus for illegal accesses */

/* TSA KT Status Register */
#define TSA_KT_STATUS_REG            ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE  + 0x04))
#define    TSA_KT_STATUS_BUSY                (1UL << 0)  /*   TSA_KRN_KT Busy. Indicates whether the TSA_KRN_KT is busy 
                                                            servicing other requests or is performing an internal reset.
                                                            0 = Idle
                                                            1 = Busy */

/* TSA KT Feature Locks Register */
#define TSA_KT_FEATURE_LOCKS         ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE  + 0x10)
#define    TSA_KT_FEATURE_ACPU_KEY_READ            (1UL << 0)
#define    TSA_KT_FEATURE_ACPU_KEY_WRITE           (1UL << 1)
#define    TSA_KT_FEATURE_PCPU_KEY_READ            (1UL << 2)
#define    TSA_KT_FEATURE_PCPU_KEY_WRITE           (1UL << 3)
#define    TSA_KT_FEATURE_ACPU_SWITCH_READ         (1UL << 4)
#define    TSA_KT_FEATURE_ACPU_SWITCH_WRITE        (1UL << 5)
#define    TSA_KT_FEATURE_PCPU_SWITCH_READ         (1UL << 6)
#define    TSA_KT_FEATURE_PCPU_SWITCH_WRITE        (1UL << 7)
#define    TSA_KT_FEATURE_PROXY_TKW_READ           (1UL << 8)
#define    TSA_KT_FEATURE_PROXY_TKW_WRITE          (1UL << 9)
#define    TSA_KT_FEATURE_ESP_TKW_READ             (1UL << 10)
#define    TSA_KT_FEATURE_ESP_TKW_WRITE            (1UL << 11)
#define    TSA_KT_FEATURE_CRYPTO_TKW_READ          (1UL << 12)
#define    TSA_KT_FEATURE_CRYPTO_TKW_WRITE         (1UL << 13)
#define    TSA_KT_FEATURE_AVK_ACCESS               (1UL << 14)
#define    TSA_KT_FEATURE_NSK_ACCESS               (1UL << 15)
#define    TSA_KT_FEATURE_KEYCTRL_TKW_READ         (1UL << 16)
#define    TSA_KT_FEATURE_KEYCTRL_TKW_WRITE        (1UL << 17)
#define    TSA_KT_FEATURE_UNSPEC_REQ_ACCESS        (1UL << 18)
#define    TSA_KT_FEATURE_ENFORCE_HIF_AUTH_TBL_A   (1UL << 19)
#define    TSA_KT_FEATURE_ENFORCE_TKW_AUTH_TBL_B   (1UL << 20)
#define    TSA_KT_FEATURE_ENFORCE_TKW_AUTH_TBL_C   (1UL << 21)
#define    TSA_KT_FEATURE_ENFORCE_TKR_AUTH_TBL_D   (1UL << 22)
#define    TSA_KT_FEATURE_ENFORCE_TKR_AUTH_TBL_E   (1UL << 23)
#define    TSA_KT_FEATURE_ENFORCE_TKR_AUTH_TBL_F   (1UL << 24)
#define    TSA_KT_FEATURE_ENFORCE_TKR_AUTH_TBL_G   (1UL << 25)
#define    TSA_KT_FEATURE_ENFORCE_TKR_AUTH_TBL_H   (1UL << 26)
#define    TSA_KT_FEATURE_ACPU_HIF_WRITE           (1UL << 31)

/* TSA KT Interrupt Clear Enable Register (Enables H/W interrupts to the HOST) */
#define TSA_KT_INT_CLR_ENABLE_REG      ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE + 0xFD8))
#define    TSA_KT_INT_CLR_ENABLE_MASK          (0xFFFFFFFF)

/* TSA KT Interrupt Set Enable Register */
#define TSA_KT_INT_SET_ENABLE_REG      ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE + 0xFDC))
#define    TSA_KT_INT_SET_ENABLE_MASK          (0xFFFFFFFF)

/* TSA KT Interrupt Status Register */
#define TSA_KT_INT_STATUS_REG          ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE + 0xFE0))
#define    TSA_KT_INT_UNAUTH_HOST_ACCESS       (1UL << 0)
#define    TSA_KT_INT_UNAUTH_KEY_WR_ACCESS     (1UL << 1)
#define    TSA_KT_INT_UNAUTH_KEY_RD_ACCESS     (1UL << 2)
#define    TSA_KT_INT_KEY_TABLE_RESETS         (1UL << 3)

/* TSA KT Interrupt Enable Register */
#define TSA_KT_INT_ENABLE_REG          ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE + 0xFE4))
#define    TSA_KT_INT_ENABLE_REG_MASK          (0xFFFFFFFF)

/* TSA KT Interrupt Clear Status Register */
#define TSA_KT_INT_CLR_STATUS_REG      ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE + 0xFE8))
#define    TSA_KT_INT_CLR_STATUS_REG_MASK      (0xFFFFFFFF)

/* TSA KT Interrupt Set Status Register */
#define TSA_KT_INT_SET_STATUS_REG      ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE + 0xFEC))
#define    TSA_KT_INT_CLR_STATUS_REG_MASK      (0xFFFFFFFF)

/* TSA KT Soft Reset Register */
#define TSA_KT_SOFT_RESET_REG          ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE + 0xFF0))
#define    TSA_KT_SOFT_RESET                   (1UL << 0)

#if 0
/* TSA KT Disable MMIO Register */
#define TSA_KT_DISABLE_MMIO_REG        ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE + 0xFF4))
#define    TSA_KT_DISABLE_MMIO                 (1UL << 0)

/* TSA KT Extended Module ID Register */
#define TSA_KT_EXT_MODULE_ID_REG       ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE + 0xFF8))

/* TSA KT Module ID Register */
#define TSA_KT_MODULE_ID_REG           ((volatile HW_DWORD *)(TSA_KEY_TABLE_CTRL_BASE + 0xFFC))
#define    TSA_KT_MODULE_ID_APERTURE_SIZE_POSN        (0)
#define    TSA_KT_MODULE_ID_APERTURE_SIZE_MASK        (0x000000FF)
#define    TSA_KT_MODULE_ID_MINOR_REV_POSN            (8)
#define    TSA_KT_MODULE_ID_MINOR_REV_MASK            (0x00000F00)
#define    TSA_KT_MODULE_ID_MAJOR_REV_POSN            (12)
#define    TSA_KT_MODULE_ID_MAJOR_REV_MASK            (0x0000F000)
#define    TSA_KT_MODULE_ID_MODULE_IDENTIFIER_POSN    (16)
#define    TSA_KT_MODULE_ID_MODULE_IDENTIFIER_MASK    (0xFFFF0000)
#endif

/* TSA KT Key Fob Word */
#define TSA_KT_KEYFOB_WORD(FobIdx, WordIdx)     ((volatile HW_DWORD *)(TSA_KEY_TABLE_BASE + TSA_KEY_TABLE_FOB_BASE + (FobIdx * 8) + (WordIdx * 4)))
#define    TSA_KT_KEYFOB_KEY_DATUM_IDX_PART_A_POSN    (0)
#define    TSA_KT_KEYFOB_KEY_DATUM_IDX_PART_A_MASK    (0x00000FFF)
#define    TSA_KT_KEYFOB_KEY_DATUM_IDX_PART_B_POSN    (12)
#define    TSA_KT_KEYFOB_KEY_DATUM_IDX_PART_B_MASK    (0x00FFF000)
#define    TSA_KT_KEYFOB_TYPE_POSN                    (24)
#define    TSA_KT_KEYFOB_TYPE_MASK                    (0x0F000000)
#define    TSA_KT_KEYFOB_SOURCE_ID_POSN               (28)
#define    TSA_KT_KEYFOB_SOURCE_ID_MASK               (0xF0000000)

#define    TSA_KT_KEYFOB_PART_VALID_0                 (1UL << 24)
#define    TSA_KT_KEYFOB_PART_VALID_1                 (1UL << 25)
#define    TSA_KT_KEYFOB_PART_VALID_2                 (1UL << 26)
#define    TSA_KT_KEYFOB_PART_VALID_3                 (1UL << 27)
#define    TSA_KT_KEYFOB_PRIVILEGED                   (1UL << 29)    /* Privileged Fob
                                                                        0 = Fob can be accessed by ACPU or PCPU
                                                                        1 = Fob can only be accessed by PCP */
                                                         
#define    TSA_KT_KEYFOB_PENDING                      (1UL << 30)    /* 0 = Not pending
                                                                        1 = Word 0 of a two-word Key Fob has been written 
                                                                            with KEY_FOB_VALID=1 but Word 1 has not yet 
                                                                            been written. */
#define    TSA_KT_KEYFOB_VALID                        (1UL << 31)    /* 0 = Key Fob is invalid or pending (read), No effect (write)
                                                                        1 = Key Fob is valid (read), Invalidate Key Fob (write) */

/* TSA KT Key Tag */
#define TSA_KT_KEY_TAG(TagIdx)                 (volatile HW_DWORD *)(TSA_KEY_TABLE_BASE + TSA_KEY_TABLE_TAG_BASE + (TagIdx * 4))
#define    TSA_KT_KEY_DATUM_TYPE_POSN              (0)
#define    TSA_KT_KEY_DATUM_TYPE_MASK              (0x0000003F)
#define    TSA_KT_KEY_DATUM_VALID                  (1UL << 8) /*  Valid
                                                                  0 = Invalid (read), No effect (write)
                                                                  1 = Valid (read), Invalidate (write) */
#define    TSA_KT_KEY_TAG_VALID                    (1UL << 9) /*  Valid
                                                                  0 = Invalid (read), No effect (write)
                                                                  1 = Valid (read), Invalidate (write) */
#define    TSA_KT_KEY_TAG_DIRTY                    (1UL << 10)/*  Dirty
                                                                  0 = Clean (read), No effect (write)
                                                                  1 = Dirty (read), Clear Dirty bit (write) */

/* Key Fob Key Datum Word */
#define TSA_KT_KEYFOB_KEYDATUM_WORD(FobIdx, DatumIdx, KeyWordIdx)    ((volatile HW_DWORD *)(TSA_KEY_TABLE_BASE + TSA_KEY_TABLE_DATUM_BASE  + (FobIdx * 64) + (DatumIdx * 16) + (KeyWordIdx * 4)))
#define TSA_KT_KEYFOB_KEYDATUM_WORD_MASK                              (0xFFFFFFFF)

#endif /*_TMMODIPTSPKT_H_*/
