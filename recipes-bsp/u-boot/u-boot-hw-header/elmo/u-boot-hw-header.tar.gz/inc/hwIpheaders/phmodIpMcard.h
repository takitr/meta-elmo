 ///////////////////////////////////////////////////////////////////// 
//                                                                  / 
// (c) NXP B.V 2009                                                / 
//                                                                  / 
// All rights are reserved. Reproduction in whole or in part is     / 
// prohibited without the prior written consent of the copy-right   / 
// owner.                                                           / 
// The information presented in this document does not form part of / 
// any quotation or contract, is believed to be accurate and        / 
// reliable and may be changed without notice. No liability will be / 
// accepted by the publisher for any consequence of its use.        / 
// Publication thereof does not convey nor imply any license under  / 
// patent- or other industrial or intellectual property rights.     / 
 ///////////////////////////////////////////////////////////////////// 
 
/*! 
 *  @brief Header file for 
mcard *  @file phmodIpMcard.h *
 *  <pre>
 *  $Author: rathd $
 *  $Revision: 157947 $
 *  $Date: 2010-04-27 00:51:22 -0500 (Tue, 27 Apr 2010) $
 *
 *  Revision history
 *  $Log: $
 *  
 *
 *  $KeysEnd$
 *  </pre>
 *
 */ 


#ifndef PHMODIPMCARD_H
#define PHMODIPMCARD_H
	
	
	#define MCARD_XMTR_REG_REG  (MCARD_BASE + 0x28)
	#define MCARD_XMTR_LENGTH_BIT_RW (0x07fff << 16)
	#define MCARD_XMTR_LENGTH_BIT_SHIFT 16
	#define MCARD_XMTR_DA_BIT_RW (0x01 << 6)
	#define MCARD_XMTR_DA_BIT_SHIFT 6
	#define MCARD_XMTR_DA_BIT_VAL0 0x00
	#define MCARD_XMTR_DA_BIT_VAL1 0x01
	#define MCARD_XMTR_HR_BIT_RW (0x01 << 5)
	#define MCARD_XMTR_HR_BIT_SHIFT 5
	#define MCARD_XMTR_HR_BIT_VAL0 0x00
	#define MCARD_XMTR_HR_BIT_VAL1 0x01
	#define MCARD_XMTR_EXT_CHAN_BIT_RW (0x01 << 4)
	#define MCARD_XMTR_EXT_CHAN_BIT_SHIFT 4
	#define MCARD_XMTR_EXT_CHAN_BIT_VAL0 0x00
	#define MCARD_XMTR_EXT_CHAN_BIT_VAL1 0x01
	#define MCARD_XMTR_FIRST_BIT_RW (0x01 << 3)
	#define MCARD_XMTR_FIRST_BIT_SHIFT 3
	#define MCARD_XMTR_FIRST_BIT_VAL0 0x00
	#define MCARD_XMTR_FIRST_BIT_VAL1 0x01
	#define MCARD_XMTR_LAST_BIT_RW (0x01 << 2)
	#define MCARD_XMTR_LAST_BIT_SHIFT 2
	#define MCARD_XMTR_LAST_BIT_VAL0 0x00
	#define MCARD_XMTR_LAST_BIT_VAL1 0x01
	#define MCARD_XMTR_ERR_BIT_RW (0x01 << 1)
	#define MCARD_XMTR_ERR_BIT_SHIFT 1
	#define MCARD_XMTR_ERR_BIT_VAL0 0x00
	#define MCARD_XMTR_ERR_BIT_VAL1 0x01
	#define MCARD_RCVR_REG_REG  (MCARD_BASE + 0x2c)
	#define MCARD_RCVR_LENGTH_BIT_RW (0x07fff << 16)
	#define MCARD_RCVR_LENGTH_BIT_SHIFT 16
	#define MCARD_RCVR_DA_BIT_RW (0x01 << 7)
	#define MCARD_RCVR_DA_BIT_SHIFT 7
	#define MCARD_RCVR_DA_BIT_VAL0 0x00
	#define MCARD_RCVR_DA_BIT_VAL1 0x01
	#define MCARD_RCVR_CR_BIT_RW (0x01 << 6)
	#define MCARD_RCVR_CR_BIT_SHIFT 6
	#define MCARD_RCVR_CR_BIT_VAL0 0x00
	#define MCARD_RCVR_CR_BIT_VAL1 0x01
	#define MCARD_RCVR_EXT_CHAN_BIT_RW (0x01 << 5)
	#define MCARD_RCVR_EXT_CHAN_BIT_SHIFT 5
	#define MCARD_RCVR_EXT_CHAN_BIT_VAL0 0x00
	#define MCARD_RCVR_EXT_CHAN_BIT_VAL1 0x01
	#define MCARD_RCVR_FIRST_BIT_RW (0x01 << 4)
	#define MCARD_RCVR_FIRST_BIT_SHIFT 4
	#define MCARD_RCVR_FIRST_BIT_VAL0 0x00
	#define MCARD_RCVR_FIRST_BIT_VAL1 0x01
	#define MCARD_RCVR_LAST_BIT_RW (0x01 << 3)
	#define MCARD_RCVR_LAST_BIT_SHIFT 3
	#define MCARD_RCVR_LAST_BIT_VAL0 0x00
	#define MCARD_RCVR_LAST_BIT_VAL1 0x01
	#define MCARD_RCVR_ERR_BIT_RW (0x01 << 1)
	#define MCARD_RCVR_ERR_BIT_SHIFT 1
	#define MCARD_RCVR_ERR_BIT_VAL0 0x00
	#define MCARD_RCVR_ERR_BIT_VAL1 0x01
	#define MCARD_RCVR_LSB_BIT_RW (0x01 << 0)
	#define MCARD_RCVR_LSB_BIT_SHIFT 0
	#define MCARD_RCVR_LSB_BIT_VAL0 0x00
	#define MCARD_RCVR_LSB_BIT_VAL1 0x01
	#define MCARD_IRQ_MSK_REG_REG  (MCARD_BASE + 0x30)
	#define MCARD_IRQ_MSK_RXINVALID_LENGTH_BIT_RW (0x01 << 10)
	#define MCARD_IRQ_MSK_RXINVALID_LENGTH_BIT_SHIFT 10
	#define MCARD_IRQ_MSK_RXINVALID_LENGTH_BIT_VAL0 0x00
	#define MCARD_IRQ_MSK_RXINVALID_LENGTH_BIT_VAL1 0x01
	#define MCARD_IRQ_MSK_DST_LINEAR_BUF_FULL_BIT_RW (0x01 << 9)
	#define MCARD_IRQ_MSK_DST_LINEAR_BUF_FULL_BIT_SHIFT 9
	#define MCARD_IRQ_MSK_DST_LINEAR_BUF_FULL_BIT_VAL0 0x00
	#define MCARD_IRQ_MSK_DST_LINEAR_BUF_FULL_BIT_VAL1 0x01
	#define MCARD_IRQ_MSK_DST_THRSH_CNT_BIT_RW (0x01 << 8)
	#define MCARD_IRQ_MSK_DST_THRSH_CNT_BIT_SHIFT 8
	#define MCARD_IRQ_MSK_DST_THRSH_CNT_BIT_VAL0 0x00
	#define MCARD_IRQ_MSK_DST_THRSH_CNT_BIT_VAL1 0x01
	#define MCARD_IRQ_MSK_SRC_DMA_HERR_BIT_RW (0x01 << 7)
	#define MCARD_IRQ_MSK_SRC_DMA_HERR_BIT_SHIFT 7
	#define MCARD_IRQ_MSK_SRC_DMA_HERR_BIT_VAL0 0x00
	#define MCARD_IRQ_MSK_SRC_DMA_HERR_BIT_VAL1 0x01
	#define MCARD_IRQ_MSK_DST_DMA_HERR_BIT_RW (0x01 << 6)
	#define MCARD_IRQ_MSK_DST_DMA_HERR_BIT_SHIFT 6
	#define MCARD_IRQ_MSK_DST_DMA_HERR_BIT_VAL0 0x00
	#define MCARD_IRQ_MSK_DST_DMA_HERR_BIT_VAL1 0x01
	#define MCARD_IRQ_MSK_RCVR_COMPLETE_BIT_RW (0x01 << 4)
	#define MCARD_IRQ_MSK_RCVR_COMPLETE_BIT_SHIFT 4
	#define MCARD_IRQ_MSK_RCVR_COMPLETE_BIT_VAL0 0x00
	#define MCARD_IRQ_MSK_RCVR_COMPLETE_BIT_VAL1 0x01
	#define MCARD_IRQ_MSK_RCVR_SYNC_ERR_BIT_RW (0x01 << 3)
	#define MCARD_IRQ_MSK_RCVR_SYNC_ERR_BIT_SHIFT 3
	#define MCARD_IRQ_MSK_RCVR_SYNC_ERR_BIT_VAL0 0x00
	#define MCARD_IRQ_MSK_RCVR_SYNC_ERR_BIT_VAL1 0x01
	#define MCARD_IRQ_MSK_RCVR_HOLD_OFF_BIT_RW (0x01 << 2)
	#define MCARD_IRQ_MSK_RCVR_HOLD_OFF_BIT_SHIFT 2
	#define MCARD_IRQ_MSK_RCVR_HOLD_OFF_BIT_VAL0 0x00
	#define MCARD_IRQ_MSK_RCVR_HOLD_OFF_BIT_VAL1 0x01
	#define MCARD_IRQ_MSK_RCV_ERR_BIT_RW (0x01 << 1)
	#define MCARD_IRQ_MSK_RCV_ERR_BIT_SHIFT 1
	#define MCARD_IRQ_MSK_RCV_ERR_BIT_VAL0 0x00
	#define MCARD_IRQ_MSK_RCV_ERR_BIT_VAL1 0x01
	#define MCARD_IRQ_MSK_XMT_COMPLETE_BIT_RW (0x01 << 0)
	#define MCARD_IRQ_MSK_XMT_COMPLETE_BIT_SHIFT 0
	#define MCARD_IRQ_MSK_XMT_COMPLETE_BIT_VAL0 0x00
	#define MCARD_IRQ_MSK_XMT_COMPLETE_BIT_VAL1 0x01
	#define MCARD_IRQ_STAT_REG_REG  (MCARD_BASE + 0x34)
	#define MCARD_IRQ_STAT_RXINVALID_LENGTH_BIT_RW (0x01 << 10)
	#define MCARD_IRQ_STAT_RXINVALID_LENGTH_BIT_SHIFT 10
	#define MCARD_IRQ_STAT_RXINVALID_LENGTH_BIT_VAL0 0x00
	#define MCARD_IRQ_STAT_RXINVALID_LENGTH_BIT_VAL1 0x01
	#define MCARD_IRQ_STAT_DST_LINEAR_BUF_FULL_BIT_RW (0x01 << 9)
	#define MCARD_IRQ_STAT_DST_LINEAR_BUF_FULL_BIT_SHIFT 9
	#define MCARD_IRQ_STAT_DST_LINEAR_BUF_FULL_BIT_VAL0 0x00
	#define MCARD_IRQ_STAT_DST_LINEAR_BUF_FULL_BIT_VAL1 0x01
	#define MCARD_IRQ_STAT_DST_THRSH_CNT_BIT_RW (0x01 << 8)
	#define MCARD_IRQ_STAT_DST_THRSH_CNT_BIT_SHIFT 8
	#define MCARD_IRQ_STAT_DST_THRSH_CNT_BIT_VAL0 0x00
	#define MCARD_IRQ_STAT_DST_THRSH_CNT_BIT_VAL1 0x01
	#define MCARD_IRQ_STAT_SRC_DMA_HERR_BIT_RW (0x01 << 7)
	#define MCARD_IRQ_STAT_SRC_DMA_HERR_BIT_SHIFT 7
	#define MCARD_IRQ_STAT_SRC_DMA_HERR_BIT_VAL0 0x00
	#define MCARD_IRQ_STAT_SRC_DMA_HERR_BIT_VAL1 0x01
	#define MCARD_IRQ_STAT_DST_DMA_HERR_BIT_RW (0x01 << 6)
	#define MCARD_IRQ_STAT_DST_DMA_HERR_BIT_SHIFT 6
	#define MCARD_IRQ_STAT_DST_DMA_HERR_BIT_VAL0 0x00
	#define MCARD_IRQ_STAT_DST_DMA_HERR_BIT_VAL1 0x01
	#define MCARD_IRQ_STAT_RCVR_COMPLETE_BIT_RW (0x01 << 4)
	#define MCARD_IRQ_STAT_RCVR_COMPLETE_BIT_SHIFT 4
	#define MCARD_IRQ_STAT_RCVR_COMPLETE_BIT_VAL0 0x00
	#define MCARD_IRQ_STAT_RCVR_COMPLETE_BIT_VAL1 0x01
	#define MCARD_IRQ_STAT_RCVR_SYNC_ERR_BIT_RW (0x01 << 3)
	#define MCARD_IRQ_STAT_RCVR_SYNC_ERR_BIT_SHIFT 3
	#define MCARD_IRQ_STAT_RCVR_SYNC_ERR_BIT_VAL0 0x00
	#define MCARD_IRQ_STAT_RCVR_SYNC_ERR_BIT_VAL1 0x01
	#define MCARD_IRQ_STAT_RCVR_HOLD_OFF_BIT_RW (0x01 << 2)
	#define MCARD_IRQ_STAT_RCVR_HOLD_OFF_BIT_SHIFT 2
	#define MCARD_IRQ_STAT_RCVR_HOLD_OFF_BIT_VAL0 0x00
	#define MCARD_IRQ_STAT_RCVR_HOLD_OFF_BIT_VAL1 0x01
	#define MCARD_IRQ_STAT_RCV_ERR_BIT_RW (0x01 << 1)
	#define MCARD_IRQ_STAT_RCV_ERR_BIT_SHIFT 1
	#define MCARD_IRQ_STAT_RCV_ERR_BIT_VAL0 0x00
	#define MCARD_IRQ_STAT_RCV_ERR_BIT_VAL1 0x01
	#define MCARD_IRQ_STAT_XMT_COMPLETE_BIT_RW (0x01 << 0)
	#define MCARD_IRQ_STAT_XMT_COMPLETE_BIT_SHIFT 0
	#define MCARD_IRQ_STAT_XMT_COMPLETE_BIT_VAL0 0x00
	#define MCARD_IRQ_STAT_XMT_COMPLETE_BIT_VAL1 0x01
	#define MCARD_SRC_DMA_CTRL_REG_REG  (MCARD_BASE + 0x38)
	#define MCARD_SRC_DMA_CTRL_CTRL_RW (0x01 << 0)
	#define MCARD_SRC_DMA_CTRL_CTRL_SHIFT 0
	#define MCARD_SRC_DMA_CTRL_CTRL_VAL0 0x00
	#define MCARD_SRC_DMA_CTRL_CTRL_VAL1 0x01
	#define MCARD_SRC_DMA_HA_ADDR_REG_REG  (MCARD_BASE + 0x3c)
	#define MCARD_SRC_DMA_HA_ADDR_HA_ADDR_RW (0x07fffffff << 0)
	#define MCARD_SRC_DMA_HA_ADDR_HA_ADDR_SHIFT 0
	#define MCARD_SRC_DMA_LENGTH_REG_REG  (MCARD_BASE + 0x40)
	#define MCARD_SRC_DMA_LENGTH_LENGTH_RW (0x01fff << 0)
	#define MCARD_SRC_DMA_LENGTH_LENGTH_SHIFT 0
	#define MCARD_DRC_DMA_CTRL_REG_REG  (MCARD_BASE + 0x44)
	#define MCARD_DRC_DMA_CTRL_THRESH_COUNT_RW (0x07fff << 16)
	#define MCARD_DRC_DMA_CTRL_THRESH_COUNT_SHIFT 16
	#define MCARD_DRC_DMA_CTRL_LNBUF_SIZE_RW (0x01 << 4)
	#define MCARD_DRC_DMA_CTRL_LNBUF_SIZE_SHIFT 4
	#define MCARD_DRC_DMA_CTRL_LNBUF_SIZE_VAL0 0x00
	#define MCARD_DRC_DMA_CTRL_LNBUF_SIZE_VAL1 0x01
	#define MCARD_DRC_DMA_CTRL_LNBUF_CTRL_BIT_RW (0x01 << 1)
	#define MCARD_DRC_DMA_CTRL_LNBUF_CTRL_BIT_SHIFT 1
	#define MCARD_DRC_DMA_CTRL_LNBUF_CTRL_BIT_VAL0 0x00
	#define MCARD_DRC_DMA_CTRL_LNBUF_CTRL_BIT_VAL1 0x01
	#define MCARD_DRC_DMA_HA_ADDR_REG_REG  (MCARD_BASE + 0x48)
	#define MCARD_DRC_DMA_HA_ADDR_HA_ADDR_RW (0x07fffffff << 0)
	#define MCARD_DRC_DMA_HA_ADDR_HA_ADDR_SHIFT 0
	#define MCARD_DRC_DMA_LENGTH_REG_REG  (MCARD_BASE + 0x4c)
	#define MCARD_DRC_DMA_LENGTH_LENGTH_RW (0x01fff << 0)
	#define MCARD_DRC_DMA_LENGTH_LENGTH_SHIFT 0
	#define MCARD_LNBUF_WR_PTR_REG_REG  (MCARD_BASE + 0xd4)
	#define MCARD_LNBUF_WR_PTR_WR_PTR_R (0x07fffffff << 0)
	#define MCARD_LNBUF_WR_PTR_WR_PTR_SHIFT 0
	#define MCARD_LNBUF_RD_PTR_REG_REG  (MCARD_BASE + 0xd8)
	#define MCARD_LNBUF_RD_PTR_RD_PTR_RW (0x07fffffff << 0)
	#define MCARD_LNBUF_RD_PTR_RD_PTR_SHIFT 0
	#define MCARD_CTRL_REG_REG  (MCARD_BASE + 0xe0)
	#define MCARD_CTRL_MCARD_REMOVED_RW (0x01 << 4)
	#define MCARD_CTRL_MCARD_REMOVED_SHIFT 4
	#define MCARD_CTRL_MCARD_REMOVED_VAL0 0x00
	#define MCARD_CTRL_MCARD_REMOVED_VAL1 0x01
	#define MCARD_CTRL_HR_CHK_DIS_RW (0x01 << 3)
	#define MCARD_CTRL_HR_CHK_DIS_SHIFT 3
	#define MCARD_CTRL_HR_CHK_DIS_VAL0 0x00
	#define MCARD_CTRL_HR_CHK_DIS_VAL1 0x01
	#define MCARD_CTRL_SW_RST_RW (0x01 << 2)
	#define MCARD_CTRL_SW_RST_SHIFT 2
	#define MCARD_CTRL_SW_RST_VAL0 0x00
	#define MCARD_CTRL_SW_RST_VAL1 0x01
	#define MCARD_CTRL_SCLK_EN_RW (0x01 << 1)
	#define MCARD_CTRL_SCLK_EN_SHIFT 1
	#define MCARD_CTRL_SCLK_EN_VAL0 0x00
	#define MCARD_CTRL_SCLK_EN_VAL1 0x01
	#define MCARD_CTRL_CARD_EN_RW (0x01 << 0)
	#define MCARD_CTRL_CARD_EN_SHIFT 0
	#define MCARD_CTRL_CARD_EN_VAL0 0x00
	#define MCARD_CTRL_CARD_EN_VAL1 0x01
	#define MCARD_INIT_WAIT_TIME_REG_REG  (MCARD_BASE + 0xe4)
	#define MCARD_INIT_WAIT_TIME_DEF_VALUE_RW (0x03ff << 0)
	#define MCARD_INIT_WAIT_TIME_DEF_VALUE_SHIFT 0
	#define MCARD_MID_REG_REG  (MCARD_BASE + 0xffc)
	#define MCARD_MID_MID_R (0x07fff << 16)
	#define MCARD_MID_MID_SHIFT 16
	
/* -------------------------------------------------------------
-------------------CONEXANT DEFINES ----------------------------
---------------------------------------------------------------*/


#define MCARD_CTRL_BASE_ADDR(x)      MCARD_BASE
#define MCARD_TSMUX_BASE(x)           0xE071FE00

#define MCARD_NUM_UNITS    1
#define MCARD0_CHANNEL_PECOS_REVA     3

   /* Transmitter control register */
#define CCIF_SER_MIC_XMTR_REG(x)                  (MCARD_CTRL_BASE_ADDR(x)+0x28)
   
#define    CCIF_SER_MIC_XMTR_CARD_ENABLE_MASK     0x00000001
#ifndef MCARD_REV_B
#define    CCIF_SER_MIC_XMTR_CARD_ENABLE_SHIFT    0
#define       CCIF_SER_MIC_XMTR_CARD_ENABLE       (1UL<<0)
#define       CCIF_SER_MIC_XMTR_CARD_DISABLE      (0UL<<0)
#endif
   
#define    CCIF_SER_MIC_XMTR_ERR_MASK             0x00000002
#define    CCIF_SER_MIC_XMTR_ERR_SHIFT            1
#define       CCIF_SER_MIC_XMTR_ERR_ENABLE        (1UL<<1)
#define       CCIF_SER_MIC_XMTR_ERR_DISABLE       (0UL<<1)
   
#define    CCIF_SER_MIC_XMTR_L_MASK               0x00000004
#define    CCIF_SER_MIC_XMTR_L_SHIFT              2
#define       CCIF_SER_MIC_XMTR_L_ENABLE          (1UL<<2)
#define       CCIF_SER_MIC_XMTR_L_DISABLE         (0UL<<2)
   
#define     CCIF_SER_MIC_XMTR_F_MASK              0x00000008
#define     CCIF_SER_MIC_XMTR_F_SHIFT             3
#define       CCIF_SER_MIC_XMTR_F_ENABLE          (1UL<<3)
#define       CCIF_SER_MIC_XMTR_F_DISABLE         (0UL<<3)
   
#define     CCIF_SER_MIC_XMTR_EC_MASK             0x00000010
#define     CCIF_SER_MIC_XMTR_EC_SHIFT            4
#define       CCIF_SER_MIC_XMTR_EC_ENABLE         (1UL<<4)
#define       CCIF_SER_MIC_XMTR_EC_DISABLE        (0UL<<4)
   
#define     CCIF_SER_MIC_XMTR_HR_MASK             0x00000020
#define     CCIF_SER_MIC_XMTR_HR_SHIFT            5
#define       CCIF_SER_MIC_XMTR_HR_ENABLE         (1UL<<5)
#define       CCIF_SER_MIC_XMTR_HR_DISABLE        (0UL<<5)
   
#define    CCIF_SER_MIC_XMTR_LEN_MASK             0xFFFF0000
#define    CCIF_SER_MIC_XMTR_LEN_SHIFT            15
   
   /* Receiver status register */
#define CCIF_SER_MIC_RCVR_REG(x)                  (MCARD_CTRL_BASE_ADDR(x)+0x2C)
   
#define    CCIF_SER_MIC_RCVR_ERR_MASK             0x00000002
#define    CCIF_SER_MIC_RCVR_ERR_SHIFT            1
#define       CCIF_SER_MIC_RCVR_ERR_ENABLE        (1UL<<1)
#define       CCIF_SER_MIC_RCVR_ERR_DISABLE       (0UL<<1)
   
#define    CCIF_SER_MIC_RCVR_DA_MASK              0x00000004
#define    CCIF_SER_MIC_RCVR_DA_SHIFT             2
#define       CCIF_SER_MIC_RCVR_DA_ENABLE         (1UL<<2)
#define       CCIF_SER_MIC_RCVR_DA_DISABLE        (0UL<<2)
   
#define    CCIF_SER_MIC_RCVR_L_MASK               0x00000008
#define    CCIF_SER_MIC_RCVR_L_SHIFT              3
#define       CCIF_SER_MIC_RCVR_L_ENABLE          (1UL<<3)
#define       CCIF_SER_MIC_RCVR_L_DISABLE         (0UL<<3)
   
#define    CCIF_SER_MIC_RCVR_F_MASK               0x00000010
#define    CCIF_SER_MIC_RCVR_F_SHIFT              4
#define       CCIF_SER_MIC_RCVR_F_ENABLE          (1UL<<4)
#define       CCIF_SER_MIC_RCVR_F_DISABLE         (0UL<<4)
   
#define    CCIF_SER_MIC_RCVR_EC_MASK              0x00000020
#define    CCIF_SER_MIC_RCVR_EC_SHIFT             5
#define       CCIF_SER_MIC_RCVR_EC_ENABLE         (1UL<<5)
#define       CCIF_SER_MIC_RCVR_EC_DISABLE        (0UL<<5)
   
#define    CCIF_SER_MIC_RCVR_CR_MASK              0x00000040
#define    CCIF_SER_MIC_RCVR_CR_SHIFT             6
#define       CCIF_SER_MIC_RCVR_CR_ENABLE         (1UL<<6)
#define       CCIF_SER_MIC_RCVR_CR_DISABLE        (0UL<<6)
   
#define    CCIF_SER_MIC_RCVR_LEN_MASK             0xFFFF0000
#define    CCIF_SER_MIC_RCVR_LEN_SHIFT            15
   
   
   /* Interrupt mask register */
#define CCIF_SER_IRQ_MSK_REG(x)                   (MCARD_CTRL_BASE_ADDR(x)+0x30)
   
#define    CCIF_SER_IRQ_XMT_COMPLETE_MASK         0x00000001
#define    CCIF_SER_IRQ_XMT_COMPLETE_SHIFT        0
#define       CCIF_SER_IRQ_XMT_COMPLETE_ENABLE    (1UL<<0)
#define       CCIF_SER_IRQ_XMT_COMPLETE_DISABLE   (0UL<<0)
   
#define    CCIF_SER_IRQ_RX_ERR_MASK               0x00000002
#define    CCIF_SER_IRQ_RX_ERR_SHIFT              1
#define       CCIF_SER_IRQ_RX_ERR_ENABLE          (1UL<<1)
#define       CCIF_SER_IRQ_RX_ERR_DISABLE          (0UL<<1)
   
#define    CCIF_SER_IRQ_RX_HOLD_MASK              0x00000004
#define    CCIF_SER_IRQ_RX_HOLD_SHIFT             2
#define       CCIF_SER_IRQ_RX_HOLD_ENABLE         (1UL<<2)
#define       CCIF_SER_IRQ_RX_HOLD_DISABLE        (0UL<<2)
   
#define    CCIF_SER_IRQ_RX_SYNC_MASK              0x00000008
#define    CCIF_SER_IRQ_RX_SYNC_SHIFT             3
#define       CCIF_SER_IRQ_RX_SYNC_ENABLE         (1UL<<3)
#define       CCIF_SER_IRQ_RX_SYNC_DISABLE        (0UL<<3)
   
#define    CCIF_SER_IRQ_DST_DMA_INT_MASK          0x00000010
#define    CCIF_SER_IRQ_DST_DMA_INT_SHIFT         4
#define       CCIF_SER_IRQ_DST_DMA_INT_ENABLE     (1UL<<4)
#define       CCIF_SER_IRQ_DST_DMA_INT_DISABLE    (0UL<<4)
   
#define    CCIF_SER_IRQ_SRC_FIFO_EMPTY_MASK       0x00000020
#define    CCIF_SER_IRQ_SRC_FIFO_EMPTY_SHIFT      5
#define       CCIF_SER_IRQ_SRC_FIFO_EMPTY_ENABLE  (1UL<<5)
#define       CCIF_SER_IRQ_SRC_FIFO_EMPTY_DISABLE (0UL<<5)
   
#define    CCIF_SER_IRQ_DST_DMA_HERR_MASK         0x00000040
#define    CCIF_SER_IRQ_DST_DMA_HERR_SHIFT        6
#define       CCIF_SER_IRQ_DST_DMA_HERR_ENABLE    (1UL<<6)
#define       CCIF_SER_IRQ_DST_DMA_HERR_DISABLE   (0UL<<6)
   
#define    CCIF_SER_IRQ_SRC_DMA_HERR_MASK         0x00000080
#define    CCIF_SER_IRQ_SRC_DMA_HERR_SHIFT        7
#define       CCIF_SER_IRQ_SRC_DMA_HERR_ENABLE    (1UL<<7)
#define       CCIF_SER_IRQ_SRC_DMA_HERR_DISABLE   (0UL<<7)
   
   
   /* MCARD_REV_B */
#define    CCIF_SER_IRQ_DST_LINEAR_BUF_CNT_MASK   0x00000100
#define    CCIF_SER_IRQ_DST_LINEAR_BUF_CNT_SHIFT  8
#define      CCIF_SER_IRQ_DST_LINEAR_BUF_CNT_ENABLE (1UL<<8)
#define      CCIF_SER_IRQ_DST_LINEAR_BUF_CNT_DISABLE (0UL<<8)
   
#define    CCIF_SER_IRQ_DST_LINEAR_BUF_FULL_MASK   0x00000200
#define    CCIF_SER_IRQ_DST_LINEAR_BUF_FULL_SHIFT  9
#define       CCIF_SER_IRQ_DST_LINEAR_BUF_FULL_ENABLE (1UL<<9)
#define       CCIF_SER_IRQ_DST_LINEAR_BUF_FULL_DISABLE (0UL<<9)
   
#define    CCIF_SER_IRQ_RX_INVALID_LEN_MASK       0x00000400
#define    CCIF_SER_IRQ_RX_INVALID_LEN_SHIFT      10
#define       CCIF_SER_IRQ_RX_INVALID_LEN_ENABLE    (1UL<<10)
#define       CCIF_SER_IRQ_RX_INVALID_LEN_DISABLE   (0UL<<10)
   
   
   /* Interrupt enable register */
#define CCIF_SER_IRQ_MSK_STAT_REG(x)              (MCARD_CTRL_BASE_ADDR(x)+0x34)
   /* bit masking would be same as above */
   
   /* Txmit DMA contol register */
#define CCIF_SER_SRC_DMA_CTRL_REG(x)              (MCARD_CTRL_BASE_ADDR(x)+0x38)
   
#define    CCIF_SER_SRC_DMA_ENABLE_MASK           0x00000001
#define    CCIF_SER_SRC_DMA_ENABLE_SHIFT          0
#define       CCIF_SER_SRC_DMA_ENABLE             (1UL<<0)
#define       CCIF_SER_SRC_DMA_DISABLE            (0UL<<0)
   
   /* SRC DMA host address register */
#define CCIF_SER_SRC_DMA_HA_REG(x)                (MCARD_CTRL_BASE_ADDR(x)+0x3C)
#define    CCIF_SER_SRC_DMA_HA_MASK               0xFFFFFFFF
#define    CCIF_SER_SRC_DMA_HA_SHIFT              0
   
   /* SRC DMA data length register */
#define CCIF_SER_SRC_DMA_LEN_REG(x)               (MCARD_CTRL_BASE_ADDR(x)+0x40)
#define    CCIF_SER_SRC_DMA_LEN_MASK              0x00001FFF
#define    CCIF_SER_SRC_DMA_LEN_SHIFT             0
   
   /* DST DMA control register */
#define CCIF_SER_DST_DMA_CTRL_REG(x)              (MCARD_CTRL_BASE_ADDR(x)+0x44)
#define    CCIF_SER_DST_CIRC_BUF_MODE_MASK        0x00000001
#define    CCIF_SER_DST_CIRC_BUF_MODE_SHIFT       0
#define       CCIF_SER_DST_CIRC_BUF_MODE_ENABLE   (1UL<<0)
#define       CCIF_SER_DST_CIRC_BUF_MODE_DISABLE  (0UL<<0)
   
   /* MCARD_REV_B */
#define    CCIF_SER_DST_LINEAR_BUF_MODE_MASK     0x00000002
#define    CCIF_SER_DST_LINEAR_BUF_MODE_SHIFT    1
#define      CCIF_SER_DST_LINEAR_BUF_MODE_ENABLE (1UL<<1)
#define      CCIF_SER_DST_LINEAR_BUF_MODE_DISABLE (0UL<<1)
   
#define    CCIF_SER_DST_BUF_MODE_MASK             0x00000004
#define    CCIF_SER_DST_BUF_MODE_SHIFT            2
#define      CCIF_SER_DST_BUF_MODE_ENABLE         (1UL<<2)
#define      CCIF_SER_DST_BUF_MODE_DISABLE        (0UL<<2)
   
#define    CCIF_SER_DST_LINEAR_BUF_SIZE_MASK      0x00000030
#define    CCIF_SER_DST_LINEAR_BUF_SIZE_SHIFT     4
#define      CCIF_SER_DST_LINEAR_BUF_SIZE_8K      (0UL<<4)
#define      CCIF_SER_DST_LINEAR_BUF_SIZE_16K     (1UL<<4)
#define      CCIF_SER_DST_LINEAR_BUF_SIZE_32K     (2UL<<4)
#define      CCIF_SER_DST_LINEAR_BUF_SIZE_64K     (3UL<<4)
   
#define    CCIF_SER_DST_LINEAR_BUF_THRESHOLD_CNT_MASK  0xFFFF0000
#define    CCIF_SER_DST_LINEAR_BUF_THRESHOLD_CNT_SHIFT 16
   
   
   /* DST DMA Host Address register */
#define CCIF_SER_DST_DMA_HA_REG(x)                   (MCARD_CTRL_BASE_ADDR(x)+0x48)
#define    CCIF_SER_DST_DMA_HA_MASK               0xFFFFFFFF
#define    CCIF_SER_DST_DMA_HA_SHIFT              0
   /* DST data length register */
#define CCIF_SER_DST_DMA_LEN_REG(x)               (MCARD_CTRL_BASE_ADDR(x)+0x4C)
#define    CCIF_SER_DST_DMA_LEN_MASK              0x000001FF
#define    CCIF_SER_DST_DMA_LEN_SHIFT             0
   
   /* DST circular buffer address and status register */
#define CCIF_CPBADDR_REG(x,y)                     (MCARD_CTRL_BASE_ADDR(x)+(0x50+(8*y)))
#define    CCIF_CPBADDR_MASK                      0xFFFFFFFF
   
#define CCIF_CPBCNT_REG(x,y)                      (MCARD_CTRL_BASE_ADDR(x)+(0x54+(8*y)))
#define    CCIF_CPB_LEN_MASK                      0x00000FFF
#define    CCIF_CPB_LEN_SHIFT                     0
#define    CCIF_CPB_LEN_CLEAR                     (0UL<<0)
   
#define    CCIF_CPB_XFER_COMPLETE_INT_MASK        0x00001000
#define    CCIF_CPB_XFER_COMPLETE_INT_SHIFT       11
#define    CCIF_CPB_XFER_COMPLETE_INT_ENABLE      (1UL<<11)
#define    CCIF_CPB_XFER_COMPLETE_INT_DISABLE     (0UL<<11)
   
   /* MCARD_REV_B */
   
#define CCIF_DST_LINEAR_BUF_WRITE_PTR_REG(x)  (MCARD_CTRL_BASE_ADDR(x)+0xD4)
#define    CCIF_DST_LINEAR_BUF_WRITE_PTR_MASK     0xFFFFFFFF
   
#define CCIF_DST_LINEAR_BUF_READ_PTR_REG(x)      (MCARD_CTRL_BASE_ADDR(x)+0xD8)
#define    CCIF_DST_LINEAR_BUF_READ_PTR_MASK      0xFFFFFFFF
   
#define CCIF_MCARD_CTRL_REG(x)                (MCARD_CTRL_BASE_ADDR(x)+0xE0)
#define    CCIF_MCARD_CTRL_CARD_ENABLE_MASK       0x00000001
#define    CCIF_MCARD_CTRL_CARD_ENABLE_SHIFT      0
#define       CCIF_MCARD_CTRL_CARD_ENABLE         (1UL<<0)
#define       CCIF_MCARD_CTRL_CARD_DISABLE        (0UL<<0)
   
#define    CCIF_MCARD_CTRL_SCLK_ENABLE_MASK       0x00000002
#define    CCIF_MCARD_CTRL_SCLK_ENABLE_SHIFT      1
#define       CCIF_MCARD_CTRL_SCLK_ENABLE         (1UL<<1)
#define       CCIF_MCARD_CTRL_SCLK_DISABLE        (0UL<<1)
   
#define    CCIF_MCARD_CTRL_SOFT_RST_MASK          0x00000004
#define    CCIF_MCARD_CTRL_SOFT_RST_SHIFT         2
#define       CCIF_MCARD_CTRL_SOFT_RST_ENABLE     (1UL<<2)
#define       CCIF_MCARD_CTRL_SOFT_RST_DISABLE    (0UL<<2)
   
#define    CCIF_MCARD_CTRL_HR_CHK_MASK           0x00000008
#define    CCIF_MCARD_CTRL_HR_CHK_SHIFT          3
#define       CCIF_MCARD_CTRL_HR_CHK_ENABLE      (0UL<<3)
#define       CCIF_MCARD_CTRL_HR_CHK_DISABLE     (1UL<<3)
   
   
   /* MCard TS Mux/ Demux Registers TBD */
#define TSMUX_SIG_MUX_CONT_REG(x)          (MCARD_TSMUX_BASE(x)+0x0)
#define    TSMUX_SIG_MUX_CONT_MCH1_MASK            0x00000001
#define    TSMUX_SIG_MUX_CONT_MCH1_SHIFT           0
#define       TSMUX_SIG_MUX_CONT_MCH1_ENABLE       (1UL<<0)
#define       TSMUX_SIG_MUX_CONT_MCH1_DISABLE      (0UL<<0)
   
#define    TSMUX_SIG_MUX_CONT_MCH2_MASK            0x00000002
#define    TSMUX_SIG_MUX_CONT_MCH2_SHIFT           1
#define       TSMUX_SIG_MUX_CONT_MCH2_ENABLE       (1UL<<1)
#define       TSMUX_SIG_MUX_CONT_MCH2_DISABLE      (0UL<<1)
   
#define    TSMUX_SIG_MUX_CONT_MCH3_MASK            0x00000004
#define    TSMUX_SIG_MUX_CONT_MCH3_SHIFT           2
#define       TSMUX_SIG_MUX_CONT_MCH3_ENABLE       (1UL<<2)
#define       TSMUX_SIG_MUX_CONT_MCH3_DISABLE      (0UL<<2)
   
#define    TSMUX_SIG_MUX_CONT_MCH4_MASK            0x00000008
#define    TSMUX_SIG_MUX_CONT_MCH4_SHIFT           3
#define       TSMUX_SIG_MUX_CONT_MCH4_ENABLE       (1UL<<3)
#define       TSMUX_SIG_MUX_CONT_MCH4_DISABLE      (0UL<<3)
   
#define TSMUX_CC_CONT_REG(x)               (MCARD_TSMUX_BASE(x)+0x4)
#define    TSMUX_CC_CONT_SCARD_MCARD_MASK         0x00000001
#define    TSMUX_CC_CONT_SCARD_MCARD_SHIFT        0
#define       TSMUX_CC_CONT_SCARD_MCARD_ENABLE    (1UL<<0)
#define       TSMUX_CC_CONT_SCARD_MCARD_DISABLE   (0UL<<0)

#define    TSMUX_CC_CONT_TSDMX_MASK         0x00000010
#define    TSMUX_CC_CONT_TSDMX_SHIFT        7
#define       TSMUX_CC_CONT_TSDMX_ENABLE       (1UL<<7)
#define       TSMUX_CC_CONT_TSDMX_DISABLE   (0UL<<7)

#define    TSMUX_CC_CONT_ENABLE_MASK      0x00000080
#define    TSMUX_CC_CONT_ENABLE_SHIFT     7
#define       TSMUX_CC_CONT_ENABLE        (1UL<<7)
#define       TSMUX_CC_CONT_DISABLE       (0UL<<7)


#define TSMUX_MCH1_LTSID_REG(x)            (MCARD_TSMUX_BASE(x)+0x8)
#define    TSMUX_MCH1_LTSID_MASK                  0x000000FF
   
#define TSMUX_MCH1_RES1_REG(x)             (MCARD_TSMUX_BASE(x)+0xC)
#define    TSMUX_MCH1_RES1_MASK                   0x000000FF
   
#define TSMUX_MCH1_RES2_REG(x)             (MCARD_TSMUX_BASE(x)+0x10)
#define    TSMUX_MCH1_RES2_MASK                   0x000000FF
   
#define TSMUX_MCH1_CAB_RES_REG(x)          (MCARD_TSMUX_BASE(x)+0x14)
#define    TSMUX_MCH1_CAB_RES_MASK                0x0000FFFF
   
#define TSMUX_MCH1_HOST_RES_REG(x)         (MCARD_TSMUX_BASE(x)+0x18)
#define    TSMUX_MCH1_HOST_RES_MASK               0x0000FFFF
   
#define TSMUX_MCH2_LTSID_REG(x)            (MCARD_TSMUX_BASE(x)+0x1C)
#define    TSMUX_MCH2_LTSID_MASK                  0x000000FF
   
#define TSMUX_MCH2_RES1_REG(x)             (MCARD_TSMUX_BASE(x)+0x20)
#define    TSMUX_MCH1_RES1_MASK                   0x000000FF
   
#define TSMUX_MCH2_RES2_REG(x)             (MCARD_TSMUX_BASE(x)+0x24)
#define    TSMUX_MCH2_RES2_MASK                   0x000000FF
   
#define TSMUX_MCH2_CAB_RES_REG(x)          (MCARD_TSMUX_BASE(x)+0x28)
#define    TSMUX_MCH2_CAB_RES_MASK                0x0000FFFF
   
#define TSMUX_MCH2_HOST_RES_REG(x)         (MCARD_TSMUX_BASE(x)+0x2C)
#define    TSMUX_MCH2_HOST_RES_MASK               0x0000FFFF
   
#define TSMUX_MCH3_LTSID_REG(x)            (MCARD_TSMUX_BASE(x)+0x30)
#define    TSMUX_MCH3_LTSID_MASK                  0x000000FF
   
#define TSMUX_MCH3_RES1_REG(x)             (MCARD_TSMUX_BASE(x)+0x34)
#define    TSMUX_MCH3_RES1_MASK                   0x000000FF
   
#define TSMUX_MCH3_RES2_REG(x)             (MCARD_TSMUX_BASE(x)+0x38)
#define    TSMUX_MCH3_RES2_MASK                   0x000000FF
   
#define TSMUX_MCH3_CAB_RES_REG(x)          (MCARD_TSMUX_BASE(x)+0x3C)
#define    TSMUX_MCH3_CAB_RES_MASK                0x0000FFFF
   
#define TSMUX_MCH3_HOST_RES_REG(x)         (MCARD_TSMUX_BASE(x)+0x40)
#define    TSMUX_MCH3_HOST_RES_MASK               0x0000FFFF
   
#define TSMUX_MCH4_LTSID_REG(x)            (MCARD_TSMUX_BASE(x)+0x5C)
#define    TSMUX_MCH4_LTSID_MASK                  0x000000FF
   
#define TSMUX_MCH4_RES1_REG(x)             (MCARD_TSMUX_BASE(x)+0x60)
#define    TSMUX_MCH4_RES1_MASK                   0x000000FF
   
#define TSMUX_MCH4_RES2_REG(x)             (MCARD_TSMUX_BASE(x)+0x64)
#define    TSMUX_MCH4_RES2_MASK                   0x000000FF
   
#define TSMUX_MCH4_CAB_RES_REG(x)          (MCARD_TSMUX_BASE(x)+0x68)
#define    TSMUX_MCH4_CAB_RES_MASK                0x0000FFFF
   
#define TSMUX_MCH4_HOST_RES_REG(x)         (MCARD_TSMUX_BASE(x)+0x6C)
#define    TSMUX_MCH4_HOST_RES_MASK               0x0000FFFF
   
#define TSDEMUX_CC_CONT_REG(x)             (MCARD_TSMUX_BASE(x)+0x2C)
#define    TSDEMUX_CC_CONT_SCARD_MCARD_MASK       0x00000001
#define    TSDEMUX_CC_CONT_SCARD_MCARD_SHIFT      0
#define       TSDEMUX_CC_CONT_SCARD_MCARD_ENABLE  (1UL<<0)
#define       TSDEMUX_CC_CONT_SCARD_MCARD_DISABLE (0UL<<0)
   
   
#define TSDEMUX_MCH1_LTSID_REG(x)          (MCARD_TSMUX_BASE(x)+0x1C)
#define    TSDEMUX_MCH1_LTSID_MASK         0x000000FF
   
#define TSDEMUX_MCH2_LTSID_REG(x)          (MCARD_TSMUX_BASE(x)+0x20)
#define    TSDEMUX_MCH2_LTSID_MASK         0x000000FF
   
#define TSDEMUX_MCH3_LTSID_REG(x)          (MCARD_TSMUX_BASE(x)+0x24)
#define    TSDEMUX_MCH3_LTSID_MASK         0x000000FF
   
#define TSDEMUX_MCH4_LTSID_REG(x)          (MCARD_TSMUX_BASE(x)+0x28)
#define    TSDEMUX_MCH4_LTSID_MASK         0x000000FF
   


#endif // PHMODIPMCARD_H
