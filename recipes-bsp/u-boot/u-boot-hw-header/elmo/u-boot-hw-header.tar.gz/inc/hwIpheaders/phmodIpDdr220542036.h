/*-------------------------------------------------------------------------*/
/* Copyright 2011 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef _PHMODIPDDR220542036_H_
#define _PHMODIPDDR220542036_H_


    /*
    * Control register
    */
    #define DDR220542036_IP_2036_CTL_REG  (DDR220542036_BASE_0 + 0x0)
    /*
    * SDRAM burst length
    */
    #define DDR220542036_IP_2036_CTL_BURST_LENGTH_RW (0x03 << 3)
    #define DDR220542036_IP_2036_CTL_BURST_LENGTH_SHIFT 3
    /*
    * Select SDRAM type
    */
    #define DDR220542036_IP_2036_CTL_MEM_TYPE_RW (0x07 << 0)
    #define DDR220542036_IP_2036_CTL_MEM_TYPE_SHIFT 0
    /*
    * Mode get register
    */
    #define DDR220542036_IP_2036_MODE_GET_CTL_REG  (DDR220542036_BASE_0 + 0x14)
    /*
    * Current mode
    */
    #define DDR220542036_IP_2036_MODE_GET_CTL_GET_MODE_R (0x03 << 0)
    #define DDR220542036_IP_2036_MODE_GET_CTL_GET_MODE_SHIFT 0
    /*
    * Low level SW command register
    */
    #define DDR220542036_IP_2036_COMMAND2_REG  (DDR220542036_BASE_0 + 0x24)
    /*
    * CKE signal, stays at this level until the next command
    */
    #define DDR220542036_IP_2036_COMMAND2_CKE_W (0x01 << 24)
    #define DDR220542036_IP_2036_COMMAND2_CKE_SHIFT 24
    /*
    * CS signal
    */
    #define DDR220542036_IP_2036_COMMAND2_CS_W (0x01 << 23)
    #define DDR220542036_IP_2036_COMMAND2_CS_SHIFT 23
    /*
    * RAS signal
    */
    #define DDR220542036_IP_2036_COMMAND2_RAS_W (0x01 << 22)
    #define DDR220542036_IP_2036_COMMAND2_RAS_SHIFT 22
    /*
    * CAS signal
    */
    #define DDR220542036_IP_2036_COMMAND2_CAS_W (0x01 << 21)
    #define DDR220542036_IP_2036_COMMAND2_CAS_SHIFT 21
    /*
    * WE signal
    */
    #define DDR220542036_IP_2036_COMMAND2_WE_W (0x01 << 20)
    #define DDR220542036_IP_2036_COMMAND2_WE_SHIFT 20
    /*
    * Bank address signals
    */
    #define DDR220542036_IP_2036_COMMAND2_BA_W (0x03 << 16)
    #define DDR220542036_IP_2036_COMMAND2_BA_SHIFT 16
    /*
    * Address signals Note that when using this register to issue a (E)MRS command, th
    * e BA and A fields must be used to specify the register and the opcode. The value
    * s in the (E)MR registers will be ignored.
    */
    #define DDR220542036_IP_2036_COMMAND2_A_W (0x0ffff << 0)
    #define DDR220542036_IP_2036_COMMAND2_A_SHIFT 0
    /*
    * Region 1 base address register
    */
    #define DDR220542036_IP_2036_REGION1_BASE_REG  (DDR220542036_BASE_0 + 0x40)
    /*
    * Region base address offset
    */
    #define DDR220542036_IP_2036_REGION_BASE_RW (0x07fff << 16)
    #define DDR220542036_IP_2036_REGION_BASE_SHIFT 16
    /*
    * Region 1 address mask register
    */
    #define DDR220542036_IP_2036_REGION1_MASK_REG  (DDR220542036_BASE_0 + 0x44)
    /*
    * Region mask bits
    */
    #define DDR220542036_IP_2036_REGION_MASK_RW (0x07fff << 16)
    #define DDR220542036_IP_2036_REGION_MASK_SHIFT 16
    /*
    * Region 0 mapping register
    */
    #define DDR220542036_IP_2036_REGION0_MAPPING_REG  (DDR220542036_BASE_0 + 0x48)
    /*
    * Enable Region 1 (only for IP_2036_REGION1_MAPPING, Region 0 is always enabled)
    */
    #define DDR220542036_IP_2036_ENABLE_RW (0x01 << 31)
    #define DDR220542036_IP_2036_ENABLE_SHIFT 31
    /*
    * Select strided mapping
    */
    #define DDR220542036_IP_2036_STRIDE_RW (0x07 << 7)
    #define DDR220542036_IP_2036_STRIDE_SHIFT 7
    /*
    * Select alternation of banks (only for strided)
    */
    #define DDR220542036_IP_2036_BANK_ALTERNATE_RW (0x01 << 6)
    #define DDR220542036_IP_2036_BANK_ALTERNATE_SHIFT 6
    /*
    * Number of banks involved in bank interleaving
    */
    #define DDR220542036_IP_2036_BANKS_INTERLEAVED_RW (0x01 << 4)
    #define DDR220542036_IP_2036_BANKS_INTERLEAVED_SHIFT 4
    /*
    * Bank interleaving is done
    */
    #define DDR220542036_IP_2036_BANK_INTERLEAVING_RW (0x0f << 0)
    #define DDR220542036_IP_2036_BANK_INTERLEAVING_SHIFT 0
    /*
    * Region 1 mapping register
    */
    #define DDR220542036_IP_2036_REGION1_MAPPING_REG  (DDR220542036_BASE_0 + 0x4c)
    /*
    * Enable Region 1 (only for IP_2036_REGION1_MAPPING, Region 0 is always enabled)
    */
    #define DDR220542036_IP_2036_ENABLE_RW (0x01 << 31)
    #define DDR220542036_IP_2036_ENABLE_SHIFT 31
    /*
    * Select strided mapping
    */
    #define DDR220542036_IP_2036_STRIDE_RW (0x07 << 7)
    #define DDR220542036_IP_2036_STRIDE_SHIFT 7
    /*
    * Select alternation of banks (only for strided)
    */
    #define DDR220542036_IP_2036_BANK_ALTERNATE_RW (0x01 << 6)
    #define DDR220542036_IP_2036_BANK_ALTERNATE_SHIFT 6
    /*
    * Number of banks involved in bank interleaving
    */
    #define DDR220542036_IP_2036_BANKS_INTERLEAVED_RW (0x01 << 4)
    #define DDR220542036_IP_2036_BANKS_INTERLEAVED_SHIFT 4
    /*
    * Bank interleaving is done
    */
    #define DDR220542036_IP_2036_BANK_INTERLEAVING_RW (0x0f << 0)
    #define DDR220542036_IP_2036_BANK_INTERLEAVING_SHIFT 0
    /*
    * Mode register
    */
    #define DDR220542036_IP_2036_MR_REG  (DDR220542036_BASE_0 + 0x80)
    /*
    * Value for the memory's Mode Register Note that this value is only used during in
    * itialization of the memory. Note that the number of bits used is equal to the nu
    * mber of address bits of the memory interface actually present.
    */
    #define DDR220542036_IP_2036_MR_VALUE_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_MR_VALUE_SHIFT 0
    /*
    * Extended Mode register
    */
    #define DDR220542036_IP_2036_EMR_REG  (DDR220542036_BASE_0 + 0x84)
    /*
    * Value for the memory's Mode Register Note that this value is only used during in
    * itialization of the memory. Note that the number of bits used is equal to the nu
    * mber of address bits of the memory interface actually present.
    */
    #define DDR220542036_IP_2036_EMR_VALUE_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_EMR_VALUE_SHIFT 0
    /*
    * Extended Mode register 2
    */
    #define DDR220542036_IP_2036_EMR2_REG  (DDR220542036_BASE_0 + 0x88)
    /*
    * Value for the memory's Mode Register Note that this value is only used during in
    * itialization of the memory. Note that the number of bits used is equal to the nu
    * mber of address bits of the memory interface actually present.
    */
    #define DDR220542036_IP_2036_EMR2_VALUE_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_EMR2_VALUE_SHIFT 0
    /*
    * Extended Mode register 3
    */
    #define DDR220542036_IP_2036_EMR3_REG  (DDR220542036_BASE_0 + 0x8c)
    /*
    * Value for the memory's Mode Register Note that this value is only used during in
    * itialization of the memory. Note that the number of bits used is equal to the nu
    * mber of address bits of the memory interface actually present.
    */
    #define DDR220542036_IP_2036_EMR3_VALUE_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_EMR3_VALUE_SHIFT 0
    /*
    * Memory rank 0 configuration register
    */
    #define DDR220542036_IP_2036_RANK0_CFG_REG  (DDR220542036_BASE_0 + 0xc0)
    /*
    * Address bit to indicate auto-precharge and precharge-all
    */
    #define DDR220542036_IP_2036_RANK0_CFG_AP_RW (0x01 << 12)
    #define DDR220542036_IP_2036_RANK0_CFG_AP_SHIFT 12
    /*
    * Select the width of the data path
    */
    #define DDR220542036_IP_2036_RANK0_CFG_DATA_WIDTH_RW (0x01 << 10)
    #define DDR220542036_IP_2036_RANK0_CFG_DATA_WIDTH_SHIFT 10
    /*
    * Select the number of bank address bits
    */
    #define DDR220542036_IP_2036_RANK0_CFG_BANK_WIDTH_RW (0x01 << 8)
    #define DDR220542036_IP_2036_RANK0_CFG_BANK_WIDTH_SHIFT 8
    /*
    * Select the number of row address bits, to support 2^ROW_WIDTH rows
    */
    #define DDR220542036_IP_2036_RANK0_CFG_ROW_WIDTH_RW (0x07 << 4)
    #define DDR220542036_IP_2036_RANK0_CFG_ROW_WIDTH_SHIFT 4
    /*
    * Select the number of column address bits, to support 2^COLUMN_WIDTH columns
    */
    #define DDR220542036_IP_2036_RANK0_CFG_COLUMN_WIDTH_RW (0x0f << 0)
    #define DDR220542036_IP_2036_RANK0_CFG_COLUMN_WIDTH_SHIFT 0
    /*
    * tRCD timing register
    */
    #define DDR220542036_IP_2036_TIMING_TRCD_REG  (DDR220542036_BASE_0 + 0x100)
    /*
    * Minimum delay from active to write in the same bank (clock cycles, 1 relative)
    */
    #define DDR220542036_IP_2036_TIMING_TRCD_TRCD_WR_RW (0x07 << 16)
    #define DDR220542036_IP_2036_TIMING_TRCD_TRCD_WR_SHIFT 16
    /*
    * Minimum delay from active to read in the same bank (clock cycles, 1 relative)
    */
    #define DDR220542036_IP_2036_TIMING_TRCD_TRCD_RD_RW (0x0f << 0)
    #define DDR220542036_IP_2036_TIMING_TRCD_TRCD_RD_SHIFT 0
    /*
    * tRC timing register
    */
    #define DDR220542036_IP_2036_TIMING_TRC_REG  (DDR220542036_BASE_0 + 0x104)
    /*
    * Minimum delay from active to active/auto-refresh in the same bank (clock cycles,
    *  1 relative)
    */
    #define DDR220542036_IP_2036_TIMING_TRC_TRC_RW (0x01f << 0)
    #define DDR220542036_IP_2036_TIMING_TRC_TRC_SHIFT 0
    /*
    * tWTR timing register
    */
    #define DDR220542036_IP_2036_TIMING_TWTR_REG  (DDR220542036_BASE_0 + 0x108)
    /*
    * Minimum delay from last unmasked write data to read (clock cycles, 1 relative)
    */
    #define DDR220542036_IP_2036_TIMING_TWTR_TWTR_RW (0x0f << 0)
    #define DDR220542036_IP_2036_TIMING_TWTR_TWTR_SHIFT 0
    /*
    * tWR timing register
    */
    #define DDR220542036_IP_2036_TIMING_TWR_REG  (DDR220542036_BASE_0 + 0x10c)
    /*
    * Write recovery time: minimum delay from last unmased write data to precharge of 
    * the same bank (clock cycles, 1 relative)
    */
    #define DDR220542036_IP_2036_TIMING_TWR_TWR_RW (0x0f << 0)
    #define DDR220542036_IP_2036_TIMING_TWR_TWR_SHIFT 0
    /*
    * tRP timing register
    */
    #define DDR220542036_IP_2036_TIMING_TRP_REG  (DDR220542036_BASE_0 + 0x110)
    /*
    * Minimum delay from precharge-all to active (clock cycles, 1 relative) For 8 bank
    *  DDR2 devices, program to tRP+1. For other devices program to tRP
    */
    #define DDR220542036_IP_2036_TIMING_TRP_TRPA_RW (0x07 << 16)
    #define DDR220542036_IP_2036_TIMING_TRP_TRPA_SHIFT 16
    /*
    * Minimum delay from precharge to active of the same bank (clock cycles, 1 relativ
    * e)
    */
    #define DDR220542036_IP_2036_TIMING_TRP_TRP_RW (0x0f << 0)
    #define DDR220542036_IP_2036_TIMING_TRP_TRP_SHIFT 0
    /*
    * tRAS timing register
    */
    #define DDR220542036_IP_2036_TIMING_TRAS_REG  (DDR220542036_BASE_0 + 0x114)
    /*
    * Minimum delay from active to precharge of the same bank (clock cycles, 1 relativ
    * e)
    */
    #define DDR220542036_IP_2036_TIMING_TRAS_TRAS_RW (0x01f << 0)
    #define DDR220542036_IP_2036_TIMING_TRAS_TRAS_SHIFT 0
    /*
    * tRRD timing register
    */
    #define DDR220542036_IP_2036_TIMING_TRRD_REG  (DDR220542036_BASE_0 + 0x11c)
    /*
    * Window in which no more than 4 active commands may be given (clock cycles, 1 rel
    * ative) For 8 bank devices program to tFAW. For other devices program to 2.
    */
    #define DDR220542036_IP_2036_TIMING_TRRD_TFAW_RW (0x03f << 16)
    #define DDR220542036_IP_2036_TIMING_TRRD_TFAW_SHIFT 16
    /*
    * Minimum delay from active to active of different banks (clock cycles, 1 relative
    * )
    */
    #define DDR220542036_IP_2036_TIMING_TRRD_TRRD_RW (0x0f << 0)
    #define DDR220542036_IP_2036_TIMING_TRRD_TRRD_SHIFT 0
    /*
    * tRFC timing register
    */
    #define DDR220542036_IP_2036_TIMING_TRFC_REG  (DDR220542036_BASE_0 + 0x120)
    /*
    * Minimum delay from auto-refresh to any command (clock cycles, 1 relative)
    */
    #define DDR220542036_IP_2036_TIMING_TRFC_TRFC_RW (0x0ff << 0)
    #define DDR220542036_IP_2036_TIMING_TRFC_TRFC_SHIFT 0
    /*
    * tMRD timing register
    */
    #define DDR220542036_IP_2036_TIMING_TMRD_REG  (DDR220542036_BASE_0 + 0x124)
    /*
    * Minimum delay from mode register set to any command (clock cycles, 1 relative)
    */
    #define DDR220542036_IP_2036_TIMING_TMRD_TMRD_RW (0x0f << 0)
    #define DDR220542036_IP_2036_TIMING_TMRD_TMRD_SHIFT 0
    /*
    * Latency timing register
    */
    #define DDR220542036_IP_2036_TIMING_LTCY_REG  (DDR220542036_BASE_0 + 0x128)
    /*
    * Write latency: delay from write command to first write data (clock cycles) For D
    * DR program to 1, for DDR2 program to CAS+AL-1
    */
    #define DDR220542036_IP_2036_TIMING_LTCY_TWL_RW (0x07 << 16)
    #define DDR220542036_IP_2036_TIMING_LTCY_TWL_SHIFT 16
    /*
    * Read latency: delay from read command to first read data (half clock cycles) For
    *  DDR program to 2*CAS, for DDR2 program to 2*(CAS+AL)
    */
    #define DDR220542036_IP_2036_TIMING_LTCY_TRL_RW (0x01f << 0)
    #define DDR220542036_IP_2036_TIMING_LTCY_TRL_SHIFT 0
    /*
    * Refresh parameter register
    */
    #define DDR220542036_IP_2036_REFRESH_REG  (DDR220542036_BASE_0 + 0x12c)
    /*
    * Maximum number of queued auto-refreshes
    */
    #define DDR220542036_IP_2036_REFRESH_BOOST_RW (0x07 << 16)
    #define DDR220542036_IP_2036_REFRESH_BOOST_SHIFT 16
    /*
    * Period between 2 auto-refresh commands
    */
    #define DDR220542036_IP_2036_REFRESH_PERIOD_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_REFRESH_PERIOD_SHIFT 0
    /*
    * tRTW timing register
    */
    #define DDR220542036_IP_2036_TIMING_TRTW_REG  (DDR220542036_BASE_0 + 0x130)
    /*
    * Minimum delay from read to write command (clock cycles, 1 relative)
    */
    #define DDR220542036_IP_2036_TIMING_TRTW_TRTW_RW (0x01f << 0)
    #define DDR220542036_IP_2036_TIMING_TRTW_TRTW_SHIFT 0
    /*
    * Read-to-precharge register
    */
    #define DDR220542036_IP_2036_TIMING_TRTP_REG  (DDR220542036_BASE_0 + 0x134)
    /*
    * SDRAM timing read-to-precharge
    */
    #define DDR220542036_IP_2036_TIMING_TRTP_TRTP_RW (0x0f << 0)
    #define DDR220542036_IP_2036_TIMING_TRTP_TRTP_SHIFT 0
    /*
    * Additive latency register
    */
    #define DDR220542036_IP_2036_TIMING_AL_REG  (DDR220542036_BASE_0 + 0x13c)
    /*
    * Additive Latency
    */
    #define DDR220542036_IP_2036_TIMING_AL_AL_RW (0x07 << 0)
    #define DDR220542036_IP_2036_TIMING_AL_AL_SHIFT 0
    /*
    * ODT turn-on/off delay register
    */
    #define DDR220542036_IP_2036_TIMING_ODT_REG  (DDR220542036_BASE_0 + 0x140)
    /*
    * Write command to ODT turn-on delay (clock cycles)
    */
    #define DDR220542036_IP_2036_TIMING_ODT_ODT_ON_RW (0x07 << 16)
    #define DDR220542036_IP_2036_TIMING_ODT_ODT_ON_SHIFT 16
    /*
    * Reduction of ODT_ON value (allows to reduce ODT_ON below zero)
    */
    #define DDR220542036_IP_2036_TIMING_ODT_ODT_ON_NEG_RW (0x01 << 8)
    #define DDR220542036_IP_2036_TIMING_ODT_ODT_ON_NEG_SHIFT 8
    /*
    * ODT turn-on to ODT turn-off delay (clock cycles)
    */
    #define DDR220542036_IP_2036_TIMING_ODT_ODT_DUR_RW (0x0f << 0)
    #define DDR220542036_IP_2036_TIMING_ODT_ODT_DUR_SHIFT 0
    /*
    * Exit self-refresh timing register
    */
    #define DDR220542036_IP_2036_TIMING_TXSR_REG  (DDR220542036_BASE_0 + 0x14c)
    /*
    * Minimum delay from exit self-refresh to read command (clock cycles, 1 relative)
    */
    #define DDR220542036_IP_2036_TIMING_TXSR_TXSRD_RW (0x01ff << 16)
    #define DDR220542036_IP_2036_TIMING_TXSR_TXSRD_SHIFT 16
    /*
    * Minimum delay from exit self-refresh to non-read command (clock cycles, 1 relati
    * ve)
    */
    #define DDR220542036_IP_2036_TIMING_TXSR_TXSNR_RW (0x03ff << 0)
    #define DDR220542036_IP_2036_TIMING_TXSR_TXSNR_SHIFT 0
    /*
    * tCKE timing register
    */
    #define DDR220542036_IP_2036_TIMING_TCKE_REG  (DDR220542036_BASE_0 + 0x150)
    /*
    * Delay between CKE assertion and precharge-all during initialization (clock cycle
    * s, 1 relative) For LPDDR don't care, for DDR program to 0, for DDR2 typically 40
    * 0ns
    */
    #define DDR220542036_IP_2036_TIMING_TCKE_TCKE_RW (0x0ff << 0)
    #define DDR220542036_IP_2036_TIMING_TCKE_TCKE_SHIFT 0
    /*
    * tOIT timing register
    */
    #define DDR220542036_IP_2036_TIMING_TOIT_REG  (DDR220542036_BASE_0 + 0x1e0)
    /*
    * tOIT, delay from last EMRS commands in initialisation to any command
    */
    #define DDR220542036_IP_2036_TIMING_TOIT_TOIT_RW (0x0f << 0)
    #define DDR220542036_IP_2036_TIMING_TOIT_TOIT_SHIFT 0
    /*
    * Data port 0 budget register
    */
    #define DDR220542036_IP_2036_ARB_DP0_BUDGET_REG  (DDR220542036_BASE_0 + 0x200)
    /*
    * Specify the gross bandwidth budget, as a fraction of the total available bandwid
    * th.
    */
    #define DDR220542036_IP_2036_ARB_DP0_BUDGET_NUMERATOR_RW (0x07f << 8)
    #define DDR220542036_IP_2036_ARB_DP0_BUDGET_NUMERATOR_SHIFT 8
    #define DDR220542036_IP_2036_ARB_DP0_BUDGET_DENOMINATOR_RW (0x0ff << 0)
    #define DDR220542036_IP_2036_ARB_DP0_BUDGET_DENOMINATOR_SHIFT 0
    /*
    * Data port 0 clip register
    */
    #define DDR220542036_IP_2036_ARB_DP0_CLIP_REG  (DDR220542036_BASE_0 + 0x204)
    /*
    * Saturation level for the account
    */
    #define DDR220542036_IP_2036_ARB_DP0_CLIP_CLIP_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP0_CLIP_CLIP_SHIFT 0
    /*
    * Data port 0 limit register
    */
    #define DDR220542036_IP_2036_ARB_DP0_LIMIT_REG  (DDR220542036_BASE_0 + 0x208)
    /*
    * Threshold for out-of-budget detection
    */
    #define DDR220542036_IP_2036_ARB_DP0_LIMIT_LIMIT_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP0_LIMIT_LIMIT_SHIFT 0
    /*
    * Data port 0 boost register
    */
    #define DDR220542036_IP_2036_ARB_DP0_BOOST_REG  (DDR220542036_BASE_0 + 0x20c)
    /*
    * Threshold for priority boosting
    */
    #define DDR220542036_IP_2036_ARB_DP0_BOOST_BOOST_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP0_BOOST_BOOST_SHIFT 0
    /*
    * Data port 0 priority register
    */
    #define DDR220542036_IP_2036_ARB_DP0_PRIO_REG  (DDR220542036_BASE_0 + 0x210)
    /*
    * Limited priority, when out-of-budget
    */
    #define DDR220542036_IP_2036_ARB_DP0_PRIO_LIMITED_RW (0x07 << 8)
    #define DDR220542036_IP_2036_ARB_DP0_PRIO_LIMITED_SHIFT 8
    /*
    * Default priority
    */
    #define DDR220542036_IP_2036_ARB_DP0_PRIO_DEFAULT_RW (0x07 << 4)
    #define DDR220542036_IP_2036_ARB_DP0_PRIO_DEFAULT_SHIFT 4
    /*
    * Boosted priority, when close to deadline
    */
    #define DDR220542036_IP_2036_ARB_DP0_PRIO_BOOSTED_RW (0x0f << 0)
    #define DDR220542036_IP_2036_ARB_DP0_PRIO_BOOSTED_SHIFT 0
    /*
    * Data port 0 account register
    */
    #define DDR220542036_IP_2036_ARB_DP0_ACCOUNT_REG  (DDR220542036_BASE_0 + 0x214)
    /*
    * Snapshot of the account value, captured together with the performance counters
    */
    #define DDR220542036_IP_2036_ARB_DP0_ACCOUNT_ACCOUNT_R (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP0_ACCOUNT_ACCOUNT_SHIFT 0
    /*
    * Data port 1 budget register
    */
    #define DDR220542036_IP_2036_ARB_DP1_BUDGET_REG  (DDR220542036_BASE_0 + 0x220)
    /*
    * Specify the gross bandwidth budget, as a fraction of the total available bandwid
    * th.
    */
    #define DDR220542036_IP_2036_ARB_DP1_BUDGET_NUMERATOR_RW (0x07f << 8)
    #define DDR220542036_IP_2036_ARB_DP1_BUDGET_NUMERATOR_SHIFT 8
    #define DDR220542036_IP_2036_ARB_DP1_BUDGET_DENOMINATOR_RW (0x0ff << 0)
    #define DDR220542036_IP_2036_ARB_DP1_BUDGET_DENOMINATOR_SHIFT 0
    /*
    * Data port 1 clip register
    */
    #define DDR220542036_IP_2036_ARB_DP1_CLIP_REG  (DDR220542036_BASE_0 + 0x224)
    /*
    * Saturation level for the account
    */
    #define DDR220542036_IP_2036_ARB_DP1_CLIP_CLIP_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP1_CLIP_CLIP_SHIFT 0
    /*
    * Data port 1 limit register
    */
    #define DDR220542036_IP_2036_ARB_DP1_LIMIT_REG  (DDR220542036_BASE_0 + 0x228)
    /*
    * Threshold for out-of-budget detection
    */
    #define DDR220542036_IP_2036_ARB_DP1_LIMIT_LIMIT_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP1_LIMIT_LIMIT_SHIFT 0
    /*
    * Data port 1 boost register
    */
    #define DDR220542036_IP_2036_ARB_DP1_BOOST_REG  (DDR220542036_BASE_0 + 0x22c)
    /*
    * Threshold for priority boosting
    */
    #define DDR220542036_IP_2036_ARB_DP1_BOOST_BOOST_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP1_BOOST_BOOST_SHIFT 0
    /*
    * Data port 1 priority register
    */
    #define DDR220542036_IP_2036_ARB_DP1_PRIO_REG  (DDR220542036_BASE_0 + 0x230)
    /*
    * Limited priority, when out-of-budget
    */
    #define DDR220542036_IP_2036_ARB_DP1_PRIO_LIMITED_RW (0x07 << 8)
    #define DDR220542036_IP_2036_ARB_DP1_PRIO_LIMITED_SHIFT 8
    /*
    * Default priority
    */
    #define DDR220542036_IP_2036_ARB_DP1_PRIO_DEFAULT_RW (0x07 << 4)
    #define DDR220542036_IP_2036_ARB_DP1_PRIO_DEFAULT_SHIFT 4
    /*
    * Boosted priority, when close to deadline
    */
    #define DDR220542036_IP_2036_ARB_DP1_PRIO_BOOSTED_RW (0x0f << 0)
    #define DDR220542036_IP_2036_ARB_DP1_PRIO_BOOSTED_SHIFT 0
    /*
    * Data port 1 account register
    */
    #define DDR220542036_IP_2036_ARB_DP1_ACCOUNT_REG  (DDR220542036_BASE_0 + 0x234)
    /*
    * Snapshot of the account value, captured together with the performance counters
    */
    #define DDR220542036_IP_2036_ARB_DP1_ACCOUNT_ACCOUNT_R (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP1_ACCOUNT_ACCOUNT_SHIFT 0
    /*
    * Data port 2 budget register
    */
    #define DDR220542036_IP_2036_ARB_DP2_BUDGET_REG  (DDR220542036_BASE_0 + 0x240)
    /*
    * Specify the gross bandwidth budget, as a fraction of the total available bandwid
    * th.
    */
    #define DDR220542036_IP_2036_ARB_DP2_BUDGET_NUMERATOR_RW (0x07f << 8)
    #define DDR220542036_IP_2036_ARB_DP2_BUDGET_NUMERATOR_SHIFT 8
    #define DDR220542036_IP_2036_ARB_DP2_BUDGET_DENOMINATOR_RW (0x0ff << 0)
    #define DDR220542036_IP_2036_ARB_DP2_BUDGET_DENOMINATOR_SHIFT 0
    /*
    * Data port 2 clip register
    */
    #define DDR220542036_IP_2036_ARB_DP2_CLIP_REG  (DDR220542036_BASE_0 + 0x244)
    /*
    * Saturation level for the account
    */
    #define DDR220542036_IP_2036_ARB_DP2_CLIP_CLIP_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP2_CLIP_CLIP_SHIFT 0
    /*
    * Data port 2 limit register
    */
    #define DDR220542036_IP_2036_ARB_DP2_LIMIT_REG  (DDR220542036_BASE_0 + 0x248)
    /*
    * Threshold for out-of-budget detection
    */
    #define DDR220542036_IP_2036_ARB_DP2_LIMIT_LIMIT_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP2_LIMIT_LIMIT_SHIFT 0
    /*
    * Data port 2 boost register
    */
    #define DDR220542036_IP_2036_ARB_DP2_BOOST_REG  (DDR220542036_BASE_0 + 0x24c)
    /*
    * Threshold for priority boosting
    */
    #define DDR220542036_IP_2036_ARB_DP2_BOOST_BOOST_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP2_BOOST_BOOST_SHIFT 0
    /*
    * Data port 2 priority register
    */
    #define DDR220542036_IP_2036_ARB_DP2_PRIO_REG  (DDR220542036_BASE_0 + 0x250)
    /*
    * Limited priority, when out-of-budget
    */
    #define DDR220542036_IP_2036_ARB_DP2_PRIO_LIMITED_RW (0x07 << 8)
    #define DDR220542036_IP_2036_ARB_DP2_PRIO_LIMITED_SHIFT 8
    /*
    * Default priority
    */
    #define DDR220542036_IP_2036_ARB_DP2_PRIO_DEFAULT_RW (0x07 << 4)
    #define DDR220542036_IP_2036_ARB_DP2_PRIO_DEFAULT_SHIFT 4
    /*
    * Boosted priority, when close to deadline
    */
    #define DDR220542036_IP_2036_ARB_DP2_PRIO_BOOSTED_RW (0x0f << 0)
    #define DDR220542036_IP_2036_ARB_DP2_PRIO_BOOSTED_SHIFT 0
    /*
    * Data port 2 account register
    */
    #define DDR220542036_IP_2036_ARB_DP2_ACCOUNT_REG  (DDR220542036_BASE_0 + 0x254)
    /*
    * Snapshot of the account value, captured together with the performance counters
    */
    #define DDR220542036_IP_2036_ARB_DP2_ACCOUNT_ACCOUNT_R (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP2_ACCOUNT_ACCOUNT_SHIFT 0
    /*
    * Data port 3 budget register
    */
    #define DDR220542036_IP_2036_ARB_DP3_BUDGET_REG  (DDR220542036_BASE_0 + 0x260)
    /*
    * Specify the gross bandwidth budget, as a fraction of the total available bandwid
    * th.
    */
    #define DDR220542036_IP_2036_ARB_DP3_BUDGET_NUMERATOR_RW (0x07f << 8)
    #define DDR220542036_IP_2036_ARB_DP3_BUDGET_NUMERATOR_SHIFT 8
    #define DDR220542036_IP_2036_ARB_DP3_BUDGET_DENOMINATOR_RW (0x0ff << 0)
    #define DDR220542036_IP_2036_ARB_DP3_BUDGET_DENOMINATOR_SHIFT 0
    /*
    * Data port 3 clip register
    */
    #define DDR220542036_IP_2036_ARB_DP3_CLIP_REG  (DDR220542036_BASE_0 + 0x264)
    /*
    * Saturation level for the account
    */
    #define DDR220542036_IP_2036_ARB_DP3_CLIP_CLIP_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP3_CLIP_CLIP_SHIFT 0
    /*
    * Data port 3 limit register
    */
    #define DDR220542036_IP_2036_ARB_DP3_LIMIT_REG  (DDR220542036_BASE_0 + 0x268)
    /*
    * Threshold for out-of-budget detection
    */
    #define DDR220542036_IP_2036_ARB_DP3_LIMIT_LIMIT_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP3_LIMIT_LIMIT_SHIFT 0
    /*
    * Data port 3 boost register
    */
    #define DDR220542036_IP_2036_ARB_DP3_BOOST_REG  (DDR220542036_BASE_0 + 0x26c)
    /*
    * Threshold for priority boosting
    */
    #define DDR220542036_IP_2036_ARB_DP3_BOOST_BOOST_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP3_BOOST_BOOST_SHIFT 0
    /*
    * Data port 3 priority register
    */
    #define DDR220542036_IP_2036_ARB_DP3_PRIO_REG  (DDR220542036_BASE_0 + 0x270)
    /*
    * Limited priority, when out-of-budget
    */
    #define DDR220542036_IP_2036_ARB_DP3_PRIO_LIMITED_RW (0x07 << 8)
    #define DDR220542036_IP_2036_ARB_DP3_PRIO_LIMITED_SHIFT 8
    /*
    * Default priority
    */
    #define DDR220542036_IP_2036_ARB_DP3_PRIO_DEFAULT_RW (0x07 << 4)
    #define DDR220542036_IP_2036_ARB_DP3_PRIO_DEFAULT_SHIFT 4
    /*
    * Boosted priority, when close to deadline
    */
    #define DDR220542036_IP_2036_ARB_DP3_PRIO_BOOSTED_RW (0x0f << 0)
    #define DDR220542036_IP_2036_ARB_DP3_PRIO_BOOSTED_SHIFT 0
    /*
    * Data port 3 account register
    */
    #define DDR220542036_IP_2036_ARB_DP3_ACCOUNT_REG  (DDR220542036_BASE_0 + 0x274)
    /*
    * Snapshot of the account value, captured together with the performance counters
    */
    #define DDR220542036_IP_2036_ARB_DP3_ACCOUNT_ACCOUNT_R (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP3_ACCOUNT_ACCOUNT_SHIFT 0
    /*
    * Data port 3 budget register
    */
    #define DDR220542036_IP_2036_ARB_DP4_BUDGET_REG  (DDR220542036_BASE_0 + 0x280)
    /*
    * Specify the gross bandwidth budget, as a fraction of the total available bandwid
    * th.
    */
    #define DDR220542036_IP_2036_ARB_DP4_BUDGET_NUMERATOR_RW (0x07f << 8)
    #define DDR220542036_IP_2036_ARB_DP4_BUDGET_NUMERATOR_SHIFT 8
    #define DDR220542036_IP_2036_ARB_DP4_BUDGET_DENOMINATOR_RW (0x0ff << 0)
    #define DDR220542036_IP_2036_ARB_DP4_BUDGET_DENOMINATOR_SHIFT 0
    /*
    * Data port 3 clip register
    */
    #define DDR220542036_IP_2036_ARB_DP4_CLIP_REG  (DDR220542036_BASE_0 + 0x284)
    /*
    * Saturation level for the account
    */
    #define DDR220542036_IP_2036_ARB_DP4_CLIP_CLIP_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP4_CLIP_CLIP_SHIFT 0
    /*
    * Data port 3 limit register
    */
    #define DDR220542036_IP_2036_ARB_DP4_LIMIT_REG  (DDR220542036_BASE_0 + 0x288)
    /*
    * Threshold for out-of-budget detection
    */
    #define DDR220542036_IP_2036_ARB_DP4_LIMIT_LIMIT_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP4_LIMIT_LIMIT_SHIFT 0
    /*
    * Data port 3 boost register
    */
    #define DDR220542036_IP_2036_ARB_DP4_BOOST_REG  (DDR220542036_BASE_0 + 0x28c)
    /*
    * Threshold for priority boosting
    */
    #define DDR220542036_IP_2036_ARB_DP4_BOOST_BOOST_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP4_BOOST_BOOST_SHIFT 0
    /*
    * Data port 3 priority register
    */
    #define DDR220542036_IP_2036_ARB_DP4_PRIO_REG  (DDR220542036_BASE_0 + 0x290)
    /*
    * Limited priority, when out-of-budget
    */
    #define DDR220542036_IP_2036_ARB_DP4_PRIO_LIMITED_RW (0x07 << 8)
    #define DDR220542036_IP_2036_ARB_DP4_PRIO_LIMITED_SHIFT 8
    /*
    * Default priority
    */
    #define DDR220542036_IP_2036_ARB_DP4_PRIO_DEFAULT_RW (0x07 << 4)
    #define DDR220542036_IP_2036_ARB_DP4_PRIO_DEFAULT_SHIFT 4
    /*
    * Boosted priority, when close to deadline
    */
    #define DDR220542036_IP_2036_ARB_DP4_PRIO_BOOSTED_RW (0x0f << 0)
    #define DDR220542036_IP_2036_ARB_DP4_PRIO_BOOSTED_SHIFT 0
    /*
    * Data port 3 account register
    */
    #define DDR220542036_IP_2036_ARB_DP4_ACCOUNT_REG  (DDR220542036_BASE_0 + 0x294)
    /*
    * Snapshot of the account value, captured together with the performance counters
    */
    #define DDR220542036_IP_2036_ARB_DP4_ACCOUNT_ACCOUNT_R (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP4_ACCOUNT_ACCOUNT_SHIFT 0
    /*
    * Data port 3 budget register
    */
    #define DDR220542036_IP_2036_ARB_DP5_BUDGET_REG  (DDR220542036_BASE_0 + 0x2a0)
    /*
    * Specify the gross bandwidth budget, as a fraction of the total available bandwid
    * th.
    */
    #define DDR220542036_IP_2036_ARB_DP5_BUDGET_NUMERATOR_RW (0x07f << 8)
    #define DDR220542036_IP_2036_ARB_DP5_BUDGET_NUMERATOR_SHIFT 8
    #define DDR220542036_IP_2036_ARB_DP5_BUDGET_DENOMINATOR_RW (0x0ff << 0)
    #define DDR220542036_IP_2036_ARB_DP5_BUDGET_DENOMINATOR_SHIFT 0
    /*
    * Data port 3 clip register
    */
    #define DDR220542036_IP_2036_ARB_DP5_CLIP_REG  (DDR220542036_BASE_0 + 0x2a4)
    /*
    * Saturation level for the account
    */
    #define DDR220542036_IP_2036_ARB_DP5_CLIP_CLIP_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP5_CLIP_CLIP_SHIFT 0
    /*
    * Data port 3 limit register
    */
    #define DDR220542036_IP_2036_ARB_DP5_LIMIT_REG  (DDR220542036_BASE_0 + 0x2a8)
    /*
    * Threshold for out-of-budget detection
    */
    #define DDR220542036_IP_2036_ARB_DP5_LIMIT_LIMIT_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP5_LIMIT_LIMIT_SHIFT 0
    /*
    * Data port 3 boost register
    */
    #define DDR220542036_IP_2036_ARB_DP5_BOOST_REG  (DDR220542036_BASE_0 + 0x2ac)
    /*
    * Threshold for priority boosting
    */
    #define DDR220542036_IP_2036_ARB_DP5_BOOST_BOOST_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP5_BOOST_BOOST_SHIFT 0
    /*
    * Data port 3 priority register
    */
    #define DDR220542036_IP_2036_ARB_DP5_PRIO_REG  (DDR220542036_BASE_0 + 0x2b0)
    /*
    * Limited priority, when out-of-budget
    */
    #define DDR220542036_IP_2036_ARB_DP5_PRIO_LIMITED_RW (0x07 << 8)
    #define DDR220542036_IP_2036_ARB_DP5_PRIO_LIMITED_SHIFT 8
    /*
    * Default priority
    */
    #define DDR220542036_IP_2036_ARB_DP5_PRIO_DEFAULT_RW (0x07 << 4)
    #define DDR220542036_IP_2036_ARB_DP5_PRIO_DEFAULT_SHIFT 4
    /*
    * Boosted priority, when close to deadline
    */
    #define DDR220542036_IP_2036_ARB_DP5_PRIO_BOOSTED_RW (0x0f << 0)
    #define DDR220542036_IP_2036_ARB_DP5_PRIO_BOOSTED_SHIFT 0
    /*
    * Data port 3 account register
    */
    #define DDR220542036_IP_2036_ARB_DP5_ACCOUNT_REG  (DDR220542036_BASE_0 + 0x2b4)
    /*
    * Snapshot of the account value, captured together with the performance counters
    */
    #define DDR220542036_IP_2036_ARB_DP5_ACCOUNT_ACCOUNT_R (0x0ffff << 0)
    #define DDR220542036_IP_2036_ARB_DP5_ACCOUNT_ACCOUNT_SHIFT 0
    /*
    * Automatic wakeup enabling register
    */
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_REG  (DDR220542036_BASE_0 + 0x308)
    /*
    * Stall commands at port 5, to guarantee absence of port activity
    */
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT5_STALL_RW (0x01 << 7)
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT5_STALL_SHIFT 7
    /*
    * Stall commands at port 4, to guarantee absence of port activity
    */
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT4_STALL_RW (0x01 << 6)
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT4_STALL_SHIFT 6
    /*
    * Stall commands at port 3, to guarantee absence of port activity
    */
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT3_STALL_RW (0x01 << 5)
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT3_STALL_SHIFT 5
    /*
    * Stall commands at port 2, to guarantee absence of port activity
    */
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT2_STALL_RW (0x01 << 4)
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT2_STALL_SHIFT 4
    /*
    * Stall commands at port 1, to guarantee absence of port activity
    */
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT1_STALL_RW (0x01 << 3)
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT1_STALL_SHIFT 3
    /*
    * Stall commands at port 0, to guarantee absence of port activity
    */
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT0_STALL_RW (0x01 << 2)
    #define DDR220542036_IP_2036_PWR_EN_WAKEUP_PORT0_STALL_SHIFT 2
    /*
    * PHY general purpose control register
    */
    #define DDR220542036_IP_2036_PHY_CTL_REG  (DDR220542036_BASE_0 + 0x404)
    /*
    * User defined control bits for the PHY, controls the phy_control output
    */
    #define DDR220542036_IP_2036_PHY_CTL_PHY_CONTROL_RW (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PHY_CTL_PHY_CONTROL_SHIFT 0
    /*
    * PHY general purpose status register
    */
    #define DDR220542036_IP_2036_PHY_STATUS_REG  (DDR220542036_BASE_0 + 0x40c)
    /*
    * User defined status bits for the PHY, reflect the phy_status input
    */
    #define DDR220542036_IP_2036_PHY_STATUS_PHY_STATUS_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PHY_STATUS_PHY_STATUS_SHIFT 0
    /*
    * IO pad impedance control register
    */
    #define DDR220542036_IP_2036_PHY_IMPEDANCE_REG  (DDR220542036_BASE_0 + 0x414)
    /*
    * DDR2 only: Enable the use of ODT on the SoC's DQ and DQS pads, and the generatio
    * n of the ODT signal for the memory
    */
    #define DDR220542036_IP_2036_PHY_IMPEDANCE_EN_ODT_RW (0x01 << 2)
    #define DDR220542036_IP_2036_PHY_IMPEDANCE_EN_ODT_SHIFT 2
    /*
    * Performance measurement control register
    */
    #define DDR220542036_IP_2036_PF_CONTROL_REG  (DDR220542036_BASE_0 + 0x600)
    /*
    * Trigger for capturing performance data into registers
    */
    #define DDR220542036_IP_2036_PF_CONTROL_CAPTURE_W (0x01 << 0)
    #define DDR220542036_IP_2036_PF_CONTROL_CAPTURE_SHIFT 0
    /*
    * Performance measurement timestamp register
    */
    #define DDR220542036_IP_2036_PF_TIMESTAMP_REG  (DDR220542036_BASE_0 + 0x604)
    /*
    * Timestamp at which performance counters and arbitration accounts were captured
    */
    #define DDR220542036_IP_2036_PF_TIMESTAMP_TIMESTAMP_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_TIMESTAMP_TIMESTAMP_SHIFT 0
    /*
    * Control port cycle count register
    */
    #define DDR220542036_IP_2036_PF_CONTROL_PORT_REG  (DDR220542036_BASE_0 + 0x610)
    /*
    * Counter for clock cycles lost because of refresh, initialization and SW commands
    * 
    */
    #define DDR220542036_IP_2036_PF_CONTROL_PORT_CONTROL_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_CONTROL_PORT_CONTROL_SHIFT 0
    /*
    * Idle cycle count register
    */
    #define DDR220542036_IP_2036_PF_IDLE_REG  (DDR220542036_BASE_0 + 0x614)
    /*
    * Counter for idle clock cycles
    */
    #define DDR220542036_IP_2036_PF_IDLE_IDLE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_IDLE_IDLE_SHIFT 0
    /*
    * Data port 0 read count register
    */
    #define DDR220542036_IP_2036_PF_DP0_READ_REG  (DDR220542036_BASE_0 + 0x700)
    /*
    * Counter for net read data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP0_READ_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP0_READ_READ_SHIFT 0
    /*
    * Data port 0 write count register
    */
    #define DDR220542036_IP_2036_PF_DP0_WRITE_REG  (DDR220542036_BASE_0 + 0x704)
    /*
    * Counter for net write data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP0_WRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP0_WRITE_WRITE_SHIFT 0
    /*
    * Data port 0 gross read count register
    */
    #define DDR220542036_IP_2036_PF_DP0_GREAD_REG  (DDR220542036_BASE_0 + 0x708)
    /*
    * Counter for gross read data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP0_GREAD_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP0_GREAD_READ_SHIFT 0
    /*
    * Data port 0 gross write count register
    */
    #define DDR220542036_IP_2036_PF_DP0_GWRITE_REG  (DDR220542036_BASE_0 + 0x70c)
    /*
    * Counter for gross write data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP0_GWRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP0_GWRITE_WRITE_SHIFT 0
    /*
    * Data port 1 read count register
    */
    #define DDR220542036_IP_2036_PF_DP1_READ_REG  (DDR220542036_BASE_0 + 0x710)
    /*
    * Counter for net read data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP1_READ_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP1_READ_READ_SHIFT 0
    /*
    * Data port 1 write count register
    */
    #define DDR220542036_IP_2036_PF_DP1_WRITE_REG  (DDR220542036_BASE_0 + 0x714)
    /*
    * Counter for net write data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP1_WRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP1_WRITE_WRITE_SHIFT 0
    /*
    * Data port 1 gross read count register
    */
    #define DDR220542036_IP_2036_PF_DP1_GREAD_REG  (DDR220542036_BASE_0 + 0x718)
    /*
    * Counter for gross read data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP1_GREAD_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP1_GREAD_READ_SHIFT 0
    /*
    * Data port 1 gross write count register
    */
    #define DDR220542036_IP_2036_PF_DP1_GWRITE_REG  (DDR220542036_BASE_0 + 0x71c)
    /*
    * Counter for gross write data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP1_GWRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP1_GWRITE_WRITE_SHIFT 0
    /*
    * Data port 2 read count register
    */
    #define DDR220542036_IP_2036_PF_DP2_READ_REG  (DDR220542036_BASE_0 + 0x720)
    /*
    * Counter for net read data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP2_READ_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP2_READ_READ_SHIFT 0
    /*
    * Data port 2 write count register
    */
    #define DDR220542036_IP_2036_PF_DP2_WRITE_REG  (DDR220542036_BASE_0 + 0x724)
    /*
    * Counter for net write data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP2_WRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP2_WRITE_WRITE_SHIFT 0
    /*
    * Data port 2 gross read count register
    */
    #define DDR220542036_IP_2036_PF_DP2_GREAD_REG  (DDR220542036_BASE_0 + 0x728)
    /*
    * Counter for gross read data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP2_GREAD_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP2_GREAD_READ_SHIFT 0
    /*
    * Data port 2 gross write count register
    */
    #define DDR220542036_IP_2036_PF_DP2_GWRITE_REG  (DDR220542036_BASE_0 + 0x72c)
    /*
    * Counter for gross write data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP2_GWRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP2_GWRITE_WRITE_SHIFT 0
    /*
    * Data port 3 read count register
    */
    #define DDR220542036_IP_2036_PF_DP3_READ_REG  (DDR220542036_BASE_0 + 0x730)
    /*
    * Counter for net read data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP3_READ_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP3_READ_READ_SHIFT 0
    /*
    * Data port 3 write count register
    */
    #define DDR220542036_IP_2036_PF_DP3_WRITE_REG  (DDR220542036_BASE_0 + 0x734)
    /*
    * Counter for net write data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP3_WRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP3_WRITE_WRITE_SHIFT 0
    /*
    * Data port 3 gross read count register
    */
    #define DDR220542036_IP_2036_PF_DP3_GREAD_REG  (DDR220542036_BASE_0 + 0x738)
    /*
    * Counter for gross read data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP3_GREAD_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP3_GREAD_READ_SHIFT 0
    /*
    * Data port 3 gross write count register
    */
    #define DDR220542036_IP_2036_PF_DP3_GWRITE_REG  (DDR220542036_BASE_0 + 0x73c)
    /*
    * Counter for gross write data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP3_GWRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP3_GWRITE_WRITE_SHIFT 0
    /*
    * Data port 3 read count register
    */
    #define DDR220542036_IP_2036_PF_DP4_READ_REG  (DDR220542036_BASE_0 + 0x740)
    /*
    * Counter for net read data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP4_READ_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP4_READ_READ_SHIFT 0
    /*
    * Data port 3 write count register
    */
    #define DDR220542036_IP_2036_PF_DP4_WRITE_REG  (DDR220542036_BASE_0 + 0x744)
    /*
    * Counter for net write data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP4_WRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP4_WRITE_WRITE_SHIFT 0
    /*
    * Data port 3 gross read count register
    */
    #define DDR220542036_IP_2036_PF_DP4_GREAD_REG  (DDR220542036_BASE_0 + 0x748)
    /*
    * Counter for gross read data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP4_GREAD_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP4_GREAD_READ_SHIFT 0
    /*
    * Data port 3 gross write count register
    */
    #define DDR220542036_IP_2036_PF_DP4_GWRITE_REG  (DDR220542036_BASE_0 + 0x74c)
    /*
    * Counter for gross write data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP4_GWRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP4_GWRITE_WRITE_SHIFT 0
    /*
    * Data port 3 read count register
    */
    #define DDR220542036_IP_2036_PF_DP5_READ_REG  (DDR220542036_BASE_0 + 0x750)
    /*
    * Counter for net read data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP5_READ_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP5_READ_READ_SHIFT 0
    /*
    * Data port 3 write count register
    */
    #define DDR220542036_IP_2036_PF_DP5_WRITE_REG  (DDR220542036_BASE_0 + 0x754)
    /*
    * Counter for net write data cycles (excluding stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP5_WRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP5_WRITE_WRITE_SHIFT 0
    /*
    * Data port 3 gross read count register
    */
    #define DDR220542036_IP_2036_PF_DP5_GREAD_REG  (DDR220542036_BASE_0 + 0x758)
    /*
    * Counter for gross read data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP5_GREAD_READ_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP5_GREAD_READ_SHIFT 0
    /*
    * Data port 3 gross write count register
    */
    #define DDR220542036_IP_2036_PF_DP5_GWRITE_REG  (DDR220542036_BASE_0 + 0x75c)
    /*
    * Counter for gross write data cycles (including stall cycles)
    */
    #define DDR220542036_IP_2036_PF_DP5_GWRITE_WRITE_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_PF_DP5_GWRITE_WRITE_SHIFT 0
    /*
    * Mode set register
    */
    #define DDR220542036_IP_2036_MODE_SET_REG  (DDR220542036_BASE_0 + 0x800)
    /*
    * Requested mode
    */
    #define DDR220542036_IP_2036_MODE_SET_SET_MODE_W (0x07 << 0)
    #define DDR220542036_IP_2036_MODE_SET_SET_MODE_SHIFT 0
    /*
    * Mode get register
    */
    #define DDR220542036_IP_2036_MODE_GET_REG  (DDR220542036_BASE_0 + 0x804)
    /*
    * Requested mode
    */
    #define DDR220542036_IP_2036_MODE_GET_GET_MODE_R (0x07 << 0)
    #define DDR220542036_IP_2036_MODE_GET_GET_MODE_SHIFT 0
    /*
    * Control of PHY PLL lock usage
    */
    #define DDR220542036_IP_2036_PLL_LOCK_CTL_REG  (DDR220542036_BASE_0 + 0x810)
    /*
    * Alternative source for PHY PLL lock indication
    */
    #define DDR220542036_IP_2036_PLL_LOCK_CTL_SYS_PLL_LOCK_RW (0x01 << 16)
    #define DDR220542036_IP_2036_PLL_LOCK_CTL_SYS_PLL_LOCK_SHIFT 16
    /*
    * Select source for PLL lock indication used in PHY
    */
    #define DDR220542036_IP_2036_PLL_LOCK_CTL_PLL_LOCK_SEL_RW (0x01 << 8)
    #define DDR220542036_IP_2036_PLL_LOCK_CTL_PLL_LOCK_SEL_SHIFT 8
    /*
    * Select source for PLL lock indication used in MODE ctrl state machine
    */
    #define DDR220542036_IP_2036_PLL_LOCK_CTL_PLL_LOCK_FORCE_RW (0x01 << 0)
    #define DDR220542036_IP_2036_PLL_LOCK_CTL_PLL_LOCK_FORCE_SHIFT 0
    /*
    * Wost-case PHY PLL lock time
    */
    #define DDR220542036_IP_2036_PLL_LOCK_TIME_REG  (DDR220542036_BASE_0 + 0x814)
    /*
    * PLL lock-time counter
    */
    #define DDR220542036_IP_2036_PLL_LOCK_TIME_PLL_LOCK_TIME_RW (0x0ffff << 0)
    #define DDR220542036_IP_2036_PLL_LOCK_TIME_PLL_LOCK_TIME_SHIFT 0
    /*
    * Control of PHY DLL lock and PCAL done usage
    */
    #define DDR220542036_IP_2036_DLL_LOCK_CTL_REG  (DDR220542036_BASE_0 + 0x820)
    /*
    * Select source for DLL lock and PCAL done indication
    */
    #define DDR220542036_IP_2036_DLL_LOCK_CTL_DLL_LOCK_FORCE_RW (0x01 << 0)
    #define DDR220542036_IP_2036_DLL_LOCK_CTL_DLL_LOCK_FORCE_SHIFT 0
    /*
    * Worst-case DLL lock and PCAL done time
    */
    #define DDR220542036_IP_2036_DLL_LOCK_TIME_REG  (DDR220542036_BASE_0 + 0x824)
    /*
    * DLL lock-time counter
    */
    #define DDR220542036_IP_2036_DLL_LOCK_TIME_DLL_LOCK_TIME_RW (0x01ffff << 0)
    #define DDR220542036_IP_2036_DLL_LOCK_TIME_DLL_LOCK_TIME_SHIFT 0
    /*
    * Control of dummy reads for PHY squelch calibration
    */
    #define DDR220542036_IP_2036_FXD_RD_EN_REG  (DDR220542036_BASE_0 + 0x830)
    /*
    * Select source criterium squelch calibration done
    */
    #define DDR220542036_IP_2036_FXD_RD_EN_FXD_RD_EN_RW (0x01 << 0)
    #define DDR220542036_IP_2036_FXD_RD_EN_FXD_RD_EN_SHIFT 0
    /*
    * Number of dummy reads
    */
    #define DDR220542036_IP_2036_FXD_RD_NMB_REG  (DDR220542036_BASE_0 + 0x834)
    /*
    * Number of dummy reads used for doing squelch calibration
    */
    #define DDR220542036_IP_2036_FXD_RD_NMB_FXD_RD_NMB_RW (0x0ff << 0)
    #define DDR220542036_IP_2036_FXD_RD_NMB_FXD_RD_NMB_SHIFT 0
    /*
    * MTL address used for dummy reads used in squelch calibration
    */
    #define DDR220542036_IP_2036_MTL_RD_ADDR_REG  (DDR220542036_BASE_0 + 0x838)
    /*
    * MTL address used for dummy reads doing squelch calibration
    */
    #define DDR220542036_IP_2036_MTL_RD_ADDR_MTL_RD_ADDR_RW (0x07fffffff << 0)
    #define DDR220542036_IP_2036_MTL_RD_ADDR_MTL_RD_ADDR_SHIFT 0
    /*
    * Counter for waiting 200 us with stable clocks (required in SDRAM initialization)
    * 
    */
    #define DDR220542036_IP_2036_SDRAM_WAIT_200US_REG  (DDR220542036_BASE_0 + 0x840)
    /*
    * Wating time in clock-cycles (must match 200 us)
    */
    #define DDR220542036_IP_2036_SDRAM_WAIT_200US_SDRAM_WAIT_200US_RW (0x0fffffff << 0)
    #define DDR220542036_IP_2036_SDRAM_WAIT_200US_SDRAM_WAIT_200US_SHIFT 0
    /*
    * Control IO PVT calibration
    */
    #define DDR220542036_IP_2036_IO_PVT_CAL_REG  (DDR220542036_BASE_0 + 0x850)
    /*
    * Number of clock-cycles between PVT Calibration updates, must be larger than 0x0
    */
    #define DDR220542036_IP_2036_IO_PVT_CAL_PCAL_TIMING_RW (0x07ffff << 12)
    #define DDR220542036_IP_2036_IO_PVT_CAL_PCAL_TIMING_SHIFT 12
    /*
    * IO PVT calibration mode
    */
    #define DDR220542036_IP_2036_IO_PVT_CAL_PCAL_CONTINUOUS_RW (0x01 << 0)
    #define DDR220542036_IP_2036_IO_PVT_CAL_PCAL_CONTINUOUS_SHIFT 0
    /*
    * Control state transtions
    */
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION1_REG  (DDR220542036_BASE_0 + 0x860)
    /*
    * Source phy_pcal_enable output mode-control module
    */
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION1_PCAL_ENABLE_RW (0x01 << 24)
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION1_PCAL_ENABLE_SHIFT 24
    /*
    * Source phy_ck_mdll_enable output mode-control module
    */
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION1_CK_DLL_ENABLE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION1_CK_DLL_ENABLE_SHIFT 16
    /*
    * Source phy_sq_mdll_enable output mode-control module
    */
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION1_SQ_DLL_ENABLE_RW (0x01 << 8)
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION1_SQ_DLL_ENABLE_SHIFT 8
    /*
    * Source dll_enable output mode-control module
    */
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION1_DLL_CORR_ENABLE_RW (0x01 << 0)
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION1_DLL_CORR_ENABLE_SHIFT 0
    /*
    * Control state transtions
    */
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION2_REG  (DDR220542036_BASE_0 + 0x864)
    /*
    * Source phy_pd[1:0] output mode-control module
    */
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION2_PHY_PD_RW (0x01 << 8)
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION2_PHY_PD_SHIFT 8
    /*
    * Source phy_init_ready output mode-control module
    */
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION2_PHY_INIT_READY_RW (0x01 << 0)
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION2_PHY_INIT_READY_SHIFT 0
    /*
    * Control state transtions
    */
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION3_REG  (DDR220542036_BASE_0 + 0x868)
    /*
    * Observation DFI signal dfi_init_complete
    */
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION3_DFI_INIT_COMPLETE_R (0x01 << 0)
    #define DDR220542036_IP_2036_CTL_STATE_TRANSITION3_DFI_INIT_COMPLETE_SHIFT 0
    /*
    * Control state transtions
    */
    #define DDR220542036_IP_2036_OBFUSCATION_CTL_REG  (DDR220542036_BASE_0 + 0x880)
    /*
    * Enable obfuscation
    */
    #define DDR220542036_IP_2036_OBFUSCATION_CTL_ENABLE_RW (0x01 << 0)
    #define DDR220542036_IP_2036_OBFUSCATION_CTL_ENABLE_SHIFT 0
    /*
    * PHY read delay control
    */
    #define DDR220542036_IP_2036_PHY_READ_CTL_REG  (DDR220542036_BASE_0 + 0x8a0)
    /*
    * Time between read command and dfi_rddata_en on DFI interface (PHY requirement)
    */
    #define DDR220542036_IP_2036_PHY_READ_CTL_TPHY_RDDATA_EN_RW (0x07 << 16)
    #define DDR220542036_IP_2036_PHY_READ_CTL_TPHY_RDDATA_EN_SHIFT 16
    /*
    * Time between read command and read data capture
    */
    #define DDR220542036_IP_2036_PHY_READ_CTL_CAPTURE_DELAY_RW (0x01f << 0)
    #define DDR220542036_IP_2036_PHY_READ_CTL_CAPTURE_DELAY_SHIFT 0
    /*
    * PHY read delay control
    */
    #define DDR220542036_IP_2036_PHY_CLK_CTL_REG  (DDR220542036_BASE_0 + 0x8a4)
    /*
    * SDRAM clock disable
    */
    #define DDR220542036_IP_2036_PHY_CLK_CTL_DFI_DRAM_CLK_DISABLE_RW (0x01 << 0)
    #define DDR220542036_IP_2036_PHY_CLK_CTL_DFI_DRAM_CLK_DISABLE_SHIFT 0
    /*
    * PHY read delay control
    */
    #define DDR220542036_IP_2036_PHY_SUSPEND_REG  (DDR220542036_BASE_0 + 0x8a8)
    /*
    * Suspend bytes (used in half-width mode)
    */
    #define DDR220542036_IP_2036_PHY_SUSPEND_PHY_SUSPEND_RW (0x0f << 0)
    #define DDR220542036_IP_2036_PHY_SUSPEND_PHY_SUSPEND_SHIFT 0
    /*
    * Select ODT control during READ
    */
    #define DDR220542036_IP_2036_CTRL_ODT_RD_REG  (DDR220542036_BASE_0 + 0x8b0)
    /*
    * Drives PHY input force_odt_off in case CTRL_RD_ODT_TYPE is 0
    */
    #define DDR220542036_IP_2036_CTRL_ODT_RD_FORCE_ODT_OFF_RW (0x01 << 4)
    #define DDR220542036_IP_2036_CTRL_ODT_RD_FORCE_ODT_OFF_SHIFT 4
    /*
    * Select ODT control type
    */
    #define DDR220542036_IP_2036_CTRL_ODT_RD_CTRL_ODT_RD_TYPE_RW (0x01 << 0)
    #define DDR220542036_IP_2036_CTRL_ODT_RD_CTRL_ODT_RD_TYPE_SHIFT 0
    /*
    * Timing ODT control during read
    */
    #define DDR220542036_IP_2036_CTRL_ODT_RD_TIMING_REG  (DDR220542036_BASE_0 + 0x8b4)
    /*
    * Delay from READ command in force_odt_off going low from the READ command (1-rela
    * tive)
    */
    #define DDR220542036_IP_2036_CTRL_ODT_RD_TIMING_ODT_RD_DELAY_RW (0x0f << 4)
    #define DDR220542036_IP_2036_CTRL_ODT_RD_TIMING_ODT_RD_DELAY_SHIFT 4
    /*
    * Extension of force_odt_off being low on top of BL/2
    */
    #define DDR220542036_IP_2036_CTRL_ODT_RD_TIMING_ODT_RD_EXT_RW (0x07 << 0)
    #define DDR220542036_IP_2036_CTRL_ODT_RD_TIMING_ODT_RD_EXT_SHIFT 0
    /*
    * Internal read strobe delay for byte-lane 3
    */
    #define DDR220542036_IP_2036_DQS_RD3_CODE_REG  (DDR220542036_BASE_0 + 0x900)
    /*
    * Keep code fixed as it is
    */
    #define DDR220542036_IP_2036_DQS_RD3_CODE_FREEZE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_DQS_RD3_CODE_FREEZE_SHIFT 16
    /*
    * +1/4 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C7_RW (0x01 << 7)
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C7_SHIFT 7
    /*
    * +1/8 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C6_RW (0x01 << 6)
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C6_SHIFT 6
    /*
    * +1/16 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C5_RW (0x01 << 5)
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C5_SHIFT 5
    /*
    * +1/32 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C4_RW (0x01 << 4)
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C4_SHIFT 4
    /*
    * +1/64 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C3_RW (0x01 << 3)
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C3_SHIFT 3
    /*
    * +1/128 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C2_RW (0x01 << 2)
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C2_SHIFT 2
    /*
    * +1/256 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C1_RW (0x01 << 1)
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C1_SHIFT 1
    /*
    * +1/512 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C0_RW (0x01 << 0)
    #define DDR220542036_IP_2036_DQS_RD3_CODE_C0_SHIFT 0
    /*
    * Internal read strobe delay for byte-lane 2
    */
    #define DDR220542036_IP_2036_DQS_RD2_CODE_REG  (DDR220542036_BASE_0 + 0x904)
    /*
    * Keep code fixed as it is
    */
    #define DDR220542036_IP_2036_DQS_RD2_CODE_FREEZE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_DQS_RD2_CODE_FREEZE_SHIFT 16
    /*
    * +1/4 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C7_RW (0x01 << 7)
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C7_SHIFT 7
    /*
    * +1/8 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C6_RW (0x01 << 6)
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C6_SHIFT 6
    /*
    * +1/16 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C5_RW (0x01 << 5)
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C5_SHIFT 5
    /*
    * +1/32 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C4_RW (0x01 << 4)
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C4_SHIFT 4
    /*
    * +1/64 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C3_RW (0x01 << 3)
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C3_SHIFT 3
    /*
    * +1/128 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C2_RW (0x01 << 2)
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C2_SHIFT 2
    /*
    * +1/256 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C1_RW (0x01 << 1)
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C1_SHIFT 1
    /*
    * +1/512 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C0_RW (0x01 << 0)
    #define DDR220542036_IP_2036_DQS_RD2_CODE_C0_SHIFT 0
    /*
    * Internal read strobe delay for byte-lane 1
    */
    #define DDR220542036_IP_2036_DQS_RD1_CODE_REG  (DDR220542036_BASE_0 + 0x908)
    /*
    * Keep code fixed as it is
    */
    #define DDR220542036_IP_2036_DQS_RD1_CODE_FREEZE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_DQS_RD1_CODE_FREEZE_SHIFT 16
    /*
    * +1/4 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C7_RW (0x01 << 7)
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C7_SHIFT 7
    /*
    * +1/8 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C6_RW (0x01 << 6)
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C6_SHIFT 6
    /*
    * +1/16 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C5_RW (0x01 << 5)
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C5_SHIFT 5
    /*
    * +1/32 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C4_RW (0x01 << 4)
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C4_SHIFT 4
    /*
    * +1/64 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C3_RW (0x01 << 3)
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C3_SHIFT 3
    /*
    * +1/128 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C2_RW (0x01 << 2)
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C2_SHIFT 2
    /*
    * +1/256 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C1_RW (0x01 << 1)
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C1_SHIFT 1
    /*
    * +1/512 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C0_RW (0x01 << 0)
    #define DDR220542036_IP_2036_DQS_RD1_CODE_C0_SHIFT 0
    /*
    * Internal read strobe delay for byte-lane 0
    */
    #define DDR220542036_IP_2036_DQS_RD0_CODE_REG  (DDR220542036_BASE_0 + 0x90c)
    /*
    * Keep code fixed as it is
    */
    #define DDR220542036_IP_2036_DQS_RD0_CODE_FREEZE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_DQS_RD0_CODE_FREEZE_SHIFT 16
    /*
    * +1/4 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C7_RW (0x01 << 7)
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C7_SHIFT 7
    /*
    * +1/8 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C6_RW (0x01 << 6)
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C6_SHIFT 6
    /*
    * +1/16 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C5_RW (0x01 << 5)
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C5_SHIFT 5
    /*
    * +1/32 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C4_RW (0x01 << 4)
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C4_SHIFT 4
    /*
    * +1/64 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C3_RW (0x01 << 3)
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C3_SHIFT 3
    /*
    * +1/128 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C2_RW (0x01 << 2)
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C2_SHIFT 2
    /*
    * +1/256 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C1_RW (0x01 << 1)
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C1_SHIFT 1
    /*
    * +1/512 cc delay
    */
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C0_RW (0x01 << 0)
    #define DDR220542036_IP_2036_DQS_RD0_CODE_C0_SHIFT 0
    /*
    * Write data delay for byte-lane 3
    */
    #define DDR220542036_IP_2036_DQ_WR3_CODE_REG  (DDR220542036_BASE_0 + 0x910)
    /*
    * Keep code fixed as it is
    */
    #define DDR220542036_IP_2036_DQ_WR3_CODE_FREEZE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_DQ_WR3_CODE_FREEZE_SHIFT 16
    /*
    * +1/4 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C7_RW (0x01 << 7)
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C7_SHIFT 7
    /*
    * +1/8 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C6_RW (0x01 << 6)
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C6_SHIFT 6
    /*
    * +1/16 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C5_RW (0x01 << 5)
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C5_SHIFT 5
    /*
    * +1/32 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C4_RW (0x01 << 4)
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C4_SHIFT 4
    /*
    * +1/64 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C3_RW (0x01 << 3)
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C3_SHIFT 3
    /*
    * +1/128 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C2_RW (0x01 << 2)
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C2_SHIFT 2
    /*
    * +1/256 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C1_RW (0x01 << 1)
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C1_SHIFT 1
    /*
    * +1/512 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C0_RW (0x01 << 0)
    #define DDR220542036_IP_2036_DQ_WR3_CODE_C0_SHIFT 0
    /*
    * Write data delay for byte-lane 2
    */
    #define DDR220542036_IP_2036_DQ_WR2_CODE_REG  (DDR220542036_BASE_0 + 0x914)
    /*
    * Keep code fixed as it is
    */
    #define DDR220542036_IP_2036_DQ_WR2_CODE_FREEZE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_DQ_WR2_CODE_FREEZE_SHIFT 16
    /*
    * +1/4 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C7_RW (0x01 << 7)
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C7_SHIFT 7
    /*
    * +1/8 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C6_RW (0x01 << 6)
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C6_SHIFT 6
    /*
    * +1/16 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C5_RW (0x01 << 5)
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C5_SHIFT 5
    /*
    * +1/32 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C4_RW (0x01 << 4)
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C4_SHIFT 4
    /*
    * +1/64 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C3_RW (0x01 << 3)
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C3_SHIFT 3
    /*
    * +1/128 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C2_RW (0x01 << 2)
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C2_SHIFT 2
    /*
    * +1/256 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C1_RW (0x01 << 1)
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C1_SHIFT 1
    /*
    * +1/512 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C0_RW (0x01 << 0)
    #define DDR220542036_IP_2036_DQ_WR2_CODE_C0_SHIFT 0
    /*
    * Write data delay for byte-lane 1
    */
    #define DDR220542036_IP_2036_DQ_WR1_CODE_REG  (DDR220542036_BASE_0 + 0x918)
    /*
    * Keep code fixed as it is
    */
    #define DDR220542036_IP_2036_DQ_WR1_CODE_FREEZE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_DQ_WR1_CODE_FREEZE_SHIFT 16
    /*
    * +1/4 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C7_RW (0x01 << 7)
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C7_SHIFT 7
    /*
    * +1/8 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C6_RW (0x01 << 6)
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C6_SHIFT 6
    /*
    * +1/16 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C5_RW (0x01 << 5)
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C5_SHIFT 5
    /*
    * +1/32 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C4_RW (0x01 << 4)
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C4_SHIFT 4
    /*
    * +1/64 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C3_RW (0x01 << 3)
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C3_SHIFT 3
    /*
    * +1/128 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C2_RW (0x01 << 2)
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C2_SHIFT 2
    /*
    * +1/256 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C1_RW (0x01 << 1)
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C1_SHIFT 1
    /*
    * +1/512 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C0_RW (0x01 << 0)
    #define DDR220542036_IP_2036_DQ_WR1_CODE_C0_SHIFT 0
    /*
    * Write data delay for byte-lane 0
    */
    #define DDR220542036_IP_2036_DQ_WR0_CODE_REG  (DDR220542036_BASE_0 + 0x91c)
    /*
    * Keep code fixed as it is
    */
    #define DDR220542036_IP_2036_DQ_WR0_CODE_FREEZE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_DQ_WR0_CODE_FREEZE_SHIFT 16
    /*
    * +1/4 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C7_RW (0x01 << 7)
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C7_SHIFT 7
    /*
    * +1/8 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C6_RW (0x01 << 6)
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C6_SHIFT 6
    /*
    * +1/16 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C5_RW (0x01 << 5)
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C5_SHIFT 5
    /*
    * +1/32 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C4_RW (0x01 << 4)
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C4_SHIFT 4
    /*
    * +1/64 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C3_RW (0x01 << 3)
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C3_SHIFT 3
    /*
    * +1/128 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C2_RW (0x01 << 2)
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C2_SHIFT 2
    /*
    * +1/256 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C1_RW (0x01 << 1)
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C1_SHIFT 1
    /*
    * +1/512 cc delay
    */
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C0_RW (0x01 << 0)
    #define DDR220542036_IP_2036_DQ_WR0_CODE_C0_SHIFT 0
    /*
    * Address/control delay w.r.t. clock
    */
    #define DDR220542036_IP_2036_AC_CCODE_REG  (DDR220542036_BASE_0 + 0x920)
    /*
    * Keep code fixed as it is
    */
    #define DDR220542036_IP_2036_AC_CCODE_FREEZE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_AC_CCODE_FREEZE_SHIFT 16
    /*
    * +1/2 cc delay
    */
    #define DDR220542036_IP_2036_AC_CCODE_C8_RW (0x01 << 8)
    #define DDR220542036_IP_2036_AC_CCODE_C8_SHIFT 8
    /*
    * +1/4 cc delay
    */
    #define DDR220542036_IP_2036_AC_CCODE_C7_RW (0x01 << 7)
    #define DDR220542036_IP_2036_AC_CCODE_C7_SHIFT 7
    /*
    * +1/8 cc delay
    */
    #define DDR220542036_IP_2036_AC_CCODE_C6_RW (0x01 << 6)
    #define DDR220542036_IP_2036_AC_CCODE_C6_SHIFT 6
    /*
    * +1/16 cc delay
    */
    #define DDR220542036_IP_2036_AC_CCODE_C5_RW (0x01 << 5)
    #define DDR220542036_IP_2036_AC_CCODE_C5_SHIFT 5
    /*
    * +1/32 cc delay
    */
    #define DDR220542036_IP_2036_AC_CCODE_C4_RW (0x01 << 4)
    #define DDR220542036_IP_2036_AC_CCODE_C4_SHIFT 4
    /*
    * +1/64 cc delay
    */
    #define DDR220542036_IP_2036_AC_CCODE_C3_RW (0x01 << 3)
    #define DDR220542036_IP_2036_AC_CCODE_C3_SHIFT 3
    /*
    * +1/128 cc delay
    */
    #define DDR220542036_IP_2036_AC_CCODE_C2_RW (0x01 << 2)
    #define DDR220542036_IP_2036_AC_CCODE_C2_SHIFT 2
    /*
    * +1/256 cc delay
    */
    #define DDR220542036_IP_2036_AC_CCODE_C1_RW (0x01 << 1)
    #define DDR220542036_IP_2036_AC_CCODE_C1_SHIFT 1
    /*
    * +1/512 cc delay
    */
    #define DDR220542036_IP_2036_AC_CCODE_C0_RW (0x01 << 0)
    #define DDR220542036_IP_2036_AC_CCODE_C0_SHIFT 0
    /*
    * Squelch delay to compensate PCB delay (internal loopback of squelch used)
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_REG  (DDR220542036_BASE_0 + 0x924)
    /*
    * Keep code fixed as it is
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_FREEZE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_FREEZE_SHIFT 16
    /*
    * +1/2 cc delay
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C8_RW (0x01 << 8)
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C8_SHIFT 8
    /*
    * +1/4 cc delay
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C7_RW (0x01 << 7)
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C7_SHIFT 7
    /*
    * +1/8 cc delay
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C6_RW (0x01 << 6)
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C6_SHIFT 6
    /*
    * +1/16 cc delay
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C5_RW (0x01 << 5)
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C5_SHIFT 5
    /*
    * +1/32 cc delay
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C4_RW (0x01 << 4)
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C4_SHIFT 4
    /*
    * +1/64 cc delay
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C3_RW (0x01 << 3)
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C3_SHIFT 3
    /*
    * +1/128 cc delay
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C2_RW (0x01 << 2)
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C2_SHIFT 2
    /*
    * +1/256 cc delay
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C1_RW (0x01 << 1)
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C1_SHIFT 1
    /*
    * +1/512 cc delay
    */
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C0_RW (0x01 << 0)
    #define DDR220542036_IP_2036_PCB_SDL_CCODE_C0_SHIFT 0
    /*
    * Observation master DLL code used by AC_CCODE, DQ_WR#_CCODE, DQS_RD#_CCODE and SQ
    * _INIT_UPDATE_CODE_BYTE#
    */
    #define DDR220542036_IP_2036_CK_MDLL_CODE_REG  (DDR220542036_BASE_0 + 0x930)
    /*
    * PHY output ck_mdll_lock
    */
    #define DDR220542036_IP_2036_CK_MDLL_CODE_CK_MDLL_LOCK_R (0x01 << 24)
    #define DDR220542036_IP_2036_CK_MDLL_CODE_CK_MDLL_LOCK_SHIFT 24
    /*
    * PHY output ck_mdll_code
    */
    #define DDR220542036_IP_2036_CK_MDLL_CODE_CK_MDLL_CODE_R (0x01ff << 0)
    #define DDR220542036_IP_2036_CK_MDLL_CODE_CK_MDLL_CODE_SHIFT 0
    /*
    * Control of squelch DLL code propagation
    */
    #define DDR220542036_IP_2036_CTL_SQUELCH_DLL_REG  (DDR220542036_BASE_0 + 0x934)
    /*
    * Enable direct propagation of squelch DLL code during normal operation
    */
    #define DDR220542036_IP_2036_CTL_SQUELCH_DLL_SQ_DIRECT_EN_RW (0x01 << 8)
    #define DDR220542036_IP_2036_CTL_SQUELCH_DLL_SQ_DIRECT_EN_SHIFT 8
    /*
    * Enable direct propagation squelch DLL code during initialization (before squelch
    *  calibration)
    */
    #define DDR220542036_IP_2036_CTL_SQUELCH_DLL_SQ_INIT_DIRECT_EN_RW (0x01 << 0)
    #define DDR220542036_IP_2036_CTL_SQUELCH_DLL_SQ_INIT_DIRECT_EN_SHIFT 0
    /*
    * Observation squelch master DLL for byte-lane 0
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE0_REG  (DDR220542036_BASE_0 + 0x940)
    /*
    * PHY output sq_mdll_lock
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE0_SQ_MDLL_LOCK_R (0x01 << 24)
    #define DDR220542036_IP_2036_SQ_CODE_BYTE0_SQ_MDLL_LOCK_SHIFT 24
    /*
    * PHY output sq_code
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE0_SQ_CODE_R (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_CODE_BYTE0_SQ_CODE_SHIFT 0
    /*
    * Observation squelch master DLL for byte-lane 1
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE1_REG  (DDR220542036_BASE_0 + 0x944)
    /*
    * PHY output sq_mdll_lock
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE1_SQ_MDLL_LOCK_R (0x01 << 24)
    #define DDR220542036_IP_2036_SQ_CODE_BYTE1_SQ_MDLL_LOCK_SHIFT 24
    /*
    * PHY output sq_code
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE1_SQ_CODE_R (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_CODE_BYTE1_SQ_CODE_SHIFT 0
    /*
    * Observation squelch master DLL for byte-lane 2
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE2_REG  (DDR220542036_BASE_0 + 0x948)
    /*
    * PHY output sq_mdll_lock
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE2_SQ_MDLL_LOCK_R (0x01 << 24)
    #define DDR220542036_IP_2036_SQ_CODE_BYTE2_SQ_MDLL_LOCK_SHIFT 24
    /*
    * PHY output sq_code
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE2_SQ_CODE_R (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_CODE_BYTE2_SQ_CODE_SHIFT 0
    /*
    * Observation squelch master DLL for byte-lane 3
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE3_REG  (DDR220542036_BASE_0 + 0x94c)
    /*
    * PHY output sq_mdll_lock
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE3_SQ_MDLL_LOCK_R (0x01 << 24)
    #define DDR220542036_IP_2036_SQ_CODE_BYTE3_SQ_MDLL_LOCK_SHIFT 24
    /*
    * PHY output sq_code
    */
    #define DDR220542036_IP_2036_SQ_CODE_BYTE3_SQ_CODE_R (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_CODE_BYTE3_SQ_CODE_SHIFT 0
    /*
    * Over-rule PHY input sq_init_update_code for byte-lane 0
    */
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE0_REG  (DDR220542036_BASE_0 + 0x950)
    /*
    * Drives PHY input sq_init_update_code in case SQ_INIT_DIRECT_EN=0
    */
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE0_SQ_INIT_UPDATE_CODE_RW (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE0_SQ_INIT_UPDATE_CODE_SHIFT 0
    /*
    * Over-rule PHY input sq_init_update_code for byte-lane 1
    */
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE1_REG  (DDR220542036_BASE_0 + 0x954)
    /*
    * Drives PHY input sq_init_update_code in case SQ_INIT_DIRECT_EN=0
    */
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE1_SQ_INIT_UPDATE_CODE_RW (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE1_SQ_INIT_UPDATE_CODE_SHIFT 0
    /*
    * Over-rule PHY input sq_init_update_code for byte-lane 2
    */
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE2_REG  (DDR220542036_BASE_0 + 0x958)
    /*
    * Drives PHY input sq_init_update_code in case SQ_INIT_DIRECT_EN=0
    */
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE2_SQ_INIT_UPDATE_CODE_RW (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE2_SQ_INIT_UPDATE_CODE_SHIFT 0
    /*
    * Over-rule PHY input sq_init_update_code for byte-lane 3
    */
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE3_REG  (DDR220542036_BASE_0 + 0x95c)
    /*
    * Drives PHY input sq_init_update_code in case SQ_INIT_DIRECT_EN=0
    */
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE3_SQ_INIT_UPDATE_CODE_RW (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_INIT_UPDATE_CODE_BYTE3_SQ_INIT_UPDATE_CODE_SHIFT 0
    /*
    * Over-rule PHY input sq_update_code for byte-lane 0
    */
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE0_REG  (DDR220542036_BASE_0 + 0x960)
    /*
    * Drives PHY input sq_update_code in case SQ_DIRECT_EN=0
    */
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE0_SQ_UPDATE_CODE_RW (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE0_SQ_UPDATE_CODE_SHIFT 0
    /*
    * Over-rule PHY input sq_update_code for byte-lane 1
    */
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE1_REG  (DDR220542036_BASE_0 + 0x964)
    /*
    * Drives PHY input sq_update_code in case SQ_DIRECT_EN=0
    */
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE1_SQ_UPDATE_CODE_RW (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE1_SQ_UPDATE_CODE_SHIFT 0
    /*
    * Over-rule PHY input sq_update_code for byte-lane 2
    */
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE2_REG  (DDR220542036_BASE_0 + 0x968)
    /*
    * Drives PHY input sq_update_code in case SQ_DIRECT_EN=0
    */
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE2_SQ_UPDATE_CODE_RW (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE2_SQ_UPDATE_CODE_SHIFT 0
    /*
    * Over-rule PHY input sq_update_code for byte-lane 3
    */
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE3_REG  (DDR220542036_BASE_0 + 0x96c)
    /*
    * Drives PHY input sq_update_code in case SQ_DIRECT_EN=0
    */
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE3_SQ_UPDATE_CODE_RW (0x03ff << 0)
    #define DDR220542036_IP_2036_SQ_UPDATE_CODE_BYTE3_SQ_UPDATE_CODE_SHIFT 0
    /*
    * IO drive-strength (reserved for future usage, only single drive strength of 30 O
    * hm implemented in this version)
    */
    #define DDR220542036_IP_2036_IO_DRIVE_STRENGTH_REG  (DDR220542036_BASE_0 + 0x980)
    #define DDR220542036_IP_2036_IO_DRIVE_STRENGTH_AC_DRIVE_STRENGTH_RW (0x01 << 16)
    #define DDR220542036_IP_2036_IO_DRIVE_STRENGTH_AC_DRIVE_STRENGTH_SHIFT 16
    #define DDR220542036_IP_2036_IO_DRIVE_STRENGTH_DQS_DRIVE_STRENGTH_RW (0x01 << 8)
    #define DDR220542036_IP_2036_IO_DRIVE_STRENGTH_DQS_DRIVE_STRENGTH_SHIFT 8
    #define DDR220542036_IP_2036_IO_DRIVE_STRENGTH_DQDM_DRIVE_STRENGTH_RW (0x01 << 0)
    #define DDR220542036_IP_2036_IO_DRIVE_STRENGTH_DQDM_DRIVE_STRENGTH_SHIFT 0
    /*
    * Data-bus ODT impedance
    */
    #define DDR220542036_IP_2036_ODT_IMPEDANCE_REG  (DDR220542036_BASE_0 + 0x984)
    #define DDR220542036_IP_2036_ODT_IMPEDANCE_ODT_IMPEDANCE_RW (0x03 << 0)
    #define DDR220542036_IP_2036_ODT_IMPEDANCE_ODT_IMPEDANCE_SHIFT 0
    /*
    * Control PVT calibration code propagation
    */
    #define DDR220542036_IP_2036_CTL_PCAL_REG  (DDR220542036_BASE_0 + 0x9a0)
    #define DDR220542036_IP_2036_CTL_PCAL_PCAL_DIRECT_EN_RW (0x01 << 0)
    #define DDR220542036_IP_2036_CTL_PCAL_PCAL_DIRECT_EN_SHIFT 0
    /*
    * Observation PVT calibration result
    */
    #define DDR220542036_IP_2036_PCAL_CODE_REG  (DDR220542036_BASE_0 + 0x9a4)
    /*
    * PHY output pcal_done
    */
    #define DDR220542036_IP_2036_PCAL_CODE_PCAL_DONE_R (0x01 << 24)
    #define DDR220542036_IP_2036_PCAL_CODE_PCAL_DONE_SHIFT 24
    /*
    * PHY output pcal_code
    */
    #define DDR220542036_IP_2036_PCAL_CODE_PCAL_CODE_R (0x03ff << 0)
    #define DDR220542036_IP_2036_PCAL_CODE_PCAL_CODE_SHIFT 0
    /*
    * Observation PVT calibration result
    */
    #define DDR220542036_IP_2036_PCAL_UPDATE_CODE_REG  (DDR220542036_BASE_0 + 0x9a8)
    /*
    * Drives PHY input pcal_update_code incase PCAL_DIRECT_EN=0
    */
    #define DDR220542036_IP_2036_PCAL_UPDATE_CODE_PCAL_UPDATE_CODE_RW (0x03ff << 0)
    #define DDR220542036_IP_2036_PCAL_UPDATE_CODE_PCAL_UPDATE_CODE_SHIFT 0
    /*
    * Control production test mode
    */
    #define DDR220542036_IP_2036_CTL_TEST_MODE_REG  (DDR220542036_BASE_0 + 0xa00)
    /*
    * Enable PLL by-pass
    */
    #define DDR220542036_IP_2036_CTL_TEST_MODE_PLL_BYPASS_RW (0x01 << 24)
    #define DDR220542036_IP_2036_CTL_TEST_MODE_PLL_BYPASS_SHIFT 24
    /*
    * Enable internal loop-back
    */
    #define DDR220542036_IP_2036_CTL_TEST_MODE_LOOP_BACK_EN_RW (0x01 << 16)
    #define DDR220542036_IP_2036_CTL_TEST_MODE_LOOP_BACK_EN_SHIFT 16
    /*
    * Enable DCPAR-mode
    */
    #define DDR220542036_IP_2036_CTL_TEST_MODE_DC_PAR_EN_RW (0x01 << 0)
    #define DDR220542036_IP_2036_CTL_TEST_MODE_DC_PAR_EN_SHIFT 0
    /*
    * Observe BIST (internal loop-back) results
    */
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_REG  (DDR220542036_BASE_0 + 0xa04)
    /*
    * PHY output pll_lock
    */
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_PLL_LOCK_R (0x01 << 24)
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_PLL_LOCK_SHIFT 24
    /*
    * PHY output ck_mdll_lock
    */
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_CK_MDLL_LOCK_R (0x01 << 16)
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_CK_MDLL_LOCK_SHIFT 16
    /*
    * PHY output sq_mdll_lock
    */
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_SQ_MDLL_LOCK_R (0x07 << 8)
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_SQ_MDLL_LOCK_SHIFT 8
    /*
    * BIST completed, address/command loop-back test passed (PHY output test_status[3]
    * )
    */
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_BIST_AC_PASSED_R (0x01 << 3)
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_BIST_AC_PASSED_SHIFT 3
    /*
    * BIST completed, address/command loop-back test failed (PHY output test_status[2]
    * )
    */
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_BIST_AC_FAILED_R (0x01 << 2)
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_BIST_AC_FAILED_SHIFT 2
    /*
    * BIST completed, data loop-back test passed (PHY output test_status[1])
    */
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_BIST_DATA_PASSED_R (0x01 << 1)
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_BIST_DATA_PASSED_SHIFT 1
    /*
    * BIST completed, data loop-back test failed (PHY output test_status[0])
    */
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_BIST_DATA_FAILED_R (0x01 << 0)
    #define DDR220542036_IP_2036_OBSERVE_TEST_STATUS_BIST_DATA_FAILED_SHIFT 0
    /*
    * Control common pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_REG  (DDR220542036_BASE_0 + 0xa08)
    /*
    * Connects to address/control bus IO-cell pin read
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_AC_READ_RW (0x01 << 19)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_AC_READ_SHIFT 19
    /*
    * Connects to address/control bus IO-cell pin ie
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_AC_IE_RW (0x01 << 18)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_AC_IE_SHIFT 18
    /*
    * Connects to address/control bus IO-cell pin pi
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_AC_PI_RW (0x01 << 17)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_AC_PI_SHIFT 17
    /*
    * Connects to address/control bus IO-cell pin oe
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_AC_OE_RW (0x01 << 16)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_AC_OE_SHIFT 16
    /*
    * Connects to data bus IO-cell pin read (byte-lane2/3)
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_H_READ_RW (0x01 << 11)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_H_READ_SHIFT 11
    /*
    * Connects to data bus IO-cell pin ie (byte-lane 2/3)
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_H_IE_RW (0x01 << 10)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_H_IE_SHIFT 10
    /*
    * Connects to data bus IO-cell pin pi (byte-lane 2/3)
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_H_PI_RW (0x01 << 9)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_H_PI_SHIFT 9
    /*
    * Connects to data bus IO-cell pin oe (byte-lane 2/3)
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_H_OE_RW (0x01 << 8)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_H_OE_SHIFT 8
    /*
    * Connects to data bus IO-cell pin read (byte-lane0/1)
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_L_READ_RW (0x01 << 3)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_L_READ_SHIFT 3
    /*
    * Connects to data bus IO-cell pin ie (byte-lane 0/1)
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_L_IE_RW (0x01 << 2)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_L_IE_SHIFT 2
    /*
    * Connects to data bus IO-cell pin pi (byte-lane 0/1)
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_L_PI_RW (0x01 << 1)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_L_PI_SHIFT 1
    /*
    * Connects to data bus IO-cell pin oe (byte-lane 0/1)
    */
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_L_OE_RW (0x01 << 0)
    #define DDR220542036_IP_2036_CTL_COMMON_PINS_PT_DQDMDQS_L_OE_SHIFT 0
    /*
    * Observes address/control bus pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_REG  (DDR220542036_BASE_0 + 0xa0c)
    /*
    * Observes CS_N in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_CS_N_IN_R (0x01 << 31)
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_CS_N_IN_SHIFT 31
    /*
    * Observes A[14:0] in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_A_IN_R (0x03fff << 16)
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_A_IN_SHIFT 16
    /*
    * Observes BA[2:0] in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_BA_IN_R (0x03 << 8)
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_BA_IN_SHIFT 8
    /*
    * Observes ODT in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_ODT_IN_R (0x01 << 4)
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_ODT_IN_SHIFT 4
    /*
    * Observes WE_N in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_WE_N_IN_R (0x01 << 3)
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_WE_N_IN_SHIFT 3
    /*
    * Observes CAS_N in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_CAS_N_IN_R (0x01 << 2)
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_CAS_N_IN_SHIFT 2
    /*
    * Observes RAS_N in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_RAS_N_IN_R (0x01 << 1)
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_RAS_N_IN_SHIFT 1
    /*
    * Observes CKE in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_CKE_IN_R (0x01 << 0)
    #define DDR220542036_IP_2036_OBSERVE_AC_INPUTS_PT_CKE_IN_SHIFT 0
    /*
    * Observes data pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_DATA_INPUTS_REG  (DDR220542036_BASE_0 + 0xa10)
    /*
    * Observes data pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_DATA_INPUTS_PT_DQ_IN_R (0x07fffffff << 0)
    #define DDR220542036_IP_2036_OBSERVE_DATA_INPUTS_PT_DQ_IN_SHIFT 0
    /*
    * Observes mask and strobe pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_DMDQS_INPUTS_REG  (DDR220542036_BASE_0 + 0xa14)
    /*
    * Observes strobe pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_DMDQS_INPUTS_PT_DQS_IN_R (0x07 << 8)
    #define DDR220542036_IP_2036_OBSERVE_DMDQS_INPUTS_PT_DQS_IN_SHIFT 8
    /*
    * Observes mask pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_OBSERVE_DMDQS_INPUTS_PT_DM_IN_R (0x0f << 0)
    #define DDR220542036_IP_2036_OBSERVE_DMDQS_INPUTS_PT_DM_IN_SHIFT 0
    /*
    * Controls address/control bus pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_REG  (DDR220542036_BASE_0 + 0xa18)
    /*
    * Controls CS_N in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_CS_N_OUT_RW (0x01 << 31)
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_CS_N_OUT_SHIFT 31
    /*
    * Controls A[14:0] in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_A_OUT_RW (0x03fff << 16)
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_A_OUT_SHIFT 16
    /*
    * Controls BA[2:0] in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_BA_OUT_RW (0x03 << 8)
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_BA_OUT_SHIFT 8
    /*
    * Controls ODT in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_ODT_OUT_RW (0x01 << 4)
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_ODT_OUT_SHIFT 4
    /*
    * Controls WE_N in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_WE_N_OUT_RW (0x01 << 3)
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_WE_N_OUT_SHIFT 3
    /*
    * Controls CAS_N in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_CAS_N_OUT_RW (0x01 << 2)
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_CAS_N_OUT_SHIFT 2
    /*
    * Controls RAS_N in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_RAS_N_OUT_RW (0x01 << 1)
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_RAS_N_OUT_SHIFT 1
    /*
    * Controls CKE in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_CKE_OUT_RW (0x01 << 0)
    #define DDR220542036_IP_2036_CTL_AC_OUTPUTS_PT_CKE_OUT_SHIFT 0
    /*
    * Controls data pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_DATA_OUTPUTS_REG  (DDR220542036_BASE_0 + 0xa1c)
    /*
    * Controls data pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_DATA_OUTPUTS_PT_DQ_OUT_RW (0x07fffffff << 0)
    #define DDR220542036_IP_2036_CTL_DATA_OUTPUTS_PT_DQ_OUT_SHIFT 0
    /*
    * Controls mask and strobe pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_DMDQS_OUTPUTS_REG  (DDR220542036_BASE_0 + 0xa20)
    /*
    * controls strobe pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_DMDQS_OUTPUTS_PT_DQS_OUT_RW (0x07 << 8)
    #define DDR220542036_IP_2036_CTL_DMDQS_OUTPUTS_PT_DQS_OUT_SHIFT 8
    /*
    * controls mask pins in DC-parametrics mode
    */
    #define DDR220542036_IP_2036_CTL_DMDQS_OUTPUTS_PT_DM_OUT_RW (0x0f << 0)
    #define DDR220542036_IP_2036_CTL_DMDQS_OUTPUTS_PT_DM_OUT_SHIFT 0
    /*
    * Power down register
    */
    #define DDR220542036_IP_2036_POWER_DOWN_REG  (DDR220542036_BASE_0 + 0xff4)
    /*
    * Controller core power down
    */
    #define DDR220542036_IP_2036_POWER_DOWN_POWER_DOWN_RW (0x01 << 0)
    #define DDR220542036_IP_2036_POWER_DOWN_POWER_DOWN_SHIFT 0
    /*
    * Module ID register
    */
    #define DDR220542036_IP_2036_MODULE_ID_REG  (DDR220542036_BASE_0 + 0xffc)
    /*
    * Memory controller module ID
    */
    #define DDR220542036_IP_2036_MODULE_ID_MODULE_ID_R (0x07fff << 16)
    #define DDR220542036_IP_2036_MODULE_ID_MODULE_ID_SHIFT 16
    /*
    * Major revision number
    */
    #define DDR220542036_IP_2036_MODULE_ID_MAJOR_REV_R (0x07 << 12)
    #define DDR220542036_IP_2036_MODULE_ID_MAJOR_REV_SHIFT 12
    /*
    * Minor revision number
    */
    #define DDR220542036_IP_2036_MODULE_ID_MINOR_REV_R (0x07 << 8)
    #define DDR220542036_IP_2036_MODULE_ID_MINOR_REV_SHIFT 8
    /*
    * Aperture size is 4 kByte ((APERTURE + 1) * 4 kByte)
    */
    #define DDR220542036_IP_2036_MODULE_ID_APERTURE_R (0x0ff << 0)
    #define DDR220542036_IP_2036_MODULE_ID_APERTURE_SHIFT 0

#endif // _PHMODIPDDR220542036_H_
