/*-------------------------------------------------------------------------*/
/* Copyright 2011 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef PHMODIPDDR320552034_H
#define PHMODIPDDR320552034_H
    
    /*
    * interface enable register
    */
    #define DDR3_IP_2034_IF_ENABLE_REG  (DDR3_IP_2034_BASE + 0x0)
    /*
    * control the acceptance of transactions on data port 6
    */
    #define DDR3_IP_2034_IF_ENABLE_REGISTER_RW (0x01 << 6)
    #define DDR3_IP_2034_IF_ENABLE_REGISTER_SHIFT 6
    /*
    * control the acceptance of transactions on data port 5
    */
    #define DDR3_IP_2034_IF_ENABLE_REGISTER1_RW (0x01 << 5)
    #define DDR3_IP_2034_IF_ENABLE_REGISTER1_SHIFT 5
    /*
    * control the acceptance of transactions on data port 4
    */
    #define DDR3_IP_2034_IF_ENABLE_REGISTER2_RW (0x01 << 4)
    #define DDR3_IP_2034_IF_ENABLE_REGISTER2_SHIFT 4
    /*
    * control the acceptance of transactions on data port 3
    */
    #define DDR3_IP_2034_IF_ENABLE_REGISTER3_RW (0x01 << 3)
    #define DDR3_IP_2034_IF_ENABLE_REGISTER3_SHIFT 3
    /*
    * control the acceptance of transactions on data port 2
    */
    #define DDR3_IP_2034_IF_ENABLE_REGISTER4_RW (0x01 << 2)
    #define DDR3_IP_2034_IF_ENABLE_REGISTER4_SHIFT 2
    /*
    * control the acceptance of transactions on data port 1
    */
    #define DDR3_IP_2034_IF_ENABLE_REGISTER5_RW (0x01 << 1)
    #define DDR3_IP_2034_IF_ENABLE_REGISTER5_SHIFT 1
    /*
    * control the acceptance of transactions on data port 0
    */
    #define DDR3_IP_2034_IF_ENABLE_REGISTER6_RW (0x01 << 0)
    #define DDR3_IP_2034_IF_ENABLE_REGISTER6_SHIFT 0
    /*
    * interface busy register
    */
    #define DDR3_IP_2034_IF_BUSY_REG  (DDR3_IP_2034_BASE + 0x4)
    /*
    * indicates whether transactions are pending on data port 6
    */
    #define DDR3_IP_2034_IF_BUSY_REGISTER_R (0x01 << 6)
    #define DDR3_IP_2034_IF_BUSY_REGISTER_SHIFT 6
    /*
    * indicates whether transactions are pending on data port 5
    */
    #define DDR3_IP_2034_IF_BUSY_REGISTER1_R (0x01 << 5)
    #define DDR3_IP_2034_IF_BUSY_REGISTER1_SHIFT 5
    /*
    * indicates whether transactions are pending on data port 4
    */
    #define DDR3_IP_2034_IF_BUSY_REGISTER2_R (0x01 << 4)
    #define DDR3_IP_2034_IF_BUSY_REGISTER2_SHIFT 4
    /*
    * indicates whether transactions are pending on data port 3
    */
    #define DDR3_IP_2034_IF_BUSY_REGISTER3_R (0x01 << 3)
    #define DDR3_IP_2034_IF_BUSY_REGISTER3_SHIFT 3
    /*
    * indicates whether transactions are pending on data port 2
    */
    #define DDR3_IP_2034_IF_BUSY_REGISTER4_R (0x01 << 2)
    #define DDR3_IP_2034_IF_BUSY_REGISTER4_SHIFT 2
    /*
    * indicates whether transactions are pending on data port 1
    */
    #define DDR3_IP_2034_IF_BUSY_REGISTER5_R (0x01 << 1)
    #define DDR3_IP_2034_IF_BUSY_REGISTER5_SHIFT 1
    /*
    * indicates whether transactions are pending on data port 0
    */
    #define DDR3_IP_2034_IF_BUSY_REGISTER6_R (0x01 << 0)
    #define DDR3_IP_2034_IF_BUSY_REGISTER6_SHIFT 0
    /*
    * data port 0 coherency control register
    */
    #define DDR3_IP_2034_IF0_COH_CTRL_REG  (DDR3_IP_2034_BASE + 0x40)
    /*
    * enable coherency checking
    */
    #define DDR3_IP_2034_IF0_COH_CTRL_ENABLE_RW (0x01 << 8)
    #define DDR3_IP_2034_IF0_COH_CTRL_ENABLE_SHIFT 8
    /*
    * select the maximum transaction size that will occur on this data port
    *  0 128 bytes
    *  1 256 bytes
    *  2 512 bytes
    *  3 1 Kbytes
    */
    #define DDR3_IP_2034_IF0_COH_CTRL_BLOCK_SIZE_RW (0x03 << 0)
    #define DDR3_IP_2034_IF0_COH_CTRL_BLOCK_SIZE_SHIFT 0
    /*
    * data port 1 coherency control register
    */
    #define DDR3_IP_2034_IF1_COH_CTRL_REG  (DDR3_IP_2034_BASE + 0x60)
    /*
    * enable coherency checking
    */
    #define DDR3_IP_2034_IF1_COH_CTRL_ENABLE_RW (0x01 << 8)
    #define DDR3_IP_2034_IF1_COH_CTRL_ENABLE_SHIFT 8
    /*
    * select the maximum transaction size that will occur on this data port
    *  0 128 bytes
    *  1 256 bytes
    *  2 512 bytes
    *  3 1 Kbytes
    */
    #define DDR3_IP_2034_IF1_COH_CTRL_BLOCK_SIZE_RW (0x03 << 0)
    #define DDR3_IP_2034_IF1_COH_CTRL_BLOCK_SIZE_SHIFT 0
    /*
    * data port 2 coherency control register
    */
    #define DDR3_IP_2034_IF2_COH_CTRL_REG  (DDR3_IP_2034_BASE + 0x80)
    /*
    * enable coherency checking
    */
    #define DDR3_IP_2034_IF2_COH_CTRL_ENABLE_RW (0x01 << 8)
    #define DDR3_IP_2034_IF2_COH_CTRL_ENABLE_SHIFT 8
    /*
    * select the maximum transaction size that will occur on this data port
    *  0 128 bytes
    *  1 256 bytes
    *  2 512 bytes
    *  3 1 Kbytes
    */
    #define DDR3_IP_2034_IF2_COH_CTRL_BLOCK_SIZE_RW (0x03 << 0)
    #define DDR3_IP_2034_IF2_COH_CTRL_BLOCK_SIZE_SHIFT 0
    /*
    * data port 3 coherency control register
    */
    #define DDR3_IP_2034_IF3_COH_CTRL_REG  (DDR3_IP_2034_BASE + 0xa0)
    /*
    * enable coherency checking
    */
    #define DDR3_IP_2034_IF3_COH_CTRL_ENABLE_RW (0x01 << 8)
    #define DDR3_IP_2034_IF3_COH_CTRL_ENABLE_SHIFT 8
    /*
    * select the maximum transaction size that will occur on this data port
    *  0 128 bytes
    *  1 256 bytes
    *  2 512 bytes
    *  3 1 Kbytes
    */
    #define DDR3_IP_2034_IF3_COH_CTRL_BLOCK_SIZE_RW (0x03 << 0)
    #define DDR3_IP_2034_IF3_COH_CTRL_BLOCK_SIZE_SHIFT 0
    /*
    * data port 4 coherency control register
    */
    #define DDR3_IP_2034_IF4_COH_CTRL_REG  (DDR3_IP_2034_BASE + 0xc0)
    /*
    * enable coherency checking
    */
    #define DDR3_IP_2034_IF4_COH_CTRL_ENABLE_RW (0x01 << 8)
    #define DDR3_IP_2034_IF4_COH_CTRL_ENABLE_SHIFT 8
    /*
    * select the maximum transaction size that will occur on this data port
    *  0 128 bytes
    *  1 256 bytes
    *  2 512 bytes
    *  3 1 Kbytes
    */
    #define DDR3_IP_2034_IF4_COH_CTRL_BLOCK_SIZE_RW (0x03 << 0)
    #define DDR3_IP_2034_IF4_COH_CTRL_BLOCK_SIZE_SHIFT 0
    /*
    * address mapping register
    */
    #define DDR3_IP_2034_QU_ADDR_MAPPING_REG  (DDR3_IP_2034_BASE + 0x200)
    /*
    * select the logical to physical address mapping scheme
    *  0 non-interleaved mapping
    *  1 8 bank, 16 word interleaved
    *  3 8 bank, 16 word interleaved, 256 word stride
    *  5 8 bank, 16 word interleaved, 512 word stride
    *  7 8 bank, 16 word interleaved, 1 kword stride
    *  11 8 bank, 16 word, 4 line interleaved, 256 word stride
    *  13 8 bank, 16 word, 4 line interleaved, 512 word stride
    *  15 8 bank, 16 word, 4 line interleaved, 1 kword stride
    */
    #define DDR3_IP_2034_QU_ADDR_MAPPING_SCHEME_RW (0x0f << 0)
    #define DDR3_IP_2034_QU_ADDR_MAPPING_SCHEME_SHIFT 0
    /*
    * region 1 address mapping register
    */
    #define DDR3_IP_2034_QU_REGION1_MAPPING_REG  (DDR3_IP_2034_BASE + 0x204)
    /*
    * select the logical to physical address mapping scheme
    *  0 non-interleaved mapping
    *  1 8 bank, 16 word interleaved
    *  3 8 bank, 16 word interleaved, 256 word stride
    *  5 8 bank, 16 word interleaved, 512 word stride
    *  7 8 bank, 16 word interleaved, 1 kword stride
    *  11 8 bank, 16 word, 4 line interleaved, 256 word stride
    *  13 8 bank, 16 word, 4 line interleaved, 512 word stride
    *  15 8 bank, 16 word, 4 line interleaved, 1 kword stride
    */
    #define DDR3_IP_2034_QU_REGION1_MAPPING_SCHEME_RW (0x0f << 0)
    #define DDR3_IP_2034_QU_REGION1_MAPPING_SCHEME_SHIFT 0
    /*
    * region 1 base register
    */
    #define DDR3_IP_2034_QU_REGION1_BASE_REG  (DDR3_IP_2034_BASE + 0x208)
    /*
    * select the base address of region 1 (most significant part only, least significa
    * nt part is always zero)
    */
    #define DDR3_IP_2034_QU_REGION1_BASE_BASE_RW (0x0ffff << 16)
    #define DDR3_IP_2034_QU_REGION1_BASE_BASE_SHIFT 16
    /*
    * region 1 mask register
    */
    #define DDR3_IP_2034_QU_REGION1_MASK_REG  (DDR3_IP_2034_BASE + 0x20c)
    /*
    * select the mask for detecting region 1 (most significant part only, least signif
    * icant part is always zero)
    *  0 region 1 disabled
    *  others address A is in region 1 if (A & MASK) == (BASE & MASK)
    */
    #define DDR3_IP_2034_QU_REGION1_MASK_BASE_RW (0x0ffff << 16)
    #define DDR3_IP_2034_QU_REGION1_MASK_BASE_SHIFT 16
    /*
    * memory configuration register
    */
    #define DDR3_IP_2034_QU_MEM_CONFIG_REG  (DDR3_IP_2034_BASE + 0x210)
    /*
    * select the data bus width of DDR interface
    *  1 16 bits(half width mode)
    *  2 32 bits
    */
    #define DDR3_IP_2034_QU_MEM_CONFIG_MAPPING_WIDTH_RW (0x03 << 26)
    #define DDR3_IP_2034_QU_MEM_CONFIG_MAPPING_WIDTH_SHIFT 26
    /*
    * select the data bus width of PCTL interface
    *  1 64 bits(half width mode)
    *  2 128 bits
    */
    #define DDR3_IP_2034_QU_MEM_CONFIG_DBUS_WIDTH_RW (0x03 << 24)
    #define DDR3_IP_2034_QU_MEM_CONFIG_DBUS_WIDTH_SHIFT 24
    /*
    * select the number of bank address bits
    */
    #define DDR3_IP_2034_QU_MEM_CONFIG_BANK_WIDTH_RW (0x03 << 16)
    #define DDR3_IP_2034_QU_MEM_CONFIG_BANK_WIDTH_SHIFT 16
    /*
    * select the number of row address bits
    */
    #define DDR3_IP_2034_QU_MEM_CONFIG_ROW_WIDTH_RW (0x01f << 8)
    #define DDR3_IP_2034_QU_MEM_CONFIG_ROW_WIDTH_SHIFT 8
    /*
    * select the number of column address bits
    */
    #define DDR3_IP_2034_QU_MEM_CONFIG_COLUMN_WIDTH_RW (0x0f << 0)
    #define DDR3_IP_2034_QU_MEM_CONFIG_COLUMN_WIDTH_SHIFT 0
    /*
    * queue filling control register
    */
    #define DDR3_IP_2034_QU_FILLING_CONTROL_REG  (DDR3_IP_2034_BASE + 0x228)
    /*
    * reset all peak filling fields for port 6
    */
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET6_RW (0x01 << 6)
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET6_SHIFT 6
    /*
    * reset all peak filling fields for port 5
    */
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET5_RW (0x01 << 5)
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET5_SHIFT 5
    /*
    * reset all peak filling fields for port 4
    */
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET4_RW (0x01 << 4)
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET4_SHIFT 4
    /*
    * reset all peak filling fields for port 3
    */
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET3_RW (0x01 << 3)
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET3_SHIFT 3
    /*
    * reset all peak filling fields for port 2
    */
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET2_RW (0x01 << 2)
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET2_SHIFT 2
    /*
    * reset all peak filling fields for port 1
    */
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET1_RW (0x01 << 1)
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET1_SHIFT 1
    /*
    * reset all peak filling fields for port 0
    */
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET0_RW (0x01 << 0)
    #define DDR3_IP_2034_QU_FILLING_CONTROL_RESET0_SHIFT 0
    /*
    * data port 0 write filling status register
    */
    #define DDR3_IP_2034_QU0_WR_FILLING_REG  (DDR3_IP_2034_BASE + 0x240)
    /*
    * maximum number of entries in the write command queue
    */
    #define DDR3_IP_2034_QU0_WR_FILLING_PEAK_R (0x01ff << 16)
    #define DDR3_IP_2034_QU0_WR_FILLING_PEAK_SHIFT 16
    /*
    * current number of entries in the write command queue
    */
    #define DDR3_IP_2034_QU0_WR_FILLING_CURRENT_R (0x01ff << 0)
    #define DDR3_IP_2034_QU0_WR_FILLING_CURRENT_SHIFT 0
    /*
    * data port 0 read filling status register
    */
    #define DDR3_IP_2034_QU0_RD_FILLING_REG  (DDR3_IP_2034_BASE + 0x244)
    /*
    * maximum number of entries in the read command queue
    */
    #define DDR3_IP_2034_QU0_RD_FILLING_PEAK_R (0x01ff << 16)
    #define DDR3_IP_2034_QU0_RD_FILLING_PEAK_SHIFT 16
    /*
    * current number of entries in the reade command queue
    */
    #define DDR3_IP_2034_QU0_RD_FILLING_CURRENT_R (0x01ff << 0)
    #define DDR3_IP_2034_QU0_RD_FILLING_CURRENT_SHIFT 0
    #define DDR3_IP_2034_QU0_REORDER_CONTROL_REG  (DDR3_IP_2034_BASE + 0x248)
    /*
    * Specify the reorder scope in number of bank transactions (0=disable). A bank tra
    * nsaction is a part of a transaction that maps to a single row of a single bank. 
    * The maximum size of a bank transaction is 16 words.
    */
    #define DDR3_IP_2034_QU0_REORDER_CONTROL_TRANSACTIONS_RW (0x03f << 0)
    #define DDR3_IP_2034_QU0_REORDER_CONTROL_TRANSACTIONS_SHIFT 0
    #define DDR3_IP_2034_QU0_BOOST_REORDER_CONTROL_REG  (DDR3_IP_2034_BASE + 0x24c)
    /*
    * Specify the number of oldest bank transactions that get priority
    * BOOSTED+1, instead of BOOSTED.
    */
    #define DDR3_IP_2034_QU0_BOOST_REORDER_CONTROL_TRANSACTIONS_RW (0x03f << 0)
    #define DDR3_IP_2034_QU0_BOOST_REORDER_CONTROL_TRANSACTIONS_SHIFT 0
    #define DDR3_IP_2034_QU1_WR_FILLING_REG  (DDR3_IP_2034_BASE + 0x260)
    /*
    * maximum number of entries in the write command queue
    */
    #define DDR3_IP_2034_QU1_WR_FILLING_PEAK_R (0x01ff << 16)
    #define DDR3_IP_2034_QU1_WR_FILLING_PEAK_SHIFT 16
    /*
    * current number of entries in the write command queue
    */
    #define DDR3_IP_2034_QU1_WR_FILLING_CURRENT_R (0x01ff << 0)
    #define DDR3_IP_2034_QU1_WR_FILLING_CURRENT_SHIFT 0
    #define DDR3_IP_2034_QU1_RD_FILLING_REG  (DDR3_IP_2034_BASE + 0x264)
    /*
    * maximum number of entries in the read command queue
    */
    #define DDR3_IP_2034_QU1_RD_FILLING_PEAK_R (0x01ff << 16)
    #define DDR3_IP_2034_QU1_RD_FILLING_PEAK_SHIFT 16
    /*
    * current number of entries in the reade command queue
    */
    #define DDR3_IP_2034_QU1_RD_FILLING_CURRENT_R (0x01ff << 0)
    #define DDR3_IP_2034_QU1_RD_FILLING_CURRENT_SHIFT 0
    #define DDR3_IP_2034_QU1_REORDER_CONTROL_REG  (DDR3_IP_2034_BASE + 0x268)
    /*
    * Specify the reorder scope in number of bank transactions (0=disable). A bank tra
    * nsaction is a part of a transaction that maps to a single row of a single bank. 
    * The maximum size of a bank transaction is 16 words.
    */
    #define DDR3_IP_2034_QU1_REORDER_CONTROL_TRANSACTIONS_RW (0x03f << 0)
    #define DDR3_IP_2034_QU1_REORDER_CONTROL_TRANSACTIONS_SHIFT 0
    #define DDR3_IP_2034_QU1_BOOST_REORDER_CONTROL_REG  (DDR3_IP_2034_BASE + 0x26c)
    /*
    * Specify the number of oldest bank transactions that get priority
    * BOOSTED+1, instead of BOOSTED.
    */
    #define DDR3_IP_2034_QU1_BOOST_REORDER_CONTROL_TRANSACTIONS_RW (0x03f << 0)
    #define DDR3_IP_2034_QU1_BOOST_REORDER_CONTROL_TRANSACTIONS_SHIFT 0
    #define DDR3_IP_2034_QU2_WR_FILLING_REG  (DDR3_IP_2034_BASE + 0x280)
    /*
    * maximum number of entries in the write command queue
    */
    #define DDR3_IP_2034_QU2_WR_FILLING_PEAK_R (0x01ff << 16)
    #define DDR3_IP_2034_QU2_WR_FILLING_PEAK_SHIFT 16
    /*
    * current number of entries in the write command queue
    */
    #define DDR3_IP_2034_QU2_WR_FILLING_CURRENT_R (0x01ff << 0)
    #define DDR3_IP_2034_QU2_WR_FILLING_CURRENT_SHIFT 0
    #define DDR3_IP_2034_QU2_RD_FILLING_REG  (DDR3_IP_2034_BASE + 0x284)
    /*
    * maximum number of entries in the read command queue
    */
    #define DDR3_IP_2034_QU2_RD_FILLING_PEAK_R (0x01ff << 16)
    #define DDR3_IP_2034_QU2_RD_FILLING_PEAK_SHIFT 16
    /*
    * current number of entries in the reade command queue
    */
    #define DDR3_IP_2034_QU2_RD_FILLING_CURRENT_R (0x01ff << 0)
    #define DDR3_IP_2034_QU2_RD_FILLING_CURRENT_SHIFT 0
    #define DDR3_IP_2034_QU2_REORDER_CONTROL_REG  (DDR3_IP_2034_BASE + 0x288)
    /*
    * Specify the reorder scope in number of bank transactions (0=disable). A bank tra
    * nsaction is a part of a transaction that maps to a single row of a single bank. 
    * The maximum size of a bank transaction is 16 words.
    */
    #define DDR3_IP_2034_QU2_REORDER_CONTROL_TRANSACTIONS_RW (0x03f << 0)
    #define DDR3_IP_2034_QU2_REORDER_CONTROL_TRANSACTIONS_SHIFT 0
    #define DDR3_IP_2034_QU2_BOOST_REORDER_CONTROL_REG  (DDR3_IP_2034_BASE + 0x28c)
    /*
    * Specify the number of oldest bank transactions that get priority
    * BOOSTED+1, instead of BOOSTED.
    */
    #define DDR3_IP_2034_QU2_BOOST_REORDER_CONTROL_TRANSACTIONS_RW (0x03f << 0)
    #define DDR3_IP_2034_QU2_BOOST_REORDER_CONTROL_TRANSACTIONS_SHIFT 0
    #define DDR3_IP_2034_QU3_WR_FILLING_REG  (DDR3_IP_2034_BASE + 0x2a0)
    /*
    * maximum number of entries in the write command queue
    */
    #define DDR3_IP_2034_QU3_WR_FILLING_PEAK_R (0x01ff << 16)
    #define DDR3_IP_2034_QU3_WR_FILLING_PEAK_SHIFT 16
    /*
    * current number of entries in the write command queue
    */
    #define DDR3_IP_2034_QU3_WR_FILLING_CURRENT_R (0x01ff << 0)
    #define DDR3_IP_2034_QU3_WR_FILLING_CURRENT_SHIFT 0
    #define DDR3_IP_2034_QU3_RD_FILLING_REG  (DDR3_IP_2034_BASE + 0x2a4)
    /*
    * maximum number of entries in the read command queue
    */
    #define DDR3_IP_2034_QU3_RD_FILLING_PEAK_R (0x01ff << 16)
    #define DDR3_IP_2034_QU3_RD_FILLING_PEAK_SHIFT 16
    /*
    * current number of entries in the reade command queue
    */
    #define DDR3_IP_2034_QU3_RD_FILLING_CURRENT_R (0x01ff << 0)
    #define DDR3_IP_2034_QU3_RD_FILLING_CURRENT_SHIFT 0
    #define DDR3_IP_2034_QU3_REORDER_CONTROL_REG  (DDR3_IP_2034_BASE + 0x2a8)
    /*
    * Specify the reorder scope in number of bank transactions (0=disable). A bank tra
    * nsaction is a part of a transaction that maps to a single row of a single bank. 
    * The maximum size of a bank transaction is 16 words.
    */
    #define DDR3_IP_2034_QU3_REORDER_CONTROL_TRANSACTIONS_RW (0x03f << 0)
    #define DDR3_IP_2034_QU3_REORDER_CONTROL_TRANSACTIONS_SHIFT 0
    #define DDR3_IP_2034_QU3_BOOST_REORDER_CONTROL_REG  (DDR3_IP_2034_BASE + 0x2ac)
    /*
    * Specify the number of oldest bank transactions that get priority
    * BOOSTED+1, instead of BOOSTED.
    */
    #define DDR3_IP_2034_QU3_BOOST_REORDER_CONTROL_TRANSACTIONS_RW (0x03f << 0)
    #define DDR3_IP_2034_QU3_BOOST_REORDER_CONTROL_TRANSACTIONS_SHIFT 0
    #define DDR3_IP_2034_QU4_WR_FILLING_REG  (DDR3_IP_2034_BASE + 0x2c0)
    /*
    * maximum number of entries in the write command queue
    */
    #define DDR3_IP_2034_QU4_WR_FILLING_PEAK_R (0x01ff << 16)
    #define DDR3_IP_2034_QU4_WR_FILLING_PEAK_SHIFT 16
    /*
    * current number of entries in the write command queue
    */
    #define DDR3_IP_2034_QU4_WR_FILLING_CURRENT_R (0x01ff << 0)
    #define DDR3_IP_2034_QU4_WR_FILLING_CURRENT_SHIFT 0
    #define DDR3_IP_2034_QU4_RD_FILLING_REG  (DDR3_IP_2034_BASE + 0x2c4)
    /*
    * maximum number of entries in the read command queue
    */
    #define DDR3_IP_2034_QU4_RD_FILLING_PEAK_R (0x01ff << 16)
    #define DDR3_IP_2034_QU4_RD_FILLING_PEAK_SHIFT 16
    /*
    * current number of entries in the reade command queue
    */
    #define DDR3_IP_2034_QU4_RD_FILLING_CURRENT_R (0x01ff << 0)
    #define DDR3_IP_2034_QU4_RD_FILLING_CURRENT_SHIFT 0
    #define DDR3_IP_2034_QU4_REORDER_CONTROL_REG  (DDR3_IP_2034_BASE + 0x2c8)
    /*
    * Specify the reorder scope in number of bank transactions (0=disable). A bank tra
    * nsaction is a part of a transaction that maps to a single row of a single bank. 
    * The maximum size of a bank transaction is 16 words.
    */
    #define DDR3_IP_2034_QU4_REORDER_CONTROL_TRANSACTIONS_RW (0x03f << 0)
    #define DDR3_IP_2034_QU4_REORDER_CONTROL_TRANSACTIONS_SHIFT 0
    #define DDR3_IP_2034_QU4_BOOST_REORDER_CONTROL_REG  (DDR3_IP_2034_BASE + 0x2cc)
    /*
    * Specify the number of oldest bank transactions that get priority
    * BOOSTED+1, instead of BOOSTED.
    */
    #define DDR3_IP_2034_QU4_BOOST_REORDER_CONTROL_TRANSACTIONS_RW (0x03f << 0)
    #define DDR3_IP_2034_QU4_BOOST_REORDER_CONTROL_TRANSACTIONS_SHIFT 0
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_REG  (DDR3_IP_2034_BASE + 0x400)
    /*
    * reset all performance counters of data port 6
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR6_RW (0x01 << 27)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR6_SHIFT 27
    /*
    * take a snapshot of all performance counters of data port 6
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE6_RW (0x01 << 26)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE6_SHIFT 26
    /*
    * stop the performance counters of data port6
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP6_RW (0x01 << 25)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP6_SHIFT 25
    /*
    * start the performance counters of data port 6
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START6_RW (0x01 << 24)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START6_SHIFT 24
    /*
    * reset all performance counters of data port 5
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR5_RW (0x01 << 23)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR5_SHIFT 23
    /*
    * take a snapshot of all performance counters of data port 5
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE5_RW (0x01 << 22)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE5_SHIFT 22
    /*
    * stop the performance counters of data port5
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP5_RW (0x01 << 21)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP5_SHIFT 21
    /*
    * start the performance counters of data port 5
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START5_RW (0x01 << 20)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START5_SHIFT 20
    /*
    * reset all performance counters of data port 4
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR4_RW (0x01 << 19)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR4_SHIFT 19
    /*
    * take a snapshot of all performance counters of data port 4
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE4_RW (0x01 << 18)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE4_SHIFT 18
    /*
    * stop the performance counters of data port 4
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP4_RW (0x01 << 17)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP4_SHIFT 17
    /*
    * start the performance counters of data port4
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START4_RW (0x01 << 16)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START4_SHIFT 16
    /*
    * reset all performance counters of data port3
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR3_RW (0x01 << 15)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR3_SHIFT 15
    /*
    * take a snapshot of all performance counters of data port 3
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE3_RW (0x01 << 14)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE3_SHIFT 14
    /*
    * stop the performance counters of data port 3
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP3_RW (0x01 << 13)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP3_SHIFT 13
    /*
    * start the performance counters of data port 3
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START3_RW (0x01 << 12)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START3_SHIFT 12
    /*
    * reset all performance counters of data port 2
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR2_RW (0x01 << 11)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR2_SHIFT 11
    /*
    * take a snapshot of all performance counters of data port 2
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE2_RW (0x01 << 10)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE2_SHIFT 10
    /*
    * stop the performance counters of data port 2
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP2_RW (0x01 << 9)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP2_SHIFT 9
    /*
    * start the performance counters of data port 2
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START2_RW (0x01 << 8)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START2_SHIFT 8
    /*
    * reset all performance counters of data port1
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR1_RW (0x01 << 7)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR1_SHIFT 7
    /*
    * take a snapshot of all performance counters of data port 1
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE1_RW (0x01 << 6)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE1_SHIFT 6
    /*
    * stop the performance counters of data port 1
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP1_RW (0x01 << 5)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP1_SHIFT 5
    /*
    * start the performance counters of data port 1
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START1_RW (0x01 << 4)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START1_SHIFT 4
    /*
    * reset all performance counters of data port 0
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR0_RW (0x01 << 3)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CLEAR0_SHIFT 3
    /*
    * take a snapshot of all performance counters of data port 0
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE0_RW (0x01 << 2)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_CAPTURE0_SHIFT 2
    /*
    * stop the performance counters of data port 0
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP0_RW (0x01 << 1)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_STOP0_SHIFT 1
    /*
    * start the performance counters of data port 0
    */
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START0_RW (0x01 << 0)
    #define DDR3_IP_2034_PRIO_PERF_CONTROL_START0_SHIFT 0
    #define DDR3_IP_2034_PRIO0_QOS_TYPE_REG  (DDR3_IP_2034_BASE + 0x600)
    /*
    * select the QoS type
    *  0 low latency (LL)
    *  1 guaranteed throughput (GT)
    *  2 best effort (BE)
    */
    #define DDR3_IP_2034_PRIO0_QOS_TYPE_TYPE_RW (0x03 << 0)
    #define DDR3_IP_2034_PRIO0_QOS_TYPE_TYPE_SHIFT 0
    #define DDR3_IP_2034_PRIO0_QOS_BW_REG  (DDR3_IP_2034_BASE + 0x604)
    /*
    * Select the net bandwidth budget (LL type) or the net guaranteed bandwidth (GT ty
    * pe), as a percentage of the gross available memory bandwidth (GABW). Range is 0.
    * .99.
    */
    #define DDR3_IP_2034_PRIO0_QOS_BW_BW_RW (0x07f << 0)
    #define DDR3_IP_2034_PRIO0_QOS_BW_BW_SHIFT 0
    #define DDR3_IP_2034_PRIO0_QOS_LL_LIMIT_REG  (DDR3_IP_2034_BASE + 0x608)
    /*
    * sets the account threshold for priority limiting
    */
    #define DDR3_IP_2034_PRIO0_QOS_LL_LIMIT_LIMIT_RW (0x0ffffffff << 0)
    #define DDR3_IP_2034_PRIO0_QOS_LL_LIMIT_LIMIT_SHIFT 0
    #define DDR3_IP_2034_PRIO0_QOS_LL_CLIP_REG  (DDR3_IP_2034_BASE + 0x60c)
    /*
    * sets the account saturation level
    */
    #define DDR3_IP_2034_PRIO0_QOS_LL_CLIP_CLIP_RW (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO0_QOS_LL_CLIP_CLIP_SHIFT 0
    #define DDR3_IP_2034_PRIO0_QOS_GT_DEADLINE_REG  (DDR3_IP_2034_BASE + 0x610)
    /*
    * sets the priority boosting timeout
    */
    #define DDR3_IP_2034_PRIO0_QOS_GT_DEADLINE_DEADLINE_RW (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO0_QOS_GT_DEADLINE_DEADLINE_SHIFT 0
    #define DDR3_IP_2034_PRIO0_QOS_PRIO_REG  (DDR3_IP_2034_BASE + 0x614)
    /*
    * Select the write priority (LL type only)
    */
    #define DDR3_IP_2034_PRIO0_QOS_PRIO_WRITE_RW (0x01f << 16)
    #define DDR3_IP_2034_PRIO0_QOS_PRIO_WRITE_SHIFT 16
    /*
    * Select the limited read priority (LL type) or boosted priority (GTtype)
    */
    #define DDR3_IP_2034_PRIO0_QOS_PRIO_LIMITED_BOOSTED_RW (0x01f << 8)
    #define DDR3_IP_2034_PRIO0_QOS_PRIO_LIMITED_BOOSTED_SHIFT 8
    /*
    * Select the default read priority (LL type) or default priority (GT or BE type)
    */
    #define DDR3_IP_2034_PRIO0_QOS_PRIO_DEFAULT_RW (0x01f << 0)
    #define DDR3_IP_2034_PRIO0_QOS_PRIO_DEFAULT_SHIFT 0
    #define DDR3_IP_2034_PRIO0_QOS_HYSTERESIS_REG  (DDR3_IP_2034_BASE + 0x618)
    /*
    * sets the minimum cycles that boosted priority is used
    */
    #define DDR3_IP_2034_PRIO0_QOS_HYSTERESIS_MIN_BOOST_RW (0x0ff << 16)
    #define DDR3_IP_2034_PRIO0_QOS_HYSTERESIS_MIN_BOOST_SHIFT 16
    /*
    * sets the minimum cycles that limited priority is used
    */
    #define DDR3_IP_2034_PRIO0_QOS_HYSTERESIS_MIN_LIMI_RW (0x0ff << 0)
    #define DDR3_IP_2034_PRIO0_QOS_HYSTERESIS_MIN_LIMI_SHIFT 0
    #define DDR3_IP_2034_PRIO0_PERF_MAX_ACCOUNT_REG  (DDR3_IP_2034_BASE + 0x61c)
    /*
    * maximum value of the account
    */
    #define DDR3_IP_2034_PRIO0_PERF_MAX_ACCOUNT_MAX_ACCOUNT_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO0_PERF_MAX_ACCOUNT_MAX_ACCOUNT_SHIFT 0
    #define DDR3_IP_2034_PRIO0_PERF_TOTAL_REG  (DDR3_IP_2034_BASE + 0x620)
    /*
    * counter for total number of elapsed cycles, with or without data
    */
    #define DDR3_IP_2034_PRIO0_PERF_TOTAL_TOTAL_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO0_PERF_TOTAL_TOTAL_SHIFT 0
    #define DDR3_IP_2034_PRIO0_PERF_RDDATA_REG  (DDR3_IP_2034_BASE + 0x624)
    /*
    * counter for net read data cycles
    */
    #define DDR3_IP_2034_PRIO0_PERF_RDDATA_READ_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO0_PERF_RDDATA_READ_SHIFT 0
    #define DDR3_IP_2034_PRIO0_PERF_RDDATA_DEF_REG  (DDR3_IP_2034_BASE + 0x628)
    /*
    * counter for net read data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO0_PERF_RDDATA_DEF_READ_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO0_PERF_RDDATA_DEF_READ_SHIFT 0
    #define DDR3_IP_2034_PRIO0_PERF_WRDATA_REG  (DDR3_IP_2034_BASE + 0x62c)
    /*
    * counter for net write data cycles
    */
    #define DDR3_IP_2034_PRIO0_PERF_WRDATA_WRITE_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO0_PERF_WRDATA_WRITE_SHIFT 0
    #define DDR3_IP_2034_PRIO0_PERF_WRDATA_DEF_REG  (DDR3_IP_2034_BASE + 0x630)
    /*
    * counter for net write data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO0_PERF_WRDATA_DEF_WRITE_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO0_PERF_WRDATA_DEF_WRITE_SHIFT 0
    #define DDR3_IP_2034_PRIO0_STATE_REG  (DDR3_IP_2034_BASE + 0x634)
    /*
    * indicates whether account is currently clipped (LL)
    */
    #define DDR3_IP_2034_PRIO0_STATE_CLIPPED_R (0x01 << 6)
    #define DDR3_IP_2034_PRIO0_STATE_CLIPPED_SHIFT 6
    /*
    * indicates whether priority is currently limited (LL)
    */
    #define DDR3_IP_2034_PRIO0_STATE_LIMITED__R (0x01 << 5)
    #define DDR3_IP_2034_PRIO0_STATE_LIMITED__SHIFT 5
    /*
    * indicates whether priority is currently boosted (GT)
    */
    #define DDR3_IP_2034_PRIO0_STATE_BOOSTED_R (0x01 << 4)
    #define DDR3_IP_2034_PRIO0_STATE_BOOSTED_SHIFT 4
    /*
    * indicates whether performance monitors are running
    */
    #define DDR3_IP_2034_PRIO0_STATE_RUNNING_R (0x01 << 0)
    #define DDR3_IP_2034_PRIO0_STATE_RUNNING_SHIFT 0
    #define DDR3_IP_2034_PRIO0_ACCOUNT_REG  (DDR3_IP_2034_BASE + 0x638)
    /*
    * counter for net write data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO0_ACCOUNT_ACCOUNT0_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO0_ACCOUNT_ACCOUNT0_SHIFT 0
    #define DDR3_IP_2034_PRIO0_PRIO_REG  (DDR3_IP_2034_BASE + 0x63c)
    /*
    * current value of the write priority
    */
    #define DDR3_IP_2034_PRIO0_PRIO_WRITE_PRIO_R (0x01f << 8)
    #define DDR3_IP_2034_PRIO0_PRIO_WRITE_PRIO_SHIFT 8
    /*
    * current value of the read priority
    */
    #define DDR3_IP_2034_PRIO0_PRIO_READ_PRIO_R (0x01f << 0)
    #define DDR3_IP_2034_PRIO0_PRIO_READ_PRIO_SHIFT 0
    #define DDR3_IP_2034_PRIO1_QOS_TYPE_REG  (DDR3_IP_2034_BASE + 0x640)
    /*
    * select the QoS type
    *  0 low latency (LL)
    *  1 guaranteed throughput (GT)
    *  2 best effort (BE)
    */
    #define DDR3_IP_2034_PRIO1_QOS_TYPE_TYPE_RW (0x03 << 0)
    #define DDR3_IP_2034_PRIO1_QOS_TYPE_TYPE_SHIFT 0
    #define DDR3_IP_2034_PRIO1_QOS_BW_REG  (DDR3_IP_2034_BASE + 0x644)
    /*
    * Select the net bandwidth budget (LL type) or the net guaranteed bandwidth (GT ty
    * pe), as a percentage of the gross available memory bandwidth (GABW). Range is 0.
    * .99.
    */
    #define DDR3_IP_2034_PRIO1_QOS_BW_BW_RW (0x07f << 0)
    #define DDR3_IP_2034_PRIO1_QOS_BW_BW_SHIFT 0
    #define DDR3_IP_2034_PRIO1_QOS_LL_LIMIT_REG  (DDR3_IP_2034_BASE + 0x648)
    /*
    * sets the account threshold for priority limiting
    */
    #define DDR3_IP_2034_PRIO1_QOS_LL_LIMIT_LIMIT_RW (0x0ffffffff << 0)
    #define DDR3_IP_2034_PRIO1_QOS_LL_LIMIT_LIMIT_SHIFT 0
    #define DDR3_IP_2034_PRIO1_QOS_LL_CLIP_REG  (DDR3_IP_2034_BASE + 0x64c)
    /*
    * sets the account saturation level
    */
    #define DDR3_IP_2034_PRIO1_QOS_LL_CLIP_CLIP_RW (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO1_QOS_LL_CLIP_CLIP_SHIFT 0
    #define DDR3_IP_2034_PRIO1_QOS_GT_DEADLINE_REG  (DDR3_IP_2034_BASE + 0x650)
    /*
    * sets the priority boosting timeout
    */
    #define DDR3_IP_2034_PRIO1_QOS_GT_DEADLINE_DEADLINE_RW (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO1_QOS_GT_DEADLINE_DEADLINE_SHIFT 0
    #define DDR3_IP_2034_PRIO1_QOS_PRIO_REG  (DDR3_IP_2034_BASE + 0x654)
    /*
    * Select the write priority (LL type only)
    */
    #define DDR3_IP_2034_PRIO1_QOS_PRIO_WRITE_RW (0x01f << 16)
    #define DDR3_IP_2034_PRIO1_QOS_PRIO_WRITE_SHIFT 16
    /*
    * Select the limited read priority (LL type) or boosted priority (GTtype)
    */
    #define DDR3_IP_2034_PRIO1_QOS_PRIO_LIMITED_BOOSTED_RW (0x01f << 8)
    #define DDR3_IP_2034_PRIO1_QOS_PRIO_LIMITED_BOOSTED_SHIFT 8
    /*
    * Select the default read priority (LL type) or default priority (GT or BE type)
    */
    #define DDR3_IP_2034_PRIO1_QOS_PRIO_DEFAULT_RW (0x01f << 0)
    #define DDR3_IP_2034_PRIO1_QOS_PRIO_DEFAULT_SHIFT 0
    #define DDR3_IP_2034_PRIO1_QOS_HYSTERESIS_REG  (DDR3_IP_2034_BASE + 0x658)
    /*
    * sets the minimum cycles that boosted priority is used
    */
    #define DDR3_IP_2034_PRIO1_QOS_HYSTERESIS_MIN_BOOST_RW (0x0ff << 16)
    #define DDR3_IP_2034_PRIO1_QOS_HYSTERESIS_MIN_BOOST_SHIFT 16
    /*
    * sets the minimum cycles that limited priority is used
    */
    #define DDR3_IP_2034_PRIO1_QOS_HYSTERESIS_MIN_LIMI_RW (0x0ff << 0)
    #define DDR3_IP_2034_PRIO1_QOS_HYSTERESIS_MIN_LIMI_SHIFT 0
    #define DDR3_IP_2034_PRIO1_PERF_MAX_ACCOUNT_REG  (DDR3_IP_2034_BASE + 0x65c)
    /*
    * maximum value of the account
    */
    #define DDR3_IP_2034_PRIO1_PERF_MAX_ACCOUNT_MAX_ACCOUNT_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO1_PERF_MAX_ACCOUNT_MAX_ACCOUNT_SHIFT 0
    #define DDR3_IP_2034_PRIO1_PERF_TOTAL_REG  (DDR3_IP_2034_BASE + 0x660)
    /*
    * counter for total number of elapsed cycles, with or without data
    */
    #define DDR3_IP_2034_PRIO1_PERF_TOTAL_TOTAL_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO1_PERF_TOTAL_TOTAL_SHIFT 0
    #define DDR3_IP_2034_PRIO1_PERF_RDDATA_REG  (DDR3_IP_2034_BASE + 0x664)
    /*
    * counter for net read data cycles
    */
    #define DDR3_IP_2034_PRIO1_PERF_RDDATA_READ_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO1_PERF_RDDATA_READ_SHIFT 0
    #define DDR3_IP_2034_PRIO1_PERF_RDDATA_DEF_REG  (DDR3_IP_2034_BASE + 0x668)
    /*
    * counter for net read data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO1_PERF_RDDATA_DEF_READ_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO1_PERF_RDDATA_DEF_READ_SHIFT 0
    #define DDR3_IP_2034_PRIO1_PERF_WRDATA_REG  (DDR3_IP_2034_BASE + 0x66c)
    /*
    * counter for net write data cycles
    */
    #define DDR3_IP_2034_PRIO1_PERF_WRDATA_WRITE_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO1_PERF_WRDATA_WRITE_SHIFT 0
    #define DDR3_IP_2034_PRIO1_PERF_WRDATA_DEF_REG  (DDR3_IP_2034_BASE + 0x670)
    /*
    * counter for net write data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO1_PERF_WRDATA_DEF_WRITE_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO1_PERF_WRDATA_DEF_WRITE_SHIFT 0
    #define DDR3_IP_2034_PRIO1_STATE_REG  (DDR3_IP_2034_BASE + 0x674)
    /*
    * indicates whether account is currently clipped (LL)
    */
    #define DDR3_IP_2034_PRIO1_STATE_CLIPPED_R (0x01 << 6)
    #define DDR3_IP_2034_PRIO1_STATE_CLIPPED_SHIFT 6
    /*
    * indicates whether priority is currently limited (LL)
    */
    #define DDR3_IP_2034_PRIO1_STATE_LIMITED__R (0x01 << 5)
    #define DDR3_IP_2034_PRIO1_STATE_LIMITED__SHIFT 5
    /*
    * indicates whether priority is currently boosted (GT)
    */
    #define DDR3_IP_2034_PRIO1_STATE_BOOSTED_R (0x01 << 4)
    #define DDR3_IP_2034_PRIO1_STATE_BOOSTED_SHIFT 4
    /*
    * indicates whether performance monitors are running
    */
    #define DDR3_IP_2034_PRIO1_STATE_RUNNING_R (0x01 << 0)
    #define DDR3_IP_2034_PRIO1_STATE_RUNNING_SHIFT 0
    #define DDR3_IP_2034_PRIO1_ACCOUNT_REG  (DDR3_IP_2034_BASE + 0x678)
    /*
    * counter for net write data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO1_ACCOUNT_ACCOUNT0_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO1_ACCOUNT_ACCOUNT0_SHIFT 0
    #define DDR3_IP_2034_PRIO1_PRIO_REG  (DDR3_IP_2034_BASE + 0x67c)
    /*
    * current value of the write priority
    */
    #define DDR3_IP_2034_PRIO1_PRIO_WRITE_PRIO_R (0x01f << 8)
    #define DDR3_IP_2034_PRIO1_PRIO_WRITE_PRIO_SHIFT 8
    /*
    * current value of the read priority
    */
    #define DDR3_IP_2034_PRIO1_PRIO_READ_PRIO_R (0x01f << 0)
    #define DDR3_IP_2034_PRIO1_PRIO_READ_PRIO_SHIFT 0
    #define DDR3_IP_2034_PRIO2_QOS_TYPE_REG  (DDR3_IP_2034_BASE + 0x680)
    /*
    * select the QoS type
    *  0 low latency (LL)
    *  1 guaranteed throughput (GT)
    *  2 best effort (BE)
    */
    #define DDR3_IP_2034_PRIO2_QOS_TYPE_TYPE_RW (0x03 << 0)
    #define DDR3_IP_2034_PRIO2_QOS_TYPE_TYPE_SHIFT 0
    #define DDR3_IP_2034_PRIO2_QOS_BW_REG  (DDR3_IP_2034_BASE + 0x684)
    /*
    * Select the net bandwidth budget (LL type) or the net guaranteed bandwidth (GT ty
    * pe), as a percentage of the gross available memory bandwidth (GABW). Range is 0.
    * .99.
    */
    #define DDR3_IP_2034_PRIO2_QOS_BW_BW_RW (0x07f << 0)
    #define DDR3_IP_2034_PRIO2_QOS_BW_BW_SHIFT 0
    #define DDR3_IP_2034_PRIO2_QOS_LL_LIMIT_REG  (DDR3_IP_2034_BASE + 0x688)
    /*
    * sets the account threshold for priority limiting
    */
    #define DDR3_IP_2034_PRIO2_QOS_LL_LIMIT_LIMIT_RW (0x0ffffffff << 0)
    #define DDR3_IP_2034_PRIO2_QOS_LL_LIMIT_LIMIT_SHIFT 0
    #define DDR3_IP_2034_PRIO2_QOS_LL_CLIP_REG  (DDR3_IP_2034_BASE + 0x68c)
    /*
    * sets the account saturation level
    */
    #define DDR3_IP_2034_PRIO2_QOS_LL_CLIP_CLIP_RW (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO2_QOS_LL_CLIP_CLIP_SHIFT 0
    #define DDR3_IP_2034_PRIO2_QOS_GT_DEADLINE_REG  (DDR3_IP_2034_BASE + 0x690)
    /*
    * sets the priority boosting timeout
    */
    #define DDR3_IP_2034_PRIO2_QOS_GT_DEADLINE_DEADLINE_RW (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO2_QOS_GT_DEADLINE_DEADLINE_SHIFT 0
    #define DDR3_IP_2034_PRIO2_QOS_PRIO_REG  (DDR3_IP_2034_BASE + 0x694)
    /*
    * Select the write priority (LL type only)
    */
    #define DDR3_IP_2034_PRIO2_QOS_PRIO_WRITE_RW (0x01f << 16)
    #define DDR3_IP_2034_PRIO2_QOS_PRIO_WRITE_SHIFT 16
    /*
    * Select the limited read priority (LL type) or boosted priority (GTtype)
    */
    #define DDR3_IP_2034_PRIO2_QOS_PRIO_LIMITED_BOOSTED_RW (0x01f << 8)
    #define DDR3_IP_2034_PRIO2_QOS_PRIO_LIMITED_BOOSTED_SHIFT 8
    /*
    * Select the default read priority (LL type) or default priority (GT or BE type)
    */
    #define DDR3_IP_2034_PRIO2_QOS_PRIO_DEFAULT_RW (0x01f << 0)
    #define DDR3_IP_2034_PRIO2_QOS_PRIO_DEFAULT_SHIFT 0
    #define DDR3_IP_2034_PRIO2_QOS_HYSTERESIS_REG  (DDR3_IP_2034_BASE + 0x698)
    /*
    * sets the minimum cycles that boosted priority is used
    */
    #define DDR3_IP_2034_PRIO2_QOS_HYSTERESIS_MIN_BOOST_RW (0x0ff << 16)
    #define DDR3_IP_2034_PRIO2_QOS_HYSTERESIS_MIN_BOOST_SHIFT 16
    /*
    * sets the minimum cycles that limited priority is used
    */
    #define DDR3_IP_2034_PRIO2_QOS_HYSTERESIS_MIN_LIMI_RW (0x0ff << 0)
    #define DDR3_IP_2034_PRIO2_QOS_HYSTERESIS_MIN_LIMI_SHIFT 0
    #define DDR3_IP_2034_PRIO2_PERF_MAX_ACCOUNT_REG  (DDR3_IP_2034_BASE + 0x69c)
    /*
    * maximum value of the account
    */
    #define DDR3_IP_2034_PRIO2_PERF_MAX_ACCOUNT_MAX_ACCOUNT_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO2_PERF_MAX_ACCOUNT_MAX_ACCOUNT_SHIFT 0
    #define DDR3_IP_2034_PRIO2_PERF_TOTAL_REG  (DDR3_IP_2034_BASE + 0x6a0)
    /*
    * counter for total number of elapsed cycles, with or without data
    */
    #define DDR3_IP_2034_PRIO2_PERF_TOTAL_TOTAL_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO2_PERF_TOTAL_TOTAL_SHIFT 0
    #define DDR3_IP_2034_PRIO2_PERF_RDDATA_REG  (DDR3_IP_2034_BASE + 0x6a4)
    /*
    * counter for net read data cycles
    */
    #define DDR3_IP_2034_PRIO2_PERF_RDDATA_READ_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO2_PERF_RDDATA_READ_SHIFT 0
    #define DDR3_IP_2034_PRIO2_PERF_RDDATA_DEF_REG  (DDR3_IP_2034_BASE + 0x6a8)
    /*
    * counter for net read data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO2_PERF_RDDATA_DEF_READ_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO2_PERF_RDDATA_DEF_READ_SHIFT 0
    #define DDR3_IP_2034_PRIO2_PERF_WRDATA_REG  (DDR3_IP_2034_BASE + 0x6ac)
    /*
    * counter for net write data cycles
    */
    #define DDR3_IP_2034_PRIO2_PERF_WRDATA_WRITE_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO2_PERF_WRDATA_WRITE_SHIFT 0
    #define DDR3_IP_2034_PRIO2_PERF_WRDATA_DEF_REG  (DDR3_IP_2034_BASE + 0x6b0)
    /*
    * counter for net write data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO2_PERF_WRDATA_DEF_WRITE_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO2_PERF_WRDATA_DEF_WRITE_SHIFT 0
    #define DDR3_IP_2034_PRIO2_STATE_REG  (DDR3_IP_2034_BASE + 0x6b4)
    /*
    * indicates whether account is currently clipped (LL)
    */
    #define DDR3_IP_2034_PRIO2_STATE_CLIPPED_R (0x01 << 6)
    #define DDR3_IP_2034_PRIO2_STATE_CLIPPED_SHIFT 6
    /*
    * indicates whether priority is currently limited (LL)
    */
    #define DDR3_IP_2034_PRIO2_STATE_LIMITED__R (0x01 << 5)
    #define DDR3_IP_2034_PRIO2_STATE_LIMITED__SHIFT 5
    /*
    * indicates whether priority is currently boosted (GT)
    */
    #define DDR3_IP_2034_PRIO2_STATE_BOOSTED_R (0x01 << 4)
    #define DDR3_IP_2034_PRIO2_STATE_BOOSTED_SHIFT 4
    /*
    * indicates whether performance monitors are running
    */
    #define DDR3_IP_2034_PRIO2_STATE_RUNNING_R (0x01 << 0)
    #define DDR3_IP_2034_PRIO2_STATE_RUNNING_SHIFT 0
    #define DDR3_IP_2034_PRIO2_ACCOUNT_REG  (DDR3_IP_2034_BASE + 0x6b8)
    /*
    * counter for net write data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO2_ACCOUNT_ACCOUNT0_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO2_ACCOUNT_ACCOUNT0_SHIFT 0
    #define DDR3_IP_2034_PRIO2_PRIO_REG  (DDR3_IP_2034_BASE + 0x6bc)
    /*
    * current value of the write priority
    */
    #define DDR3_IP_2034_PRIO2_PRIO_WRITE_PRIO_R (0x01f << 8)
    #define DDR3_IP_2034_PRIO2_PRIO_WRITE_PRIO_SHIFT 8
    /*
    * current value of the read priority
    */
    #define DDR3_IP_2034_PRIO2_PRIO_READ_PRIO_R (0x01f << 0)
    #define DDR3_IP_2034_PRIO2_PRIO_READ_PRIO_SHIFT 0
    #define DDR3_IP_2034_PRIO3_QOS_TYPE_REG  (DDR3_IP_2034_BASE + 0x6c0)
    /*
    * select the QoS type
    *  0 low latency (LL)
    *  1 guaranteed throughput (GT)
    *  2 best effort (BE)
    */
    #define DDR3_IP_2034_PRIO3_QOS_TYPE_TYPE_RW (0x03 << 0)
    #define DDR3_IP_2034_PRIO3_QOS_TYPE_TYPE_SHIFT 0
    #define DDR3_IP_2034_PRIO3_QOS_BW_REG  (DDR3_IP_2034_BASE + 0x6c4)
    /*
    * Select the net bandwidth budget (LL type) or the net guaranteed bandwidth (GT ty
    * pe), as a percentage of the gross available memory bandwidth (GABW). Range is 0.
    * .99.
    */
    #define DDR3_IP_2034_PRIO3_QOS_BW_BW_RW (0x07f << 0)
    #define DDR3_IP_2034_PRIO3_QOS_BW_BW_SHIFT 0
    #define DDR3_IP_2034_PRIO3_QOS_LL_LIMIT_REG  (DDR3_IP_2034_BASE + 0x6c8)
    /*
    * sets the account threshold for priority limiting
    */
    #define DDR3_IP_2034_PRIO3_QOS_LL_LIMIT_LIMIT_RW (0x0ffffffff << 0)
    #define DDR3_IP_2034_PRIO3_QOS_LL_LIMIT_LIMIT_SHIFT 0
    #define DDR3_IP_2034_PRIO3_QOS_LL_CLIP_REG  (DDR3_IP_2034_BASE + 0x6cc)
    /*
    * sets the account saturation level
    */
    #define DDR3_IP_2034_PRIO3_QOS_LL_CLIP_CLIP_RW (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO3_QOS_LL_CLIP_CLIP_SHIFT 0
    #define DDR3_IP_2034_PRIO3_QOS_GT_DEADLINE_REG  (DDR3_IP_2034_BASE + 0x6d0)
    /*
    * sets the priority boosting timeout
    */
    #define DDR3_IP_2034_PRIO3_QOS_GT_DEADLINE_DEADLINE_RW (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO3_QOS_GT_DEADLINE_DEADLINE_SHIFT 0
    #define DDR3_IP_2034_PRIO3_QOS_PRIO_REG  (DDR3_IP_2034_BASE + 0x6d4)
    /*
    * Select the write priority (LL type only)
    */
    #define DDR3_IP_2034_PRIO3_QOS_PRIO_WRITE_RW (0x01f << 16)
    #define DDR3_IP_2034_PRIO3_QOS_PRIO_WRITE_SHIFT 16
    /*
    * Select the limited read priority (LL type) or boosted priority (GTtype)
    */
    #define DDR3_IP_2034_PRIO3_QOS_PRIO_LIMITED_BOOSTED_RW (0x01f << 8)
    #define DDR3_IP_2034_PRIO3_QOS_PRIO_LIMITED_BOOSTED_SHIFT 8
    /*
    * Select the default read priority (LL type) or default priority (GT or BE type)
    */
    #define DDR3_IP_2034_PRIO3_QOS_PRIO_DEFAULT_RW (0x01f << 0)
    #define DDR3_IP_2034_PRIO3_QOS_PRIO_DEFAULT_SHIFT 0
    #define DDR3_IP_2034_PRIO3_QOS_HYSTERESIS_REG  (DDR3_IP_2034_BASE + 0x6d8)
    /*
    * sets the minimum cycles that boosted priority is used
    */
    #define DDR3_IP_2034_PRIO3_QOS_HYSTERESIS_MIN_BOOST_RW (0x0ff << 16)
    #define DDR3_IP_2034_PRIO3_QOS_HYSTERESIS_MIN_BOOST_SHIFT 16
    /*
    * sets the minimum cycles that limited priority is used
    */
    #define DDR3_IP_2034_PRIO3_QOS_HYSTERESIS_MIN_LIMI_RW (0x0ff << 0)
    #define DDR3_IP_2034_PRIO3_QOS_HYSTERESIS_MIN_LIMI_SHIFT 0
    #define DDR3_IP_2034_PRIO3_PERF_MAX_ACCOUNT_REG  (DDR3_IP_2034_BASE + 0x6dc)
    /*
    * maximum value of the account
    */
    #define DDR3_IP_2034_PRIO3_PERF_MAX_ACCOUNT_MAX_ACCOUNT_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO3_PERF_MAX_ACCOUNT_MAX_ACCOUNT_SHIFT 0
    #define DDR3_IP_2034_PRIO3_PERF_TOTAL_REG  (DDR3_IP_2034_BASE + 0x6e0)
    /*
    * counter for total number of elapsed cycles, with or without data
    */
    #define DDR3_IP_2034_PRIO3_PERF_TOTAL_TOTAL_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO3_PERF_TOTAL_TOTAL_SHIFT 0
    #define DDR3_IP_2034_PRIO3_PERF_RDDATA_REG  (DDR3_IP_2034_BASE + 0x6e4)
    /*
    * counter for net read data cycles
    */
    #define DDR3_IP_2034_PRIO3_PERF_RDDATA_READ_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO3_PERF_RDDATA_READ_SHIFT 0
    #define DDR3_IP_2034_PRIO3_PERF_RDDATA_DEF_REG  (DDR3_IP_2034_BASE + 0x6e8)
    /*
    * counter for net read data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO3_PERF_RDDATA_DEF_READ_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO3_PERF_RDDATA_DEF_READ_SHIFT 0
    #define DDR3_IP_2034_PRIO3_PERF_WRDATA_REG  (DDR3_IP_2034_BASE + 0x6ec)
    /*
    * counter for net write data cycles
    */
    #define DDR3_IP_2034_PRIO3_PERF_WRDATA_WRITE_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO3_PERF_WRDATA_WRITE_SHIFT 0
    #define DDR3_IP_2034_PRIO3_PERF_WRDATA_DEF_REG  (DDR3_IP_2034_BASE + 0x6f0)
    /*
    * counter for net write data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO3_PERF_WRDATA_DEF_WRITE_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO3_PERF_WRDATA_DEF_WRITE_SHIFT 0
    #define DDR3_IP_2034_PRIO3_STATE_REG  (DDR3_IP_2034_BASE + 0x6f4)
    /*
    * indicates whether account is currently clipped (LL)
    */
    #define DDR3_IP_2034_PRIO3_STATE_CLIPPED_R (0x01 << 6)
    #define DDR3_IP_2034_PRIO3_STATE_CLIPPED_SHIFT 6
    /*
    * indicates whether priority is currently limited (LL)
    */
    #define DDR3_IP_2034_PRIO3_STATE_LIMITED__R (0x01 << 5)
    #define DDR3_IP_2034_PRIO3_STATE_LIMITED__SHIFT 5
    /*
    * indicates whether priority is currently boosted (GT)
    */
    #define DDR3_IP_2034_PRIO3_STATE_BOOSTED_R (0x01 << 4)
    #define DDR3_IP_2034_PRIO3_STATE_BOOSTED_SHIFT 4
    /*
    * indicates whether performance monitors are running
    */
    #define DDR3_IP_2034_PRIO3_STATE_RUNNING_R (0x01 << 0)
    #define DDR3_IP_2034_PRIO3_STATE_RUNNING_SHIFT 0
    #define DDR3_IP_2034_PRIO3_ACCOUNT_REG  (DDR3_IP_2034_BASE + 0x6f8)
    /*
    * counter for net write data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO3_ACCOUNT_ACCOUNT0_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO3_ACCOUNT_ACCOUNT0_SHIFT 0
    #define DDR3_IP_2034_PRIO3_PRIO_REG  (DDR3_IP_2034_BASE + 0x6fc)
    /*
    * current value of the write priority
    */
    #define DDR3_IP_2034_PRIO3_PRIO_WRITE_PRIO_R (0x01f << 8)
    #define DDR3_IP_2034_PRIO3_PRIO_WRITE_PRIO_SHIFT 8
    /*
    * current value of the read priority
    */
    #define DDR3_IP_2034_PRIO3_PRIO_READ_PRIO_R (0x01f << 0)
    #define DDR3_IP_2034_PRIO3_PRIO_READ_PRIO_SHIFT 0
    #define DDR3_IP_2034_PRIO4_QOS_TYPE_REG  (DDR3_IP_2034_BASE + 0x700)
    /*
    * select the QoS type
    *  0 low latency (LL)
    *  1 guaranteed throughput (GT)
    *  2 best effort (BE)
    */
    #define DDR3_IP_2034_PRIO4_QOS_TYPE_TYPE_RW (0x03 << 0)
    #define DDR3_IP_2034_PRIO4_QOS_TYPE_TYPE_SHIFT 0
    #define DDR3_IP_2034_PRIO4_QOS_BW_REG  (DDR3_IP_2034_BASE + 0x704)
    /*
    * Select the net bandwidth budget (LL type) or the net guaranteed bandwidth (GT ty
    * pe), as a percentage of the gross available memory bandwidth (GABW). Range is 0.
    * .99.
    */
    #define DDR3_IP_2034_PRIO4_QOS_BW_BW_RW (0x07f << 0)
    #define DDR3_IP_2034_PRIO4_QOS_BW_BW_SHIFT 0
    #define DDR3_IP_2034_PRIO4_QOS_LL_LIMIT_REG  (DDR3_IP_2034_BASE + 0x708)
    /*
    * sets the account threshold for priority limiting
    */
    #define DDR3_IP_2034_PRIO4_QOS_LL_LIMIT_LIMIT_RW (0x0ffffffff << 0)
    #define DDR3_IP_2034_PRIO4_QOS_LL_LIMIT_LIMIT_SHIFT 0
    #define DDR3_IP_2034_PRIO4_QOS_LL_CLIP_REG  (DDR3_IP_2034_BASE + 0x70c)
    /*
    * sets the account saturation level
    */
    #define DDR3_IP_2034_PRIO4_QOS_LL_CLIP_CLIP_RW (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO4_QOS_LL_CLIP_CLIP_SHIFT 0
    #define DDR3_IP_2034_PRIO4_QOS_GT_DEADLINE_REG  (DDR3_IP_2034_BASE + 0x710)
    /*
    * sets the priority boosting timeout
    */
    #define DDR3_IP_2034_PRIO4_QOS_GT_DEADLINE_DEADLINE_RW (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO4_QOS_GT_DEADLINE_DEADLINE_SHIFT 0
    #define DDR3_IP_2034_PRIO4_QOS_PRIO_REG  (DDR3_IP_2034_BASE + 0x714)
    /*
    * Select the write priority (LL type only)
    */
    #define DDR3_IP_2034_PRIO4_QOS_PRIO_WRITE_RW (0x01f << 16)
    #define DDR3_IP_2034_PRIO4_QOS_PRIO_WRITE_SHIFT 16
    /*
    * Select the limited read priority (LL type) or boosted priority (GTtype)
    */
    #define DDR3_IP_2034_PRIO4_QOS_PRIO_LIMITED_BOOSTED_RW (0x01f << 8)
    #define DDR3_IP_2034_PRIO4_QOS_PRIO_LIMITED_BOOSTED_SHIFT 8
    /*
    * Select the default read priority (LL type) or default priority (GT or BE type)
    */
    #define DDR3_IP_2034_PRIO4_QOS_PRIO_DEFAULT_RW (0x01f << 0)
    #define DDR3_IP_2034_PRIO4_QOS_PRIO_DEFAULT_SHIFT 0
    #define DDR3_IP_2034_PRIO4_QOS_HYSTERESIS_REG  (DDR3_IP_2034_BASE + 0x718)
    /*
    * sets the minimum cycles that boosted priority is used
    */
    #define DDR3_IP_2034_PRIO4_QOS_HYSTERESIS_MIN_BOOST_RW (0x0ff << 16)
    #define DDR3_IP_2034_PRIO4_QOS_HYSTERESIS_MIN_BOOST_SHIFT 16
    /*
    * sets the minimum cycles that limited priority is used
    */
    #define DDR3_IP_2034_PRIO4_QOS_HYSTERESIS_MIN_LIMI_RW (0x0ff << 0)
    #define DDR3_IP_2034_PRIO4_QOS_HYSTERESIS_MIN_LIMI_SHIFT 0
    #define DDR3_IP_2034_PRIO4_PERF_MAX_ACCOUNT_REG  (DDR3_IP_2034_BASE + 0x71c)
    /*
    * maximum value of the account
    */
    #define DDR3_IP_2034_PRIO4_PERF_MAX_ACCOUNT_MAX_ACCOUNT_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO4_PERF_MAX_ACCOUNT_MAX_ACCOUNT_SHIFT 0
    #define DDR3_IP_2034_PRIO4_PERF_TOTAL_REG  (DDR3_IP_2034_BASE + 0x720)
    /*
    * counter for total number of elapsed cycles, with or without data
    */
    #define DDR3_IP_2034_PRIO4_PERF_TOTAL_TOTAL_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO4_PERF_TOTAL_TOTAL_SHIFT 0
    #define DDR3_IP_2034_PRIO4_PERF_RDDATA_REG  (DDR3_IP_2034_BASE + 0x724)
    /*
    * counter for net read data cycles
    */
    #define DDR3_IP_2034_PRIO4_PERF_RDDATA_READ_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO4_PERF_RDDATA_READ_SHIFT 0
    #define DDR3_IP_2034_PRIO4_PERF_RDDATA_DEF_REG  (DDR3_IP_2034_BASE + 0x728)
    /*
    * counter for net read data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO4_PERF_RDDATA_DEF_READ_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO4_PERF_RDDATA_DEF_READ_SHIFT 0
    #define DDR3_IP_2034_PRIO4_PERF_WRDATA_REG  (DDR3_IP_2034_BASE + 0x72c)
    /*
    * counter for net write data cycles
    */
    #define DDR3_IP_2034_PRIO4_PERF_WRDATA_WRITE_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO4_PERF_WRDATA_WRITE_SHIFT 0
    #define DDR3_IP_2034_PRIO4_PERF_WRDATA_DEF_REG  (DDR3_IP_2034_BASE + 0x730)
    /*
    * counter for net write data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO4_PERF_WRDATA_DEF_WRITE_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO4_PERF_WRDATA_DEF_WRITE_SHIFT 0
    #define DDR3_IP_2034_PRIO4_STATE_REG  (DDR3_IP_2034_BASE + 0x734)
    /*
    * indicates whether account is currently clipped (LL)
    */
    #define DDR3_IP_2034_PRIO4_STATE_CLIPPED_R (0x01 << 6)
    #define DDR3_IP_2034_PRIO4_STATE_CLIPPED_SHIFT 6
    /*
    * indicates whether priority is currently limited (LL)
    */
    #define DDR3_IP_2034_PRIO4_STATE_LIMITED__R (0x01 << 5)
    #define DDR3_IP_2034_PRIO4_STATE_LIMITED__SHIFT 5
    /*
    * indicates whether priority is currently boosted (GT)
    */
    #define DDR3_IP_2034_PRIO4_STATE_BOOSTED_R (0x01 << 4)
    #define DDR3_IP_2034_PRIO4_STATE_BOOSTED_SHIFT 4
    /*
    * indicates whether performance monitors are running
    */
    #define DDR3_IP_2034_PRIO4_STATE_RUNNING_R (0x01 << 0)
    #define DDR3_IP_2034_PRIO4_STATE_RUNNING_SHIFT 0
    #define DDR3_IP_2034_PRIO4_ACCOUNT_REG  (DDR3_IP_2034_BASE + 0x738)
    /*
    * counter for net write data cycles with default priority
    */
    #define DDR3_IP_2034_PRIO4_ACCOUNT_ACCOUNT0_R (0x07fffffff << 0)
    #define DDR3_IP_2034_PRIO4_ACCOUNT_ACCOUNT0_SHIFT 0
    #define DDR3_IP_2034_PRIO4_PRIO_REG  (DDR3_IP_2034_BASE + 0x73c)
    /*
    * current value of the write priority
    */
    #define DDR3_IP_2034_PRIO4_PRIO_WRITE_PRIO_R (0x01f << 8)
    #define DDR3_IP_2034_PRIO4_PRIO_WRITE_PRIO_SHIFT 8
    /*
    * current value of the read priority
    */
    #define DDR3_IP_2034_PRIO4_PRIO_READ_PRIO_R (0x01f << 0)
    #define DDR3_IP_2034_PRIO4_PRIO_READ_PRIO_SHIFT 0
    #define DDR3_IP_2034_MX0_RW_MIN_TIMERS_REG  (DDR3_IP_2034_BASE + 0x804)
    /*
    * minimum time that writing has preference once started
    */
    #define DDR3_IP_2034_MX0_RW_MIN_TIMERS_MIN_WRITE_TIME_RW (0x0ff << 16)
    #define DDR3_IP_2034_MX0_RW_MIN_TIMERS_MIN_WRITE_TIME_SHIFT 16
    /*
    * minimum time that reading has preference once started
    */
    #define DDR3_IP_2034_MX0_RW_MIN_TIMERS_MIN_READ_TIME_RW (0x0ff << 0)
    #define DDR3_IP_2034_MX0_RW_MIN_TIMERS_MIN_READ_TIME_SHIFT 0
    #define DDR3_IP_2034_MX0_PAGE_POLICY_REG  (DDR3_IP_2034_BASE + 0x808)
    /*
    * select the page policy to be used
    *  0 closed page policy
    *  1 open page policy
    */
    #define DDR3_IP_2034_MX0_PAGE_POLICY_OPEN_PAGE_RW (0x01 << 0)
    #define DDR3_IP_2034_MX0_PAGE_POLICY_OPEN_PAGE_SHIFT 0
    #define DDR3_IP_2034_OBF_CONTROL_REG  (DDR3_IP_2034_BASE + 0xa00)
    /*
    * enable/disable the use of obfuscation
    *  0 disable use of obfuscation
    *  1 enable use of obfuscation
    */
    #define DDR3_IP_2034_OBF_CONTROL_ENABLE_RW (0x01 << 0)
    #define DDR3_IP_2034_OBF_CONTROL_ENABLE_SHIFT 0

    #define DDR3_IP_2034_OBF_OCW0_REG  (DDR3_IP_2034_BASE + 0xb00)
    #define DDR3_IP_2034_OBF_OCW1_REG  (DDR3_IP_2034_BASE + 0xb04)
    #define DDR3_IP_2034_OBF_OCW2_REG  (DDR3_IP_2034_BASE + 0xb08)
    #define DDR3_IP_2034_OBF_OCW3_REG  (DDR3_IP_2034_BASE + 0xb0c)
    #define DDR3_IP_2034_OBF_OCW4_REG  (DDR3_IP_2034_BASE + 0xb10)
    #define DDR3_IP_2034_OBF_OCW5_REG  (DDR3_IP_2034_BASE + 0xb14)
    #define DDR3_IP_2034_OBF_OCW6_REG  (DDR3_IP_2034_BASE + 0xb18)
    #define DDR3_IP_2034_OBF_OCW7_REG  (DDR3_IP_2034_BASE + 0xb1c)
    #define DDR3_IP_2034_OBF_OCW8_REG  (DDR3_IP_2034_BASE + 0xb20)
    #define DDR3_IP_2034_OBF_OCW9_REG  (DDR3_IP_2034_BASE + 0xb24)
    #define DDR3_IP_2034_OBF_OCW10_REG  (DDR3_IP_2034_BASE + 0xb28)
    #define DDR3_IP_2034_OBF_OCW11_REG  (DDR3_IP_2034_BASE + 0xb2c)
    #define DDR3_IP_2034_OBF_OCW12_REG  (DDR3_IP_2034_BASE + 0xb30)
    #define DDR3_IP_2034_OBF_OCW13_REG  (DDR3_IP_2034_BASE + 0xb34)
    #define DDR3_IP_2034_OBF_OCW14_REG  (DDR3_IP_2034_BASE + 0xb38)
    #define DDR3_IP_2034_OBF_OCW15_REG  (DDR3_IP_2034_BASE + 0xb3c)
    #define DDR3_IP_2034_OBF_OCW16_REG  (DDR3_IP_2034_BASE + 0xb40)
    #define DDR3_IP_2034_OBF_OCW17_REG  (DDR3_IP_2034_BASE + 0xb44)
    #define DDR3_IP_2034_OBF_OCW18_REG  (DDR3_IP_2034_BASE + 0xb48)
    #define DDR3_IP_2034_OBF_OCW19_REG  (DDR3_IP_2034_BASE + 0xb4c)
    #define DDR3_IP_2034_OBF_OCW20_REG  (DDR3_IP_2034_BASE + 0xb50)
    #define DDR3_IP_2034_OBF_OCW21_REG  (DDR3_IP_2034_BASE + 0xb54)
    #define DDR3_IP_2034_OBF_OCW22_REG  (DDR3_IP_2034_BASE + 0xb58)
    #define DDR3_IP_2034_OBF_OCW23_REG  (DDR3_IP_2034_BASE + 0xb5c)
    #define DDR3_IP_2034_OBF_OCW24_REG  (DDR3_IP_2034_BASE + 0xb60)
    #define DDR3_IP_2034_OBF_OCW25_REG  (DDR3_IP_2034_BASE + 0xb64)
    #define DDR3_IP_2034_OBF_OCW26_REG  (DDR3_IP_2034_BASE + 0xb68)
    #define DDR3_IP_2034_OBF_OCW27_REG  (DDR3_IP_2034_BASE + 0xb6c)
    #define DDR3_IP_2034_OBF_OCW28_REG  (DDR3_IP_2034_BASE + 0xb70)
    #define DDR3_IP_2034_OBF_OCW29_REG  (DDR3_IP_2034_BASE + 0xb74)
    #define DDR3_IP_2034_OBF_OCW30_REG  (DDR3_IP_2034_BASE + 0xb78)
    #define DDR3_IP_2034_OBF_OCW31_REG  (DDR3_IP_2034_BASE + 0xb7c)
    #define DDR3_IP_2034_OBF_OCW32_REG  (DDR3_IP_2034_BASE + 0xb80)
    #define DDR3_IP_2034_OBF_OCW33_REG  (DDR3_IP_2034_BASE + 0xb84)
    #define DDR3_IP_2034_OBF_OCW34_REG  (DDR3_IP_2034_BASE + 0xb88)
    #define DDR3_IP_2034_OBF_OCW35_REG  (DDR3_IP_2034_BASE + 0xb8c)
    #define DDR3_IP_2034_OBF_OCW36_REG  (DDR3_IP_2034_BASE + 0xb90)
    #define DDR3_IP_2034_OBF_OCW37_REG  (DDR3_IP_2034_BASE + 0xb94)
    #define DDR3_IP_2034_OBF_OCW38_REG  (DDR3_IP_2034_BASE + 0xb98)
    #define DDR3_IP_2034_OBF_OCW39_REG  (DDR3_IP_2034_BASE + 0xb9c)
    #define DDR3_IP_2034_OBF_OCW40_REG  (DDR3_IP_2034_BASE + 0xba0)
    #define DDR3_IP_2034_OBF_OCW41_REG  (DDR3_IP_2034_BASE + 0xba4)
    #define DDR3_IP_2034_OBF_OCW42_REG  (DDR3_IP_2034_BASE + 0xba8)
    #define DDR3_IP_2034_OBF_OCW43_REG  (DDR3_IP_2034_BASE + 0xbac)
    #define DDR3_IP_2034_OBF_OCW44_REG  (DDR3_IP_2034_BASE + 0xbb0)
    #define DDR3_IP_2034_OBF_OCW45_REG  (DDR3_IP_2034_BASE + 0xbb4)
    #define DDR3_IP_2034_OBF_OCW46_REG  (DDR3_IP_2034_BASE + 0xbb8)
    #define DDR3_IP_2034_OBF_OCW47_REG  (DDR3_IP_2034_BASE + 0xbbc)
    #define DDR3_IP_2034_OBF_OCW48_REG  (DDR3_IP_2034_BASE + 0xbc0)
    #define DDR3_IP_2034_OBF_OCW49_REG  (DDR3_IP_2034_BASE + 0xbc4)
    #define DDR3_IP_2034_OBF_OCW50_REG  (DDR3_IP_2034_BASE + 0xbc8)
    #define DDR3_IP_2034_OBF_OCW51_REG  (DDR3_IP_2034_BASE + 0xbcc)
    #define DDR3_IP_2034_OBF_OCW52_REG  (DDR3_IP_2034_BASE + 0xbd0)
    #define DDR3_IP_2034_OBF_OCW53_REG  (DDR3_IP_2034_BASE + 0xbd4)
    #define DDR3_IP_2034_OBF_OCW54_REG  (DDR3_IP_2034_BASE + 0xbd8)
    #define DDR3_IP_2034_OBF_OCW55_REG  (DDR3_IP_2034_BASE + 0xbdc)
    #define DDR3_IP_2034_OBF_OCW56_REG  (DDR3_IP_2034_BASE + 0xbe0)
    #define DDR3_IP_2034_OBF_OCW57_REG  (DDR3_IP_2034_BASE + 0xbe4)
    #define DDR3_IP_2034_OBF_OCW58_REG  (DDR3_IP_2034_BASE + 0xbe8)
    #define DDR3_IP_2034_OBF_OCW59_REG  (DDR3_IP_2034_BASE + 0xbec)
    #define DDR3_IP_2034_OBF_OCW60_REG  (DDR3_IP_2034_BASE + 0xbf0)
    #define DDR3_IP_2034_OBF_OCW61_REG  (DDR3_IP_2034_BASE + 0xbf4)
    #define DDR3_IP_2034_OBF_OCW62_REG  (DDR3_IP_2034_BASE + 0xbf8)
    #define DDR3_IP_2034_OBF_OCW63_REG  (DDR3_IP_2034_BASE + 0xbfc)
    #define DDR3_IP_2034_OBF_OCW64_REG  (DDR3_IP_2034_BASE + 0xc00)
    #define DDR3_IP_2034_OBF_OCW65_REG  (DDR3_IP_2034_BASE + 0xc04)
    #define DDR3_IP_2034_OBF_OCW66_REG  (DDR3_IP_2034_BASE + 0xc08)
    #define DDR3_IP_2034_OBF_OCW67_REG  (DDR3_IP_2034_BASE + 0xc0c)
    #define DDR3_IP_2034_OBF_OCW68_REG  (DDR3_IP_2034_BASE + 0xc10)
    #define DDR3_IP_2034_OBF_OCW69_REG  (DDR3_IP_2034_BASE + 0xc14)
    #define DDR3_IP_2034_OBF_OCW70_REG  (DDR3_IP_2034_BASE + 0xc18)
    #define DDR3_IP_2034_OBF_OCW71_REG  (DDR3_IP_2034_BASE + 0xc1c)
    #define DDR3_IP_2034_OBF_OCW72_REG  (DDR3_IP_2034_BASE + 0xc20)
    #define DDR3_IP_2034_OBF_OCW73_REG  (DDR3_IP_2034_BASE + 0xc24)
    #define DDR3_IP_2034_OBF_OCW74_REG  (DDR3_IP_2034_BASE + 0xc28)
    #define DDR3_IP_2034_OBF_OCW75_REG  (DDR3_IP_2034_BASE + 0xc2c)
    #define DDR3_IP_2034_OBF_OCW76_REG  (DDR3_IP_2034_BASE + 0xc30)
    #define DDR3_IP_2034_OBF_OCW77_REG  (DDR3_IP_2034_BASE + 0xc34)
    #define DDR3_IP_2034_OBF_OCW78_REG  (DDR3_IP_2034_BASE + 0xc38)
    #define DDR3_IP_2034_OBF_OCW79_REG  (DDR3_IP_2034_BASE + 0xc3c)
    #define DDR3_IP_2034_OBF_OCW80_REG  (DDR3_IP_2034_BASE + 0xc40)
    #define DDR3_IP_2034_OBF_OCW81_REG  (DDR3_IP_2034_BASE + 0xc44)
    #define DDR3_IP_2034_OBF_OCW82_REG  (DDR3_IP_2034_BASE + 0xc48)
    #define DDR3_IP_2034_OBF_OCW83_REG  (DDR3_IP_2034_BASE + 0xc4c)
    #define DDR3_IP_2034_OBF_OCW84_REG  (DDR3_IP_2034_BASE + 0xc50)
    #define DDR3_IP_2034_OBF_OCW85_REG  (DDR3_IP_2034_BASE + 0xc54)
    #define DDR3_IP_2034_OBF_OCW86_REG  (DDR3_IP_2034_BASE + 0xc58)
    #define DDR3_IP_2034_OBF_OCW87_REG  (DDR3_IP_2034_BASE + 0xc5c)
    #define DDR3_IP_2034_OBF_OCW88_REG  (DDR3_IP_2034_BASE + 0xc60)
    #define DDR3_IP_2034_OBF_OCW89_REG  (DDR3_IP_2034_BASE + 0xc64)
    #define DDR3_IP_2034_OBF_OCW90_REG  (DDR3_IP_2034_BASE + 0xc68)
    #define DDR3_IP_2034_OBF_OCW91_REG  (DDR3_IP_2034_BASE + 0xc6c)
    #define DDR3_IP_2034_OBF_OCW92_REG  (DDR3_IP_2034_BASE + 0xc70)
    #define DDR3_IP_2034_OBF_OCW93_REG  (DDR3_IP_2034_BASE + 0xc74)
    #define DDR3_IP_2034_OBF_OCW94_REG  (DDR3_IP_2034_BASE + 0xc78)
    #define DDR3_IP_2034_OBF_OCW95_REG  (DDR3_IP_2034_BASE + 0xc7c)
    #define DDR3_IP_2034_OBF_OCW96_REG  (DDR3_IP_2034_BASE + 0xc80)
    #define DDR3_IP_2034_OBF_OCW97_REG  (DDR3_IP_2034_BASE + 0xc84)
    #define DDR3_IP_2034_OBF_OCW98_REG  (DDR3_IP_2034_BASE + 0xc88)
    #define DDR3_IP_2034_OBF_OCW99_REG  (DDR3_IP_2034_BASE + 0xc8c)
    #define DDR3_IP_2034_OBF_OCW100_REG  (DDR3_IP_2034_BASE + 0xc90)
    #define DDR3_IP_2034_OBF_OCW101_REG  (DDR3_IP_2034_BASE + 0xc94)
    #define DDR3_IP_2034_OBF_OCW102_REG  (DDR3_IP_2034_BASE + 0xc98)
    #define DDR3_IP_2034_OBF_OCW103_REG  (DDR3_IP_2034_BASE + 0xc9c)
    #define DDR3_IP_2034_OBF_OCW104_REG  (DDR3_IP_2034_BASE + 0xca0)
    #define DDR3_IP_2034_OBF_OCW105_REG  (DDR3_IP_2034_BASE + 0xca4)
    #define DDR3_IP_2034_OBF_OCW106_REG  (DDR3_IP_2034_BASE + 0xca8)
    #define DDR3_IP_2034_OBF_OCW107_REG  (DDR3_IP_2034_BASE + 0xcac)
    #define DDR3_IP_2034_OBF_OCW108_REG  (DDR3_IP_2034_BASE + 0xcb0)
    #define DDR3_IP_2034_OBF_OCW109_REG  (DDR3_IP_2034_BASE + 0xcb4)
    #define DDR3_IP_2034_OBF_OCW110_REG  (DDR3_IP_2034_BASE + 0xcb8)
    #define DDR3_IP_2034_OBF_OCW111_REG  (DDR3_IP_2034_BASE + 0xcbc)
    #define DDR3_IP_2034_OBF_OCW112_REG  (DDR3_IP_2034_BASE + 0xcc0)
    #define DDR3_IP_2034_OBF_OCW113_REG  (DDR3_IP_2034_BASE + 0xcc4)
    #define DDR3_IP_2034_OBF_OCW114_REG  (DDR3_IP_2034_BASE + 0xcc8)
    #define DDR3_IP_2034_OBF_OCW115_REG  (DDR3_IP_2034_BASE + 0xccc)
    #define DDR3_IP_2034_OBF_OCW116_REG  (DDR3_IP_2034_BASE + 0xcd0)
    #define DDR3_IP_2034_OBF_OCW117_REG  (DDR3_IP_2034_BASE + 0xcd4)
    #define DDR3_IP_2034_OBF_OCW118_REG  (DDR3_IP_2034_BASE + 0xcd8)
    #define DDR3_IP_2034_OBF_OCW119_REG  (DDR3_IP_2034_BASE + 0xcdc)
    #define DDR3_IP_2034_OBF_OCW120_REG  (DDR3_IP_2034_BASE + 0xce0)
    #define DDR3_IP_2034_OBF_OCW121_REG  (DDR3_IP_2034_BASE + 0xce4)
    #define DDR3_IP_2034_OBF_OCW122_REG  (DDR3_IP_2034_BASE + 0xce8)
    #define DDR3_IP_2034_OBF_OCW123_REG  (DDR3_IP_2034_BASE + 0xcec)
    #define DDR3_IP_2034_OBF_OCW124_REG  (DDR3_IP_2034_BASE + 0xcf0)
    #define DDR3_IP_2034_OBF_OCW125_REG  (DDR3_IP_2034_BASE + 0xcf4)
    #define DDR3_IP_2034_OBF_OCW126_REG  (DDR3_IP_2034_BASE + 0xcf8)
    #define DDR3_IP_2034_OBF_OCW127_REG  (DDR3_IP_2034_BASE + 0xcfc)
    #define DDR3_IP_2034_SW_RESET_REG  (DDR3_IP_2034_BASE + 0xff0)
    /*
    * Reset of the complete memory controller subsystem
    */
    #define DDR3_IP_2034_SW_RESET_RESET_RW (0x01 << 0)
    #define DDR3_IP_2034_SW_RESET_RESET_SHIFT 0

    #define DDR3_IP_2034_POWERMODE_CTRL_REG  (DDR3_IP_2034_BASE + 0xff4)
    /*
    * low power mode acknowledge
    */
    #define DDR3_IP_2034_POWERMODE_CTRL_LPMODE_ACK_RW (0x01 << 1)
    #define DDR3_IP_2034_POWERMODE_CTRL_LPMODE_ACK_SHIFT 1
    /*
    * low power mode request
    */
    #define DDR3_IP_2034_POWERMODE_CTRL_LPMODE_REQ_RW (0x01 << 0)
    #define DDR3_IP_2034_POWERMODE_CTRL_LPMODE_REQ_SHIFT 0

    #define DDR3_IP_2034_MODULE_ID_REG  (DDR3_IP_2034_BASE + 0xffc)
    /*
    * Module ID value
    */
    #define DDR3_IP_2034_MODULE_ID_MOD_ID_R (0x0ffff << 16)
    #define DDR3_IP_2034_MODULE_ID_MOD_ID_SHIFT 16
    /*
    * Major revision number
    */
    #define DDR3_IP_2034_MODULE_ID_MAJOR_REV_R (0x0f << 12)
    #define DDR3_IP_2034_MODULE_ID_MAJOR_REV_SHIFT 12
    /*
    * Minor revision number
    */
    #define DDR3_IP_2034_MODULE_ID_MINOR_REV_R (0x0f << 8)
    #define DDR3_IP_2034_MODULE_ID_MINOR_REV_SHIFT 8
    /*
    * Aperture size multiple of 4K bytes
    */
    #define DDR3_IP_2034_MODULE_ID_APERTURE_R (0x0ff << 0)
    #define DDR3_IP_2034_MODULE_ID_APERTURE_SHIFT 0

#endif // PHMODIPDDR320552034_H
