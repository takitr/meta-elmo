/*-------------------------------------------------------------------------*/
/* Copyright 2011 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef PHMODIPCGU_H
#define PHMODIPCGU_H


#define CGU_PLL_CGU1G4_CON1_CTL_REG    (CGU_BASE + 0x0)
#define CGU_PLL_CGU1G4_CON2_CTL_REG    (CGU_BASE + 0x4)
#define CGU_PLL_CGU1G4_STA_CTL_REG     (CGU_BASE + 0x8)

/* bit field definition are commonly defined for all PLLs */
/* SELX */
/* CORE PLL */
#define    CGU_PLL_CORE_SELR_MASK          (0x00F << 28)
#define    CGU_PLL_CORE_SELR_SHIFT         28
#define    CGU_PLL_CORE_SELI_MASK          (0x03f << 22)
#define    CGU_PLL_CORE_SELI_SHIFT         22
#define    CGU_PLL_CORE_SELP_MASK          (0x01f << 17)
#define    CGU_PLL_CORE_SELP_SHIFT         17

/* AFE PLL */
#define    CGU_PLL_AFE_SELR_MASK           (0x00F << 11)
#define    CGU_PLL_AFE_SELR_SHIFT          11
#define    CGU_PLL_AFE_SELI_MASK           (0x03f << 5)
#define    CGU_PLL_AFE_SELI_SHIFT           5
#define    CGU_PLL_AFE_SELP_MASK           (0x01f << 0)
#define    CGU_PLL_AFE_SELP_SHIFT           0

#define    CGU_PLL_CTL_SRC_SEL_MASK        (0x003 << 29)
#define    CGU_PLL_SRC_SEL_SHIFT           29
#define    CGU_PLL_CTL_SRC_EN_MASK         (0x001 << 28)
#define    CGU_PLL_CTL_SRC_EN_SHIFT        28
#define       CGU_PLL_CTL_SRC_EN_ENABLE    (0x000 << 28)
#define       CGU_PLL_CTL_SRC_EN_DISABLE   (0x001 << 28)

/* NDEC */
/* for AFE fractional PLLs, NDEC is bit 7:16 */
#define    CGU_PLL_AFE_FRAC_NDEC_MASK      (0x03ff << 7)
#define    CGU_PLL_AFE_FRAC_NDEC_SHIFT     7
/* for AFE integer PLLs, NDEC is bit 15:24 */
#define    CGU_PLL_AFE_INT_NDEC_MASK       (0x03ff << 15)
#define    CGU_PLL_AFE_INT_NDEC_SHIFT      15
/* for Core integer PLLs, NDEC is bit 16:25 */
#define    CGU_PLL_CORE_INT_NDEC_MASK      (0x03ff << 16)
#define    CGU_PLL_CORE_INT_NDEC_SHIFT     16

/* PDEC */
/* for AFE PLLs, PDEC is bit 0:7 */
#define    CGU_PLL_AFE_PDEC_MASK           (0x07f << 0)
#define    CGU_PLL_AFE_PDEC_SHIFT          0
/* for Core PLLs, PDEC is bit 9:15 */
#define    CGU_PLL_CORE_PDEC_MASK          (0x07f << 9)
#define    CGU_PLL_CORE_PDEC_SHIFT         9

/* MDEC */
/* for AFE PLLs, MDEC is bit 7:23 */
#define    CGU_PLL_AFE_MDEC_MASK           (0x1ffff << 7)
#define    CGU_PLL_AFE_MDEC_SHIFT          7
/* for AFE PLLs, MDEC_EXT is bit 0:16 */
#define    CGU_PLL_AFE_MDEC_EXT_MASK       (0x1ffff << 0)
#define    CGU_PLL_AFE_MDEC_EXT_SHIFT      0
/* for Core PLLs, MDEC is bit 0:16 */
#define    CGU_PLL_CORE_MDEC_MASK          (0x1ffff << 0)
#define    CGU_PLL_CORE_MDEC_SHIFT         0

/* MREQ */
/* for AFE fractional PLLs, MREQ is bit 3, MREQ_EXT is bit 4 */
#define    CGU_PLL_AFE_FRAC_MREQ_MASK       (0x01 << 3)
#define    CGU_PLL_AFE_FRAC_MREQ_SHIFT      3
#define    CGU_PLL_AFE_FRAC_MREQ_EXT_MASK   (0x01 << 4)
#define    CGU_PLL_AFE_FRAC_MREQ_EXT_SHIFT  4
/* for AFE integer PLLs, MREQ is bit 9 */
#define    CGU_PLL_AFE_INT_MREQ_MASK        (0x01 << 9)
#define    CGU_PLL_AFE_INT_MREQ_SHIFT       9
/* for Core integer PLLs, MREQ is bit 6 */
#define    CGU_PLL_CORE_INT_MREQ_MASK       (0x01 << 6)
#define    CGU_PLL_CORE_INT_MREQ_SHIFT      6

/* NREQ */
/* for AFE fractional PLLs, NREQ is bit 10 */
#define    CGU_PLL_AFE_FRAC_NREQ_MASK       (0x01 << 10)
#define    CGU_PLL_AFE_FRAC_NREQ_SHIFT      10
/* for AFE integer PLLs, NREQ is bit 10 */
#define    CGU_PLL_AFE_INT_NREQ_MASK        (0x01 << 10)
#define    CGU_PLL_AFE_INT_NREQ_SHIFT       10
/* for Core integer PLLs, NREQ is bit 8 */
#define    CGU_PLL_CORE_INT_NREQ_MASK       (0x01 << 8)
#define    CGU_PLL_CORE_INT_NREQ_SHIFT      8

/* PREQ */
/* for AFE fractional PLLs, PREQ is bit 8 */
#define    CGU_PLL_AFE_FRAC_PREQ_MASK       (0x01 << 8)
#define    CGU_PLL_AFE_FRAC_PREQ_SHIFT      8
/* for AFE integer PLLs, PREQ is bit 8 */
#define    CGU_PLL_AFE_INT_PREQ_MASK        (0x01 << 8)
#define    CGU_PLL_AFE_INT_PREQ_SHIFT       8
/* for Core integer PLLs, PREQ is bit 7 */
#define    CGU_PLL_CORE_INT_PREQ_MASK       (0x01 << 7)
#define    CGU_PLL_CORE_INT_PREQ_SHIFT      7

/* PLL and CLK output power down, common for PLLs and CLOCKs */
#define    CGU_CTL_PD_MASK                  (0x01 << 0)
#define    CGU_CTL_PD_SHIFT                 0

/* PLL block enable */
#define    CGU_PLL_CTL_BLOCK_EN_MASK        (0x01 << 1)
#define    CGU_PLL_CTL_BLOCK_EN_SHIFT       1

/* PLL BYPASS */
#define    CGU_PLL_CTL_BYPASS_MASK          (0x01 << 2)
#define    CGU_PLL_CTL_BYPASS_SHIFT         2

/* PLL DIRECTO */
#define    CGU_PLL_CTL_DIRECTO_MASK         (0x01 << 3)
#define    CGU_PLL_CTL_DIRECTO_SHIFT        3

/* PLL DIRECTI */
#define    CGU_PLL_CTL_DIRECTI_MASK         (0x01 << 4)
#define    CGU_PLL_CTL_DIRECTI_SHIFT        4

/* PLL FRM */
#define    CGU_PLL_CTL_FRM_MASK             (0x01 << 5)
#define    CGU_PLL_CTL_FRM_SHIFT            5

/*
* 11 - pll0 = backup_clk[1]
* 10 - pll0 = pl1g4_clk_100
* 01 - pll0 = xclk_clk_25
* 00 - pll0 = 50MHz xtal_clk
*/
#define    CGU_PLL_SRC_SEL_MASK             (0x03<<29)
#define    CGU_PLL_SRC_SEL_SHIFT            29
#define       CGU_PLL_SRC_SEL_XTAL          (0x00<<29)
#define       CGU_PLL_SRC_SEL_XTAL_2        (0x01<<29)
#define       CGU_PLL_SRC_SEL_1G4_100       (0x02<<29)
#define       CGU_PLL_SRC_SEL_BACKUP        (0x03<<29)

/* STATUS REG */
/* CORE PLL: Free Running bit 2 */
#define    CGU_PLL_CORE_STA_FR_MASK         (0x01 << 2)
#define    CGU_PLL_CORE_STA_FR_SHIFT        2
#define       CGU_PLL_CORE_STA_FR           (0x01<<2)
#define       CGU_PLL_CORE_STA_FR_NOT       (0x00<<2)

/* AFE PLL: Free Running, bit 4 */
#define    CGU_PLL_AFE_STA_FR_MASK          (0x01 << 4)
#define    CGU_PLL_AFE_STA_FR_SHIFT         4
#define       CGU_PLL_AFE_STA_FR            (0x01<<4)
#define       CGU_PLL_AFE_STA_FR_NOT        (0x00<<4)

#define    CGU_PLL_STA_BLOCKED_MASK         (0x01 << 1)
#define    CGU_PLL_STA_BLOCKED_SHIFT        1
#define       CGU_PLL_STA_BLOCKED_NOT       (0x00<<1)
#define       CGU_PLL_STA_BLOCKED           (0x01<<1)
#define    CGU_PLL_STA_LOCK_MASK            (0x01 << 0)
#define    CGU_PLL_STA_LOCK_SHIFT           0
#define       CGU_PLL_STA_LOCK              0x01
#define       CGU_PLL_STA_LOCK_NOT          0x00

#define CGU_DIVCLK_PD_CTL_REG              (CGU_BASE + 0xc)
#define    CGU_DIVCLK_PD_400_PD_MASK       (0x01 << 13)
#define    CGU_DIVCLK_PD_400_PD_SHIFT      13
#define    CGU_DIVCLK_PD_20_PD_MASK        (0x01 << 12)
#define    CGU_DIVCLK_PD_20_PD_SHIFT       12
#define    CGU_DIVCLK_PD_266_PD_MASK       (0x01 << 11)
#define    CGU_DIVCLK_PD_266_PD_SHIFT      11
#define    CGU_DIVCLK_PD_228_PD_MASK       (0x01 << 10)
#define    CGU_DIVCLK_PD_228_PD_SHIFT      10
#define    CGU_DIVCLK_PD_200_PD_MASK       (0x01 << 9)
#define    CGU_DIVCLK_PD_200_PD_SHIFT      9
#define    CGU_DIVCLK_PD_177_PD_MASK       (0x01 << 8)
#define    CGU_DIVCLK_PD_177_PD_SHIFT      8
#define    CGU_DIVCLK_PD_160_PD_MASK       (0x01 << 7)
#define    CGU_DIVCLK_PD_160_PD_SHIFT      7
#define    CGU_DIVCLK_PD_145_PD_MASK       (0x01 << 6)
#define    CGU_DIVCLK_PD_145_PD_SHIFT      6
#define    CGU_DIVCLK_PD_133_PD_MASK       (0x01 << 5)
#define    CGU_DIVCLK_PD_133_PD_SHIFT      5
#define    CGU_DIVCLK_PD_123_PD_MASK       (0x01 << 4)
#define    CGU_DIVCLK_PD_123_PD_SHIFT      4
#define    CGU_DIVCLK_PD_114_PD_MASK       (0x01 << 3)
#define    CGU_DIVCLK_PD_114_PD_SHIFT      3
#define    CGU_DIVCLK_PD_106_PD_MASK       (0x01 << 2)
#define    CGU_DIVCLK_PD_106_PD_SHIFT      2
#define    CGU_DIVCLK_PD_100_PD_MASK       (0x01 << 1)
#define    CGU_DIVCLK_PD_100_PD_SHIFT      1
#define    CGU_DIVCLK_PD_94_PD_MASK        (0x01 << 0)
#define    CGU_DIVCLK_PD_94_PD_SHIFT       0

#define CGU_PLL_PLL0_CON1_CTL_REG           (CGU_BASE + 0x00)
#define CGU_PLL_PLL0_CON2_CTL_REG           (CGU_BASE + 0x04)
#define CGU_PLL_PLL0_STA_CTL_REG            (CGU_BASE + 0x08)





/*
* 0 - Fractional wrapper active
* 1 - Fractional wrapper powered down.
*/
#define    CGU_PLL1_PLLFRAC_PD_MASK        (0x01 << 31)
#define    CGU_PLL1_PLLFRAC_PD_SHIFT       31
#define       CGU_PLL1_PLLFRAC_PD_ACTIVE   (0x00<<31)
#define       CGU_PLL1_PLLFRAC_PD          (0x01<<31)
/*
* 0 - pll1 fractional wapper not used
* 1 - pll1 fractional wapper used
*/
#define    CGU_PLL1_PLLFRAC_SEL_MASK               (0x01 << 30)
#define    CGU_PLL1_PLLFRAC_SEL_SHIFT              30
#define       CGU_PLL1_PLLFRAC_SEL_WAPPER_NOT_USED (0x00<<30)
#define       CGU_PLL1_PLLFRAC_SEL_WAPPER_USED     (0x01<<30)
#define    CGU_PLL1_PLLFRAC_REQ_MASK               (0x01 << 29)
#define    CGU_PLL1_PLLFRAC_REQ_SHIFT              29



#define CGU_PLL_MVD_CON1_CTL_REG                  (HM_CGU_BASE + 0x00)
#define CGU_PLL_MVD_CON2_CTL_REG                  (HM_CGU_BASE + 0x04)
#define CGU_PLL_MVD_STA_CTL_REG                   (HM_CGU_BASE + 0x08)

#define CGU_PLL_TMAUD_CON1_CTL_REG                (HOST_CGU_BASE + 0x10)
#define CGU_PLL_TMAUD_CON2_CTL_REG                (HOST_CGU_BASE + 0x14)
#define CGU_PLL_TMAUD_STA_CTL_REG                 (HOST_CGU_BASE + 0x18)





#define CGU_PLL_ARM_CON1_CTL_REG                  (HM_CGU_BASE + 0x0c)
#define CGU_PLL_ARM_CON2_CTL_REG                  (HM_CGU_BASE + 0x10)
#define CGU_PLL_ARM_STA_CTL_REG                   (HM_CGU_BASE + 0x14)

#define CGU_PLL_MEM_CON1_CTL_REG                  (HOST_CGU_BASE + 0x1c)
#define CGU_PLL_MEM_CON2_CTL_REG                  (HOST_CGU_BASE + 0x20)
#define CGU_PLL_MEM_STA_CTL_REG                   (HOST_CGU_BASE + 0x24)
#define CGU_PLL_MEM_SSCG_CTL_REG                  (HOST_CGU_BASE + 0x28)

#define CGU_PLL_MPG0_CON0_CTL_REG                 (HOST_CGU_BASE + 0x2C)
#define CGU_PLL_MPG0_CON1_CTL_REG                 (HOST_CGU_BASE + 0x30)

#define CGU_PLL_MPG0_STAT_CTL_REG                 (HOST_CGU_BASE + 0x34)
/* pllfract_ctrl_change acknowledge (Fractional PLL specific)*/
#define    CGU_PLL_STAT_FRAC_PLLFRACT_ACK_MASK    (0x01 << 5)
#define    CGU_PLL_STAT_FRAC_PLLFRACT_ACK_SHIFT   5
/* pre-divider ratio change acknowledge */
#define    CGU_PLL_STAT_NACK_MASK                 (0x01 << 3)
#define    CGU_PLL_STAT_NACK_SHIFT                3
/* feedback divider ratio change acknowledge */
#define    CGU_PLL_TAT_MACK_MASK                  (0x01 << 2)
#define    CGU_PLL_TAT_MACK_SHIFT                 2
/* post-divider ratio change acknowledge */
#define    CGU_PLL_STAT_PACK_MASK                 (0x01 << 1)
#define    CGU_PLL_STAT_PACK_SHIFT                1
/* lock detector output (active high) */
#define    CGU_PLL_STAT_LOCK_MASK                 (0x01 << 0)
#define    CGU_PLL_STAT_LOCK_SHIFT                0

#define CGU_PLL_MPG0_FRAC1_CTL_REG                (HOST_CGU_BASE + 0x38)
/* to select an external mreq value */
#define    CGU_PLL_FRAC1_CTL_MREQ_EXT_MASK        (0x01 << 4)
#define    CGU_PLL_FRAC1_CTL_MREQ_EXT_SHIFT       4
/* pllfract_ctrl change request */
#define    CGU_PLL_FRAC1_CTL_PLLFRACT_REQ_MASK    (0x01 << 3)
#define    CGU_PLL_FRAC1_CTL_PLLFRACT_REQ_SHIFT   3
#define    CGU_PLL_FRAC1_SEL_EXT_MASK             (0x01 << 2)
#define    CGU_PLL_FRAC1_SEL_EXT_SHIFT            2
#define    CGU_PLL_FRAC1_DITHER_MASK              (0x01 << 1)
#define    CGU_PLL_FRAC1_DITHER_SHIFT             1
#define    CGU_PLL_FRAC1_PD_MASK                  (0x01 << 0)
#define    CGU_PLL_FRAC1_PD_SHIFT                 0

#define CGU_PLL_MPG0_FRAC2_CTL_REG                (HOST_CGU_BASE + 0x3C)
#define    CGU_PLL_FRAC2_PLLFRACT_CTRL_MASK       (0xffffffff)
#define    CGU_PLL_FRAC2_PLLFRACT_CTRL_SHIFT      0

#define CGU_PLL_MPG0_FRAC3_CTL_REG                (HOST_CGU_BASE + 0x40)
/*
* to select an external mdec value
*/
#define    CGU_PLL_FRAC3_MDEC_EXT_MASK            (0x01ffff << 0)
#define    CGU_PLL_FRAC3_MDEC_EXT_SHIFT           0

/* bit fields are the same as MPG0 PLL */
#define CGU_PLL_HD_CON0_CTL_REG                   (HOST_CGU_BASE + 0x44)
#define CGU_PLL_HD_CON1_CTL_REG                   (HOST_CGU_BASE + 0x48)
#define CGU_PLL_HD_STAT_CTL_REG                   (HOST_CGU_BASE + 0x4c)
#define CGU_PLL_HD_FRAC1_CTL_REG                  (HOST_CGU_BASE + 0x50)
#define CGU_PLL_HD_FRAC2_CTL_REG                  (HOST_CGU_BASE + 0x54)
#define CGU_PLL_HD_FRAC3_CTL_REG                  (HOST_CGU_BASE + 0x58)

/* bit fields are the same as MPG0 PLL */
#define CGU_PLL_AUD_CON0_CTL_REG                  (HOST_CGU_BASE + 0x5c)
#define CGU_PLL_AUD_CON1_CTL_REG                  (HOST_CGU_BASE + 0x60)
#define CGU_PLL_AUD_CON2_CTL_REG                  (HOST_CGU_BASE + 0x64)
#define    CGU_PLL_AUD_CON2_DIV_RESET_MASK        0x00000001
#define    CGU_PLL_AUD_CON2_DIV_RESET_SHIFT       0
#define    CGU_PLL_AUD_CON2_DIV_MASK              0x000001FE
#define    CGU_PLL_AUD_CON2_DIV_SHIFT             1
#define    CGU_PLL_AUD_CON2_INVCLK_SEL_MASK       0x00000200
#define    CGU_PLL_AUD_CON2_INVCLK_SEL_SHIFT      9

#define CGU_PLL_AUD_STAT_CTL_REG                  (HOST_CGU_BASE + 0x68)
#define CGU_PLL_AUD_FRAC1_CTL_REG                 (HOST_CGU_BASE + 0x6c)
#define CGU_PLL_AUD_FRAC2_CTL_REG                 (HOST_CGU_BASE + 0x70)
#define CGU_PLL_AUD_FRAC3_CTL_REG                 (HOST_CGU_BASE + 0x74)






#define CGU_PLL_USB_CON0_CTL_REG                  (HOST_CGU_BASE + 0x78)
#define CGU_PLL_USB_CON1_CTL_REG                  (HOST_CGU_BASE + 0x7c)
#define CGU_PLL_USB_CON2_CTL_REG                  (HOST_CGU_BASE + 0x80)
#define CGU_PLL_USB_CON3_CTL_REG                  (HOST_CGU_BASE + 0x84) /* specific */
/* clock divide value */
#define    CGU_PLL_USB_CON3_DIV1_VAL_MASK         (0x0F << 5)
#define    CGU_PLL_USB_CON3_DIV1_VAL_SHIFT        5
#define    CGU_PLL_USB_CON3_DIV0_VAL_MASK         (0x0F << 1)
#define    CGU_PLL_USB_CON3_DIV0_VAL_SHIFT        1
/* clock divider reset active low */
#define    CGU_PLL_USB_CON3_DIV_RESET_N_MASK      (0x01 << 0)
#define    CGU_PLL_USB_CON3_DIV_RESET_N_SHIFT     0

#define CGU_PLL_USB_STAT_CTL_REG                  (HOST_CGU_BASE + 0x88)

#define CGU_PLL_HDMI_CON0_CTL_REG                 (HOST_CGU_BASE + 0x8c)
#define    CGU_PLL_HDMI_CON0_CTL_SEL_SD_VAL_MASK  0x80000000
#define    CGU_PLL_HDMI_CON0_CTL_SEL_SD_VAL_SHIFT 31
#define       CGU_PLL_HDMI_CON0_CTL_SEL_SD_VAL_IP    (1UL<<31)
#define       CGU_PLL_HDMI_CON0_CTL_SEL_SD_VAL_CGU   (0UL<<31)
#define CGU_PLL_HDMI_CON1_CTL_REG                 (HOST_CGU_BASE + 0x90)
#define CGU_PLL_HDMI_CON2_CTL_REG                 (HOST_CGU_BASE + 0x94)
#define CGU_PLL_HDMI_CON3_CTL_REG                 (HOST_CGU_BASE + 0x98)
/*
* HDMI PLL reference clock selection:
* 00: hdpll_clkout
* 01: m0pll_clkout
* 10: hdmi_pll_format_clkin
* 11: hdpll_clkout
*/
#define   CGU_PLL_HDMI_CON3_SEL_REF_MASK          (0x03 << 5)
#define   CGU_PLL_HDMI_CON3_SEL_REF_SHIFT         5
#define   CGU_PLL_HDMI_CON3_SEL_REF_HD            (0x00 << 5)
#define   CGU_PLL_HDMI_CON3_SEL_REF_MPG0          (0x01 << 5)
#define   CGU_PLL_HDMI_CON3_SEL_REF_CLKIN         (0x02 << 5)
#define   CGU_PLL_HDMI_CON3_SEL_REF_HD_CLKOUT     (0x03 << 5)
/* clock divide value */
#define   CGU_PLL_HDMI_CON3_DIV_VAL_MASK          (0x0F << 1)
#define   CGU_PLL_HDMI_CON3_DIV_VAL_SHIFT         1
/* clock divider reset active low */
#define   CGU_PLL_HDMI_CON3_DIV_RESET_N_MASK      (0x01 << 0)
#define   CGU_PLL_HDMI_CON3_DIV_RESET_N_SHIFT     0

#define CGU_PLL_HDMI_STAT_CTL_REG                 (HOST_CGU_BASE + 0x9c)


/* CLOCKS */
/* common mask and shift for sel_src */
#define CGU_CLK_CTL_SEL_SRC_MASK (0x07 << 4)
#define CGU_CLK_CTL_SEL_SRC_SHIFT 4
/* common for most clocks */
#define CGU_CLK_CTL_SEL_MASK (0x03 << 1)
#define CGU_CLK_CTL_SEL_SHIFT 1
#define    CGU_CLK_CTL_SEL_XTAL     (0x00<<1)
#define    CGU_CLK_CTL_SEL_SRC      (0x01<<1)
#define    CGU_CLK_CTL_SEL_NOT_SRC  (0x02<<1)
#define    CGU_CLK_CTL_SEL_BACKUP   (0x03<<1)
#define CGU_CLK_CTL_EN_MASK (0x01 << 0)
#define CGU_CLK_CTL_EN_SHIFT 0
#define    CGU_CLK_CTL_ENABLE  0x00
#define    CGU_CLK_CTL_DISABLE 0x01

#define CGU_CLK_MEM05_CTL_REG                     (HOST_CGU_BASE + 0xb0)
#define CGU_CLK_I2C1_DMA_CTL_REG  (CGU_BASE + 0x20)
#define CGU_CLK_I2C2_DMA_CTL_REG  (CGU_BASE + 0x24)
#define CGU_CLK_I2C3_DMA_CTL_REG  (CGU_BASE + 0x28)
#define CGU_CLK_SPI_FBIN_CTL_REG  (CGU_BASE + 0x38)
#define CGU_CLK_SMARTCARD_1_CTL_REG  (CGU_BASE + 0x14)
#define CGU_CLK_SMARTCARD_2_CTL_REG  (CGU_BASE + 0x18)
/* offset between CGU_CLK_SMARTCARD_x_CTL_REG to CGU_SMCARDx_FRACDIV_REG */
#define    CGU_SMARTCARD_CTL_TO_FRACDIV_OFFSET     0x3EC
/* common for tsp27, smartcard, mpg1 and mpg3 clocks */
#define    CGU_CLK_SEL_PLLCLKIN_MASK  0x00000008

#define    CGU_CLK_SMARTCARD_CTL_SEL_PLL_CLKIN_MASK  0x00000008
#define    CGU_CLK_SMARTCARD_CTL_SEL_PLL_CLKIN_SHIFT 3
#define    CGU_CLK_SMARTCARD_CTL_SEL_PLL_CLKIN_MPG0  (0)
#define    CGU_CLK_SMARTCARD_CTL_SEL_PLL_CLKIN_USB   (1)
#define    CGU_CLK_SMARTCARD_CTL_SEL_CLK_SHIFT       1
#define    CGU_CLK_SMARTCARD_CTL_SEL_CLK_BKP         (3)
#define    CGU_CLK_SMARTCARD_CTL_SEL_CLK_XTAL2       (2)
#define    CGU_CLK_SMARTCARD_CTL_SEL_CLK_DIVOUT      (1)
#define    CGU_CLK_SMARTCARD_CTL_SEL_CLK_XTAL        (0)
#define    CGU_CLK_SMARTCARD_CTL_EN_CLK_SHIFT        0
#define    CGU_CLK_SMARTCARD_CTL_DIS_CLK             (0)
#define    CGU_CLK_SMARTCARD_CTL_EN_CLK              (1)

#define CGU_CLK_TURING_NEWTCLK_CTL_REG  (HOST_CGU_BASE + 0xf8)
#define    CGU_CLK_TURING_NEWTCLK_CTL_SEL_SRC_MASK           0x00000030
#define    CGU_CLK_TURING_NEWTCLK_CTL_SEL_SRC_SHIFT          4
#define    CGU_CLK_TURING_NEWTCLK_CTL_SEL_SRC_RFMOD_1_5      (0UL<<4)
#define    CGU_CLK_TURING_NEWTCLK_CTL_SEL_SRC_RFMOD_2        (1UL<<4)
#define    CGU_CLK_TURING_NEWTCLK_CTL_SEL_SRC_50MHZ          (2UL<<4)
#define    CGU_CLK_TURING_NEWTCLK_CTL_SEL_SRC_1MHZ           (3UL<<4)


#define CGU_CLK_DMAC_AHB_CTL_REG     (HM_CGU_BASE + 0x28)



#define CGU_CLK_CORTEXA9_PER_CTL_REG  (HM_CGU_BASE + 0x1c)

#define CGU_CLK_CORTEXA9_CTL_REG  (HM_CGU_BASE + 0x18)
#define CGU_CLK_CORTEXA9_AXI_CTL_REG  (HM_CGU_BASE + 0x20)
#define CGU_CLK_GCS_AHBCLK_GATED_CTL_REG  (HOST_CGU_BASE + 0xbc)



#define CGU_CLK_USBOTG2_CLK30OUT_CTL_REG  (HOST_CGU_BASE + 0xd8)
#define CGU_CLK_USBOTG2_AHBCLK_CTL_REG  (HOST_CGU_BASE + 0xdc)
#define CGU_CLK_SPI_GATED_CTL_REG  (CGU_BASE + 0x30)
#define CGU_CLK_AOD_XCLK_25_CTL_REG  (CGU_BASE + 0x48)
#define CGU_CLK_AOD_XCLK_50_CTL_REG  (CGU_BASE + 0x4C)
#define CGU_CLK_CEC_CTL_REG  (CGU_BASE + 0x50)
#define CGU_CLK_PT2_CTL_REG  (CGU_BASE + 0x58)
#define CGU_CLK_RTC_CTL_REG  (CGU_BASE + 0x5c)
#define CGU_CLK_PWM2_CTL_REG  (CGU_BASE + 0x68)
#define CGU_CLK_PWM3_CTL_REG  (CGU_BASE + 0x6C)


#define CGU_CLK_TSP_NSK_CTL_REG  (HOST_CGU_BASE + 0xfc)
#define CGU_CLK_HS0CLK_IN_CTL_REG  (CGU_BASE + 0xa4)
#define CGU_CLK_HS1CLK_IN_CTL_REG  (CGU_BASE + 0xa8)
#define CGU_CLK_HS2CLK_IN_CTL_REG  (CGU_BASE + 0xac)
#define CGU_CLK_HS3CLK_IN_CTL_REG  (CGU_BASE + 0xb0)


#define CGU_CLK_HS6CLK_IN_CTL_REG  (CGU_BASE + 0xb4)

#define CGU_CLK_TSP_HS3CLK_CTL_REG  (CGU_BASE + 0xbc)


#define CGU_CLK_TSP_HS6CLK_CTL_REG  (CGU_BASE + 0xc0)

#define CGU_CLK_HDMI_IM_CTL_REG  (HOST_CGU_BASE + 0x164)
#define CGU_CLK_HDMI_TMDS_CTL_REG  (HOST_CGU_BASE + 0x160)
#define CGU_CLK_AUDIO_DSP_CTL_REG  (HOST_CGU_BASE + 0x158)
#define CGU_CLK_HDMI_VP_CTL_REG  (HOST_CGU_BASE + 0x15c)










#define CGU_CLK_SPDO_CTL_REG  (HOST_CGU_BASE + 0x168)




#define   CGU_CLK_AOBTSC_OSCLK_SRC_SEL_MASK                0x00000070
#define   CGU_CLK_AOBTSC_OSCLK_SRC_SEL_SHIFT               4
#define      CGU_CLK_AOBTSC_OSCLK_SRC_SEL_AUDPLL_INTDIV    (0UL<<4)
#define      CGU_CLK_AOBTSC_OSCLK_SRC_SEL_MPG0PLL_FRACDIV  (1UL<<4)
#define      CGU_CLK_AOBTSC_OSCLK_SRC_SEL_HDPLL_FRACDIV    (2UL<<4)
#define      CGU_CLK_AOBTSC_OSCLK_SRC_SEL_PLL1PLL_FRACDIV  (3UL<<4)


#define   CGU_CLK_AOBTSC_OSCLK_SEL_SRC_MASK                0x00000070
#define   CGU_CLK_AOBTSC_OSCLK_SEL_SRC_SHIFT               4
#define      CGU_CLK_AOBTSC_OSCLK_SEL_SRC_AUDPLL_INTDIV    (0UL<<4)
#define      CGU_CLK_AOBTSC_OSCLK_SEL_SRC_MPG0PLL_FRACDIV  (1UL<<4)
#define      CGU_CLK_AOBTSC_OSCLK_SEL_SRC_HDPLL_FRACDIV    (2UL<<4)
#define      CGU_CLK_AOBTSC_OSCLK_SEL_SRC_PLL1PLL_FRACDIV  (3UL<<4)

#define CGU_CLK_AO4_OSCLK_CTL_REG  (HOST_CGU_BASE + 0x16c)
#define CGU_CLK_AO4_SCLK_OUT_CTL_REG  (HOST_CGU_BASE + 0x170)
#define CGU_CLK_AO_OSCLK_CTL_REG  (HOST_CGU_BASE + 0x174)
#define CGU_CLK_AO_SCLK_OUT_CTL_REG  (HOST_CGU_BASE + 0x178)
#define CGU_CLK_CLKIN_DSP_CTL_REG  (HOST_CGU_BASE + 0x17c)
#define      CGU_CLK_SEL_SRC_AUDPLL_DIV0_CLK_OUT    (0UL<<4)
#define      CGU_CLK_SEL_SRC_AUDPLL_DIV0_CLK_OUT_2  (1UL<<4)
#define      CGU_CLK_SEL_SRC_AUDPLL_DIV0_CLK_OUT_16 (2UL<<4)
#define      CGU_CLK_SEL_SRC_AUDPLL_DIV0_CLK_OUT_32 (3UL<<4)

#define CGU_CLK_CLKIN_NS_CTL_REG  (HOST_CGU_BASE + 0x180)
#define      CGU_CLK_CLKIN_NS_SEL_SRC_AUDPLL_DIV0_CLK_OUT    (0UL<<4)
#define      CGU_CLK_CLKIN_NS_SEL_SRC_AUDPLL_DIV0_CLK_OUT_16 (1UL<<4)
#define CGU_CLK_GMAC0_AHBCLK_CTL_REG  (CGU_BASE + 0xc4)
#define CGU_CLK_GMAC0_PHY_TX_CTL_REG  (CGU_BASE + 0xc8)
#define CGU_CLK_GMAC0_PHY_RX_CTL_REG  (CGU_BASE + 0xcc)


#define CGU_CLK_GMAC1_AHBCLK_CTL_REG  (CGU_BASE + 0xd4)
#define CGU_CLK_GMAC1_PHY_TX_CTL_REG  (CGU_BASE + 0xd8)
#define CGU_CLK_GMAC1_PHY_RX_CTL_REG  (CGU_BASE + 0xdc)

#define CGU_CLK_GMAC1_TXCLK_OUT_CTL_REG  (CGU_BASE + 0xe4)
#define CGU_CLK_GMAC0_PTP_REF_CTL_REG  (CGU_BASE + 0xd0)
#define CGU_CLK_GMAC1_PTP_REF_CTL_REG  (CGU_BASE + 0xe8)
#define CGU_CLK_DMAC_ACP_CTL_REG  (HM_CGU_BASE + 0x24)
#define CGU_CLK_GCS_ECCCLK_CTL_REG  (HOST_CGU_BASE + 0xc0)

#define CGU_CLK_USBOTG1_CLK30OUT_CTL_REG  (HOST_CGU_BASE + 0xd0)
#define CGU_CLK_CORTEXM3_FCLK_CTL_REG  (CGU_BASE + 0x1c)

#define CGU_CLK_PT1_CTL_REG  (CGU_BASE + 0x54)
#define CGU_CLK_IR_CTL_REG  (CGU_BASE + 0x60)
#define CGU_CLK_XCLK_25_CTL_REG  (HOST_CGU_BASE + 0xe4)
#define CGU_CLK_XCLK_50_CTL_REG  (HOST_CGU_BASE + 0xe8)

#define CGU_CLK_STDBY_DTL_CTL_REG  (CGU_BASE + 0x10)
#define CGU_CLK_I2C_DEBUG_CTL_REG  (HOST_CGU_BASE + 0xe0)
#define CGU_CLK_M_DTL_CTL_REG  (HOST_CGU_BASE + 0xa0)
#define CGU_CLK_M_DCS_CTL_REG  (HOST_CGU_BASE + 0xa4)
#define CGU_CLK_TM_DTL_CTL_REG  (HOST_CGU_BASE + 0xa8)
#define CGU_CLK_TM_DCS_CTL_REG  (HOST_CGU_BASE + 0xac)
#define CGU_CLK_STDBY_DCS_CTL_REG  (CGU_BASE + 0x0c)
#define CGU_CLK_3D_GRAPHICS_CTL_REG  (HOST_CGU_BASE + 0xb4)
#define CGU_CLK_SPI_CTL_REG  (CGU_BASE + 0x2c)
#define CGU_CLK_SPI_AHB_CTL_REG  (CGU_BASE + 0x34)

#define CGU_CLK_UART1_CTL_REG  (CGU_BASE + 0x3c)
#define CGU_CLK_UART2_CTL_REG  (CGU_BASE + 0x40)
#define CGU_CLK_UART3_CTL_REG  (CGU_BASE + 0x44)
#define CGU_CLK_TURING_SSPCLK_CTL_REG  (HOST_CGU_BASE + 0xf0)
#define CGU_CLK_TURING_TURINGCLK_CTL_REG  (HOST_CGU_BASE + 0xf4)
#define    CGU_CLK_TURING_CTL_SEL_SRC_MASK           0x00000030
#define    CGU_CLK_TURING_CTL_SEL_SRC_SHIFT          4

#define CGU_CLK_DRAW2D_CTL_REG  (HOST_CGU_BASE + 0xec)
#define CGU_CLK_PWM1_CTL_REG  (CGU_BASE + 0x64)
#define CGU_CLK_GCS_AHBCLK_CTL_REG  (HOST_CGU_BASE + 0xb8)

#define CGU_CLK_USBOTG1_AHBCLK_CTL_REG  (HOST_CGU_BASE + 0xd4)
#define CGU_CLK_TSP_TSX_CTL_REG  (CGU_BASE + 0x70)
#define CGU_CLK_TSP_MCX_CTL_REG  (CGU_BASE + 0x74)
#define CGU_CLK_TSP_CTL_REG  (CGU_BASE + 0x78)
#define CGU_CLK_TSP_TSR_CTL_REG  (CGU_BASE + 0x7c)
#define CGU_CLK_TSP_SLOWCLK_CTL_REG  (CGU_BASE + 0x80)
#define CGU_CLK_TSP_FASTCLK_CTL_REG  (CGU_BASE + 0x84)
#define CGU_CLK_TSP_27_CTL_REG  (CGU_BASE + 0x88)
/* offset between CGU_CLK_TSP_27_CTL_REG to CGU_TSP27_FRACDIV_REG(0x608) */
#define    CGU_TSP27_CTL_TO_FRACDIV_OFFSET        0xC0
#define    CGU_CLK_TSP_27_CTL_SEL_PLL_CLKIN_MASK  0x00000008
#define    CGU_CLK_TSP_27_CTL_SEL_PLL_CLKIN_SHIFT 3
#define    CGU_CLK_TSP_27_CTL_SEL_PLL_CLKIN_MPG0  (1UL<<3)
#define    CGU_CLK_TSP_27_CTL_SEL_PLL_CLKIN_PLL1  (0UL<<3)

#define CGU_CLK_TSP_ASX_CTL_REG  (CGU_BASE + 0x8c)
#define CGU_CLK_TSP_CAM_CTL_REG  (CGU_BASE + 0x90)
#define CGU_CLK_MPG0_CTL_REG  (CGU_BASE + 0x94)
#define CGU_CLK_MPG1_CTL_REG  (CGU_BASE + 0x98)
#define    CGU_CLK_MPG_CTL_SEL_PLL_CLKIN_MASK  0x00000008
#define    CGU_CLK_MPG_CTL_SEL_PLL_CLKIN_SHIFT 3
#define    CGU_CLK_MPG_CTL_SEL_PLL_CLKIN_MPG0  (1UL<<3)
#define    CGU_CLK_MPG_CTL_SEL_PLL_CLKIN_OTHER (0UL<<3)

#define CGU_CLK_MPG2_CTL_REG  (CGU_BASE + 0x9c)
#define    CGU_CLK_MPG_CTL_SEL_CLK_FRACDIV       (1UL<<1)
#define    CGU_CLK_MPG_CTL_SET_CLK_XTAL           (0UL<<1)
#define CGU_CLK_MVD_ARM926_CTL_REG  (HM_CGU_BASE + 0x2c)

#define CGU_CLK_MVD_MALONE_CTL_REG  (HM_CGU_BASE + 0x30)
#define CGU_CLK_MPG3_CTL_REG  (CGU_BASE + 0xa0)

#define CGU_CLK_VSD_MBVP_CTL_REG  (HOST_CGU_BASE + 0x100)
#define CGU_CLK_VSD_CPSD_L1_CTL_REG  (HOST_CGU_BASE + 0x104)
#define CGU_CLK_VSD_CPSD_L2_CTL_REG  (HOST_CGU_BASE + 0x108)
#define CGU_CLK_VSD_CPSD_L3_CTL_REG  (HOST_CGU_BASE + 0x10c)
#define CGU_CLK_VSD_CPSD_PIX_CTL_REG  (HOST_CGU_BASE + 0x114)
#define CGU_CLK_VSD_CPSD_OUT_CTL_REG  (HOST_CGU_BASE + 0x118)
#define CGU_CLK_VSD_CPHD_L1_CTL_REG  (HOST_CGU_BASE + 0x11c)
#define CGU_CLK_VSD_CPHD_L2_CTL_REG  (HOST_CGU_BASE + 0x120)
#define CGU_CLK_VSD_CPHD_L3_CTL_REG  (HOST_CGU_BASE + 0x124)
#define CGU_CLK_VSD_CPHD_L4_CTL_REG  (HOST_CGU_BASE + 0x128)
#define CGU_CLK_VSD_CPHD_PIX_CTL_REG  (HOST_CGU_BASE + 0x12c)
#define CGU_CLK_VSD_CPHD_OUT_CTL_REG  (HOST_CGU_BASE + 0x130)
#define CGU_CLK_VSD_CPHD_OUT2_CTL_REG  (HOST_CGU_BASE + 0x134)
#define CGU_CLK_HD_DENC_CTL_REG  (HOST_CGU_BASE + 0x138)
#define CGU_CLK_SD_DENC_CTL_REG  (HOST_CGU_BASE + 0x13c)
#define CGU_CLK_VDAC_A_CTL_REG  (HOST_CGU_BASE + 0x140)
#define CGU_CLK_VDAC_B_CTL_REG  (HOST_CGU_BASE + 0x144)
#define CGU_CLK_VDAC_C_CTL_REG  (HOST_CGU_BASE + 0x148)
#define CGU_CLK_VDAC_D_CTL_REG  (HOST_CGU_BASE + 0x14c)


#define CGU_CLK_VSD_CPSD_L4_CTL_REG  (HOST_CGU_BASE + 0x110)
//unknown regs, not in apollo or kronos board file
//#define CGU_HDMI_FPLL_CON1_REG  (CGU_BASE + 0x5f8)
//#define CGU_HDMI_FPLL_CON2_REG  (CGU_BASE + 0x5fc)

#define CGU_FRACDIV_BASE_OFFSET  0x600
/* valid 1 ~ 2 */
#define CGU_SMCARD_FRACDIV_INDEX(x) (x-1)
#define CGU_TSP27_FRACDIV_INDEX    2
/* valid 0 ~ 3 */
#define CGU_MPG_FRACDIV_INDEX(x) (3+x)
/* valid 3~ 7*/
#define CGU_TSP_HS_FRACDIV_INDEX(x)  (4+x)

#define CGU_SMCARD1_FRACDIV_REG           (CGU_BASE + 0x124)
#define CGU_SMCARD2_FRACDIV_REG           (CGU_BASE + 0x128)
#define CGU_SMCARD_FRACDIV_REG_NUM_MASK   (0xFFFF0000)
#define CGU_SMCARD_FRACDIV_REG_DENUM_MASK (0x0000FFFF)
#define CGU_TSP27FRACDIV_REG  (CGU_BASE + 0x12c)
#define CGU_MPG0_FRACDIV_REG  (CGU_BASE + 0x130)
#define CGU_MPG1_FRACDIV_REG  (CGU_BASE + 0x134)
#define CGU_MPG2_FRACDIV_REG  (CGU_BASE + 0x138)
#define CGU_MPG3_FRACDIV_REG  (CGU_BASE + 0x13c)
#define CGU_HS3_FRACDIV_REG  (CGU_BASE + 0x144)


#define CGU_HS6_FRACDIV_REG  (CGU_BASE + 0x148)

/* common for all fractional divider clocks */
#define    CGU_FRACDIV_DEN_MASK   0x0000FFFF
#define    CGU_FRACDIV_DEN_SHIFT  0
#define    CGU_FRACDIV_NUM_MASK   0xFFFF0000
#define    CGU_FRACDIV_NUM_SHIFT  16
#define CGU_VCGEN_G1SEL_REG  (HOST_CGU_BASE + 0x190)
#define CGU_VCGEN_G2SEL_REG  (HOST_CGU_BASE + 0x194)
#define CGU_VCGEN_G3SEL_REG  (HOST_CGU_BASE + 0x198)
#define CGU_VCGEN_G4SEL_REG  (HOST_CGU_BASE+ 0x19c)
#define CGU_VCGEN_G5SEL_REG  (HOST_CGU_BASE + 0x1a0)
/* common for G1SEL ~ G5SEL */
#define    CGU_VCGEN_SEL_MASK           0x0000000F
#define    CGU_VCGEN_SEL_SHIFT          0
#define       CGU_VCGEN_SEL_MPG0        0x00
#define       CGU_VCGEN_SEL_MPG0_2      0x01
#define       CGU_VCGEN_SEL_MPG0_4      0x02
#define       CGU_VCGEN_SEL_MPG0_8      0x03
#define       CGU_VCGEN_SEL_MPG0_11     0x04
#define       CGU_VCGEN_SEL_MPG0_22     0x05
#define       CGU_VCGEN_SEL_MPG0_44     0x06
#define       CGU_VCGEN_SEL_PLL2_4      0x07
#define       CGU_VCGEN_SEL_HD          0x08
#define       CGU_VCGEN_SEL_HD_2        0x09
#define       CGU_VCGEN_SEL_HD_4        0x0A
#define       CGU_VCGEN_SEL_HD_8        0x0B
#define       CGU_VCGEN_SEL_HD_11       0x0C
#define       CGU_VCGEN_SEL_HD_22       0x0D
#define       CGU_VCGEN_SEL_HD_44       0x0E
#define       CGU_VCGEN_SEL_PLL2_3      0x0F
#define    CGU_VCGEN_SEL_SRC_MASK       0x00000008
#define    CGU_VCGEN_SEL_SRC_SHIFT      3

#define CGU_VCGEN_G6SEL_REG  (HOST_CGU_BASE + 0x1a4)
#define    CGU_VCGEN_G6SEL_MASK           0x00000008
#define    CGU_VCGEN_G6SEL_SHIFT          3
#define       CGU_VCGEN_G6SEL_MPG0_22     (0UL<<3)
#define       CGU_VCGEN_G6SEL_HD_22       (1UL<<3)

#define CGU_VDAC0_SEL_REG  (HOST_CGU_BASE + 0x1a8)
#define CGU_VDAC1_SEL_REG  (HOST_CGU_BASE + 0x1ac)
#define CGU_VDAC2_SEL_REG  (HOST_CGU_BASE + 0x1b0)
#define CGU_VDAC3_SEL_REG  (HOST_CGU_BASE + 0x1b4)


/* offset between VDAC_X_CTL_REG to VDAC_X_SEL_REG */
#define    CGU_VDAC_CTL_TO_SEL_OFFSET     0x98
/* commond for all VDAC */
#define    CGU_VDAC_SEL_MASK           0x00000007
#define    CGU_VDAC_SEL_SHIFT          0
#define       CGU_VDAC_SEL_MPG0_2      0x00
#define       CGU_VDAC_SEL_MPG0_4      0x01
#define       CGU_VDAC_SEL_MPG0_8      0x02
#define       CGU_VDAC_SEL_HD_2        0x04
#define       CGU_VDAC_SEL_HD_4        0x05
#define       CGU_VDAC_SEL_HD_8        0x06
#define    CGU_VDAC_SEL_SRC_MASK       0x00000004
#define    CGU_VDAC_SEL_SRC_SHIFT      2
#define       CGU_SEL_SRC_MGP0_OR_HD_MPG0    0
#define       CGU_SEL_SRC_MGP0_OR_HD_HD      1

#define CGU_ACLK_MPG0PLL_FRACDIV_REG  (HOST_CGU_BASE + 0x1b8)
#define CGU_ACLK_HDPLL_FRACDIV_REG  (HOST_CGU_BASE + 0x1bc)

#define CGU_ACLK_AUDPLL_INTDIV_REG  (HOST_CGU_BASE + 0x1c0)

#define CGU_ACLK_SPDOCLK_REG  (HOST_CGU_BASE + 0x1c4)

#define   CGU_ACLK_INT_DIVIDER_MASK            0x000000FF
#define   CGU_ACLK_INT_DIVIDER_SHIFT           0
#define   CGU_ACLK_MUX_SEL_MASK                0x00000300
#define   CGU_ACLK_MUX_SEL_SHIFT               8
#define      CGU_ACLK_MUX_SEL_AUDPLL_INTDIV    (0UL<<8)
#define      CGU_ACLK_MUX_SEL_MPG0PLL_FRACDIV  (1UL<<8)
#define      CGU_ACLK_MUX_SEL_HDPLL_FRACDIV    (2UL<<8)
#define      CGU_ACLK_MUX_SEL_PLL1PLL_FRACDIV  (3UL<<8)

#define CGU_ACLK_AIOSCLK_REG  (HOST_CGU_BASE + 0x1c8)
#define    CGU_ACLK_DIVIDER_MASK           0x000000FF
#define    CGU_ACLK_DIDIDER_SHIFT          0
#define CGU_ACLK_AO4OSCLK_REG  (HOST_CGU_BASE + 0x1cc)


#define CGU_CLK_CS_ATCLK_CTL_REG  (HOST_CGU_BASE + 0x184)
#define CGU_CLK_CS_PCLKDBG_CTL_REG  (HOST_CGU_BASE + 0x188)

#define CGU_DFT_FREQ_CTL_REG  (CGU_BASE + 0xc00)
/*
* Result of a frequency count operation
*/
#define    CGU_DFT_FREQ_CTL_DFT_CTR_COUNT_RW (0x07fff << 16)
#define    CGU_DFT_FREQ_CTL_DFT_CTR_COUNT_SHIFT 16
/*
* Selects 16 clocks for output to the 16 dft_clk pins,
* dft_clk[0] is used as input to the frequency counter
*/
#define    CGU_DFT_FREQ_CTL_DFT_CLK_SEL_RW (0x07 << 8)
#define    CGU_DFT_FREQ_CTL_DFT_CLK_SEL_SHIFT 8
/*
* Rotate control for the 16 dft_clk signals, this allows any of
* the selected output clocks to be rotated onto dft_clk[0] for
* the frequency counter to use
*/
#define    CGU_DFT_FREQ_CTL_DFT_CLK_ROTATE_RW (0x07 << 4)
#define    CGU_DFT_FREQ_CTL_DFT_CLK_ROTATE_SHIFT 4
/*
* Cleared when start bit set, stays low for 10us during fre
* quency counter operation then returns high
*/
#define    CGU_DFT_FREQ_CTL_DFT_CTR_DONE_RW (0x01 << 1)
#define    CGU_DFT_FREQ_CTL_DFT_CTR_DONE_SHIFT 1
/*
* 1 - Start frequency counter, self-clearing bit
*/
#define    CGU_DFT_FREQ_CTL_DFT_CTR_START_RW (0x01 << 0)
#define    CGU_DFT_FREQ_CTL_DFT_CTR_START_SHIFT 0
#define CGU_DFT_CLK_PD_CTL_REG  (CGU_BASE + 0xc04)
/*
* dft_clk_pd[n] = 0 - DFT Clock \xd4 n\xd5 is oprational
* dft_clk_pd[n] = 1 - DFT Clock \xd4 n\xd5 in power down mode
*/
#define    CGU_DFT_CLK_PD_CTL_DFT_CLK_PD_RW (0x0ffff << 0)
#define    CGU_DFT_CLK_PD_CTL_DFT_CLK_PD_SHIFT 0

#define CGU_MISC_CTL_REG  (HOST_CGU_BASE + 0xc08)
/*
* 0 - disable CGU dividers 1G4 PLL programming
* 1 - enable CGU dividers 1G4 PLL programming
*/
#define    CGU_MISC_CTL_PL1G4_PROG_EN_RW (0x01 << 0)
#define    CGU_MISC_CTL_PL1G4_PROG_EN_SHIFT 0

//cannot find regs in apollo or kronos board files
//#define CGU_INTERRUPT_STATUS_REG  (CGU_BASE + 0xfe0)
//#define CGU_INTERRUPT_ENABLE_REG  (CGU_BASE + 0xfe4)
//#define CGU_INTERRUPT_CLEAR_REG   (CGU_BASE + 0xfe8)
//#define CGU_INTERRUPT_SET_REG     (CGU_BASE + 0xfec)
/* the mask and shift are common for all interrup registers */
/* u is 1~10 */
#define    CGU_INTERRUPT_EXT_CLK_IN_PRESENT_MASK(u)    (0x01 << (u+18))
#define    CGU_INTERRUPT_EXT_CLK_IN_PRESENT_SHIFT(u)   (u+18)
#define    CGU_INTERRUPT_EXT_CLK_IN_MASK(u)            (0x01 << (u))
#define    CGU_INTERRUPT_EXT_CLK_IN_SHIFT(u)           u

//cannot find regs in apollo or kronos board files
//#define CGU_MODULE_ID_REG  (CGU_BASE + 0xffc)
/*
* 16-bit Module ID
*/
#define CGU_MODULE_ID_MODULE_ID_NUMBER_RW (0x07fff << 16)
#define CGU_MODULE_ID_MODULE_ID_NUMBER_SHIFT 16
/*
* 4-bit major revision
*/
#define CGU_MODULE_ID_MAJOR_REV_RW (0x07 << 12)
#define CGU_MODULE_ID_MAJOR_REV_SHIFT 12
/*
* 4-bit minor revision
*/
#define CGU_MODULE_ID_MINOR_REV_RW (0x07 << 8)
#define CGU_MODULE_ID_MINOR_REV_SHIFT 8
/*
* 8-bit mmio size
*/
#define CGU_MODULE_ID_MMIO_SIZE_RW (0x0ff << 0)
#define CGU_MODULE_ID_MMIO_SIZE_SHIFT 0

#endif // PHMODIPCGU_H












