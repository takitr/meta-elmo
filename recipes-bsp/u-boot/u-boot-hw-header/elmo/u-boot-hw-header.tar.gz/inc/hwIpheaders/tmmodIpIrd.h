/******************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                    */
/*                        SOFTWARE FILE/MODULE HEADER                         */
/*                    Copyright Conexant Systems Inc. 2006 ~ 2007             */
/*                                 Austin, TX                                 */
/*                            All Rights Reserved                             */
/******************************************************************************/
/*
 * Filename:        tmmodIpIrd.h
 *
 *
 * Description:     Public header file defining hardware-specific values (such
 *                  as register addresses, bit definitions, etc.) for the IRD
 *                  module.
 *
 *
 * Author:          Rajani Tirumalasetty, Arun Kumar Gogineni & Billy Jackman
 *
 ******************************************************************************/
/* $Id: tmmodIpIrd.h 145156 2010-02-08 13:08:25Z paruphs $
 ******************************************************************************/

#ifndef _TMMODIPIRD_H_
#define _TMMODIPIRD_H_


#define IRD_BANK_SIZE   0x00001000

/****************************/
/* IRD Register Definitions */
/****************************/

/* Macros allowing access to registers in different IRD instances */
/* Infrared Remote Control Register */
#define IRD_CONTROL_REG                                      (IRD_BASE + 0x00)
#define IRD_CONTROL_REG_ADDR(iBank)          (IRD_CONTROL_REG        + (iBank)*IRD_BANK_SIZE)
/* For WindowCtrl */ 
#define     IRD_CONTROL_WINDOW_CTRL_MASK                         0x00000003
#define     IRD_CONTROL_WINDOW_CTRL_SHIFT                               0
#define        IRD_CONTROL_WINDOW_3_3                             (0UL<<0)
#define        IRD_CONTROL_WINDOW_4_3                             (1UL<<0)
#define        IRD_CONTROL_WINDOW_3_4                             (2UL<<0)
#define        IRD_CONTROL_WINDOW_4_4                             (3UL<<0)
/* For EdgeCtrl */
#define     IRD_CONTROL_EDGE_CTRL_MASK                           0x0000000C
#define     IRD_CONTROL_EDGE_CTRL_SHIFT                                 2
#define        IRD_CONTROL_EDGE_DIS                               (0UL<<2)
#define        IRD_CONTROL_EDGE_FALL                              (1UL<<2)
#define        IRD_CONTROL_EDGE_RISE                              (2UL<<2)
#define        IRD_CONTROL_EDGE_EITHER                            (3UL<<2)
#define     IRD_CONTROL_ENBL_DEMOD_MASK                          0x00000010
#define     IRD_CONTROL_ENBL_DEMOD_SHIFT                                4
#define        IRD_CONTROL_ENBL_DEMOD_DIS                         (0UL<<4)
#define        IRD_CONTROL_ENBL_DEMOD_ENA                         (1UL<<4)
#define     IRD_CONTROL_ENBL_MOD_MASK                            0x00000020
#define     IRD_CONTROL_ENBL_MOD_SHIFT                                  5
#define        IRD_CONTROL_ENBL_MOD_DIS                           (0UL<<5)
#define        IRD_CONTROL_ENBL_MOD_ENA                           (1UL<<5)
#define     IRD_CONTROL_ENBL_RXFIFO_MASK                         0x00000040
#define     IRD_CONTROL_ENBL_RXFIFO_SHIFT                               6
#define        IRD_CONTROL_ENBL_RXFIFO_DIS                        (0UL<<6)
#define        IRD_CONTROL_ENBL_RXFIFO_ENA                        (1UL<<6)
#define     IRD_CONTROL_ENBL_TXFIFO_MASK                         0x00000080
#define     IRD_CONTROL_ENBL_TXFIFO_SHIFT                               7
#define        IRD_CONTROL_ENBL_TXFIFO_DIS                        (0UL<<7)
#define        IRD_CONTROL_ENBL_TXFIFO_ENA                        (1UL<<7)
#define     IRD_CONTROL_ENBL_RX_MASK                             0x00000100
#define     IRD_CONTROL_ENBL_RX_SHIFT                                   8
#define        IRD_CONTROL_ENBL_RX_DIS                            (0UL<<8)
#define        IRD_CONTROL_ENBL_RX_ENA                            (1UL<<8)
#define     IRD_CONTROL_ENBL_TX_MASK                             0x00000200
#define     IRD_CONTROL_ENBL_TX_SHIFT                                   9
#define        IRD_CONTROL_ENBL_TX_DIS                            (0UL<<9)
#define        IRD_CONTROL_ENBL_TX_ENA                            (1UL<<9)
#define     IRD_CONTROL_RXINT_CTRL_MASK                          0x00000400
#define     IRD_CONTROL_RXINT_CTRL_SHIFT                               10
#define        IRD_CONTROL_RXINT_HALF                             (0UL<<10)
#define        IRD_CONTROL_RXINT_NONEMPTY                         (1UL<<10)
/* For RxIntCtrl */
#define IRD_RXINT_HALF_FULL 0
#define IRD_RXINT_NOT_EMPTY 1
#define     IRD_CONTROL_TXINT_CTRL_MASK                          0x00000800
#define     IRD_CONTROL_TXINT_CTRL_SHIFT                               11
#define        IRD_CONTROL_TXINT_HALFLESS                         (0UL<<11)
#define        IRD_CONTROL_TXINT_IDLE                             (1UL<<11)
/* For TxIntCtrl */
#define IRD_TXINT_HALF_FULL 0
#define IRD_TXINT_NOT_BUSY  1
#define     IRD_CONTROL_CARRIER_POLARITY_MASK                    0x00001000
#define     IRD_CONTROL_CARRIER_POLARITY_SHIFT                         12
#define        IRD_CONTROL_CARRIER_1MARK_0SPACE                   (0UL<<12)
#define        IRD_CONTROL_CARRIER_1SPACE_0MARK                   (1UL<<12)
#define     IRD_CONTROL_LOOPBACK_MASK                            0x00002000
#define     IRD_CONTROL_LOOPBACK_SHIFT                                 13
#define        IRD_CONTROL_LOOPBACK_DIS                           (0UL<<13)
#define        IRD_CONTROL_LOOPBACK_ENA                           (1UL<<13)
#define     IRD_CONTROL_OVERFLOW_COUNT_DISABLE_MASK              0x00004000
#define     IRD_CONTROL_OVERFLOW_COUNT_DISABLE_SHIFT                   14
#define        IRD_CONTROL_OVERFLOW_COUNT_ENABLE_PUSH             (0UL<<14)
#define        IRD_CONTROL_OVERFLOW_COUNT_DISABLE_PUSH            (1UL<<14)
#define     IRD_CONTROL_OUTPUT_INVERT_ENBL_MASK                  0x00008000
#define     IRD_CONTROL_OUTPUT_INVERT_ENBL_SHIFT                       15
#define        IRD_CONTROL_OUTPUT_INVERT_ENBL_DIS                 (0UL<<15)
#define        IRD_CONTROL_OUTPUT_INVERT_ENBL_ENA                 (1UL<<15)

/* Infrared Remote Transmit Clock Divider Register */
#define IRD_TX_CLK_CONTROL_REG                               (IRD_BASE + 0x04)
#define IRD_TX_CLK_CONTROL_REG_ADDR(iBank)   (IRD_TX_CLK_CONTROL_REG + (iBank)*IRD_BANK_SIZE)
#define    IRD_TX_CLK_DIV_MASK                                   0x0000FFFF
#define    IRD_TX_CLK_DIV_SHIFT                                         0

/* Infrared Remote Receive Clock Divider Register */
#define IRD_RX_CLK_CONTROL_REG                               (IRD_BASE + 0x08)
#define IRD_RX_CLK_CONTROL_REG_ADDR(iBank)   (IRD_RX_CLK_CONTROL_REG + (iBank)*IRD_BANK_SIZE)
#define    IRD_RX_CLK_DIV_MASK                                   0x0000FFFF
#define    IRD_RX_CLK_DIV_SHIFT                                         0

/* Infrared Remote Transmit Carrier Duty Cycle Register */
#define IRD_TX_CARRIER_REG                                   (IRD_BASE + 0x0C)
#define IRD_TX_CARRIER_REG_ADDR(iBank)       (IRD_TX_CARRIER_REG     + (iBank)*IRD_BANK_SIZE)
#define    IRD_TX_CARRIER_DUTY_CYCLE_MASK                        0x0000000F
#define    IRD_TX_CARRIER_DUTY_CYCLE_SHIFT                              0

/* Infrared Remote Status Register */
#define IRD_STATUS_REG                                       (IRD_BASE + 0x10)
#define IRD_STATUS_REG_ADDR(iBank)           (IRD_STATUS_REG         + (iBank)*IRD_BANK_SIZE)
#define     IRD_STATUS_RXTIMEOUT_MASK                            0x00000001
#define     IRD_STATUS_RXTIMEOUT_SHIFT                                  0
#define        IRD_STATUS_RXTIMEOUT_NO                             (0UL<<0)
#define        IRD_STATUS_RXTIMEOUT_YES                            (1UL<<0)
#define     IRD_STATUS_RXOVERRUN_MASK                            0x00000002
#define     IRD_STATUS_RXOVERRUN_SHIFT                                  1
#define        IRD_STATUS_RXOVERRUN_NO                             (0UL<<1)
#define        IRD_STATUS_RXOVERRUN_YES                            (1UL<<1)
#define     IRD_STATUS_RXBUSY_MASK                               0x00000004
#define     IRD_STATUS_RXBUSY_SHIFT                                     2
#define        IRD_STATUS_RXBUSY_IDLE                              (0UL<<2)
#define        IRD_STATUS_RXBUSY_BUSY                              (1UL<<2)
#define     IRD_STATUS_TRBUSY_MASK                               0x00000008
#define     IRD_STATUS_TRBUSY_SHIFT                                     3
#define        IRD_STATUS_TRBUSY_IDLE                              (0UL<<3)
#define        IRD_STATUS_TRBUSY_BUSY                              (1UL<<3)
#define     IRD_STATUS_RXFIFO_REQ_MASK                           0x00000010
#define     IRD_STATUS_RXFIFO_REQ_SHIFT                                 4
#define        IRD_STATUS_RXFIFO_REQ_NO                            (0UL<<4)
#define        IRD_STATUS_RXFIFO_REQ_YES                           (1UL<<4)
#define     IRD_STATUS_TXFIFO_REQ_MASK                           0x00000020
#define     IRD_STATUS_TXFIFO_REQ_SHIFT                                 5
#define        IRD_STATUS_TXFIFO_REQ_NO                            (0UL<<5)
#define        IRD_STATUS_TXFIFO_REQ_YES                           (1UL<<5)
#define     IRD_STATUS_TXFIFO_FULL_MASK                          0x00000040
#define     IRD_STATUS_TXFIFO_FULL_SHIFT                                 6
#define        IRD_STATUS_TXFIFO_FULL_NO                           (0UL<<6)
#define        IRD_STATUS_TXFIFO_FULL_YES                          (1UL<<6)

/* Infrared Remote Interrupt Enable Register */
#define IRD_INT_ENABLE_REG                                   (IRD_BASE + 0x14)
#define IRD_INT_ENABLE_REG_ADDR(iBank)       (IRD_INT_ENABLE_REG     + (iBank)*IRD_BANK_SIZE)
#define     IRD_INT_ENABLE_RXPULSE_WIDTH_TIMEOUT_MASK            0x00000001
#define     IRD_INT_ENABLE_RXPULSE_WIDTH_TIMEOUT_SHIFT                  0
#define        IRD_INT_ENABLE_RXPULSE_WIDTH_TIMEOUT_DIS            (0UL<<0)
#define        IRD_INT_ENABLE_RXPULSE_WIDTH_TIMEOUT_ENA            (1UL<<0)
#define     IRD_INT_ENABLE_RXFIFO_OVERRUN_MASK                   0x00000002
#define     IRD_INT_ENABLE_RXFIFO_OVERRUN_SHIFT                         1
#define        IRD_INT_ENABLE_RXFIFO_OVERRUN_DIS                   (0UL<<1)
#define        IRD_INT_ENABLE_RXFIFO_OVERRUN_ENA                   (1UL<<1)
#define     IRD_INT_ENABLE_RXFIFO_MASK                           0x00000010
#define     IRD_INT_ENABLE_RXFIFO_SHIFT                                 4
#define        IRD_INT_ENABLE_RXFIFO_DIS                           (0UL<<4)
#define        IRD_INT_ENABLE_RXFIFO_ENA                           (1UL<<4)
#define     IRD_INT_ENABLE_TXFIFO_MASK                           0x00000020
#define     IRD_INT_ENABLE_TXFIFO_SHIFT                                 5
#define        IRD_INT_ENABLE_TXFIFO_DIS                           (0UL<<5)
#define        IRD_INT_ENABLE_TXFIFO_ENA                           (1UL<<5)

/* Infrared Remote Low Pass Filter Register */
#define IRD_LOWPASS_FILTER_REG                               (IRD_BASE + 0x18)
#define IRD_LOWPASS_FILTER_REG_ADDR(iBank)   (IRD_LOWPASS_FILTER_REG + (iBank)*IRD_BANK_SIZE)
#define    IRD_LOWPASS_FILTER_MODULUS_MASK                       0x0000FFFF
#define    IRD_LOWPASS_FILTER_MODULUS_SHIFT                             0

/* Infrared Remote FIFO Register, x = 0~15 */
#define IRD_DATA_BASE                                        (IRD_BASE + 0x40)
#define IRD_DATA_BASE_ADDR(iBank, x)          (IRD_DATA_BASE + x * 4 + (iBank)*IRD_BANK_SIZE)
#define    IRD_DATA_TXRX_FIFO_MASK                               0x0000FFFF
#define    IRD_DATA_TXRX_FIFO_SHIFT                                     0
#define    IRD_DATA_TXRX_LEVEL_MASK                              0x00010000
#define    IRD_DATA_TXRX_LEVEL_SHIFT                                   16
#define       IRD_DATA_TXRX_LEVEL_HIGH                            (1UL<<16)
#define       IRD_DATA_TXRX_LEVEL_LOW                             (0UL<<16)
#define    IRD_DATA_RX_NEXT_DATA_VALID_MASK                      0x00020000
#define    IRD_DATA_RX_NEXT_DATA_VALID_SHIFT                           17
#define       IRD_DATA_RX_NEXT_DATA_VALID_YES                     (1UL<<17)
#define       IRD_DATA_RX_NEXT_DATA_VALID_NO                      (0UL<<17)


/* To do (for software team): check below definitions if they are used in code. If so, 
   change code to use bit-shfited definition above and remove these unshifted 
   definition. */
/* Absolute values for writing the whole register at once */

#define IRD_EDGE_CTRL_MASK  0x0000000C
#define IRD_ENABLE_DEMOD    0x00000010
#define IRD_ENABLE_MOD      0x00000020
#define IRD_ENABLE_RX_FIFO  0x00000040
#define IRD_ENABLE_TX_FIFO  0x00000080
#define IRD_ENABLE_RX       0x00000100
#define IRD_ENABLE_TX       0x00000200
#define IRD_RX_INT_CTRL     0x00000400
#define IRD_TX_INT_CTRL     0x00000800
#define IRD_CARRIER_POL     0x00001000
#define IRD_LOOPBACK        0x00002000

/* Absolute values for writing the whole register at once */
#define IRD_RX_TIMEOUT 0x00000001
#define IRD_RX_OVERRUN 0x00000002
#define IRD_RX_BUSY    0x00000004
#define IRD_TX_BUSY    0x00000008
#define IRD_RX_EMPTY   0x00000010
#define IRD_TX_FULL    0x00000020

/* Absolute values for writing the whole register at once */
#define IRD_INT_PLSTIMEOUT 0x00000001
#define IRD_INT_OVERRUN    0x00000002
#define IRD_INT_RX_FIFO    0x00000010
#define IRD_INT_TX_FIFO    0x00000020

#define IRD_FILTER_DISABLE 0

/* Absolute values for writing the whole register at once */
#define IRD_DATA_MASK  0x0000FFFF
#define IRD_BIT_LEVEL  0x00010000
#define IRD_DATA_AVAIL 0x00020000

#endif /* _TMMODIPIRD_H_ */

/*******************************************************************************
 * Modifications:
 * $Log$
 *
 ******************************************************************************/

