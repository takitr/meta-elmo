/*==========================================================================
#        COPYRIGHT (c) NXP B.V. 2009
#        All rights are reserved. Reproduction in whole or in part is
#        prohibited without the written consent of the copyright owner.
#--------------------------------------------------------------------------
*
* Filename: tmmodIpVsmDma.h
*
*
* Description: Public header file defining hardware-specific values
* (such as register addresses, bit definitions, etc.) for VSM DMA
*
* Author: Srini Venkataraman, Nitin Garg
*
****************************************************************************/
/* $Id: tmmodIpVsmDma.h 100496 2009-06-29 18:01:42Z gargn $
****************************************************************************/

#ifndef _TMMODIPVSMDMA_H_
#define _TMMODIPVSMDMA_H_

/* VSM DMA REGISTER DEFINITIONS */

#define VSM_DMA_REG_SET_SIZE                             0x100

#define VSM_DMA_CMD_REG(base)                            (base + 0x0)
#define VSM_DMA_NDA_A_REG(base)                          (base + 0x4)
#define VSM_DMA_NDA_B_REG(base)                          (base + 0x8)
#define VSM_DMA_STATUS_REG(base)                         (base + 0xC)
#define VSM_DMA_CDA_REG(base)                            (base + 0x10)
#define VSM_DMA_SRC_ADDR_REG(base)                       (base + 0x14)
#define VSM_DMA_DST_ADDR_REG(base)                       (base + 0x18)
#define VSM_DMA_INFO_0_REG(base)                         (base + 0x1C)
#define VSM_DMA_INFO_1_REG(base)                         (base + 0x20)
#define VSM_DMA_INFO_2_REG(base)                         (base + 0x24)
#define VSM_DMA_INT_STATUS_REG(base)                     (base + 0xE0)
#define VSM_DMA_INT_ENABLE_REG(base)                     (base + 0xE4)
#define VSM_DMA_INT_CLEAR_REG(base)                      (base + 0xE8)
#define VSM_DMA_INT_SET_REG(base)                        (base + 0xEC)

/* the following is defined for CRYPTO only */
#define VSM_DMA_INT_OUT_REG(base)                        (base + 0xF0)

/* the following is defined for TSR only */
#define VSM_DMA_INT_SOFT_RESET_REG(base)                 (base + 0xF0)
#define VSM_DMA_SPY_PORT_STATUS_REG(base) i              (base + 0xF4)

/* VSM DMA COMMAND REGISTER DESCRIPTIONS */
#define VSM_DMA_CMD_VD_RESET                             (1UL << 0)
#define VSM_DMA_CMD_VD_RESET_MASK                        (0x1)
#define VSM_DMA_CMD_VD_ENABLE                            (1UL << 1)
#define VSM_DMA_CMD_VD_ENABLE_MASK                       (0x2)
#define VSM_DMA_CMD_VD_DISABLE                           (1UL << 2)
#define VSM_DMA_CMD_VD_DISABLE_MASK                      (0x4)
#define VSM_DMA_CMD_VD_STOP                              (1UL << 3)
#define VSM_DMA_CMD_VD_STOP_MASK                         (0x8)
#define VSM_DMA_CMD_VD_NDA_A_VALIDATE                    (1UL << 4)
#define VSM_DMA_CMD_VD_NDA_A_VALIDATE_MASK               (0x10)
#define VSM_DMA_CMD_VD_NDA_B_VALIDATE                    (1UL << 5)
#define VSM_DMA_CMD_VD_NDA_B_VALIDATE_MASK               (0x20)
#define VSM_DMA_CMD_VD_NDA_A_INVALIDATE                  (1UL << 6)
#define VSM_DMA_CMD_VD_NDA_A_INVALIDATE_MASK             (0x40)
#define VSM_DMA_CMD_VD_NDA_B_INVALIDATE                  (1UL << 7)
#define VSM_DMA_CMD_VD_NDA_B_INVALIDATE_MASK             (0x80)

/* VSM DMA STATUS REGISTER DESCRIPTIONS */
#define VSM_DMA_STATUS_VD_ENABLED                        (1UL << 0)
#define VSM_DMA_STATUS_VD_ENABLED_MASK                   (0x1)
#define VSM_DMA_STATUS_VD_STOPPED                        (1UL << 1)
#define VSM_DMA_STATUS_VD_STOPPED_MASK                   (0x2)
#define VSM_DMA_STATUS_VD_STATE_MASK                     0x0000000C
#define VSM_DMA_STATUS_VD_STATE_SHIFT                    (2)
#define VSM_DMA_STATUS_VD_STATE_DTA_ACTIVE               (1)
#define VSM_DMA_STATUS_VD_STATE_DTB_ACTIVE               (2)
#define VSM_DMA_STATUS_VD_STATE_IDLE                     (0)
#define VSM_DMA_STATUS_NDA_A_VALID                       (1UL << 4)
#define VSM_DMA_STATUS_NDA_A_VALID_MASK                  (0x10)
#define VSM_DMA_STATUS_NDA_B_VALID                       (1UL << 5)
#define VSM_DMA_STATUS_NDA_B_VALID_MASK                  (0x20)

/* VSM DMA CHANNEL INFO 0 REGISTER DESCRIPTIONS */
#define VSM_DMA_INFO_0_RD_ITEM_SIZE_MASK                 (0x00000003)
#define VSM_DMA_INFO_0_RD_ITEM_SIZE_SHIFT                (0)
#define VSM_DMA_INFO_0_RD_ITEM_SIZE_8_BIT                (0)
#define VSM_DMA_INFO_0_RD_ITEM_SIZE_16_BIT               (1)
#define VSM_DMA_INFO_0_RD_ITEM_SIZE_32_BIT               (2)
#define VSM_DMA_INFO_0_RD_ITEM_SIZE_64_BIT               (3)
#define VSM_DMA_INFO_0_DIRECTION_MASK                    (0x0000000C)
#define VSM_DMA_INFO_0_DIRECTION_SHIFT                   (2)
#define VSM_DMA_INFO_0_DIRECTION_MEM_TO_MEM              (0)
#define VSM_DMA_INFO_0_DIRECTION_MEM_TO_OUTDATAPORT      (1)
#define VSM_DMA_INFO_0_DIRECTION_INDATAPORT_TO_MEM       (2)
#define VSM_DMA_INFO_0_DIRECTION_MEM_TO_MEM_VIA_PORTS    (3)
#define VSM_DMA_INFO_0_INTERRUPT                         (1UL << 4)
#define VSM_DMA_INFO_0_END                               (1UL << 5)
#define VSM_DMA_INFO_0_WR_ITEM_SIZE_MASK                 (0x000000C0)
#define VSM_DMA_INFO_0_WR_ITEM_SIZE_SHIFT                (6)
#define VSM_DMA_INFO_0_CMD_BYTE_MASK                     (0x0000FF00)
#define VSM_DMA_INFO_0_CMD_BYTE_SHIFT                    (8)

/* VSM DMA CHANNEL INFO 1 REGISTER DESCRIPTIONS */
#define VSM_DMA_INFO_1_SRC_CNT_MASK                      (0x0000FFFF)
#define VSM_DMA_INFO_1_SRC_CNT_SHIFT                     (0)
#define VSM_DMA_INFO_1_DST_CNT_MASK                      (0xFFFF0000)
#define VSM_DMA_INFO_1_DST_CNT_SHIFT                     (16)

/* VSM DMA CHANNEL INFO 2 REGISTER DESCRIPTIONS */
#define VSM_DMA_INFO_2_CURR_CNT_MASK                     (0x0000FFFF)
#define VSM_DMA_INFO_2_CURR_CNT_SHIFT                    (0)

/* VSM DMA INTERRUPT REGISTER DESCRIPTIONS - common for all the 4 interrupt related registers */
#define VSM_DMA_INTERRUPT_VD_READY                       (1UL << 0)
#define VSM_DMA_INTERRUPT_VD_READY_MASK                  (0x1)
#define VSM_DMA_INTERRUPT_VD_STOP_A                      (1UL << 1)
#define VSM_DMA_INTERRUPT_VD_STOP_A_MASK                 (0x2)
#define VSM_DMA_INTERRUPT_VD_STOP_B                      (1UL << 2)
#define VSM_DMA_INTERRUPT_VD_STOP_B_MASK                 (0x4)
#define VSM_DMA_INTERRUPT_VD_PROG_A                      (1UL << 3)
#define VSM_DMA_INTERRUPT_VD_PROG_A_MASK                 (0x8)
#define VSM_DMA_INTERRUPT_VD_PROG_B                      (1UL << 4)
#define VSM_DMA_INTERRUPT_VD_PROG_B_MASK                 (0x10)
#define VSM_DMA_INTERRUPT_VD_LAST_A                      (1UL << 5)
#define VSM_DMA_INTERRUPT_VD_LAST_A_MASK                 (0x20)
#define VSM_DMA_INTERRUPT_VD_LAST_B                      (1UL << 6)
#define VSM_DMA_INTERRUPT_VD_LAST_B_MASK                 (0x40)

/* VSM DMA SOFT RESET REGISTER DESCRIPTIONS */
#define VSM_DMA_SOFT_RESET                               (1UL << 0)

/* VSM DMA SPY PORT STATUS REGISTER DESCRIPTIONS */
#define VSM_DMA_SPY_SET0_VD_READY                        (1UL << 0)
#define VSM_DMA_SPY_SET0_DTL_VD_CMD_ACCEPT               (1UL << 1)
#define VSM_DMA_SPY_SET0_DTL_VD_CMD_VALID                (1UL << 2)
#define VSM_DMA_SPY_SET0_DTL_VD_DESC_RD_ACCEPT           (1UL << 3)
#define VSM_DMA_SPY_SET0_DTL_VD_DESC_RD_VALID            (1UL << 4)
#define VSM_DMA_SPY_SET0_DTL_VD_DESC_CMD_ACCEPT          (1UL << 5)
#define VSM_DMA_SPY_SET0_DTL_VD_DESC_CMD_VALID           (1UL << 6)
#define VSM_DMA_SPY_SET0_CP                              (1UL << 7)

#define VSM_DMA_SPY_SET1_VD_STATUS_4_3_2_MASK            (0x00000007)
#define VSM_DMA_SPY_SET1_VD_PROG_A                       (1UL << 3)
#define VSM_DMA_SPY_SET1_VD_PROG_B                       (1UL << 4)
#define VSM_DMA_SPY_SET1_DTL_VD_TAG_ACK                  (1UL << 5)
#define VSM_DMA_SPY_SET1_DTL_VD_TAG                      (1UL << 6)
#define VSM_DMA_SPY_SET1_DTL_VD_WR_ACCEPT                (1UL << 7)
#define VSM_DMA_SPY_SET1_DTL_VD_WR_VALID                 (1UL << 8)
#define VSM_DMA_SPY_SET1_DTL_VD_RD_ACCEPT                (1UL << 9)
#define VSM_DMA_SPY_SET1_DTL_VD_RD_VALID                 (1UL << 10)
#define VSM_DMA_SPY_SET1_CP                              (1UL << 11)

#define VSM_DMA_SPY_SET2_VD_INT_STATUS_2_1_MASK          (0x00000003)
#define VSM_DMA_SPY_SET2_VD_INT_STATUS_6_5_MASK          (0x0000000C)
#define VSM_DMA_SPY_SET2_VD_STATUS_BIT_5                 (1UL << 4)
#define VSM_DMA_SPY_SET2_VD_INFO_BIT_2                   (1UL << 5)
#define VSM_DMA_SPY_SET2_VD_INFO_BIT_2_INVERSE           (1UL << 6)
#define VSM_DMA_SPY_SET2_VD_IO_WR_ACCEPT                 (1UL << 7)
#define VSM_DMA_SPY_SET2_VD_IO_WR_VALID                  (1UL << 8)
#define VSM_DMA_SPY_SET2_VD_IO_RD_ACCEPT                 (1UL << 9)
#define VSM_DMA_SPY_SET2_VD_IO_RD_VALID                  (1UL << 10)
#define VSM_DMA_SPY_SET2_CP                              (1UL << 11)

#endif /* #ifndef _TMMODIPVSMDMA_H_ */

/*******************************************************************************
 * Modifications:
 * $Log$
 *
 ******************************************************************************/

