/*-------------------------------------------------------------------------*/
/* Copyright 2011 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef PHMODIPGLOBALREG_H
#define PHMODIPGLOBALREG_H
    
    /*
    * Malone Main Control Register
    */
    #define GLOBALREG_A926_MAIN_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x80)
    /*
    * Reserved
    */
    #define GLOBALREG_A926_MAIN_CTRL_RESERVED_RW (0x01ffff << 15)
    #define GLOBALREG_A926_MAIN_CTRL_RESERVED_SHIFT 15
    #define GLOBALREG_A926_MAIN_CTRL_GLBREG_REMAP_VECTOR_EN_RW (0x01 << 14)
    #define GLOBALREG_A926_MAIN_CTRL_GLBREG_REMAP_VECTOR_EN_SHIFT 14
    #define GLOBALREG_A926_MAIN_CTRL_RESERVED2_RW (0x07ff << 3)
    #define GLOBALREG_A926_MAIN_CTRL_RESERVED2_SHIFT 3
    #define GLOBALREG_A926_MAIN_CTRL_SYS_BIGENDIAN_RW (0x01 << 2)
    #define GLOBALREG_A926_MAIN_CTRL_SYS_BIGENDIAN_SHIFT 2
    #define GLOBALREG_A926_MAIN_CTRL_RESERVED4_RW (0x01 << 1)
    #define GLOBALREG_A926_MAIN_CTRL_RESERVED4_SHIFT 1
    /*
    * ARM926 is in Wait for interrupt standby state (read-only)
    */
    #define GLOBALREG_A926_MAIN_CTRL_ARM_STANDBYWFI_RW (0x01 << 0)
    #define GLOBALREG_A926_MAIN_CTRL_ARM_STANDBYWFI_SHIFT 0
    /*
    * Malone Reset Vector
    */
    #define GLOBALREG_A926_RESET_VECTOR_REG1  (GLOBALREG_BASE_UNIT1 + 0x84)
    /*
    * Reserved
    */
    #define GLOBALREG_A926_RESET_VECTOR_RESERVED_RW (0x0ffff << 16)
    #define GLOBALREG_A926_RESET_VECTOR_RESERVED_SHIFT 16
    /*
    * Malone Reset Vector
    */
    #define GLOBALREG_A926_RESET_VECTOR_A926_RESET_VECTOR_RW (0x0ffff << 0)
    #define GLOBALREG_A926_RESET_VECTOR_A926_RESET_VECTOR_SHIFT 0
    /*
    * The PIO Pin Mux 0 Select register controls the selection of primary functions fo
    * r PIO pin 0-31. Bit 0 corresponds to PIO[0], bit 1 to PIO[1], and so on up to PI
    * O[31].
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_REG  (GLOBALREG_BASE_UNIT1 + 0x100)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_031_RW (0x01 << 31)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_031_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_030_RW (0x01 << 30)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_030_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_029_RW (0x01 << 29)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_029_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_028_RW (0x01 << 28)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_028_SHIFT 28
    /*
    * uhf1
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_027_RW (0x01 << 27)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_027_SHIFT 27
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_026_RW (0x01 << 26)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_026_SHIFT 26
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_025_RW (0x01 << 25)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_025_SHIFT 25
    /*
    * pwm2
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_024_RW (0x01 << 24)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_024_SHIFT 24
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_023_RW (0x01 << 23)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_023_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_022_RW (0x01 << 22)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_022_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_021_RW (0x01 << 21)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_021_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_020_RW (0x01 << 20)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_020_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_019_RW (0x01 << 19)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_019_SHIFT 19
    /*
    * scl1
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_018_RW (0x01 << 18)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_018_SHIFT 18
    /*
    * sda1
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_017_RW (0x01 << 17)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_017_SHIFT 17
    /*
    * pwm1
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_016_RW (0x01 << 16)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_016_SHIFT 16
    /*
    * sda3
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_015_RW (0x01 << 15)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_015_SHIFT 15
    /*
    * scl3
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_014_RW (0x01 << 14)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_014_SHIFT 14
    /*
    * vga_hsync
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_013_RW (0x01 << 13)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_013_SHIFT 13
    /*
    * irin1
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_012_RW (0x01 << 12)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_012_SHIFT 12
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_011_RW (0x01 << 11)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_011_SHIFT 11
    /*
    * irout1
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_010_RW (0x01 << 10)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_010_SHIFT 10
    /*
    * uart1ctl1_01
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_009_RW (0x01 << 9)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_009_SHIFT 9
    /*
    * uart1ctl2_01
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_008_RW (0x01 << 8)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_008_SHIFT 8
    /*
    * ioa18
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_007_RW (0x01 << 7)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_007_SHIFT 7
    /*
    * ioa17
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_006_RW (0x01 << 6)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_006_SHIFT 6
    /*
    * ioa16
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_005_RW (0x01 << 5)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_005_SHIFT 5
    /*
    * uart2rx
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_004_RW (0x01 << 4)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_004_SHIFT 4
    /*
    * uart2tx
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_003_RW (0x01 << 3)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_003_SHIFT 3
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_002_RW (0x01 << 2)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_002_SHIFT 2
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_001_RW (0x01 << 1)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_001_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_000_RW (0x01 << 0)
    #define GLOBALREG_GPIO_PIN_MUX_0_GMUX_000_SHIFT 0
    /*
    * The PIO Pin Mux 1 Select register controls the selection of primary functions fo
    * r PIO pin 63-32. . Bit 0 corresponds to PIO[32], bit 1 to PIO[33], and so on up 
    * to PIO[63].
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_REG  (GLOBALREG_BASE_UNIT1 + 0x104)
    /*
    * ioa19
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_063_RW (0x01 << 31)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_063_SHIFT 31
    /*
    * ioa15
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_062_RW (0x01 << 30)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_062_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_061_RW (0x01 << 29)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_061_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_060_RW (0x01 << 28)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_060_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_059_RW (0x01 << 27)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_059_SHIFT 27
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_058_RW (0x01 << 26)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_058_SHIFT 26
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_057_RW (0x01 << 25)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_057_SHIFT 25
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_056_RW (0x01 << 24)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_056_SHIFT 24
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_055_RW (0x01 << 23)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_055_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_054_RW (0x01 << 22)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_054_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_053_RW (0x01 << 21)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_053_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_052_RW (0x01 << 20)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_052_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_051_RW (0x01 << 19)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_051_SHIFT 19
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_050_RW (0x01 << 18)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_050_SHIFT 18
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_049_RW (0x01 << 17)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_049_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_048_RW (0x01 << 16)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_048_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_047_RW (0x01 << 15)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_047_SHIFT 15
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_046_RW (0x01 << 14)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_046_SHIFT 14
    /*
    * usb1vbusdrive
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_045_RW (0x01 << 13)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_045_SHIFT 13
    /*
    * usb1fault
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_044_RW (0x01 << 12)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_044_SHIFT 12
    /*
    * slnb0dc
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_043_RW (0x01 << 11)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_043_SHIFT 11
    /*
    * slnb022k
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_042_RW (0x01 << 10)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_042_SHIFT 10
    /*
    * sagcv1
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_041_RW (0x01 << 9)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_041_SHIFT 9
    /*
    * sagcv0
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_040_RW (0x01 << 8)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_040_SHIFT 8
    /*
    * audtxspdif
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_039_RW (0x01 << 7)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_039_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_038_RW (0x01 << 6)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_038_SHIFT 6
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_037_RW (0x01 << 5)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_037_SHIFT 5
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_036_RW (0x01 << 4)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_036_SHIFT 4
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_035_RW (0x01 << 3)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_035_SHIFT 3
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_034_RW (0x01 << 2)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_034_SHIFT 2
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_033_RW (0x01 << 1)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_033_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_032_RW (0x01 << 0)
    #define GLOBALREG_GPIO_PIN_MUX_1_GMUX_032_SHIFT 0
    /*
    * The PIO Pin Mux 2 Select register controls the selection of primary functions fo
    * r PIO pin 95-64. Bit 0 corresponds to PIO[64], bit 1 to PIO[65], and so on up to
    *  bit 31 which corresponds to PIO[95].
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_REG  (GLOBALREG_BASE_UNIT1 + 0x108)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_095_RW (0x01 << 31)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_095_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_094_RW (0x01 << 30)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_094_SHIFT 30
    /*
    * hs3d[7]
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_093_RW (0x01 << 29)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_093_SHIFT 29
    /*
    * hs3d[5]
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_092_RW (0x01 << 28)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_092_SHIFT 28
    /*
    * hs3d[3]
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_091_RW (0x01 << 27)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_091_SHIFT 27
    /*
    * hs3d[1]
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_090_RW (0x01 << 26)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_090_SHIFT 26
    /*
    * hs3clk
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_089_RW (0x01 << 25)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_089_SHIFT 25
    /*
    * hs3sync
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_088_RW (0x01 << 24)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_088_SHIFT 24
    /*
    * hs3err
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_087_RW (0x01 << 23)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_087_SHIFT 23
    /*
    * hs3val
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_086_RW (0x01 << 22)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_086_SHIFT 22
    /*
    * hs3d[0]
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_085_RW (0x01 << 21)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_085_SHIFT 21
    /*
    * hs3d[2]
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_084_RW (0x01 << 20)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_084_SHIFT 20
    /*
    * hs3d[4]
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_083_RW (0x01 << 19)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_083_SHIFT 19
    /*
    * hs3d[6]
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_082_RW (0x01 << 18)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_082_SHIFT 18
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_081_RW (0x01 << 17)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_081_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_080_RW (0x01 << 16)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_080_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_079_RW (0x01 << 15)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_079_SHIFT 15
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_078_RW (0x01 << 14)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_078_SHIFT 14
    /*
    * usb2vbusdrive
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_077_RW (0x01 << 13)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_077_SHIFT 13
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_076_RW (0x01 << 12)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_076_SHIFT 12
    /*
    * vga_vsync
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_075_RW (0x01 << 11)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_075_SHIFT 11
    /*
    * sdled
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_074_RW (0x01 << 10)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_074_SHIFT 10
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_073_RW (0x01 << 9)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_073_SHIFT 9
    /*
    * sm0aux2
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_072_RW (0x01 << 8)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_072_SHIFT 8
    /*
    * sm0aux1
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_071_RW (0x01 << 7)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_071_SHIFT 7
    /*
    * io_reg
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_070_RW (0x01 << 6)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_070_SHIFT 6
    /*
    * uart1rx
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_069_RW (0x01 << 5)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_069_SHIFT 5
    /*
    * uart1tx
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_068_RW (0x01 << 4)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_068_SHIFT 4
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_067_RW (0x01 << 3)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_067_SHIFT 3
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_066_RW (0x01 << 2)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_066_SHIFT 2
    /*
    * ioa21
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_065_RW (0x01 << 1)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_065_SHIFT 1
    /*
    * ioa20
    */
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_064_RW (0x01 << 0)
    #define GLOBALREG_GPIO_PIN_MUX_2_GMUX_064_SHIFT 0
    /*
    * The PIO Pin Mux 3 Select register controls the selection of primary functions fo
    * r PIO pin 127-96. Bit 0 corresponds to PIO[96], bit 1 to PIO[97], and so on up t
    * o bit 31 which corresponds to PIO[127].
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_REG  (GLOBALREG_BASE_UNIT1 + 0x10c)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_127_RW (0x01 << 31)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_127_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_126_RW (0x01 << 30)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_126_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_125_RW (0x01 << 29)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_125_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_124_RW (0x01 << 28)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_124_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_123_RW (0x01 << 27)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_123_SHIFT 27
    /*
    * hs2d[2]
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_122_RW (0x01 << 26)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_122_SHIFT 26
    /*
    * hs2d[1]
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_121_RW (0x01 << 25)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_121_SHIFT 25
    /*
    * hs2d[0]
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_120_RW (0x01 << 24)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_120_SHIFT 24
    /*
    * hs2clk
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_119_RW (0x01 << 23)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_119_SHIFT 23
    /*
    * uhf2
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_118_RW (0x01 << 22)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_118_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_117_RW (0x01 << 21)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_117_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_116_RW (0x01 << 20)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_116_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_115_RW (0x01 << 19)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_115_SHIFT 19
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_114_RW (0x01 << 18)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_114_SHIFT 18
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_113_RW (0x01 << 17)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_113_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_112_RW (0x01 << 16)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_112_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_111_RW (0x01 << 15)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_111_SHIFT 15
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_110_RW (0x01 << 14)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_110_SHIFT 14
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_109_RW (0x01 << 13)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_109_SHIFT 13
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_108_RW (0x01 << 12)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_108_SHIFT 12
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_107_RW (0x01 << 11)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_107_SHIFT 11
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_106_RW (0x01 << 10)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_106_SHIFT 10
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_105_RW (0x01 << 9)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_105_SHIFT 9
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_104_RW (0x01 << 8)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_104_SHIFT 8
    /*
    * resetinn
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_103_RW (0x01 << 7)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_103_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_102_RW (0x01 << 6)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_102_SHIFT 6
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_101_RW (0x01 << 5)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_101_SHIFT 5
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_100_RW (0x01 << 4)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_100_SHIFT 4
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_090_RW (0x01 << 3)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_090_SHIFT 3
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_098_RW (0x01 << 2)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_098_SHIFT 2
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_097_RW (0x01 << 1)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_097_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_096_RW (0x01 << 0)
    #define GLOBALREG_GPIO_PIN_MUX_3_GMUX_096_SHIFT 0
    /*
    * The PIO Pin Mux 4 Select register controls the selection of primary functions fo
    * r PIO pin 159-128. Bit 0 corresponds to PIO[128], bit 1 to PIO[129], and so on u
    * p to bit 31 which corresponds to PIO[159].
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_REG  (GLOBALREG_BASE_UNIT1 + 0x110)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_159_RW (0x01 << 31)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_159_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_158_RW (0x01 << 30)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_158_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_157_RW (0x01 << 29)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_157_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_156_RW (0x01 << 28)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_156_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_155_RW (0x01 << 27)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_155_SHIFT 27
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_154_RW (0x01 << 26)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_154_SHIFT 26
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_153_RW (0x01 << 25)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_153_SHIFT 25
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_152_RW (0x01 << 24)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_152_SHIFT 24
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_151_RW (0x01 << 23)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_151_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_150_RW (0x01 << 22)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_150_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_149_RW (0x01 << 21)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_149_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_148_RW (0x01 << 20)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_148_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_147_RW (0x01 << 19)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_147_SHIFT 19
    /*
    * pwm3
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_146_RW (0x01 << 18)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_146_SHIFT 18
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_145_RW (0x01 << 17)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_145_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_144_RW (0x01 << 16)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_144_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_143_RW (0x01 << 15)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_143_SHIFT 15
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_142_RW (0x01 << 14)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_142_SHIFT 14
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_141_RW (0x01 << 13)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_141_SHIFT 13
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_140_RW (0x01 << 12)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_140_SHIFT 12
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_139_RW (0x01 << 11)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_139_SHIFT 11
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_138_RW (0x01 << 10)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_138_SHIFT 10
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_137_RW (0x01 << 9)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_137_SHIFT 9
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_136_RW (0x01 << 8)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_136_SHIFT 8
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_135_RW (0x01 << 7)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_135_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_134_RW (0x01 << 6)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_134_SHIFT 6
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_133_RW (0x01 << 5)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_133_SHIFT 5
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_132_RW (0x01 << 4)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_132_SHIFT 4
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_131_RW (0x01 << 3)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_131_SHIFT 3
    /*
    * hs2val
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_130_RW (0x01 << 2)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_130_SHIFT 2
    /*
    * hs2sync
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_129_RW (0x01 << 1)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_129_SHIFT 1
    /*
    * hs2err
    */
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_128_RW (0x01 << 0)
    #define GLOBALREG_GPIO_PIN_MUX_4_GMUX_128_SHIFT 0
    /*
    * The PIO Pin Mux 5 Select register controls the selection of primary functions fo
    * r PIO pin 191-160. Bit 0 corresponds to PIO[160], bit 1 to PIO[161], and so on u
    * p to bit 31 which corresponds to PIO[191].
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_REG  (GLOBALREG_BASE_UNIT1 + 0x114)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_191_RW (0x01 << 31)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_191_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_190_RW (0x01 << 30)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_190_SHIFT 30
    /*
    * rgmii1mdc
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_189_RW (0x01 << 29)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_189_SHIFT 29
    /*
    * rgmii1mdio
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_188_RW (0x01 << 28)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_188_SHIFT 28
    /*
    * rgmii1rxck
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_187_RW (0x01 << 27)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_187_SHIFT 27
    /*
    * rgmii1rxd0
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_186_RW (0x01 << 26)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_186_SHIFT 26
    /*
    * rgmii1rxd1
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_185_RW (0x01 << 25)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_185_SHIFT 25
    /*
    * rgmii1rxd2
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_184_RW (0x01 << 24)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_184_SHIFT 24
    /*
    * rgmii1rxd3
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_183_RW (0x01 << 23)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_183_SHIFT 23
    /*
    * rgmii1rxdv
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_182_RW (0x01 << 22)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_182_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_181_RW (0x01 << 21)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_181_SHIFT 21
    /*
    * rgmii1txck
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_180_RW (0x01 << 20)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_180_SHIFT 20
    /*
    * rgmii1txd[0]
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_179_RW (0x01 << 19)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_179_SHIFT 19
    /*
    * scl2
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_178_RW (0x01 << 18)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_178_SHIFT 18
    /*
    * sda2
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_177_RW (0x01 << 17)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_177_SHIFT 17
    /*
    * rgmii1txd[1]
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_176_RW (0x01 << 16)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_176_SHIFT 16
    /*
    * hs2d[6]
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_175_RW (0x01 << 15)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_175_SHIFT 15
    /*
    * hs2d[5]
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_174_RW (0x01 << 14)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_174_SHIFT 14
    /*
    * hs2d[4]
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_173_RW (0x01 << 13)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_173_SHIFT 13
    /*
    * hs2d[3]
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_172_RW (0x01 << 12)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_172_SHIFT 12
    /*
    * ioa23
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_171_RW (0x01 << 11)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_171_SHIFT 11
    /*
    * ioa22
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_170_RW (0x01 << 10)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_170_SHIFT 10
    /*
    * hs2d[7]
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_169_RW (0x01 << 9)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_169_SHIFT 9
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_168_RW (0x01 << 8)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_168_SHIFT 8
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_167_RW (0x01 << 7)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_167_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_166_RW (0x01 << 6)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_166_SHIFT 6
    /*
    * rgmii1txd[2]
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_165_RW (0x01 << 5)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_165_SHIFT 5
    /*
    * rgmii1txd[3]
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_164_RW (0x01 << 4)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_164_SHIFT 4
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_163_RW (0x01 << 3)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_163_SHIFT 3
    /*
    * rgmii1txen
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_162_RW (0x01 << 2)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_162_SHIFT 2
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_161_RW (0x01 << 1)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_161_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_160_RW (0x01 << 0)
    #define GLOBALREG_GPIO_PIN_MUX_5_GMUX_160_SHIFT 0
    /*
    * The PIO Pin Mux 6 Select register controls the selection of primary functions fo
    * r PIO pin 223-192. Bit 0 corresponds to PIO[192], bit 1 to PIO[193], and so on u
    * p to bit 31 which corresponds to PIO[223].
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_REG  (GLOBALREG_BASE_UNIT1 + 0x118)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_223_RW (0x01 << 31)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_223_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_222_RW (0x01 << 30)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_222_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_221_RW (0x01 << 29)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_221_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_220_RW (0x01 << 28)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_220_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_219_RW (0x01 << 27)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_219_SHIFT 27
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_218_RW (0x01 << 26)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_218_SHIFT 26
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_217_RW (0x01 << 25)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_217_SHIFT 25
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_216_RW (0x01 << 24)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_216_SHIFT 24
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_215_RW (0x01 << 23)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_215_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_214_RW (0x01 << 22)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_214_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_213_RW (0x01 << 21)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_213_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_212_RW (0x01 << 20)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_212_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_211_RW (0x01 << 19)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_211_SHIFT 19
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_210_RW (0x01 << 18)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_210_SHIFT 18
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_209_RW (0x01 << 17)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_209_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_208_RW (0x01 << 16)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_208_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_207_RW (0x01 << 15)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_207_SHIFT 15
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_206_RW (0x01 << 14)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_206_SHIFT 14
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_205_RW (0x01 << 13)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_205_SHIFT 13
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_204_RW (0x01 << 12)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_204_SHIFT 12
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_203_RW (0x01 << 11)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_203_SHIFT 11
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_202_RW (0x01 << 10)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_202_SHIFT 10
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_201_RW (0x01 << 9)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_201_SHIFT 9
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_200_RW (0x01 << 8)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_200_SHIFT 8
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_199_RW (0x01 << 7)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_199_SHIFT 7
    /*
    * ethled1
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_198_RW (0x01 << 6)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_198_SHIFT 6
    /*
    * ethled0
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_197_RW (0x01 << 5)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_197_SHIFT 5
    /*
    * ioa26
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_196_RW (0x01 << 4)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_196_SHIFT 4
    /*
    * ioa25
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_195_RW (0x01 << 3)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_195_SHIFT 3
    /*
    * ioa24
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_194_RW (0x01 << 2)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_194_SHIFT 2
    /*
    * usb2fault
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_193_RW (0x01 << 1)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_193_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_192_RW (0x01 << 0)
    #define GLOBALREG_GPIO_PIN_MUX_6_GMUX_192_SHIFT 0
    /*
    * The PIO Pin Mux 0 Select register controls the selection of secondary functions 
    * for PIO pin 0-31. Bit 0 corresponds to PIO[0], bit 1 to PIO[1], and so on up to 
    * PIO[31].
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_REG  (GLOBALREG_BASE_UNIT1 + 0x120)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_031_RW (0x01 << 31)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_031_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_030_RW (0x01 << 30)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_030_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_029_RW (0x01 << 29)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_029_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_028_RW (0x01 << 28)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_028_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_027_RW (0x01 << 27)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_027_SHIFT 27
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_026_RW (0x01 << 26)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_026_SHIFT 26
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_025_RW (0x01 << 25)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_025_SHIFT 25
    /*
    * sdled
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_024_RW (0x01 << 24)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_024_SHIFT 24
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_023_RW (0x01 << 23)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_023_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_022_RW (0x01 << 22)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_022_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_021_RW (0x01 << 21)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_021_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_020_RW (0x01 << 20)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_020_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_019_RW (0x01 << 19)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_019_SHIFT 19
    /*
    * sat_scl1
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_018_RW (0x01 << 18)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_018_SHIFT 18
    /*
    * sat_sda1
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_017_RW (0x01 << 17)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_017_SHIFT 17
    /*
    * sataled
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_016_RW (0x01 << 16)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_016_SHIFT 16
    /*
    * uart3rx
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_015_RW (0x01 << 15)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_015_SHIFT 15
    /*
    * uart3tx
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_014_RW (0x01 << 14)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_014_SHIFT 14
    /*
    * hs6sync
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_013_RW (0x01 << 13)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_013_SHIFT 13
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_012_RW (0x01 << 12)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_012_SHIFT 12
    /*
    * hs6d0
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_011_RW (0x01 << 11)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_011_SHIFT 11
    /*
    * intclk0
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_010_RW (0x01 << 10)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_010_SHIFT 10
    /*
    * sscs_sync_serial
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_009_RW (0x01 << 9)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_009_SHIFT 9
    /*
    * ssclk_sync_serial
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_008_RW (0x01 << 8)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_008_SHIFT 8
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_007_RW (0x01 << 7)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_007_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_006_RW (0x01 << 6)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_006_SHIFT 6
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_005_RW (0x01 << 5)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_005_SHIFT 5
    /*
    * sdcrdwp_00
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_004_RW (0x01 << 4)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_004_SHIFT 4
    /*
    * sdcrdetect_00
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_003_RW (0x01 << 3)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_003_SHIFT 3
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_002_RW (0x01 << 2)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_002_SHIFT 2
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_001_RW (0x01 << 1)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_001_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_000_RW (0x01 << 0)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_0_SMUX_000_SHIFT 0
    /*
    * The PIO Pin Mux 1 Select register controls the selection of secondary functions 
    * for PIO pin 63-32. . Bit 0 corresponds to PIO[32], bit 1 to PIO[33], and so on u
    * p to PIO[63].
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_REG  (GLOBALREG_BASE_UNIT1 + 0x124)
    /*
    * sddata0
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_063_RW (0x01 << 31)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_063_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_062_RW (0x01 << 30)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_062_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_061_RW (0x01 << 29)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_061_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_GMUX_060_RW (0x01 << 28)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_GMUX_060_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_059_RW (0x01 << 27)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_059_SHIFT 27
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_058_RW (0x01 << 26)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_058_SHIFT 26
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_057_RW (0x01 << 25)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_057_SHIFT 25
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_056_RW (0x01 << 24)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_056_SHIFT 24
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_055_RW (0x01 << 23)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_055_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_054_RW (0x01 << 22)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_054_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_053_RW (0x01 << 21)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_053_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_052_RW (0x01 << 20)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_052_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_051_RW (0x01 << 19)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_051_SHIFT 19
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_050_RW (0x01 << 18)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_050_SHIFT 18
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_049_RW (0x01 << 17)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_049_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_048_RW (0x01 << 16)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_048_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_047_RW (0x01 << 15)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_047_SHIFT 15
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_046_RW (0x01 << 14)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_046_SHIFT 14
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_045_RW (0x01 << 13)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_045_SHIFT 13
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_044_RW (0x01 << 12)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_044_SHIFT 12
    /*
    * vga_hsync
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_043_RW (0x01 << 11)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_043_SHIFT 11
    /*
    * vga_vsync
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_042_RW (0x01 << 10)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_042_SHIFT 10
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_041_RW (0x01 << 9)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_041_SHIFT 9
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_040_RW (0x01 << 8)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_040_SHIFT 8
    /*
    * intclk0
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_039_RW (0x01 << 7)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_039_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_038_RW (0x01 << 6)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_038_SHIFT 6
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_037_RW (0x01 << 5)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_037_SHIFT 5
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_036_RW (0x01 << 4)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_036_SHIFT 4
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_035_RW (0x01 << 3)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_035_SHIFT 3
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_034_RW (0x01 << 2)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_034_SHIFT 2
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_033_RW (0x01 << 1)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_033_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_032_RW (0x01 << 0)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_1_SMUX_032_SHIFT 0
    /*
    * The PIO Pin Mux 2 Select register controls the selection of secondary functions 
    * for PIO pin 95-64. Bit 0 corresponds to PIO[64], bit 1 to PIO[65], and so on up 
    * to bit 31 which corresponds to PIO[95].
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_REG  (GLOBALREG_BASE_UNIT1 + 0x128)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_095_RW (0x01 << 31)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_095_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_094_RW (0x01 << 30)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_094_SHIFT 30
    /*
    * rgmii1crs
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_093_RW (0x01 << 29)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_093_SHIFT 29
    /*
    * rgmii1txer
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_092_RW (0x01 << 28)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_092_SHIFT 28
    /*
    * uart2ctl2
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_091_RW (0x01 << 27)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_091_SHIFT 27
    /*
    * rgmiirxer
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_090_RW (0x01 << 26)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_090_SHIFT 26
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_089_RW (0x01 << 25)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_089_SHIFT 25
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_088_RW (0x01 << 24)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_088_SHIFT 24
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_087_RW (0x01 << 23)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_087_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_086_RW (0x01 << 22)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_086_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_085_RW (0x01 << 21)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_085_SHIFT 21
    /*
    * uart2ctl1
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_084_RW (0x01 << 20)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_084_SHIFT 20
    /*
    * uart2ctl3
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_083_RW (0x01 << 19)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_083_SHIFT 19
    /*
    * rgmii1col
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_082_RW (0x01 << 18)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_082_SHIFT 18
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_081_RW (0x01 << 17)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_081_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_080_RW (0x01 << 16)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_080_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_079_RW (0x01 << 15)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_079_SHIFT 15
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_078_RW (0x01 << 14)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_078_SHIFT 14
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_077_RW (0x01 << 13)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_077_SHIFT 13
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_076_RW (0x01 << 12)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_076_SHIFT 12
    /*
    * hs6val
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_075_RW (0x01 << 11)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_075_SHIFT 11
    /*
    * hs6err
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_074_RW (0x01 << 10)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_074_SHIFT 10
    /*
    * hs6clk
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_073_RW (0x01 << 9)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_073_SHIFT 9
    /*
    * uart3tx
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_072_RW (0x01 << 8)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_072_SHIFT 8
    /*
    * uart3rx
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_071_RW (0x01 << 7)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_071_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_070_RW (0x01 << 6)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_070_SHIFT 6
    /*
    * ssrx_sync_serial
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_069_RW (0x01 << 5)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_069_SHIFT 5
    /*
    * sstx_sync_serial
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_068_RW (0x01 << 4)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_068_SHIFT 4
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_067_RW (0x01 << 3)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_067_SHIFT 3
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_066_RW (0x01 << 2)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_066_SHIFT 2
    /*
    * sddata2
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_065_RW (0x01 << 1)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_065_SHIFT 1
    /*
    * sddata1
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_064_RW (0x01 << 0)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_2_SMUX_064_SHIFT 0
    /*
    * The PIO Pin Mux 3 Select register controls the selection of secondary functions 
    * for PIO pin 127-96. Bit 0 corresponds to PIO[96], bit 1 to PIO[97], and so on up
    *  to bit 31 which corresponds to PIO[127].
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_REG  (GLOBALREG_BASE_UNIT1 + 0x12c)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_127_RW (0x01 << 31)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_127_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_126_RW (0x01 << 30)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_126_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_125_RW (0x01 << 29)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_125_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_124_RW (0x01 << 28)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_124_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_123_RW (0x01 << 27)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_123_SHIFT 27
    /*
    * i2sinsck
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_122_RW (0x01 << 26)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_122_SHIFT 26
    /*
    * i2sinosclk
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_121_RW (0x01 << 25)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_121_SHIFT 25
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_120_RW (0x01 << 24)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_120_SHIFT 24
    /*
    * sgpio[5]
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_119_RW (0x01 << 23)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_119_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_118_RW (0x01 << 22)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_118_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_117_RW (0x01 << 21)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_117_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_116_RW (0x01 << 20)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_116_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_115_RW (0x01 << 19)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_115_SHIFT 19
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_114_RW (0x01 << 18)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_114_SHIFT 18
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_113_RW (0x01 << 17)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_113_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_112_RW (0x01 << 16)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_112_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_111_RW (0x01 << 15)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_111_SHIFT 15
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_110_RW (0x01 << 14)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_110_SHIFT 14
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_109_RW (0x01 << 13)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_109_SHIFT 13
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_108_RW (0x01 << 12)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_108_SHIFT 12
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_107_RW (0x01 << 11)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_107_SHIFT 11
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_106_RW (0x01 << 10)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_106_SHIFT 10
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_105_RW (0x01 << 9)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_105_SHIFT 9
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_104_RW (0x01 << 8)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_104_SHIFT 8
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_103_RW (0x01 << 7)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_103_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_102_RW (0x01 << 6)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_102_SHIFT 6
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_101_RW (0x01 << 5)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_101_SHIFT 5
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_100_RW (0x01 << 4)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_100_SHIFT 4
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_090_RW (0x01 << 3)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_090_SHIFT 3
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_098_RW (0x01 << 2)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_098_SHIFT 2
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_097_RW (0x01 << 1)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_097_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_096_RW (0x01 << 0)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_3_SMUX_096_SHIFT 0
    /*
    * The PIO Pin Mux 4 Select register controls the selection of secondary functions 
    * for PIO pin 159-128. Bit 0 corresponds to PIO[128], bit 1 to PIO[129], and so on
    *  up to bit 31 which corresponds to PIO[159].
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_REG  (GLOBALREG_BASE_UNIT1 + 0x130)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_159_RW (0x01 << 31)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_159_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_158_RW (0x01 << 30)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_158_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_157_RW (0x01 << 29)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_157_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_156_RW (0x01 << 28)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_156_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_155_RW (0x01 << 27)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_155_SHIFT 27
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_154_RW (0x01 << 26)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_154_SHIFT 26
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_153_RW (0x01 << 25)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_153_SHIFT 25
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_152_RW (0x01 << 24)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_152_SHIFT 24
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_151_RW (0x01 << 23)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_151_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_150_RW (0x01 << 22)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_150_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_149_RW (0x01 << 21)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_149_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_148_RW (0x01 << 20)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_148_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_147_RW (0x01 << 19)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_147_SHIFT 19
    /*
    * 656fref
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_146_RW (0x01 << 18)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_146_SHIFT 18
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_145_RW (0x01 << 17)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_145_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_144_RW (0x01 << 16)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_144_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_143_RW (0x01 << 15)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_143_SHIFT 15
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_142_RW (0x01 << 14)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_142_SHIFT 14
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_141_RW (0x01 << 13)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_141_SHIFT 13
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_140_RW (0x01 << 12)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_140_SHIFT 12
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_139_RW (0x01 << 11)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_139_SHIFT 11
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_138_RW (0x01 << 10)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_138_SHIFT 10
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_137_RW (0x01 << 9)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_137_SHIFT 9
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_136_RW (0x01 << 8)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_136_SHIFT 8
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_135_RW (0x01 << 7)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_135_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_134_RW (0x01 << 6)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_134_SHIFT 6
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_133_RW (0x01 << 5)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_133_SHIFT 5
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_132_RW (0x01 << 4)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_132_SHIFT 4
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_131_RW (0x01 << 3)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_131_SHIFT 3
    /*
    * sgpio[1]
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_130_RW (0x01 << 2)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_130_SHIFT 2
    /*
    * sgpio[4]
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_129_RW (0x01 << 1)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_129_SHIFT 1
    /*
    * sgpio[0]
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_128_RW (0x01 << 0)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_4_SMUX_128_SHIFT 0
    /*
    * The PIO Pin Mux 5 Select register controls the selection of secondary functions 
    * for PIO pin 191-160. Bit 0 corresponds to PIO[160], bit 1 to PIO[161], and so on
    *  up to bit 31 which corresponds to PIO[191].
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_REG  (GLOBALREG_BASE_UNIT1 + 0x134)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_191_RW (0x01 << 31)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_191_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_190_RW (0x01 << 30)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_190_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_189_RW (0x01 << 29)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_189_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_188_RW (0x01 << 28)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_188_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_187_RW (0x01 << 27)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_187_SHIFT 27
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_186_RW (0x01 << 26)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_186_SHIFT 26
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_185_RW (0x01 << 25)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_185_SHIFT 25
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_184_RW (0x01 << 24)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_184_SHIFT 24
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_183_RW (0x01 << 23)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_183_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_182_RW (0x01 << 22)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_182_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_181_RW (0x01 << 21)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_181_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_180_RW (0x01 << 20)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_180_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_179_RW (0x01 << 19)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_179_SHIFT 19
    /*
    * sdcrdwp
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_178_RW (0x01 << 18)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_178_SHIFT 18
    /*
    * sdcrdectect
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_177_RW (0x01 << 17)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_177_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_176_RW (0x01 << 16)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_176_SHIFT 16
    /*
    * i2sind2
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_175_RW (0x01 << 15)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_175_SHIFT 15
    /*
    * i2sind1
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_174_RW (0x01 << 14)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_174_SHIFT 14
    /*
    * i2sind0
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_173_RW (0x01 << 13)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_173_SHIFT 13
    /*
    * i2sinws
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_172_RW (0x01 << 12)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_172_SHIFT 12
    /*
    * nand_rb3
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_171_RW (0x01 << 11)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_171_SHIFT 11
    /*
    * sddata3
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_170_RW (0x01 << 10)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_170_SHIFT 10
    /*
    * i2sind3
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_169_RW (0x01 << 9)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_169_SHIFT 9
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_168_RW (0x01 << 8)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_168_SHIFT 8
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_167_RW (0x01 << 7)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_167_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_166_RW (0x01 << 6)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_166_SHIFT 6
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_165_RW (0x01 << 5)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_165_SHIFT 5
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_164_RW (0x01 << 4)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_164_SHIFT 4
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_163_RW (0x01 << 3)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_163_SHIFT 3
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_162_RW (0x01 << 2)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_162_SHIFT 2
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_161_RW (0x01 << 1)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_161_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_160_RW (0x01 << 0)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_5_SMUX_160_SHIFT 0
    /*
    * The PIO Pin Mux 6 Select register controls the selection of secondary functions 
    * for PIO pin 223-192. Bit 0 corresponds to PIO[192], bit 1 to PIO[193], and so on
    *  up to bit 31 which corresponds to PIO[223].
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_REG  (GLOBALREG_BASE_UNIT1 + 0x138)
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_223_RW (0x01 << 31)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_223_SHIFT 31
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_222_RW (0x01 << 30)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_222_SHIFT 30
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_221_RW (0x01 << 29)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_221_SHIFT 29
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_220_RW (0x01 << 28)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_220_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_219_RW (0x01 << 27)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_219_SHIFT 27
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_218_RW (0x01 << 26)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_218_SHIFT 26
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_217_RW (0x01 << 25)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_217_SHIFT 25
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_216_RW (0x01 << 24)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_216_SHIFT 24
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_215_RW (0x01 << 23)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_215_SHIFT 23
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_214_RW (0x01 << 22)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_214_SHIFT 22
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_213_RW (0x01 << 21)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_213_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_212_RW (0x01 << 20)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_212_SHIFT 20
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_211_RW (0x01 << 19)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_211_SHIFT 19
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_210_RW (0x01 << 18)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_210_SHIFT 18
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_209_RW (0x01 << 17)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_209_SHIFT 17
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_208_RW (0x01 << 16)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_208_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_207_RW (0x01 << 15)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_207_SHIFT 15
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_206_RW (0x01 << 14)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_206_SHIFT 14
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_205_RW (0x01 << 13)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_205_SHIFT 13
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_204_RW (0x01 << 12)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_204_SHIFT 12
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_203_RW (0x01 << 11)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_203_SHIFT 11
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_202_RW (0x01 << 10)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_202_SHIFT 10
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_201_RW (0x01 << 9)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_201_SHIFT 9
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_200_RW (0x01 << 8)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_200_SHIFT 8
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_199_RW (0x01 << 7)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_199_SHIFT 7
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_198_RW (0x01 << 6)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_198_SHIFT 6
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_197_RW (0x01 << 5)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_197_SHIFT 5
    /*
    * nand_rb0
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_196_RW (0x01 << 4)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_196_SHIFT 4
    /*
    * nand_rb1
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_195_RW (0x01 << 3)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_195_SHIFT 3
    /*
    * nand_rb2
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_194_RW (0x01 << 2)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_194_SHIFT 2
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_193_RW (0x01 << 1)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_193_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_192_RW (0x01 << 0)
    #define GLOBALREG_GPIO_SEC_PIN_MUX_6_SMUX_192_SHIFT 0
    /*
    * Alternate Function Pin select Register 0
    */
    #define GLOBALREG_ALT_PIN_MUX_0_REG  (GLOBALREG_BASE_UNIT1 + 0x140)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT31_INTCK1_RW (0x01 << 31)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT31_INTCK1_SHIFT 31
    #define GLOBALREG_ALT_PIN_MUX_0_ALT30_SDIO_RW (0x01 << 30)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT30_SDIO_SHIFT 30
    #define GLOBALREG_ALT_PIN_MUX_0_ALT29_CDP_AAGC_RW (0x01 << 29)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT29_CDP_AAGC_SHIFT 29
    #define GLOBALREG_ALT_PIN_MUX_0_ALT28_SAT_I2C2_RW (0x01 << 28)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT28_SAT_I2C2_SHIFT 28
    #define GLOBALREG_ALT_PIN_MUX_0_ALT27_SDCMD_RW (0x01 << 27)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT27_SDCMD_SHIFT 27
    #define GLOBALREG_ALT_PIN_MUX_0_ALT26_EPHYMII_RW (0x01 << 26)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT26_EPHYMII_SHIFT 26
    #define GLOBALREG_ALT_PIN_MUX_0_ALT25_CDP_TBUS_RW (0x01 << 25)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT25_CDP_TBUS_SHIFT 25
    #define GLOBALREG_ALT_PIN_MUX_0_ALT24_TSENSE_TBUS_RW (0x01 << 24)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT24_TSENSE_TBUS_SHIFT 24
    #define GLOBALREG_ALT_PIN_MUX_0_ALT23_RW (0x01 << 23)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT23_SHIFT 23
    #define GLOBALREG_ALT_PIN_MUX_0_ALT22_TESTI2S_RW (0x01 << 22)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT22_TESTI2S_SHIFT 22
    #define GLOBALREG_ALT_PIN_MUX_0_ALT21_EPHYDBG_RW (0x01 << 21)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT21_EPHYDBG_SHIFT 21
    #define GLOBALREG_ALT_PIN_MUX_0_ALT20_RW (0x01 << 20)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT20_SHIFT 20
    #define GLOBALREG_ALT_PIN_MUX_0_ALT19_RW (0x01 << 19)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT19_SHIFT 19
    #define GLOBALREG_ALT_PIN_MUX_0_ALT18_RW (0x01 << 18)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT18_SHIFT 18
    #define GLOBALREG_ALT_PIN_MUX_0_RESERVED_RW (0x01 << 17)
    #define GLOBALREG_ALT_PIN_MUX_0_RESERVED_SHIFT 17
    #define GLOBALREG_ALT_PIN_MUX_0_RESERVED15_RW (0x01 << 16)
    #define GLOBALREG_ALT_PIN_MUX_0_RESERVED15_SHIFT 16
    #define GLOBALREG_ALT_PIN_MUX_0_ALT15_SGPIO7_RW (0x01 << 15)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT15_SGPIO7_SHIFT 15
    #define GLOBALREG_ALT_PIN_MUX_0_ALT14_SGPIO6_RW (0x01 << 14)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT14_SGPIO6_SHIFT 14
    #define GLOBALREG_ALT_PIN_MUX_0_ALT13_DBGI2C_RW (0x01 << 13)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT13_DBGI2C_SHIFT 13
    #define GLOBALREG_ALT_PIN_MUX_0_ALT12_UART2_RW (0x01 << 12)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT12_UART2_SHIFT 12
    #define GLOBALREG_ALT_PIN_MUX_0_ALT11_USBTESTIN_RW (0x01 << 11)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT11_USBTESTIN_SHIFT 11
    #define GLOBALREG_ALT_PIN_MUX_0_RESERVED21_RW (0x01 << 10)
    #define GLOBALREG_ALT_PIN_MUX_0_RESERVED21_SHIFT 10
    #define GLOBALREG_ALT_PIN_MUX_0_ALT09_MEMRD_RW (0x01 << 9)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT09_MEMRD_SHIFT 9
    #define GLOBALREG_ALT_PIN_MUX_0_ALT08_TBUS_RW (0x01 << 8)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT08_TBUS_SHIFT 8
    #define GLOBALREG_ALT_PIN_MUX_0_RESERVED24_RW (0x01 << 7)
    #define GLOBALREG_ALT_PIN_MUX_0_RESERVED24_SHIFT 7
    #define GLOBALREG_ALT_PIN_MUX_0_ALT06_TRACE_RW (0x01 << 6)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT06_TRACE_SHIFT 6
    #define GLOBALREG_ALT_PIN_MUX_0_ALT05_SDIO_RW (0x01 << 5)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT05_SDIO_SHIFT 5
    #define GLOBALREG_ALT_PIN_MUX_0_ALT04_DAC_RW (0x01 << 4)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT04_DAC_SHIFT 4
    #define GLOBALREG_ALT_PIN_MUX_0_ALT03_656_RW (0x01 << 3)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT03_656_SHIFT 3
    #define GLOBALREG_ALT_PIN_MUX_0_ALT02_656HI_RW (0x01 << 2)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT02_656HI_SHIFT 2
    #define GLOBALREG_ALT_PIN_MUX_0_ALT01_PHYDTO_RW (0x01 << 1)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT01_PHYDTO_SHIFT 1
    #define GLOBALREG_ALT_PIN_MUX_0_ALT00_USBMON_RW (0x01 << 0)
    #define GLOBALREG_ALT_PIN_MUX_0_ALT00_USBMON_SHIFT 0
    /*
    * Alternate Function Pin select Register 1
    */
    #define GLOBALREG_ALT_PIN_MUX_1_REG  (GLOBALREG_BASE_UNIT1 + 0x144)
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_RESERVED_RW (0x01fff << 19)
    #define GLOBALREG_ALT_PIN_MUX_1_RESERVED_SHIFT 19
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_SECDBG_OPVERRIDE_RW (0x01 << 18)
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_SECDBG_OPVERRIDE_SHIFT 18
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_UART1CTL2_SEL_RW (0x07 << 15)
    #define GLOBALREG_ALT_PIN_MUX_1_UART1CTL2_SEL_SHIFT 15
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_UART1CTL1_SEL_RW (0x07 << 12)
    #define GLOBALREG_ALT_PIN_MUX_1_UART1CTL1_SEL_SHIFT 12
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL5_RW (0x01 << 11)
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL5_SHIFT 11
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL4_RW (0x01 << 10)
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL4_SHIFT 10
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL3_RW (0x01 << 9)
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL3_SHIFT 9
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL2_RW (0x01 << 8)
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL2_SHIFT 8
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL1_RW (0x01 << 7)
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL1_SHIFT 7
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL0_RW (0x01 << 6)
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BKUPCLK_SEL0_SHIFT 6
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_RET_BLAZER_I2C_SEL_RW (0x01 << 5)
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_RET_BLAZER_I2C_SEL_SHIFT 5
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_RESERVED11_RW (0x07 << 2)
    #define GLOBALREG_ALT_PIN_MUX_1_RESERVED11_SHIFT 2
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BERT_MPG1_RW (0x01 << 1)
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BERT_MPG1_SHIFT 1
    /*
    * spare
    */
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BERT_MPG0_RW (0x01 << 0)
    #define GLOBALREG_ALT_PIN_MUX_1_ALT_REG_BERT_MPG0_SHIFT 0
    /*
    * Alternate Function Pin select Register 2
    */
    #define GLOBALREG_ALT_PIN_MUX_2_REG  (GLOBALREG_BASE_UNIT1 + 0x148)
    /*
    * Spare
    */
    #define GLOBALREG_ALT_PIN_MUX_2_ALT_REG2_RW (0x03fffff << 10)
    #define GLOBALREG_ALT_PIN_MUX_2_ALT_REG2_SHIFT 10
    /*
    * Spare
    */
    #define GLOBALREG_ALT_PIN_MUX_2_MON_USB_SEL_RW (0x01 << 9)
    #define GLOBALREG_ALT_PIN_MUX_2_MON_USB_SEL_SHIFT 9
    /*
    * Spare
    */
    #define GLOBALREG_ALT_PIN_MUX_2_UART2CTL1_SEL_RW (0x07 << 6)
    #define GLOBALREG_ALT_PIN_MUX_2_UART2CTL1_SEL_SHIFT 6
    /*
    * Spare
    */
    #define GLOBALREG_ALT_PIN_MUX_2_UART2CTL2_SEL_RW (0x07 << 3)
    #define GLOBALREG_ALT_PIN_MUX_2_UART2CTL2_SEL_SHIFT 3
    /*
    * Spare
    */
    #define GLOBALREG_ALT_PIN_MUX_2_UART2CTL3_SEL_RW (0x07 << 0)
    #define GLOBALREG_ALT_PIN_MUX_2_UART2CTL3_SEL_SHIFT 0
    /*
    * Internal bus DRAM low address
    */
    #define GLOBALREG_DMA_GATE_LO_REG1  (GLOBALREG_BASE_UNIT1 + 0x200)
    /*
    * Lowest DCSN address mapped to DRAM, granularity of 64K. Internal bus DRAM apertu
    * re is reset to start at 0.
    */
    #define GLOBALREG_DMA_GATE_LO_DMA_GATE_LO_RW (0x0ffff << 16)
    #define GLOBALREG_DMA_GATE_LO_DMA_GATE_LO_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_DMA_GATE_LO_RESERVED_RW (0x0ffff << 0)
    #define GLOBALREG_DMA_GATE_LO_RESERVED_SHIFT 0
    /*
    * Internal bus DRAM high address
    */
    #define GLOBALREG_DMA_GATE_HI_REG1  (GLOBALREG_BASE_UNIT1 + 0x204)
    /*
    * First address outside DCSN DRAM space, granularity of 64K. Internal bus DRAM ape
    * rture is reset to 64MB.
    */
    #define GLOBALREG_DMA_GATE_HI_DMA_GATE_HI_RW (0x0ffff << 16)
    #define GLOBALREG_DMA_GATE_HI_DMA_GATE_HI_SHIFT 16
    #define GLOBALREG_DMA_GATE_HI_RESERVED_RW (0x0ffff << 0)
    #define GLOBALREG_DMA_GATE_HI_RESERVED_SHIFT 0
    /*
    * Enables writes to DMA_GATE_LO and DMA_GATE_HI
    */
    #define GLOBALREG_APERTURE_WE_REG1  (GLOBALREG_BASE_UNIT1 + 0x208)
    /*
    * Reserved
    */
    #define GLOBALREG_APERTURE_WE_RESERVED_RW (0x0ffffffff << 0)
    #define GLOBALREG_APERTURE_WE_RESERVED_SHIFT 0
    /*
    * Flash space low address
    */
    #define GLOBALREG_FLASH_LO_REG1  (GLOBALREG_BASE_UNIT1 + 0x20c)
    /*
    * Low address of Flash/SPI/ISA space
    */
    #define GLOBALREG_FLASH_LO_FLASH_LO_RW (0x0f << 28)
    #define GLOBALREG_FLASH_LO_FLASH_LO_SHIFT 28
    /*
    * Reserved
    */
    #define GLOBALREG_FLASH_LO_RESERVED_RW (0x0fffffff << 0)
    #define GLOBALREG_FLASH_LO_RESERVED_SHIFT 0
    /*
    * Flash space high address
    */
    #define GLOBALREG_FLASH_HI_REG1  (GLOBALREG_BASE_UNIT1 + 0x210)
    /*
    * High address of Flash/SPI/ISA space
    */
    #define GLOBALREG_FLASH_HI_FLASH_HI_RW (0x0f << 28)
    #define GLOBALREG_FLASH_HI_FLASH_HI_SHIFT 28
    #define GLOBALREG_FLASH_HI_RESERVED_RW (0x0fffffff << 0)
    #define GLOBALREG_FLASH_HI_RESERVED_SHIFT 0
    /*
    * Malone DMA Gate High
    */
    #define GLOBALREG_FMVD_DMA_GATE_HI_REG1  (GLOBALREG_BASE_UNIT1 + 0x220)
    /*
    * Malone DMA Gate High
    */
    #define GLOBALREG_FMVD_DMA_GATE_HI_FMVD_DMA_GATE_HI_RW (0x0ffff << 16)
    #define GLOBALREG_FMVD_DMA_GATE_HI_FMVD_DMA_GATE_HI_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_FMVD_DMA_GATE_HI_RESERVED_RW (0x0ffff << 0)
    #define GLOBALREG_FMVD_DMA_GATE_HI_RESERVED_SHIFT 0
    /*
    * Malone DMA Gate Low
    */
    #define GLOBALREG_FMVD_DMA_GATE_LO_REG1  (GLOBALREG_BASE_UNIT1 + 0x224)
    /*
    * Malone DMA Gate Low
    */
    #define GLOBALREG_FMVD_DMA_GATE_LO_FMVD_DMA_GATE_LO_RW (0x0ffff << 16)
    #define GLOBALREG_FMVD_DMA_GATE_LO_FMVD_DMA_GATE_LO_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_FMVD_DMA_GATE_LO_RESERVED_RW (0x0ffff << 0)
    #define GLOBALREG_FMVD_DMA_GATE_LO_RESERVED_SHIFT 0
    /*
    * Base 14 MMIO Offset
    */
    #define GLOBALREG_BASE14_MMIO_REG1  (GLOBALREG_BASE_UNIT1 + 0x240)
    /*
    * Base 14 (MMIO) value used for DCS-N address decoding when WIN2K = 1. When WIN2K 
    * = 0 then this field is not used, and the PCI/XIO BASE14 value (MMIO register) is
    *  used instead.
    */
    #define GLOBALREG_BASE14_MMIO_BASE14_MMIO_RW (0x07ff << 21)
    #define GLOBALREG_BASE14_MMIO_BASE14_MMIO_SHIFT 21
    /*
    * Reserved
    */
    #define GLOBALREG_BASE14_MMIO_RESERVED_RW (0x01fffff << 0)
    #define GLOBALREG_BASE14_MMIO_RESERVED_SHIFT 0
    /*
    * BIS Base Address
    */
    #define GLOBALREG_BIS_BASE_ADDR_REG1  (GLOBALREG_BASE_UNIT1 + 0x2f0)
    /*
    * BIS Base Address (no output)
    */
    #define GLOBALREG_BIS_BASE_ADDR_BIS_BASE_ADDR_RW (0x0ffffffff << 0)
    #define GLOBALREG_BIS_BASE_ADDR_BIS_BASE_ADDR_SHIFT 0
    /*
    * GMAC0 Control
    */
    #define GLOBALREG_GMAC0_CTL_REG  (GLOBALREG_BASE_UNIT1 + 0x300)
    /*
    * Reserved
    */
    #define GLOBALREG_GMAC0_CTL_RESERVED_RW (0x0ffffffff << 0)
    #define GLOBALREG_GMAC0_CTL_RESERVED_SHIFT 0
    /*
    * GMAC1 Control
    */
    #define GLOBALREG_GMAC1_CTL_REG  (GLOBALREG_BASE_UNIT1 + 0x304)
    /*
    * Reserved
    */
    #define GLOBALREG_GMAC1_CTL_RESERVED_RW (0x03fffff << 10)
    #define GLOBALREG_GMAC1_CTL_RESERVED_SHIFT 10
    /*
    * Rx clock input delay selection, used in MII and RGMII modes.
    * 0 = no added delay
    * 1 = 1 delay element added
    * 2 = 2 delay elements added
    * 3 = 3 delay elements added
    */
    #define GLOBALREG_GMAC1_CTL_GMAC1_RX_DELAY_SEL_RW (0x03 << 8)
    #define GLOBALREG_GMAC1_CTL_GMAC1_RX_DELAY_SEL_SHIFT 8
    /*
    * Reserved
    */
    #define GLOBALREG_GMAC1_CTL_RESERVED2_RW (0x03 << 6)
    #define GLOBALREG_GMAC1_CTL_RESERVED2_SHIFT 6
    /*
    * PHY interface select
    * 0 = MII
    * 1 = RGMII
    * 2 = RMII
    * 3 = Reserved
    */
    #define GLOBALREG_GMAC1_CTL_GMAC1_PHY_INTF_SEL_RW (0x03 << 4)
    #define GLOBALREG_GMAC1_CTL_GMAC1_PHY_INTF_SEL_SHIFT 4
    #define GLOBALREG_GMAC1_CTL_RESERVED4_RW (0x0f << 0)
    #define GLOBALREG_GMAC1_CTL_RESERVED4_SHIFT 0
    /*
    * Host Processor Control
    */
    #define GLOBALREG_HOST_CTL_REG1  (GLOBALREG_BASE_UNIT1 + 0x308)
    /*
    * Reserved
    */
    #define GLOBALREG_HOST_CTL_RESERVED_RW (0x07fffff << 9)
    #define GLOBALREG_HOST_CTL_RESERVED_SHIFT 9
    /*
    * When set, disables the burst modification logic for the DMA controller's accesse
    * s to main memory. This logic lengthens bursts under certain conditions, which im
    * proves performance.
    */
    #define GLOBALREG_HOST_CTL_DMAC_PMAN_BMOD_DISABLE_RW (0x01 << 8)
    #define GLOBALREG_HOST_CTL_DMAC_PMAN_BMOD_DISABLE_SHIFT 8
    /*
    * When set, disables the burst modification logic for the DMA controller's ACP por
    * t accesses. This logic lengthens bursts under certain conditions, which improves
    *  performance.
    */
    #define GLOBALREG_HOST_CTL_DMAC_ACP_BMOD_DISABLE_RW (0x01 << 7)
    #define GLOBALREG_HOST_CTL_DMAC_ACP_BMOD_DISABLE_SHIFT 7
    /*
    * Controls the out-of-reset default exception handling state:
    * 0 = ARM mode
    * 1 = Thumb mode
    * This bit is only sampled during reset, and sets the initial state of SCTLR.TE.
    */
    #define GLOBALREG_HOST_CTL_HOST_TEINIT_RW (0x01 << 6)
    #define GLOBALREG_HOST_CTL_HOST_TEINIT_SHIFT 6
    /*
    * Host processor non-maskable FIQ configuration
    * 0 = FIQ interrupt is maskable, 1 = FIQ interrupt is non-maskable
    * Only takes effect after a host processor reset.
    */
    #define GLOBALREG_HOST_CTL_HOST_CFGNMFI_RW (0x01 << 5)
    #define GLOBALREG_HOST_CTL_HOST_CFGNMFI_SHIFT 5
    /*
    * Host processor endianness:
    * 0 = little endian, 1 = big endian
    * Only takes effect after a host processor reset.
    */
    #define GLOBALREG_HOST_CTL_HOST_ENDIAN_RW (0x01 << 4)
    #define GLOBALREG_HOST_CTL_HOST_ENDIAN_SHIFT 4
    /*
    * Controls the location of the host processor exception vectors after reset, and t
    * he location of the first instruction executed after reset is released.
    * 0 = exception vectors start at 0x00000000
    * 1 = exception vectors start at 0xffff0000
    * This bit is only sampled during reset, and sets the initial state of SCTLR.V.
    */
    #define GLOBALREG_HOST_CTL_HOST_VINITHI_RW (0x01 << 3)
    #define GLOBALREG_HOST_CTL_HOST_VINITHI_SHIFT 3
    /*
    * Host Processor Maximum Clock Latency
    */
    #define GLOBALREG_HOST_CTL_HOST_MAXCLKLATENCY_RW (0x07 << 0)
    #define GLOBALREG_HOST_CTL_HOST_MAXCLKLATENCY_SHIFT 0
    /*
    * Typhoon Control
    */
    #define GLOBALREG_TYPHOON_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x30c)
    /*
    * Reserved
    */
    #define GLOBALREG_TYPHOON_CTRL_RESERVED_RW (0x07fffffff << 1)
    #define GLOBALREG_TYPHOON_CTRL_RESERVED_SHIFT 1
    /*
    * direct tv mode
    */
    #define GLOBALREG_TYPHOON_CTRL_DIRECT_TV_MODE_RW (0x01 << 0)
    #define GLOBALREG_TYPHOON_CTRL_DIRECT_TV_MODE_SHIFT 0
    /*
    * Auxillary trigger in connections control
    */
    #define GLOBALREG_CROSS_TRIG_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x310)
    /*
    * Reserved
    */
    #define GLOBALREG_CROSS_TRIG_CTRL_RESERVED_RW (0x0ffffffff << 0)
    #define GLOBALREG_CROSS_TRIG_CTRL_RESERVED_SHIFT 0
    /*
    * Slave address bits for IIC DTL
    */
    #define GLOBALREG_IIC_SLAVE_ADDR_REG1  (GLOBALREG_BASE_UNIT1 + 0x314)
    /*
    * Reserved
    */
    #define GLOBALREG_IIC_SLAVE_ADDR_RESERVED_RW (0x0ffffff << 8)
    #define GLOBALREG_IIC_SLAVE_ADDR_RESERVED_SHIFT 8
    /*
    * Slave address used by the IIC
    */
    #define GLOBALREG_IIC_SLAVE_ADDR_IIC_SLAVE_ADDR_RW (0x07f << 1)
    #define GLOBALREG_IIC_SLAVE_ADDR_IIC_SLAVE_ADDR_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_IIC_SLAVE_ADDR_RESERVED2_RW (0x01 << 0)
    #define GLOBALREG_IIC_SLAVE_ADDR_RESERVED2_SHIFT 0
    /*
    * Sata Control
    */
    #define GLOBALREG_SATA_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x318)
    /*
    * Reserved
    */
    #define GLOBALREG_SATA_CTRL_RESERVED_RW (0x0ffffffff << 0)
    #define GLOBALREG_SATA_CTRL_RESERVED_SHIFT 0
    /*
    * USB Control
    */
    #define GLOBALREG_USB_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x31c)
    /*
    * Reserved
    */
    #define GLOBALREG_USB_CTRL_RESERVED_RW (0x03ffff << 14)
    #define GLOBALREG_USB_CTRL_RESERVED_SHIFT 14
    /*
    * Spare Control
    */
    #define GLOBALREG_USB_CTRL_RESERVED1_RW (0x01 << 13)
    #define GLOBALREG_USB_CTRL_RESERVED1_SHIFT 13
    /*
    * usb control
    */
    #define GLOBALREG_USB_CTRL_RESERVED2_RW (0x01 << 12)
    #define GLOBALREG_USB_CTRL_RESERVED2_SHIFT 12
    /*
    * Spare Control
    */
    #define GLOBALREG_USB_CTRL_RESERVED3_RW (0x01 << 11)
    #define GLOBALREG_USB_CTRL_RESERVED3_SHIFT 11
    /*
    * usb control
    */
    #define GLOBALREG_USB_CTRL_RESERVED4_RW (0x01 << 10)
    #define GLOBALREG_USB_CTRL_RESERVED4_SHIFT 10
    /*
    * Spare Control
    */
    #define GLOBALREG_USB_CTRL_RESERVED5_RW (0x01 << 9)
    #define GLOBALREG_USB_CTRL_RESERVED5_SHIFT 9
    /*
    * usb control
    */
    #define GLOBALREG_USB_CTRL_RESERVED6_RW (0x01 << 8)
    #define GLOBALREG_USB_CTRL_RESERVED6_SHIFT 8
    /*
    * Drive VBUS polarity select for usb2 core. The default polarity of vbusdrive is a
    * ctive high. Setting this bit to 1 will invert the polarity of vbusdrive.
    */
    #define GLOBALREG_USB_CTRL_USB0_IDDQ_CTRL_RW (0x01 << 7)
    #define GLOBALREG_USB_CTRL_USB0_IDDQ_CTRL_SHIFT 7
    /*
    * Drive VBUS polarity select for usb1 core. The default polarity of vbusdrive is a
    * ctive high. Setting this bit to 1 will invert the polarity of vbusdrive.
    */
    #define GLOBALREG_USB_CTRL_USB1_VBUSDRIVE_POL_SEL_RW (0x01 << 6)
    #define GLOBALREG_USB_CTRL_USB1_VBUSDRIVE_POL_SEL_SHIFT 6
    /*
    * Drive VBUS polarity select for usb0 core. The default polarity of vbusdrive is a
    * ctive high. Setting this bit to 1 will invert the polarity of vbusdrive.
    */
    #define GLOBALREG_USB_CTRL_USB0_VBUSDRIVE_POL_SEL_RW (0x01 << 5)
    #define GLOBALREG_USB_CTRL_USB0_VBUSDRIVE_POL_SEL_SHIFT 5
    /*
    * VBUS powerfault polarity select for usb2 core. The default polarity of vbusfault
    *  is active low. Setting this bit to1 will invert the polarity of vbusfault.
    */
    #define GLOBALREG_USB_CTRL_USB1_IDDQ_CTRL_RW (0x01 << 4)
    #define GLOBALREG_USB_CTRL_USB1_IDDQ_CTRL_SHIFT 4
    /*
    * VBUS powerfault polarity select for usb1 core. The default polarity of vbusfault
    *  is active low. Setting this bit to1 will invert the polarity of vbusfault.
    */
    #define GLOBALREG_USB_CTRL_USB1_VBUSFAULT_POL_SEL_RW (0x01 << 3)
    #define GLOBALREG_USB_CTRL_USB1_VBUSFAULT_POL_SEL_SHIFT 3
    /*
    * VBUS powerfault polarity select for usb0 core. The default polarity of vbusfault
    *  is active low. Setting this bit to1 will invert the polarity of vbusfault.
    */
    #define GLOBALREG_USB_CTRL_USB0_VBUSFAULT_POL_SEL_RW (0x01 << 2)
    #define GLOBALREG_USB_CTRL_USB0_VBUSFAULT_POL_SEL_SHIFT 2
    /*
    * Reserved
    */
    #define GLOBALREG_USB_CTRL_RESERVED13_RW (0x01 << 1)
    #define GLOBALREG_USB_CTRL_RESERVED13_SHIFT 1
    /*
    * Reserved
    */
    #define GLOBALREG_USB_CTRL_RESERVED14_RW (0x01 << 0)
    #define GLOBALREG_USB_CTRL_RESERVED14_SHIFT 0
    /*
    * Accelerator Coherency Port Attributes 0
    */
    #define GLOBALREG_REG_ACP_ATTR0_REG1  (GLOBALREG_BASE_UNIT1 + 0x320)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR0_RESERVED_RW (0x01f << 27)
    #define GLOBALREG_REG_ACP_ATTR0_RESERVED_SHIFT 27
    /*
    * ACP write port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR0_ACP_WR_ATTRIBUTES0_RW (0x07ff << 16)
    #define GLOBALREG_REG_ACP_ATTR0_ACP_WR_ATTRIBUTES0_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR0_RESERVED2_RW (0x01f << 11)
    #define GLOBALREG_REG_ACP_ATTR0_RESERVED2_SHIFT 11
    /*
    * ACP read port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR0_ACP_RD_ATTRIBUTES0_RW (0x07ff << 0)
    #define GLOBALREG_REG_ACP_ATTR0_ACP_RD_ATTRIBUTES0_SHIFT 0
    /*
    * Accelerator Coherency Port Attributes 1
    */
    #define GLOBALREG_REG_ACP_ATTR1_REG1  (GLOBALREG_BASE_UNIT1 + 0x324)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR1_RESERVED_RW (0x01f << 27)
    #define GLOBALREG_REG_ACP_ATTR1_RESERVED_SHIFT 27
    /*
    * ACP write port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR1_ACP_WR_ATTRIBUTES1_RW (0x07ff << 16)
    #define GLOBALREG_REG_ACP_ATTR1_ACP_WR_ATTRIBUTES1_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR1_RESERVED2_RW (0x01f << 11)
    #define GLOBALREG_REG_ACP_ATTR1_RESERVED2_SHIFT 11
    /*
    * ACP read port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR1_ACP_RD_ATTRIBUTES1_RW (0x07ff << 0)
    #define GLOBALREG_REG_ACP_ATTR1_ACP_RD_ATTRIBUTES1_SHIFT 0
    /*
    * Accelerator Coherency Port Attributes 2
    */
    #define GLOBALREG_REG_ACP_ATTR2_REG1  (GLOBALREG_BASE_UNIT1 + 0x328)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR2_RESERVED_RW (0x01f << 27)
    #define GLOBALREG_REG_ACP_ATTR2_RESERVED_SHIFT 27
    /*
    * ACP write port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR2_ACP_WR_ATTRIBUTES2_RW (0x07ff << 16)
    #define GLOBALREG_REG_ACP_ATTR2_ACP_WR_ATTRIBUTES2_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR2_RESERVED2_RW (0x01f << 11)
    #define GLOBALREG_REG_ACP_ATTR2_RESERVED2_SHIFT 11
    /*
    * ACP read port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR2_ACP_RD_ATTRIBUTES2_RW (0x07ff << 0)
    #define GLOBALREG_REG_ACP_ATTR2_ACP_RD_ATTRIBUTES2_SHIFT 0
    /*
    * Accelerator Coherency Port Attributes 3
    */
    #define GLOBALREG_REG_ACP_ATTR3_REG1  (GLOBALREG_BASE_UNIT1 + 0x32c)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR3_RESERVED_RW (0x01f << 27)
    #define GLOBALREG_REG_ACP_ATTR3_RESERVED_SHIFT 27
    /*
    * ACP write port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR3_ACP_WR_ATTRIBUTES3_RW (0x07ff << 16)
    #define GLOBALREG_REG_ACP_ATTR3_ACP_WR_ATTRIBUTES3_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR3_RESERVED2_RW (0x01f << 11)
    #define GLOBALREG_REG_ACP_ATTR3_RESERVED2_SHIFT 11
    /*
    * ACP read port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR3_ACP_RD_ATTRIBUTES3_RW (0x07ff << 0)
    #define GLOBALREG_REG_ACP_ATTR3_ACP_RD_ATTRIBUTES3_SHIFT 0
    /*
    * Accelerator Coherency Port Attributes 4
    */
    #define GLOBALREG_REG_ACP_ATTR4_REG1  (GLOBALREG_BASE_UNIT1 + 0x330)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR4_RESERVED_RW (0x01f << 27)
    #define GLOBALREG_REG_ACP_ATTR4_RESERVED_SHIFT 27
    /*
    * ACP write port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR4_ACP_WR_ATTRIBUTES4_RW (0x07ff << 16)
    #define GLOBALREG_REG_ACP_ATTR4_ACP_WR_ATTRIBUTES4_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR4_RESERVED2_RW (0x01f << 11)
    #define GLOBALREG_REG_ACP_ATTR4_RESERVED2_SHIFT 11
    /*
    * ACP read port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR4_ACP_RD_ATTRIBUTES4_RW (0x07ff << 0)
    #define GLOBALREG_REG_ACP_ATTR4_ACP_RD_ATTRIBUTES4_SHIFT 0
    /*
    * Accelerator Coherency Port Attributes 5
    */
    #define GLOBALREG_REG_ACP_ATTR5_REG1  (GLOBALREG_BASE_UNIT1 + 0x334)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR5_RESERVED_RW (0x01f << 27)
    #define GLOBALREG_REG_ACP_ATTR5_RESERVED_SHIFT 27
    /*
    * ACP write port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR5_ACP_WR_ATTRIBUTES5_RW (0x07ff << 16)
    #define GLOBALREG_REG_ACP_ATTR5_ACP_WR_ATTRIBUTES5_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR5_RESERVED2_RW (0x01f << 11)
    #define GLOBALREG_REG_ACP_ATTR5_RESERVED2_SHIFT 11
    /*
    * ACP read port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR5_ACP_RD_ATTRIBUTES5_RW (0x07ff << 0)
    #define GLOBALREG_REG_ACP_ATTR5_ACP_RD_ATTRIBUTES5_SHIFT 0
    /*
    * Accelerator Coherency Port Attributes 6
    */
    #define GLOBALREG_REG_ACP_ATTR6_REG1  (GLOBALREG_BASE_UNIT1 + 0x338)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR6_RESERVED_RW (0x01f << 27)
    #define GLOBALREG_REG_ACP_ATTR6_RESERVED_SHIFT 27
    /*
    * ACP write port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR6_ACP_WR_ATTRIBUTES6_RW (0x07ff << 16)
    #define GLOBALREG_REG_ACP_ATTR6_ACP_WR_ATTRIBUTES6_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR6_RESERVED2_RW (0x01f << 11)
    #define GLOBALREG_REG_ACP_ATTR6_RESERVED2_SHIFT 11
    /*
    * ACP read port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR6_ACP_RD_ATTRIBUTES6_RW (0x07ff << 0)
    #define GLOBALREG_REG_ACP_ATTR6_ACP_RD_ATTRIBUTES6_SHIFT 0
    /*
    * Accelerator Coherency Port Attributes 7
    */
    #define GLOBALREG_REG_ACP_ATTR7_REG1  (GLOBALREG_BASE_UNIT1 + 0x33c)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR7_RESERVED_RW (0x01f << 27)
    #define GLOBALREG_REG_ACP_ATTR7_RESERVED_SHIFT 27
    /*
    * ACP write port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR7_ACP_WR_ATTRIBUTES7_RW (0x07ff << 16)
    #define GLOBALREG_REG_ACP_ATTR7_ACP_WR_ATTRIBUTES7_SHIFT 16
    /*
    * Reserved
    */
    #define GLOBALREG_REG_ACP_ATTR7_RESERVED2_RW (0x01f << 11)
    #define GLOBALREG_REG_ACP_ATTR7_RESERVED2_SHIFT 11
    /*
    * ACP read port attributes
    */
    #define GLOBALREG_REG_ACP_ATTR7_ACP_RD_ATTRIBUTES7_RW (0x07ff << 0)
    #define GLOBALREG_REG_ACP_ATTR7_ACP_RD_ATTRIBUTES7_SHIFT 0
    /*
    * Host Processor Timestamp Control
    */
    #define GLOBALREG_REG_HOST_TS_REG1  (GLOBALREG_BASE_UNIT1 + 0x340)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_HOST_TS_RESERVED_RW (0x0ffffffff << 0)
    #define GLOBALREG_REG_HOST_TS_RESERVED_SHIFT 0
    /*
    * Noise Sensor Control
    */
    #define GLOBALREG_REG_NOISE_CONTROL_REG1  (GLOBALREG_BASE_UNIT1 + 0x380)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_NOISE_CONTROL_RESERVED_RW (0x0fffff << 12)
    #define GLOBALREG_REG_NOISE_CONTROL_RESERVED_SHIFT 12
    /*
    * bit 11 - Reserved
    * bit 10 - reset - reset noise sensor
    * bit 9:2 dacsel[7:0] - DAC Reference Voltage control
    * bit 1:0 - muxsel[1:0] - sets detection type
    */
    #define GLOBALREG_REG_NOISE_CONTROL_REG_NOISE_CONTROL_RW (0x0fff << 0)
    #define GLOBALREG_REG_NOISE_CONTROL_REG_NOISE_CONTROL_SHIFT 0
    /*
    * Temperature Sensor Control
    */
    #define GLOBALREG_REG_TEMP_CONTROL_REG1  (GLOBALREG_BASE_UNIT1 + 0x384)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_TEMP_CONTROL_RESERVED_RW (0x01ffffff << 7)
    #define GLOBALREG_REG_TEMP_CONTROL_RESERVED_SHIFT 7
    /*
    * bit 6 - Reserved
    * bit 5:0 - temp_sel_enc - 6 to 40 bit one-hot encoder to select Temperature Thres
    * hold
    */
    #define GLOBALREG_REG_TEMP_CONTROL_REG_TEMP_CONTROL_RW (0x07f << 0)
    #define GLOBALREG_REG_TEMP_CONTROL_REG_TEMP_CONTROL_SHIFT 0
    /*
    * SIST measurement results
    */
    #define GLOBALREG_REG_SENSOR_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x388)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_SENSOR_CTRL_RESERVED_RW (0x03fff << 18)
    #define GLOBALREG_REG_SENSOR_CTRL_RESERVED_SHIFT 18
    /*
    * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
    * 000 : Selects TCB control of sensor to go to PLL_OUT
    * 001 : Noise sensor is outputted
    * 010 : Temperature sensor is outputted
    * 011 : Reserved
    * 100 : Reserved
    * 101 : LVT Ringo is ouputted
    * 110 : SVT Ringo is outputted
    * 111 : Reserved
    */
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_5_CTRL_RW (0x07 << 15)
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_5_CTRL_SHIFT 15
    /*
    * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
    * 000 : Selects TCB control of sensor to go to PLL_OUT
    * 001 : Noise sensor is outputted
    * 010 : Temperature sensor is outputted
    * 011 : Reserved
    * 100 : Reserved
    * 101 : LVT Ringo is ouputted
    * 110 : SVT Ringo is outputted
    * 111 : Reserved
    */
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_4_CTRL_RW (0x07 << 12)
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_4_CTRL_SHIFT 12
    /*
    * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
    * 000 : Selects TCB control of sensor to go to PLL_OUT
    * 001 : Noise sensor is outputted
    * 010 : Temperature sensor is outputted
    * 011 : Reserved
    * 100 : Reserved
    * 101 : LVT Ringo is ouputted
    * 110 : SVT Ringo is outputted
    * 111 : Reserved
    */
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_3_CTRL_RW (0x07 << 9)
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_3_CTRL_SHIFT 9
    /*
    * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
    * 000 : Selects TCB control of sensor to go to PLL_OUT
    * 001 : Noise sensor is outputted
    * 010 : Temperature sensor is outputted
    * 011 : Reserved
    * 100 : Reserved
    * 101 : LVT Ringo is ouputted
    * 110 : SVT Ringo is outputted
    * 111 : Reserved
    */
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_2_CTRL_RW (0x07 << 6)
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_2_CTRL_SHIFT 6
    /*
    * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
    * 000 : Selects TCB control of sensor to go to PLL_OUT
    * 001 : Noise sensor is outputted
    * 010 : Temperature sensor is outputted
    * 011 : Reserved
    * 100 : Reserved
    * 101 : LVT Ringo is ouputted
    * 110 : SVT Ringo is outputted
    * 111 : Reserved
    */
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_1_CTRL_RW (0x07 << 3)
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_1_CTRL_SHIFT 3
    /*
    * Selects which sensor is output on PLL_OUT and switches on appropriate sensor
    * 000 : Selects TCB control of sensor to go to PLL_OUT
    * 001 : Noise sensor is outputted
    * 010 : Temperature sensor is outputted
    * 011 : Reserved
    * 100 : Reserved
    * 101 : LVT Ringo is ouputted
    * 110 : SVT Ringo is outputted
    * 111 : Reserved
    */
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_0_CTRL_RW (0x07 << 0)
    #define GLOBALREG_REG_SENSOR_CTRL_REG_SENSOR_0_CTRL_SHIFT 0
    /*
    * Miscellaneous IO pin control
    */
    #define GLOBALREG_IO_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x38c)
    /*
    * Reserved
    */
    #define GLOBALREG_IO_CTRL_RESERVED_RW (0x0ffffffff << 0)
    #define GLOBALREG_IO_CTRL_RESERVED_SHIFT 0
    /*
    * ADSP Trimedia powerdown request
    */
    #define GLOBALREG_ADSP_TM_PWRDWN_CONTROL_REG1  (GLOBALREG_BASE_UNIT1 + 0x400)
    /*
    * Reserved
    */
    #define GLOBALREG_ADSP_TM_PWRDWN_CONTROL_RESERVED_RW (0x07fffffff << 1)
    #define GLOBALREG_ADSP_TM_PWRDWN_CONTROL_RESERVED_SHIFT 1
    /*
    * ADSP Trimedia powerdown request:
    * 0 = Do not request a Trimedia powerdown.
    * 1 = Request a Trimedia powerdown.
    */
    #define GLOBALREG_ADSP_TM_PWRDWN_CONTROL_ADSP_TM_PWRDWN_REQ_RW (0x01 << 0)
    #define GLOBALREG_ADSP_TM_PWRDWN_CONTROL_ADSP_TM_PWRDWN_REQ_SHIFT 0
    /*
    * ADSP Trimedia powerdown acknowledge
    */
    #define GLOBALREG_ADSP_TM_PWRDWN_STATUS_REG1  (GLOBALREG_BASE_UNIT1 + 0x404)
    /*
    * Reserved
    */
    #define GLOBALREG_ADSP_TM_PWRDWN_STATUS_RESERVED_R (0x07fffffff << 1)
    #define GLOBALREG_ADSP_TM_PWRDWN_STATUS_RESERVED_SHIFT 1
    /*
    * 0 = ADSP Trimedia does not acknowledge powerdown
    * request.
    * 1 = ADSP Trimedia acknowledges powerdown request.
    */
    #define GLOBALREG_ADSP_TM_PWRDWN_STATUS_ADSP_TM_PWRDWN_ACK_R (0x01 << 0)
    #define GLOBALREG_ADSP_TM_PWRDWN_STATUS_ADSP_TM_PWRDWN_ACK_SHIFT 0
    /*
    * ADSP Trimedia miscellaneous control
    */
    #define GLOBALREG_ADSP_TM_MISC_REG1  (GLOBALREG_BASE_UNIT1 + 0x408)
    /*
    * Reserved
    */
    #define GLOBALREG_ADSP_TM_MISC_RESERVED_RW (0x0fffffff << 4)
    #define GLOBALREG_ADSP_TM_MISC_RESERVED_SHIFT 4
    /*
    * When de-asserted, prohibits hardware initiated
    * prefetch.
    */
    #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_LS_PREF_ALLOWED_RW (0x01 << 3)
    #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_LS_PREF_ALLOWED_SHIFT 3
    /*
    * When asserted, allows ADSP TM to change its own memory apertures (DRAM and APERT
    * URE 1). The value on this pin should be set before the ADSP TM reset is de-asser
    * ted and may not be changed when ADSP TM is running.
    */
    #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_APERT_MODIFIABLE_RW (0x01 << 2)
    #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_APERT_MODIFIABLE_SHIFT 2
    /*
    * When de-asserted, prohibits the execution of non-aligned load and store operatio
    * ns.
    */
    #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_NONAL_ALLOWED_RW (0x01 << 1)
    #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_NONAL_ALLOWED_SHIFT 1
    /*
    * When asserted, does not allow external devices to access most of the ADSP TM int
    * ernal MMIO registers.
    */
    #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_DEBUG_NOT_ALLOWED_RW (0x01 << 0)
    #define GLOBALREG_ADSP_TM_MISC_ADSP_TM_DEBUG_NOT_ALLOWED_SHIFT 0
    /*
    * ADSP Trimedia observe signals
    */
    #define GLOBALREG_ADSP_TM_OBSERVE_REG1  (GLOBALREG_BASE_UNIT1 + 0x40c)
    /*
    * Reserved
    */
    #define GLOBALREG_ADSP_TM_OBSERVE_RESERVED_R (0x0ffffff << 8)
    #define GLOBALREG_ADSP_TM_OBSERVE_RESERVED_SHIFT 8
    /*
    * ADSP Trimedia observe signal
    */
    #define GLOBALREG_ADSP_TM_OBSERVE_ADSP_TM_OBSERVE_R (0x0ff << 0)
    #define GLOBALREG_ADSP_TM_OBSERVE_ADSP_TM_OBSERVE_SHIFT 0
    /*
    * Memory Power down
    */
    #define GLOBALREG_MEMORY_PD_REG  (GLOBALREG_BASE_UNIT1 + 0x428)
    #define GLOBALREG_MEMORY_PD_GCS_RW (0x01 << 31)
    #define GLOBALREG_MEMORY_PD_GCS_SHIFT 31
    #define GLOBALREG_MEMORY_PD_SDIO_RW (0x01 << 30)
    #define GLOBALREG_MEMORY_PD_SDIO_SHIFT 30
    #define GLOBALREG_MEMORY_PD_DRAW2D_RW (0x01 << 29)
    #define GLOBALREG_MEMORY_PD_DRAW2D_SHIFT 29
    #define GLOBALREG_MEMORY_PD_GMAC0_RW (0x01 << 28)
    #define GLOBALREG_MEMORY_PD_GMAC0_SHIFT 28
    #define GLOBALREG_MEMORY_PD_GMAC1_RW (0x01 << 27)
    #define GLOBALREG_MEMORY_PD_GMAC1_SHIFT 27
    #define GLOBALREG_MEMORY_PD_HDMITX_RW (0x01 << 26)
    #define GLOBALREG_MEMORY_PD_HDMITX_SHIFT 26
    #define GLOBALREG_MEMORY_PD_VPIPE_RW (0x01 << 25)
    #define GLOBALREG_MEMORY_PD_VPIPE_SHIFT 25
    #define GLOBALREG_MEMORY_PD_TURING_RW (0x01 << 24)
    #define GLOBALREG_MEMORY_PD_TURING_SHIFT 24
    #define GLOBALREG_MEMORY_PD_HVSND_RW (0x01 << 23)
    #define GLOBALREG_MEMORY_PD_HVSND_SHIFT 23
    #define GLOBALREG_MEMORY_PD_TAVOR_RW (0x01 << 22)
    #define GLOBALREG_MEMORY_PD_TAVOR_SHIFT 22
    #define GLOBALREG_MEMORY_PD_IMG_SGX531_RW (0x01 << 21)
    #define GLOBALREG_MEMORY_PD_IMG_SGX531_SHIFT 21
    #define GLOBALREG_MEMORY_PD_PMAN_RW (0x01 << 20)
    #define GLOBALREG_MEMORY_PD_PMAN_SHIFT 20
    #define GLOBALREG_MEMORY_PD_TSA_RW (0x01 << 19)
    #define GLOBALREG_MEMORY_PD_TSA_SHIFT 19
    #define GLOBALREG_MEMORY_PD_BLAZER_RW (0x01 << 18)
    #define GLOBALREG_MEMORY_PD_BLAZER_SHIFT 18
    #define GLOBALREG_MEMORY_PD_USB0_RW (0x01 << 17)
    #define GLOBALREG_MEMORY_PD_USB0_SHIFT 17
    #define GLOBALREG_MEMORY_PD_USB1_RW (0x01 << 16)
    #define GLOBALREG_MEMORY_PD_USB1_SHIFT 16
    #define GLOBALREG_MEMORY_PD_DDR_RW (0x01 << 15)
    #define GLOBALREG_MEMORY_PD_DDR_SHIFT 15
    #define GLOBALREG_MEMORY_PD_FMVD_RW (0x01 << 14)
    #define GLOBALREG_MEMORY_PD_FMVD_SHIFT 14
    #define GLOBALREG_MEMORY_PD_IP_DBG_RW (0x01 << 13)
    #define GLOBALREG_MEMORY_PD_IP_DBG_SHIFT 13
    #define GLOBALREG_MEMORY_PD_SATA_RW (0x01 << 12)
    #define GLOBALREG_MEMORY_PD_SATA_SHIFT 12
    #define GLOBALREG_MEMORY_PD_TMCONFIG_RW (0x01 << 11)
    #define GLOBALREG_MEMORY_PD_TMCONFIG_SHIFT 11
    #define GLOBALREG_MEMORY_PD_A9_RW (0x07 << 8)
    #define GLOBALREG_MEMORY_PD_A9_SHIFT 8
    #define GLOBALREG_MEMORY_PD_RESERVED_RW (0x0ff << 0)
    #define GLOBALREG_MEMORY_PD_RESERVED_SHIFT 0
    /*
    * VDSP Trimedia observe signals
    */
    #define GLOBALREG_VDSP_TM_OBSERVE_REG1  (GLOBALREG_BASE_UNIT1 + 0x42c)
    /*
    * Reserved
    */
    #define GLOBALREG_VDSP_TM_OBSERVE_RESERVED_R (0x0ffffff << 8)
    #define GLOBALREG_VDSP_TM_OBSERVE_RESERVED_SHIFT 8
    /*
    * VDSP Trimedia observe signal
    */
    #define GLOBALREG_VDSP_TM_OBSERVE_VDSP_TM_OBSERVE_R (0x0ff << 0)
    #define GLOBALREG_VDSP_TM_OBSERVE_VDSP_TM_OBSERVE_SHIFT 0
    /*
    * Pads configuration Register 0
    */
    #define GLOBALREG_PAD_CONFIGURATION_0_REG  (GLOBALREG_BASE_UNIT1 + 0x430)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_HDMIHTPLG_EPD_RW (0x01 << 31)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_HDMIHTPLG_EPD_SHIFT 31
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_HDMI_CEC_EF_RW (0x01 << 30)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_HDMI_CEC_EF_SHIFT 30
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO017_SDA1_EF_RW (0x01 << 29)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO017_SDA1_EF_SHIFT 29
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO017_SDA1_EGP_RW (0x01 << 28)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO017_SDA1_EGP_SHIFT 28
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO018_SCL1_EF_RW (0x01 << 27)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO018_SCL1_EF_SHIFT 27
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO018_SCL1_EGP_RW (0x01 << 26)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO018_SCL1_EGP_SHIFT 26
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO040_SAGCV0_EHYS_RW (0x01 << 25)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO040_SAGCV0_EHYS_SHIFT 25
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO041_SAGCV1_EHYS_RW (0x01 << 24)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO041_SAGCV1_EHYS_SHIFT 24
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO042_SLNB022K_EHYS_RW (0x01 << 23)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO042_SLNB022K_EHYS_SHIFT 23
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO043_SLNB0DC_EHYS_RW (0x01 << 22)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO043_SLNB0DC_EHYS_SHIFT 22
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO177_SDA2_SDCRDETECT_EF_RW (0x01 << 21)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO177_SDA2_SDCRDETECT_EF_SHIFT 21
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO177_SDA2_SDCRDETECT_EGP_RW (0x01 << 20)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO177_SDA2_SDCRDETECT_EGP_SHIFT 20
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO178_SCL2_SDCRDWP_EF_RW (0x01 << 19)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO178_SCL2_SDCRDWP_EF_SHIFT 19
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO178_SCL2_SDCRDWP_EGP_RW (0x01 << 18)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO178_SCL2_SDCRDWP_EGP_SHIFT 18
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO182_RGMII1RXDV_EHS0_RW (0x01 << 17)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO182_RGMII1RXDV_EHS0_SHIFT 17
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO182_RGMII1RXDV_EHS1_RW (0x01 << 16)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO182_RGMII1RXDV_EHS1_SHIFT 16
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO182_RGMII1RXDV_EHYS_RW (0x01 << 15)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO182_RGMII1RXDV_EHYS_SHIFT 15
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO186_RGMII1RXD0_EHS0_RW (0x01 << 14)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO186_RGMII1RXD0_EHS0_SHIFT 14
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO186_RGMII1RXD0_EHS1_RW (0x01 << 13)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO186_RGMII1RXD0_EHS1_SHIFT 13
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO186_RGMII1RXD0_EHYS_RW (0x01 << 12)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO186_RGMII1RXD0_EHYS_SHIFT 12
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO185_RGMII1RXD1_EHS0_RW (0x01 << 11)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO185_RGMII1RXD1_EHS0_SHIFT 11
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO185_RGMII1RXD1_EHS1_RW (0x01 << 10)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO185_RGMII1RXD1_EHS1_SHIFT 10
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO185_RGMII1RXD1_EHYS_RW (0x01 << 9)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO185_RGMII1RXD1_EHYS_SHIFT 9
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO184_RGMII1RXD2_EHS0_RW (0x01 << 8)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO184_RGMII1RXD2_EHS0_SHIFT 8
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO184_RGMII1RXD2_EHS1_RW (0x01 << 7)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO184_RGMII1RXD2_EHS1_SHIFT 7
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO184_RGMII1RXD2_EHYS_RW (0x01 << 6)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO184_RGMII1RXD2_EHYS_SHIFT 6
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO183_RGMII1RXD3_EHS0_RW (0x01 << 5)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO183_RGMII1RXD3_EHS0_SHIFT 5
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO183_RGMII1RXD3_EHS1_RW (0x01 << 4)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO183_RGMII1RXD3_EHS1_SHIFT 4
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO183_RGMII1RXD3_EHYS_RW (0x01 << 3)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO183_RGMII1RXD3_EHYS_SHIFT 3
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO187_RGMII1RXCK_EHS0_RW (0x01 << 2)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO187_RGMII1RXCK_EHS0_SHIFT 2
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO187_RGMII1RXCK_EHS1_RW (0x01 << 1)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO187_RGMII1RXCK_EHS1_SHIFT 1
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO187_RGMII1RXCK_EHYS_RW (0x01 << 0)
    #define GLOBALREG_PAD_CONFIGURATION_0_AO_PIO187_RGMII1RXCK_EHYS_SHIFT 0
    /*
    * Pads configuration Register 0
    */
    #define GLOBALREG_PAD_CONFIGURATION_1_REG  (GLOBALREG_BASE_UNIT1 + 0x434)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO014_SCL3_UART3TX_EF_RW (0x01 << 31)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO014_SCL3_UART3TX_EF_SHIFT 31
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO014_SCL3_UART3TX_EGP_RW (0x01 << 30)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO014_SCL3_UART3TX_EGP_SHIFT 30
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO015_SDA3_UART3RX_EF_RW (0x01 << 29)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO015_SDA3_UART3RX_EF_SHIFT 29
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO015_SDA3_UART3RX_EGP_RW (0x01 << 28)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO015_SDA3_UART3RX_EGP_SHIFT 28
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO180_RGMII1TXCK_EHS0_RW (0x01 << 27)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO180_RGMII1TXCK_EHS0_SHIFT 27
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO180_RGMII1TXCK_EHS1_RW (0x01 << 26)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO180_RGMII1TXCK_EHS1_SHIFT 26
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO180_RGMII1TXCK_EHYS_RW (0x01 << 25)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO180_RGMII1TXCK_EHYS_SHIFT 25
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO179_RGMII1TXD0_EHS0_RW (0x01 << 24)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO179_RGMII1TXD0_EHS0_SHIFT 24
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO179_RGMII1TXD0_EHS1_RW (0x01 << 23)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO179_RGMII1TXD0_EHS1_SHIFT 23
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO179_RGMII1TXD0_EHYS_RW (0x01 << 22)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO179_RGMII1TXD0_EHYS_SHIFT 22
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO165_RGMII1TXD2_EHS0_RW (0x01 << 21)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO165_RGMII1TXD2_EHS0_SHIFT 21
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO165_RGMII1TXD2_EHS1_RW (0x01 << 20)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO165_RGMII1TXD2_EHS1_SHIFT 20
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO165_RGMII1TXD2_EHYS_RW (0x01 << 19)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO165_RGMII1TXD2_EHYS_SHIFT 19
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO164_RGMII1TXD3_EHS0_RW (0x01 << 18)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO164_RGMII1TXD3_EHS0_SHIFT 18
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO164_RGMII1TXD3_EHS1_RW (0x01 << 17)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO164_RGMII1TXD3_EHS1_SHIFT 17
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO164_RGMII1TXD3_EHYS_RW (0x01 << 16)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO164_RGMII1TXD3_EHYS_SHIFT 16
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO162_RGMII1TXEN_EHS0_RW (0x01 << 15)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO162_RGMII1TXEN_EHS0_SHIFT 15
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO162_RGMII1TXEN_EHS1_RW (0x01 << 14)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO162_RGMII1TXEN_EHS1_SHIFT 14
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO162_RGMII1TXEN_EHYS_RW (0x01 << 13)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO162_RGMII1TXEN_EHYS_SHIFT 13
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO176_RGMII1TXD1_EHS0_RW (0x01 << 12)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO176_RGMII1TXD1_EHS0_SHIFT 12
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO176_RGMII1TXD1_EHS1_RW (0x01 << 11)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO176_RGMII1TXD1_EHS1_SHIFT 11
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO176_RGMII1TXD1_EHYS_RW (0x01 << 10)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO176_RGMII1TXD1_EHYS_SHIFT 10
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO189_RGMII1MDC_EHS0_RW (0x01 << 9)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO189_RGMII1MDC_EHS0_SHIFT 9
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO189_RGMII1MDC_EHS1_RW (0x01 << 8)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO189_RGMII1MDC_EHS1_SHIFT 8
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO189_RGMII1MDC_EHYS_RW (0x01 << 7)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO189_RGMII1MDC_EHYS_SHIFT 7
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO188_RGMII1MDIO_EHS0_RW (0x01 << 6)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO188_RGMII1MDIO_EHS0_SHIFT 6
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO188_RGMII1MDIO_EHS1_RW (0x01 << 5)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO188_RGMII1MDIO_EHS1_SHIFT 5
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO188_RGMII1MDIO_EHYS_RW (0x01 << 4)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO188_RGMII1MDIO_EHYS_SHIFT 4
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO008_UART1CTL2_SSCLK_EHS0_RW (0x01 << 3)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO008_UART1CTL2_SSCLK_EHS0_SHIFT 3
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO008_UART1CTL2_SSCLK_EHS1_RW (0x01 << 2)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO008_UART1CTL2_SSCLK_EHS1_SHIFT 2
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO008_UART1CTL2_SSCLK_EHYS_RW (0x01 << 1)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO008_UART1CTL2_SSCLK_EHYS_SHIFT 1
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO069_UART1RX_SSRX_EHS0_RW (0x01 << 0)
    #define GLOBALREG_PAD_CONFIGURATION_1_AO_PIO069_UART1RX_SSRX_EHS0_SHIFT 0
    /*
    * Pads configuration Register 1
    */
    #define GLOBALREG_PAD_CONFIGURATION_2_REG  (GLOBALREG_BASE_UNIT1 + 0x438)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO069_UART1RX_SSRX_EHS1_RW (0x01 << 31)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO069_UART1RX_SSRX_EHS1_SHIFT 31
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO069_UART1RX_SSRX_EHYS_RW (0x01 << 30)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO069_UART1RX_SSRX_EHYS_SHIFT 30
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO068_UART1TX_SSTX_EHS0_RW (0x01 << 29)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO068_UART1TX_SSTX_EHS0_SHIFT 29
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO068_UART1TX_SSTX_EHS1_RW (0x01 << 28)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO068_UART1TX_SSTX_EHS1_SHIFT 28
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO068_UART1TX_SSTX_EHYS_RW (0x01 << 27)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO068_UART1TX_SSTX_EHYS_SHIFT 27
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO009_UART1CTL1_SSCS_EHS0_RW (0x01 << 26)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO009_UART1CTL1_SSCS_EHS0_SHIFT 26
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO009_UART1CTL1_SSCS_EHS1_RW (0x01 << 25)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO009_UART1CTL1_SSCS_EHS1_SHIFT 25
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO009_UART1CTL1_SSCS_EHYS_RW (0x01 << 24)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO009_UART1CTL1_SSCS_EHYS_SHIFT 24
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO010_IROUT1_INTCLK0_EHS0_RW (0x01 << 23)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO010_IROUT1_INTCLK0_EHS0_SHIFT 23
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO010_IROUT1_INTCLK0_EHS1_RW (0x01 << 22)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO010_IROUT1_INTCLK0_EHS1_SHIFT 22
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO010_IROUT1_INTCLK0_EHYS_RW (0x01 << 21)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO010_IROUT1_INTCLK0_EHYS_SHIFT 21
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO003_UART2TX_SDCRDETECT_656VS_EHYS_RW (0x01 << 20)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO003_UART2TX_SDCRDETECT_656VS_EHYS_SHIFT 20
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO004_UART2RX_SDCRDWP_656HS_EHYS_RW (0x01 << 19)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO004_UART2RX_SDCRDWP_656HS_EHYS_SHIFT 19
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO024_PWM2_SDLED_EHYS_RW (0x01 << 18)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO024_PWM2_SDLED_EHYS_SHIFT 18
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO024_PWM2_SDLED_DS0_RW (0x01 << 17)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO024_PWM2_SDLED_DS0_SHIFT 17
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO024_PWM2_SDLED_DS1_RW (0x01 << 16)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO024_PWM2_SDLED_DS1_SHIFT 16
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO146_PWM3_656FREF_EHYS_RW (0x01 << 15)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO146_PWM3_656FREF_EHYS_SHIFT 15
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO146_PWM3_656FREF_DS0_RW (0x01 << 14)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO146_PWM3_656FREF_DS0_SHIFT 14
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO146_PWM3_656FREF_DS1_RW (0x01 << 13)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO146_PWM3_656FREF_DS1_SHIFT 13
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO016_PWM1_SATALED_EHYS_RW (0x01 << 12)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO016_PWM1_SATALED_EHYS_SHIFT 12
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO016_PWM1_SATALED_DS0_RW (0x01 << 11)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO016_PWM1_SATALED_DS0_SHIFT 11
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO016_PWM1_SATALED_DS1_RW (0x01 << 10)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO016_PWM1_SATALED_DS1_SHIFT 10
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO093_HS3D7_656D7_RGMII1CRS_EHS0_RW (0x01 << 9)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO093_HS3D7_656D7_RGMII1CRS_EHS0_SHIFT 9
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO093_HS3D7_656D7_RGMII1CRS_EHS1_RW (0x01 << 8)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO093_HS3D7_656D7_RGMII1CRS_EHS1_SHIFT 8
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO093_HS3D7_656D7_RGMII1CRS_EHYS_RW (0x01 << 7)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO093_HS3D7_656D7_RGMII1CRS_EHYS_SHIFT 7
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO086_HS3VAL_656D9_EHS0_RW (0x01 << 6)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO086_HS3VAL_656D9_EHS0_SHIFT 6
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO086_HS3VAL_656D9_EHS1_RW (0x01 << 5)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO086_HS3VAL_656D9_EHS1_SHIFT 5
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO086_HS3VAL_656D9_EHYS_RW (0x01 << 4)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO086_HS3VAL_656D9_EHYS_SHIFT 4
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO088_HS3SYNC_656D10_EHS0_RW (0x01 << 3)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO088_HS3SYNC_656D10_EHS0_SHIFT 3
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO088_HS3SYNC_656D10_EHS1_RW (0x01 << 2)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO088_HS3SYNC_656D10_EHS1_SHIFT 2
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO088_HS3SYNC_656D10_EHYS_RW (0x01 << 1)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO088_HS3SYNC_656D10_EHYS_SHIFT 1
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO092_HS3D5_656D5_RGMII1TXER_EHS0_RW (0x01 << 0)
    #define GLOBALREG_PAD_CONFIGURATION_2_AO_PIO092_HS3D5_656D5_RGMII1TXER_EHS0_SHIFT 0
    /*
    * Pads configuration Register 2
    */
    #define GLOBALREG_PAD_CONFIGURATION_3_REG  (GLOBALREG_BASE_UNIT1 + 0x43c)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO092_HS3D5_656D5_RGMII1TXER_EHS1_RW (0x01 << 31)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO092_HS3D5_656D5_RGMII1TXER_EHS1_SHIFT 31
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO092_HS3D5_656D5_RGMII1TXER_EHYS_RW (0x01 << 30)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO092_HS3D5_656D5_RGMII1TXER_EHYS_SHIFT 30
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO085_HS3D0_656D0_EHS0_RW (0x01 << 29)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO085_HS3D0_656D0_EHS0_SHIFT 29
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO085_HS3D0_656D0_EHS1_RW (0x01 << 28)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO085_HS3D0_656D0_EHS1_SHIFT 28
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO085_HS3D0_656D0_EHYS_RW (0x01 << 27)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO085_HS3D0_656D0_EHYS_SHIFT 27
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO089_HS3CLK_656CLK_EHS0_RW (0x01 << 26)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO089_HS3CLK_656CLK_EHS0_SHIFT 26
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO089_HS3CLK_656CLK_EHS1_RW (0x01 << 25)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO089_HS3CLK_656CLK_EHS1_SHIFT 25
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO089_HS3CLK_656CLK_EHYS_RW (0x01 << 24)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO089_HS3CLK_656CLK_EHYS_SHIFT 24
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO122_HS2D2_I2SINSCK_EHS0_RW (0x01 << 23)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO122_HS2D2_I2SINSCK_EHS0_SHIFT 23
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO122_HS2D2_I2SINSCK_EHS1_RW (0x01 << 22)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO122_HS2D2_I2SINSCK_EHS1_SHIFT 22
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO122_HS2D2_I2SINSCK_EHYS_RW (0x01 << 21)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO122_HS2D2_I2SINSCK_EHYS_SHIFT 21
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO121_HS2D1_I2SINOSCLK_EHS0_RW (0x01 << 20)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO121_HS2D1_I2SINOSCLK_EHS0_SHIFT 20
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO121_HS2D1_I2SINOSCLK_EHS1_RW (0x01 << 19)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO121_HS2D1_I2SINOSCLK_EHS1_SHIFT 19
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO121_HS2D1_I2SINOSCLK_EHYS_RW (0x01 << 18)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO121_HS2D1_I2SINOSCLK_EHYS_SHIFT 18
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO090_HS3D1_656D1_RGMII1RXER_EHS0_RW (0x01 << 17)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO090_HS3D1_656D1_RGMII1RXER_EHS0_SHIFT 17
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO090_HS3D1_656D1_RGMII1RXER_EHS1_RW (0x01 << 16)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO090_HS3D1_656D1_RGMII1RXER_EHS1_SHIFT 16
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO090_HS3D1_656D1_RGMII1RXER_EHYS_RW (0x01 << 15)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO090_HS3D1_656D1_RGMII1RXER_EHYS_SHIFT 15
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO087_HS3ERR_MEMWRN_656D8_EHYS_RW (0x01 << 14)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO087_HS3ERR_MEMWRN_656D8_EHYS_SHIFT 14
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO082_HS3D6_656D6_RGMII1COL_EHS0_RW (0x01 << 13)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO082_HS3D6_656D6_RGMII1COL_EHS0_SHIFT 13
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO082_HS3D6_656D6_RGMII1COL_EHS1_RW (0x01 << 12)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO082_HS3D6_656D6_RGMII1COL_EHS1_SHIFT 12
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO082_HS3D6_656D6_RGMII1COL_EHYS_RW (0x01 << 11)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO082_HS3D6_656D6_RGMII1COL_EHYS_SHIFT 11
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO083_HS3D4_656D4_UART2CTL3_EHS0_RW (0x01 << 10)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO083_HS3D4_656D4_UART2CTL3_EHS0_SHIFT 10
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO083_HS3D4_656D4_UART2CTL3_EHS1_RW (0x01 << 9)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO083_HS3D4_656D4_UART2CTL3_EHS1_SHIFT 9
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO083_HS3D4_656D4_UART2CTL3_EHYS_RW (0x01 << 8)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO083_HS3D4_656D4_UART2CTL3_EHYS_SHIFT 8
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO091_HS3D3_656D3_UART2CTL2_EHS0_RW (0x01 << 7)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO091_HS3D3_656D3_UART2CTL2_EHS0_SHIFT 7
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO091_HS3D3_656D3_UART2CTL2_EHS1_RW (0x01 << 6)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO091_HS3D3_656D3_UART2CTL2_EHS1_SHIFT 6
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO091_HS3D3_656D3_UART2CTL2_EHYS_RW (0x01 << 5)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO091_HS3D3_656D3_UART2CTL2_EHYS_SHIFT 5
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO084_HS3D2_656D2_UART2CTL1_EHS0_RW (0x01 << 4)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO084_HS3D2_656D2_UART2CTL1_EHS0_SHIFT 4
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO084_HS3D2_656D2_UART2CTL1_EHS1_RW (0x01 << 3)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO084_HS3D2_656D2_UART2CTL1_EHS1_SHIFT 3
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO084_HS3D2_656D2_UART2CTL1_EHYS_RW (0x01 << 2)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO084_HS3D2_656D2_UART2CTL1_EHYS_SHIFT 2
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO174_HS2D5_I2SIND1_EHS0_RW (0x01 << 1)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO174_HS2D5_I2SIND1_EHS0_SHIFT 1
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO174_HS2D5_I2SIND1_EHS1_RW (0x01 << 0)
    #define GLOBALREG_PAD_CONFIGURATION_3_AO_PIO174_HS2D5_I2SIND1_EHS1_SHIFT 0
    /*
    * Miscellaneous Status
    */
    #define GLOBALREG_REG_MISC_STATUS_REG  (GLOBALREG_BASE_UNIT1 + 0x440)
    /*
    * Reserved
    */
    #define GLOBALREG_REG_MISC_STATUS_RESERVED_R (0x01fffffff << 3)
    #define GLOBALREG_REG_MISC_STATUS_RESERVED_SHIFT 3
    /*
    * When set, indicates that the debugger wants the A9 to be in emulated power-down,
    *  instead of actual power-down (read-only).
    */
    #define GLOBALREG_REG_MISC_STATUS_A9_DBGNOPWRDWN_R (0x01 << 2)
    #define GLOBALREG_REG_MISC_STATUS_A9_DBGNOPWRDWN_SHIFT 2
    /*
    * L2 Cache controller is idle when set (read-only).
    */
    #define GLOBALREG_REG_MISC_STATUS_L2CACHE_IDLE_R (0x01 << 1)
    #define GLOBALREG_REG_MISC_STATUS_L2CACHE_IDLE_SHIFT 1
    /*
    * HDMI Hotplug status (read-only).
    * This register bit reflects the state of the HDMI hotplug input pin.
    */
    #define GLOBALREG_REG_MISC_STATUS_HDMI_HOTPLUG_IN_R (0x01 << 0)
    #define GLOBALREG_REG_MISC_STATUS_HDMI_HOTPLUG_IN_SHIFT 0
    /*
    * Pads configuration Register 2
    */
    #define GLOBALREG_PAD_CONFIGURATION_4_REG  (GLOBALREG_BASE_UNIT1 + 0x448)
    #define GLOBALREG_PAD_CONFIGURATION_4_RESERVED_RW (0x01 << 31)
    #define GLOBALREG_PAD_CONFIGURATION_4_RESERVED_SHIFT 31
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO174_HS2D5_I2SIND1_EHYS_RW (0x01 << 30)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO174_HS2D5_I2SIND1_EHYS_SHIFT 30
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO175_HS2D6_I2SIND2_EHS0_RW (0x01 << 29)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO175_HS2D6_I2SIND2_EHS0_SHIFT 29
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO175_HS2D6_I2SIND2_EHS1_RW (0x01 << 28)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO175_HS2D6_I2SIND2_EHS1_SHIFT 28
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO175_HS2D6_I2SIND2_EHYS_RW (0x01 << 27)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO175_HS2D6_I2SIND2_EHYS_SHIFT 27
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO169_HS2D7_I2SIND3_EHS0_RW (0x01 << 26)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO169_HS2D7_I2SIND3_EHS0_SHIFT 26
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO169_HS2D7_I2SIND3_EHS1_RW (0x01 << 25)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO169_HS2D7_I2SIND3_EHS1_SHIFT 25
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO169_HS2D7_I2SIND3_EHYS_RW (0x01 << 24)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO169_HS2D7_I2SIND3_EHYS_SHIFT 24
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO130_HS2VAL_656D11_EHYS_RW (0x01 << 23)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO130_HS2VAL_656D11_EHYS_SHIFT 23
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO129_HS2SYNC_656D12_EHYS_RW (0x01 << 22)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO129_HS2SYNC_656D12_EHYS_SHIFT 22
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO120_HS2D0_656D13_EHYS_RW (0x01 << 21)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO120_HS2D0_656D13_EHYS_SHIFT 21
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO119_HS2CLK_656D14_EHS0_RW (0x01 << 20)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO119_HS2CLK_656D14_EHS0_SHIFT 20
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO119_HS2CLK_656D14_EHS1_RW (0x01 << 19)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO119_HS2CLK_656D14_EHS1_SHIFT 19
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO119_HS2CLK_656D14_EHYS_RW (0x01 << 18)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO119_HS2CLK_656D14_EHYS_SHIFT 18
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO128_HS2ERR_MEMRDN_656D15_EHYS_RW (0x01 << 17)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO128_HS2ERR_MEMRDN_656D15_EHYS_SHIFT 17
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO173_HS2D4_I2SIND0_EHS0_RW (0x01 << 16)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO173_HS2D4_I2SIND0_EHS0_SHIFT 16
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO173_HS2D4_I2SIND0_EHS1_RW (0x01 << 15)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO173_HS2D4_I2SIND0_EHS1_SHIFT 15
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO173_HS2D4_I2SIND0_EHYS_RW (0x01 << 14)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO173_HS2D4_I2SIND0_EHYS_SHIFT 14
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO172_HS2D3_I2SINWS_EHS0_RW (0x01 << 13)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO172_HS2D3_I2SINWS_EHS0_SHIFT 13
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO172_HS2D3_I2SINWS_EHS1_RW (0x01 << 12)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO172_HS2D3_I2SINWS_EHS1_SHIFT 12
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO172_HS2D3_I2SINWS_EHYS_RW (0x01 << 11)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO172_HS2D3_I2SINWS_EHYS_SHIFT 11
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO075_SM1CMDVCCN_HS6VAL_I2SOUTSCK_EHYS_RW (0x01 << 10)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO075_SM1CMDVCCN_HS6VAL_I2SOUTSCK_EHYS_SHIFT 10
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO013_SM1RST_HS6SYNC_I2SOUTWS_EHYS_RW (0x01 << 9)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO013_SM1RST_HS6SYNC_I2SOUTWS_EHYS_SHIFT 9
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO013_SM1RST_HS6SYNC_I2SOUTWS_EPUN_RW (0x01 << 8)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO013_SM1RST_HS6SYNC_I2SOUTWS_EPUN_SHIFT 8
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO074_SM1CLK_HS6ERR_SDLED_EHYS_RW (0x01 << 7)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO074_SM1CLK_HS6ERR_SDLED_EHYS_SHIFT 7
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO074_SM1CLK_HS6ERR_SDLED_EPD_RW (0x01 << 6)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO074_SM1CLK_HS6ERR_SDLED_EPD_SHIFT 6
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO074_SM1CLK_HS6ERR_SDLED_EPUN_RW (0x01 << 5)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO074_SM1CLK_HS6ERR_SDLED_EPUN_SHIFT 5
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EHS0_RW (0x01 << 4)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EHS0_SHIFT 4
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EHS1_RW (0x01 << 3)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EHS1_SHIFT 3
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EHYS_RW (0x01 << 2)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EHYS_SHIFT 2
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EPUN_RW (0x01 << 1)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO073_SM1IO_HS6CLK_I2SOUTOSCLK_UART2TX_EPUN_SHIFT 1
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO011_SM1OFFN_HS6D0_I2SOUTD1_UART2RX_EHYS_RW (0x01 << 0)
    #define GLOBALREG_PAD_CONFIGURATION_4_AO_PIO011_SM1OFFN_HS6D0_I2SOUTD1_UART2RX_EHYS_SHIFT 0
    /*
    * Pads configuration Register 2
    */
    #define GLOBALREG_PAD_CONFIGURATION_5_REG  (GLOBALREG_BASE_UNIT1 + 0x44c)
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS3N_EHS0_RW (0x01 << 31)
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS3N_EHS0_SHIFT 31
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS3N_EHS1_RW (0x01 << 30)
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS3N_EHS1_SHIFT 30
    #define GLOBALREG_PAD_CONFIGURATION_5_IOWN_EHS0_RW (0x01 << 29)
    #define GLOBALREG_PAD_CONFIGURATION_5_IOWN_EHS0_SHIFT 29
    #define GLOBALREG_PAD_CONFIGURATION_5_IOWN_EHS1_RW (0x01 << 28)
    #define GLOBALREG_PAD_CONFIGURATION_5_IOWN_EHS1_SHIFT 28
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO196_IOA26_NANDRB0_EHYS_RW (0x01 << 27)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO196_IOA26_NANDRB0_EHYS_SHIFT 27
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO064_IOA20_SDDATA1_EHYS_RW (0x01 << 26)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO064_IOA20_SDDATA1_EHYS_SHIFT 26
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO063_IOA19_SDDATA0_EHYS_RW (0x01 << 25)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO063_IOA19_SDDATA0_EHYS_SHIFT 25
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS4N_SDCLK_EHS0_RW (0x01 << 24)
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS4N_SDCLK_EHS0_SHIFT 24
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS4N_SDCLK_EHS1_RW (0x01 << 23)
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS4N_SDCLK_EHS1_SHIFT 23
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS1N_INTCLK1_EHS0_RW (0x01 << 22)
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS1N_INTCLK1_EHS0_SHIFT 22
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS1N_INTCLK1_EHS1_RW (0x01 << 21)
    #define GLOBALREG_PAD_CONFIGURATION_5_IO_CS1N_INTCLK1_EHS1_SHIFT 21
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO062_IOA15_EHYS_RW (0x01 << 20)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO062_IOA15_EHYS_SHIFT 20
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO070_IOREGN_EHYS_RW (0x01 << 19)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO070_IOREGN_EHYS_SHIFT 19
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO171_IOA23_NANDRB3_EHYS_RW (0x01 << 18)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO171_IOA23_NANDRB3_EHYS_SHIFT 18
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO170_IOA22_SDDATA3_EHYS_RW (0x01 << 17)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO170_IOA22_SDDATA3_EHYS_SHIFT 17
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO007_IOA18_NANDALE_EHYS_RW (0x01 << 16)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO007_IOA18_NANDALE_EHYS_SHIFT 16
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO006_IOA17_NANDCLE_EHYS_RW (0x01 << 15)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO006_IOA17_NANDCLE_EHYS_SHIFT 15
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO065_IOA21_SDDATA2_EHYS_RW (0x01 << 14)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO065_IOA21_SDDATA2_EHYS_SHIFT 14
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO005_IOA16_EHYS_RW (0x01 << 13)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO005_IOA16_EHYS_SHIFT 13
    #define GLOBALREG_PAD_CONFIGURATION_5_IORN_EHS0_RW (0x01 << 12)
    #define GLOBALREG_PAD_CONFIGURATION_5_IORN_EHS0_SHIFT 12
    #define GLOBALREG_PAD_CONFIGURATION_5_IORN_EHS1_RW (0x01 << 11)
    #define GLOBALREG_PAD_CONFIGURATION_5_IORN_EHS1_SHIFT 11
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO194_IOA24_NANDRB2_EHYS_RW (0x01 << 10)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO194_IOA24_NANDRB2_EHYS_SHIFT 10
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO195_IOA25_NANDRB1_EHYS_RW (0x01 << 9)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO195_IOA25_NANDRB1_EHYS_SHIFT 9
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO077_USB2VBUSDRIVE_EHYS_RW (0x01 << 8)
    #define GLOBALREG_PAD_CONFIGURATION_5_PIO077_USB2VBUSDRIVE_EHYS_SHIFT 8
    #define GLOBALREG_PAD_CONFIGURATION_5_RESERVED_RW (0x01 << 7)
    #define GLOBALREG_PAD_CONFIGURATION_5_RESERVED_SHIFT 7
    #define GLOBALREG_PAD_CONFIGURATION_5_HDMI_SCL1_EF_RW (0x01 << 6)
    #define GLOBALREG_PAD_CONFIGURATION_5_HDMI_SCL1_EF_SHIFT 6
    #define GLOBALREG_PAD_CONFIGURATION_5_RESERVED26_RW (0x01 << 5)
    #define GLOBALREG_PAD_CONFIGURATION_5_RESERVED26_SHIFT 5
    #define GLOBALREG_PAD_CONFIGURATION_5_RESERVED27_RW (0x01 << 4)
    #define GLOBALREG_PAD_CONFIGURATION_5_RESERVED27_SHIFT 4
    #define GLOBALREG_PAD_CONFIGURATION_5_HDMI_SDA1_EF_RW (0x01 << 3)
    #define GLOBALREG_PAD_CONFIGURATION_5_HDMI_SDA1_EF_SHIFT 3
    #define GLOBALREG_PAD_CONFIGURATION_5_RESERVED29_RW (0x01 << 2)
    #define GLOBALREG_PAD_CONFIGURATION_5_RESERVED29_SHIFT 2
    #define GLOBALREG_PAD_CONFIGURATION_5_TDO_EHS0_RW (0x01 << 1)
    #define GLOBALREG_PAD_CONFIGURATION_5_TDO_EHS0_SHIFT 1
    #define GLOBALREG_PAD_CONFIGURATION_5_TDO_EHS1_RW (0x01 << 0)
    #define GLOBALREG_PAD_CONFIGURATION_5_TDO_EHS1_SHIFT 0
    /*
    * Pads configuration Register 2
    */
    #define GLOBALREG_PAD_CONFIGURATION_6_REG  (GLOBALREG_BASE_UNIT1 + 0x450)
    #define GLOBALREG_PAD_CONFIGURATION_6_AO_PIO042_SLNB022K_EHS0_RW (0x01 << 8)
    #define GLOBALREG_PAD_CONFIGURATION_6_AO_PIO042_SLNB022K_EHS0_SHIFT 8
    #define GLOBALREG_PAD_CONFIGURATION_6_RESERVED_RW (0x01ffffff << 7)
    #define GLOBALREG_PAD_CONFIGURATION_6_RESERVED_SHIFT 7
    #define GLOBALREG_PAD_CONFIGURATION_6_AO_PIO042_SLNB022K_EHS1_RW (0x01 << 7)
    #define GLOBALREG_PAD_CONFIGURATION_6_AO_PIO042_SLNB022K_EHS1_SHIFT 7
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO045_USB1VBUSDRIVE_EHYS_RW (0x01 << 6)
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO045_USB1VBUSDRIVE_EHYS_SHIFT 6
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO039_AUDTXSPDIF_INTCLK0_EHS0_RW (0x01 << 5)
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO039_AUDTXSPDIF_INTCLK0_EHS0_SHIFT 5
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO039_AUDTXSPDIF_INTCLK0_EHS1_RW (0x01 << 4)
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO039_AUDTXSPDIF_INTCLK0_EHS1_SHIFT 4
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO197_ETHLED0_DS0_RW (0x01 << 3)
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO197_ETHLED0_DS0_SHIFT 3
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO197_ETHLED0_DS1_RW (0x01 << 2)
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO197_ETHLED0_DS1_SHIFT 2
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO198_ETHLED1_DS0_RW (0x01 << 1)
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO198_ETHLED1_DS0_SHIFT 1
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO198_ETHLED1_DS1_RW (0x01 << 0)
    #define GLOBALREG_PAD_CONFIGURATION_6_PIO198_ETHLED1_DS1_SHIFT 0
    /*
    * Spare Control
    */
    #define GLOBALREG_GLBREG_MISC1_REG  (GLOBALREG_BASE_UNIT1 + 0x500)
    #define GLOBALREG_GLBREG_MISC1_RESERVED_RW (0x0fff << 20)
    #define GLOBALREG_GLBREG_MISC1_RESERVED_SHIFT 20
    #define GLOBALREG_GLBREG_MISC1_GLBREG_UART_INT_SEL_RW (0x01 << 19)
    #define GLOBALREG_GLBREG_MISC1_GLBREG_UART_INT_SEL_SHIFT 19
    #define GLOBALREG_GLBREG_MISC1_GMAC0_MAC_ENDIANNESS_RW (0x01 << 18)
    #define GLOBALREG_GLBREG_MISC1_GMAC0_MAC_ENDIANNESS_SHIFT 18
    #define GLOBALREG_GLBREG_MISC1_GMAC1_MAC_ENDIANNESS_RW (0x01 << 17)
    #define GLOBALREG_GLBREG_MISC1_GMAC1_MAC_ENDIANNESS_SHIFT 17
    #define GLOBALREG_GLBREG_MISC1_A9_DBGSWENABLE_RW (0x01 << 16)
    #define GLOBALREG_GLBREG_MISC1_A9_DBGSWENABLE_SHIFT 16
    #define GLOBALREG_GLBREG_MISC1_RESERVED5_RW (0x03ff << 6)
    #define GLOBALREG_GLBREG_MISC1_RESERVED5_SHIFT 6
    #define GLOBALREG_GLBREG_MISC1_GLBREG_DEMOD_MODE_RW (0x01 << 5)
    #define GLOBALREG_GLBREG_MISC1_GLBREG_DEMOD_MODE_SHIFT 5
    #define GLOBALREG_GLBREG_MISC1_RESERVED7_RW (0x03 << 3)
    #define GLOBALREG_GLBREG_MISC1_RESERVED7_SHIFT 3
    #define GLOBALREG_GLBREG_MISC1_ADAC_TEST_CLK_SEL_RW (0x01 << 2)
    #define GLOBALREG_GLBREG_MISC1_ADAC_TEST_CLK_SEL_SHIFT 2
    #define GLOBALREG_GLBREG_MISC1_ADAC_FIFO_BYPASS_RW (0x01 << 1)
    #define GLOBALREG_GLBREG_MISC1_ADAC_FIFO_BYPASS_SHIFT 1
    #define GLOBALREG_GLBREG_MISC1_AUPLL_DIV_UPDATE_RW (0x01 << 0)
    #define GLOBALREG_GLBREG_MISC1_AUPLL_DIV_UPDATE_SHIFT 0
    /*
    * Spare Control
    */
    #define GLOBALREG_GLBREG_MISC2_REG  (GLOBALREG_BASE_UNIT1 + 0x504)
    #define GLOBALREG_GLBREG_MISC2_MR1_BOOT_MTL_ENABLE_RW (0x01 << 29)
    #define GLOBALREG_GLBREG_MISC2_MR1_BOOT_MTL_ENABLE_SHIFT 29
    #define GLOBALREG_GLBREG_MISC2_MR1_BOOT_MTL_WR_ENABLE_RW (0x01 << 28)
    #define GLOBALREG_GLBREG_MISC2_MR1_BOOT_MTL_WR_ENABLE_SHIFT 28
    #define GLOBALREG_GLBREG_MISC2_GLBREG_MISC2_RW (0x0ffffffff << 0)
    #define GLOBALREG_GLBREG_MISC2_GLBREG_MISC2_SHIFT 0
    /*
    * Spare Control
    */
    #define GLOBALREG_GLBREG_MISC3_REG  (GLOBALREG_BASE_UNIT1 + 0x508)
    #define GLOBALREG_GLBREG_MISC3_DDR3_RET_EN_RW (0x01 << 15)
    #define GLOBALREG_GLBREG_MISC3_DDR3_RET_EN_SHIFT 15
    #define GLOBALREG_GLBREG_MISC3_ETHLED2_SEL_RW (0x01f << 10)
    #define GLOBALREG_GLBREG_MISC3_ETHLED2_SEL_SHIFT 10
    #define GLOBALREG_GLBREG_MISC3_ETHLED1_SEL_RW (0x01f << 5)
    #define GLOBALREG_GLBREG_MISC3_ETHLED1_SEL_SHIFT 5
    #define GLOBALREG_GLBREG_MISC3_GLBREG_MISC3_RW (0x0ffffffff << 0)
    #define GLOBALREG_GLBREG_MISC3_GLBREG_MISC3_SHIFT 0
    #define GLOBALREG_GLBREG_MISC3_ETHLED0_SEL_RW (0x01f << 0)
    #define GLOBALREG_GLBREG_MISC3_ETHLED0_SEL_SHIFT 0
    /*
    * Spare Control
    */
    #define GLOBALREG_GLBREG_MISC4_REG  (GLOBALREG_BASE_UNIT1 + 0x50c)
    #define GLOBALREG_GLBREG_MISC4_RESERVED_RW (0x0ffffffff << 0)
    #define GLOBALREG_GLBREG_MISC4_RESERVED_SHIFT 0
    /*
    * Lock command register
    */
    #define GLOBALREG_LOCK_CMD_REG1  (GLOBALREG_BASE_UNIT1 + 0x510)
    /*
    * The LOCKCMD register controls write access to the LOCKSTAT register. The LOCKSTA
    * T register must be unlocked before write operations are accepted. The LOCKSTAT r
    * egister is unlocked by performing two back-to-back writes to the LOCKCMD registe
    * r using write data of 0xF8 for the first write and 0x2B for the second write. Th
    * e LOCKSTAT register is unlocked only for the next write operation and then goes 
    * back to the locked state
    */
    #define GLOBALREG_LOCK_CMD_UNLOCK_DATA_W (0x0ffffffff << 0)
    #define GLOBALREG_LOCK_CMD_UNLOCK_DATA_SHIFT 0
    /*
    * Lock status register
    */
    #define GLOBALREG_LOCK_STATUS_REG1  (GLOBALREG_BASE_UNIT1 + 0x514)
    /*
    * Reserved
    */
    #define GLOBALREG_LOCK_STATUS_RESERVED_RW (0x0ff << 24)
    #define GLOBALREG_LOCK_STATUS_RESERVED_SHIFT 24
    /*
    * The LOCKSTAT register allows access to system critical registers to be controlle
    * d. The register is reset at power-on, to enable write access to the controlled r
    * egisters. The listed system registers may be protected from accidental change by
    *  setting the corresponding bit in this register. The Resource Lock Register can 
    * not be written until access is enabled through the Resource Lock Enable register
    * . For each of the entries, a 1 indicates the resource has been locked (cannot be
    *  written), and 0 indicates the resource is open (can be written). lock for timer
    *  registers
    */
    #define GLOBALREG_LOCK_STATUS_TIMER_LOCK_RW (0x0ffffff << 0)
    #define GLOBALREG_LOCK_STATUS_TIMER_LOCK_SHIFT 0
    /*
    * AFE Top control
    */
    #define GLOBALREG_SDIO_CTRL0_REG1  (GLOBALREG_BASE_UNIT1 + 0x520)
    /*
    * Reserved
    */
    #define GLOBALREG_SDIO_CTRL0_RESERVED_RW (0x01fffff << 11)
    #define GLOBALREG_SDIO_CTRL0_RESERVED_SHIFT 11
    #define GLOBALREG_SDIO_CTRL0_CMD_CONFLICT_DIS_RW (0x01 << 10)
    #define GLOBALREG_SDIO_CTRL0_CMD_CONFLICT_DIS_SHIFT 10
    #define GLOBALREG_SDIO_CTRL0_IP_TAP_EN_RW (0x01 << 9)
    #define GLOBALREG_SDIO_CTRL0_IP_TAP_EN_SHIFT 9
    #define GLOBALREG_SDIO_CTRL0_FIXED_TAP_DELAY_RW (0x03f << 3)
    #define GLOBALREG_SDIO_CTRL0_FIXED_TAP_DELAY_SHIFT 3
    #define GLOBALREG_SDIO_CTRL0_RETUNING_REQUIRE_RW (0x01 << 2)
    #define GLOBALREG_SDIO_CTRL0_RETUNING_REQUIRE_SHIFT 2
    #define GLOBALREG_SDIO_CTRL0_DELAY_CTRL_RW (0x03 << 0)
    #define GLOBALREG_SDIO_CTRL0_DELAY_CTRL_SHIFT 0
    /*
    * AFE Top control
    */
    #define GLOBALREG_SDIO_CTRL1_REG1  (GLOBALREG_BASE_UNIT1 + 0x524)
    /*
    * Reserved
    */
    #define GLOBALREG_SDIO_CTRL1_RESERVED_RW (0x03f << 26)
    #define GLOBALREG_SDIO_CTRL1_RESERVED_SHIFT 26
    #define GLOBALREG_SDIO_CTRL1_DEFAULT_PRESET_IN_RW (0x01fff << 13)
    #define GLOBALREG_SDIO_CTRL1_DEFAULT_PRESET_IN_SHIFT 13
    #define GLOBALREG_SDIO_CTRL1_INIT_PRESET_IN_RW (0x01fff << 0)
    #define GLOBALREG_SDIO_CTRL1_INIT_PRESET_IN_SHIFT 0
    /*
    * AFE Top control
    */
    #define GLOBALREG_SDIO_CTRL2_REG1  (GLOBALREG_BASE_UNIT1 + 0x528)
    /*
    * Reserved
    */
    #define GLOBALREG_SDIO_CTRL2_RESERVED_RW (0x03f << 26)
    #define GLOBALREG_SDIO_CTRL2_RESERVED_SHIFT 26
    #define GLOBALREG_SDIO_CTRL2_SDR12_PRESET_IN_RW (0x01fff << 13)
    #define GLOBALREG_SDIO_CTRL2_SDR12_PRESET_IN_SHIFT 13
    #define GLOBALREG_SDIO_CTRL2_HIGH_SPEED_PRESET_IN_RW (0x01fff << 0)
    #define GLOBALREG_SDIO_CTRL2_HIGH_SPEED_PRESET_IN_SHIFT 0
    /*
    * AFE Top control
    */
    #define GLOBALREG_SDIO_CTRL3_REG1  (GLOBALREG_BASE_UNIT1 + 0x52c)
    /*
    * Reserved
    */
    #define GLOBALREG_SDIO_CTRL3_RESERVED_RW (0x03f << 26)
    #define GLOBALREG_SDIO_CTRL3_RESERVED_SHIFT 26
    #define GLOBALREG_SDIO_CTRL3_SDR25_PRESET_IN_RW (0x01fff << 13)
    #define GLOBALREG_SDIO_CTRL3_SDR25_PRESET_IN_SHIFT 13
    #define GLOBALREG_SDIO_CTRL3_SDR50_PRESET_IN_RW (0x01fff << 0)
    #define GLOBALREG_SDIO_CTRL3_SDR50_PRESET_IN_SHIFT 0
    /*
    * AFE Top control
    */
    #define GLOBALREG_SDIO_CTRL4_REG1  (GLOBALREG_BASE_UNIT1 + 0x530)
    /*
    * Reserved
    */
    #define GLOBALREG_SDIO_CTRL4_RESERVED_RW (0x03f << 26)
    #define GLOBALREG_SDIO_CTRL4_RESERVED_SHIFT 26
    #define GLOBALREG_SDIO_CTRL4_DDR50_PRESET_IN_RW (0x01fff << 13)
    #define GLOBALREG_SDIO_CTRL4_DDR50_PRESET_IN_SHIFT 13
    #define GLOBALREG_SDIO_CTRL4_SDR104_PRESET_IN_RW (0x01fff << 0)
    #define GLOBALREG_SDIO_CTRL4_SDR104_PRESET_IN_SHIFT 0
    /*
    * AFE Top control
    */
    #define GLOBALREG_AFE_CTRL0_REG1  (GLOBALREG_BASE_UNIT1 + 0x800)
    /*
    * Reserved
    */
    #define GLOBALREG_AFE_CTRL0_RESERVED_RW (0x01ffff << 15)
    #define GLOBALREG_AFE_CTRL0_RESERVED_SHIFT 15
    /*
    * bypass test mode input
    */
    #define GLOBALREG_AFE_CTRL0_RESERVED1_RW (0x01 << 14)
    #define GLOBALREG_AFE_CTRL0_RESERVED1_SHIFT 14
    /*
    * power down input
    */
    #define GLOBALREG_AFE_CTRL0_RESERVED2_RW (0x01 << 13)
    #define GLOBALREG_AFE_CTRL0_RESERVED2_SHIFT 13
    /*
    * oscillator low / high transconductance selection inputs
    */
    #define GLOBALREG_AFE_CTRL0_XTAL_HF0_RW (0x01 << 12)
    #define GLOBALREG_AFE_CTRL0_XTAL_HF0_SHIFT 12
    /*
    * oscillator low / high transconductance selection inputs
    */
    #define GLOBALREG_AFE_CTRL0_XTAL_HF1_RW (0x01 << 11)
    #define GLOBALREG_AFE_CTRL0_XTAL_HF1_SHIFT 11
    /*
    * oscillator low / high transconductance selection inputs
    */
    #define GLOBALREG_AFE_CTRL0_RESERVED5_RW (0x01 << 10)
    #define GLOBALREG_AFE_CTRL0_RESERVED5_SHIFT 10
    /*
    * low jitter mode input
    */
    #define GLOBALREG_AFE_CTRL0_XTAL_HP_RW (0x01 << 9)
    #define GLOBALREG_AFE_CTRL0_XTAL_HP_SHIFT 9
    /*
    * Reserved
    */
    #define GLOBALREG_AFE_CTRL0_RESERVED7_RW (0x01ff << 0)
    #define GLOBALREG_AFE_CTRL0_RESERVED7_SHIFT 0
    /*
    * Left and Right Channel Audio DAC Control
    */
    #define GLOBALREG_ADAC_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x804)
    /*
    * Reserved
    */
    #define GLOBALREG_ADAC_CTRL_RESERVED_RW (0x07fffffff << 1)
    #define GLOBALREG_ADAC_CTRL_RESERVED_SHIFT 1
    /*
    * ADAC SW reset active low
    */
    #define GLOBALREG_ADAC_CTRL_ADAC_RESET_N_RW (0x01 << 0)
    #define GLOBALREG_ADAC_CTRL_ADAC_RESET_N_SHIFT 0
    /*
    * AFE spare inputs (reserved for future use)
    */
    #define GLOBALREG_AFE_SPARE_IN_REG1  (GLOBALREG_BASE_UNIT1 + 0x824)
    /*
    * Reserved
    */
    #define GLOBALREG_AFE_SPARE_IN_RESERVED_RW (0x0ff << 24)
    #define GLOBALREG_AFE_SPARE_IN_RESERVED_SHIFT 24
    /*
    * Spare control inputs for IPs through vdac_routing for general use
    */
    #define GLOBALREG_AFE_SPARE_IN_VDAC_ROUTING_SPARE_IN_RW (0x0ff << 16)
    #define GLOBALREG_AFE_SPARE_IN_VDAC_ROUTING_SPARE_IN_SHIFT 16
    /*
    * Spare control inputs for IPs through afe_routing1 for general use
    */
    #define GLOBALREG_AFE_SPARE_IN_AFE_ROUTING1_SPARE_IN_RW (0x0ff << 8)
    #define GLOBALREG_AFE_SPARE_IN_AFE_ROUTING1_SPARE_IN_SHIFT 8
    /*
    * Spare control inputs for IPs through afe_routing0 for general use
    */
    #define GLOBALREG_AFE_SPARE_IN_AFE_ROUTING0_SPARE_IN_RW (0x0ff << 0)
    #define GLOBALREG_AFE_SPARE_IN_AFE_ROUTING0_SPARE_IN_SHIFT 0
    /*
    * AFE spare outputs (reserved for future use)
    */
    #define GLOBALREG_AFE_SPARE_OUT_REG1  (GLOBALREG_BASE_UNIT1 + 0x828)
    /*
    * Reserved
    */
    #define GLOBALREG_AFE_SPARE_OUT_RESERVED_R (0x0ff << 24)
    #define GLOBALREG_AFE_SPARE_OUT_RESERVED_SHIFT 24
    /*
    * Spare control outputs for IPs through vdac_routing for general use
    */
    #define GLOBALREG_AFE_SPARE_OUT_VDAC_ROUTING_SPARE_OUT_R (0x0ff << 16)
    #define GLOBALREG_AFE_SPARE_OUT_VDAC_ROUTING_SPARE_OUT_SHIFT 16
    /*
    * Spare control outputs for IPs through afe_routing1 for general use
    */
    #define GLOBALREG_AFE_SPARE_OUT_AFE_ROUTING1_SPARE_OUT_R (0x0ff << 8)
    #define GLOBALREG_AFE_SPARE_OUT_AFE_ROUTING1_SPARE_OUT_SHIFT 8
    /*
    * Spare control outputs for IPs through afe_routing0 for general use
    */
    #define GLOBALREG_AFE_SPARE_OUT_AFE_ROUTING0_SPARE_OUT_R (0x0ff << 0)
    #define GLOBALREG_AFE_SPARE_OUT_AFE_ROUTING0_SPARE_OUT_SHIFT 0
    /*
    * FADC Status
    */
    #define GLOBALREG_FADC_STAT_REG1  (GLOBALREG_BASE_UNIT1 + 0x834)
    /*
    * Reserved
    */
    #define GLOBALREG_FADC_STAT_RESERVED_R (0x0ffff << 16)
    #define GLOBALREG_FADC_STAT_RESERVED_SHIFT 16
    #define GLOBALREG_FADC_STAT_FDAC_SPARE_IN_R (0x0ff << 8)
    #define GLOBALREG_FADC_STAT_FDAC_SPARE_IN_SHIFT 8
    /*
    * Spare bits used for status
    */
    #define GLOBALREG_FADC_STAT_FDAC_SPARE_OUT_R (0x0ff << 0)
    #define GLOBALREG_FADC_STAT_FDAC_SPARE_OUT_SHIFT 0
    /*
    * AFE Status
    */
    #define GLOBALREG_AFE_STAT_REG1  (GLOBALREG_BASE_UNIT1 + 0x8a8)
    /*
    * Reserved
    */
    #define GLOBALREG_AFE_STAT_RESERVED_R (0x01fffffff << 3)
    #define GLOBALREG_AFE_STAT_RESERVED_SHIFT 3
    /*
    * power on reset low voltage test output
    */
    #define GLOBALREG_AFE_STAT_PORTAP_R (0x01 << 2)
    #define GLOBALREG_AFE_STAT_PORTAP_SHIFT 2
    /*
    * power on reset test output
    */
    #define GLOBALREG_AFE_STAT_PORTEST_R (0x01 << 1)
    #define GLOBALREG_AFE_STAT_PORTEST_SHIFT 1
    /*
    * power on reset constant output
    */
    #define GLOBALREG_AFE_STAT_PORCONST_R (0x01 << 0)
    #define GLOBALREG_AFE_STAT_PORCONST_SHIFT 0
    /*
    * RFDAC REF control
    */
    #define GLOBALREG_REF_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x8ac)
    /*
    * Reserved
    */
    #define GLOBALREG_REF_CTRL_RESERVED_RW (0x0ffffffff << 0)
    #define GLOBALREG_REF_CTRL_RESERVED_SHIFT 0
    /*
    * Regulator control
    */
    #define GLOBALREG_REGU_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x8b0)
    /*
    * Reserved
    */
    #define GLOBALREG_REGU_CTRL_RESERVED_RW (0x0fffff << 12)
    #define GLOBALREG_REGU_CTRL_RESERVED_SHIFT 12
    /*
    * regu_vbg_ctrl
    */
    #define GLOBALREG_REGU_CTRL_REG1U_VBG_CTRL_RW (0x07 << 9)
    #define GLOBALREG_REGU_CTRL_REG1U_VBG_CTRL_SHIFT 9
    /*
    * 3 Bit Control signals. Bits [1:0] for Programming the 1.0 V Regulator. Signal Le
    * vel for HIGH = Ô1 VÕ and LOW = Ô0VÕ and Bit 2 for adacl_power_enable and adacr_p
    * ower_enable control.
    */
    #define GLOBALREG_REGU_CTRL_REG1U_VREG1V_CTRL_RW (0x07 << 6)
    #define GLOBALREG_REGU_CTRL_REG1U_VREG1V_CTRL_SHIFT 6
    /*
    * 3 Bit Control signals for Programming the 2.5 V Regulator. Signal Level for HIGH
    *  = Ô1 VÕ and LOW = Ô0VÕ.
    */
    #define GLOBALREG_REGU_CTRL_REG1U_VREG2P5V_CTRL_RW (0x07 << 3)
    #define GLOBALREG_REGU_CTRL_REG1U_VREG2P5V_CTRL_SHIFT 3
    /*
    * Enable signal for 2.5 V Regulator.
    * Signal Level for Enable = Ô1 VÕ and for Disable = Ô0 VÕ
    */
    #define GLOBALREG_REGU_CTRL_RESERVED4_RW (0x01 << 2)
    #define GLOBALREG_REGU_CTRL_RESERVED4_SHIFT 2
    /*
    * Enable signal for 1.0V regulator. Signal Level for Enable = Ô1 VÕ and for Disabl
    * e = Ô0 VÕ
    */
    #define GLOBALREG_REGU_CTRL_RESERVED5_RW (0x01 << 1)
    #define GLOBALREG_REGU_CTRL_RESERVED5_SHIFT 1
    /*
    * Enable signal for band gap reference. Signal level for Enable = Ô1 VÕ, For Disab
    * le = Ô0 VÕ
    */
    #define GLOBALREG_REGU_CTRL_RESERVED6_RW (0x01 << 0)
    #define GLOBALREG_REGU_CTRL_RESERVED6_SHIFT 0
    /*
    * vdac Control0
    */
    #define GLOBALREG_VDAC0_CTRL0_REG1  (GLOBALREG_BASE_UNIT1 + 0x8fc)
    /*
    * Reserved
    */
    #define GLOBALREG_VDAC0_CTRL0_RESERVED_RW (0x07 << 29)
    #define GLOBALREG_VDAC0_CTRL0_RESERVED_SHIFT 29
    /*
    * Power down filter/driver for channel D
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC_PD_FLTDRV_D_RW (0x01 << 28)
    #define GLOBALREG_VDAC0_CTRL0_VDAC_PD_FLTDRV_D_SHIFT 28
    #define GLOBALREG_VDAC0_CTRL0_RESERVED2_RW (0x01 << 27)
    #define GLOBALREG_VDAC0_CTRL0_RESERVED2_SHIFT 27
    /*
    * Value is added to / subtracted from internally generated filter calibration code
    * 
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC_F_OFFSET_RW (0x03f << 21)
    #define GLOBALREG_VDAC0_CTRL0_VDAC_F_OFFSET_SHIFT 21
    /*
    * Resets the digital portion of VDAC
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC_RESET_N_RW (0x01 << 20)
    #define GLOBALREG_VDAC0_CTRL0_VDAC_RESET_N_SHIFT 20
    /*
    * Spare input bits
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC_SPARE_IN_RW (0x03 << 18)
    #define GLOBALREG_VDAC0_CTRL0_VDAC_SPARE_IN_SHIFT 18
    /*
    * Set common mode voltage for the filter. High-> 750mV Low->650mV
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC_BUFFER_SEL_1P0_RW (0x01 << 17)
    #define GLOBALREG_VDAC0_CTRL0_VDAC_BUFFER_SEL_1P0_SHIFT 17
    /*
    * Program slope and value of bandgap voltage
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC_BG_RW (0x07 << 14)
    #define GLOBALREG_VDAC0_CTRL0_VDAC_BG_SHIFT 14
    /*
    * Set High to increase the bias current of the related block as follows:
    * <5> Not used
    * <4> Driver (1.5x)
    * <3> D2S (1.5x)
    * <2> Driver regulator (2x)
    * <1> D2S regulator (2x)
    * <0> Filter (2x)
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC_ADJ_IBIAS_RW (0x03f << 8)
    #define GLOBALREG_VDAC0_CTRL0_VDAC_ADJ_IBIAS_SHIFT 8
    /*
    * Power down Bandgap
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_BG_PD_RW (0x01 << 7)
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_BG_PD_SHIFT 7
    /*
    * Power down filter/driver for channel A
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_A_RW (0x01 << 6)
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_A_SHIFT 6
    /*
    * Power down filter/driver for channel B
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_B_RW (0x01 << 5)
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_B_SHIFT 5
    /*
    * Power down filter/driver for channel C
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_C_RW (0x01 << 4)
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_FLTDRV_C_SHIFT 4
    /*
    * Enable DAC channel A
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_A_RW (0x01 << 3)
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_A_SHIFT 3
    /*
    * Enable DAC channel B
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_B_RW (0x01 << 2)
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_B_SHIFT 2
    /*
    * Enable DAC channel C
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_C_RW (0x01 << 1)
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_EN_C_SHIFT 1
    /*
    * Power down reference loop
    */
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_REF_RW (0x01 << 0)
    #define GLOBALREG_VDAC0_CTRL0_VDAC0_PD_REF_SHIFT 0
    /*
    * vdac Control1
    */
    #define GLOBALREG_VDAC0_CTRL1_REG1  (GLOBALREG_BASE_UNIT1 + 0x900)
    /*
    * Reserved
    */
    #define GLOBALREG_VDAC0_CTRL1_RESERVED_RW (0x01 << 31)
    #define GLOBALREG_VDAC0_CTRL1_RESERVED_SHIFT 31
    /*
    * Program reference loop voltage. Full scale output voltage changes as follows:
    * 000 0.9v
    * 001 0.95v
    * 010 1.0v
    * 011 1.05v
    * 100 1.25v
    * 101 1.3v
    * 110 1.35v
    * 111 1.4v
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_VREF_SEL_RW (0x07 << 28)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_VREF_SEL_SHIFT 28
    /*
    * Enable override for compensation capacitor calibration code
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_CCAL_OVRD_RW (0x01 << 27)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_CCAL_OVRD_SHIFT 27
    /*
    * Calibration code used for compensation capacitors when ccal_ovrd is High
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_CCODE_OVRD_RW (0x07 << 24)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_CCODE_OVRD_SHIFT 24
    /*
    * Low: c_offset is added to internally generated capacitor calibration code
    * High: c_offset is subtracted from internally generated capacitor calibration cod
    * e
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_C_OFFSET_SUBTRACT_RW (0x01 << 23)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_C_OFFSET_SUBTRACT_SHIFT 23
    /*
    * Value is added to / subtracted from internally generated capacitor calibration c
    * ode
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_C_OFFSET_RW (0x07 << 20)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_C_OFFSET_SHIFT 20
    /*
    * Low: f_offset is added to internally generated filter calibration code
    * High: f_offset is subtracted from internally generated filter calibration code
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FOFFSET_SUBTRACT_RW (0x01 << 19)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FOFFSET_SUBTRACT_SHIFT 19
    /*
    * Reserved
    */
    #define GLOBALREG_VDAC0_CTRL1_RESERVED7_RW (0x01f << 14)
    #define GLOBALREG_VDAC0_CTRL1_RESERVED7_SHIFT 14
    /*
    * Calibration code used for filter calibration when flt_ovrd is High
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLTCODE_OVRD_RW (0x03f << 8)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLTCODE_OVRD_SHIFT 8
    /*
    * Enable override for filter calibration code
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_OVRD_RW (0x01 << 7)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_OVRD_SHIFT 7
    /*
    * Enables filter calibration
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_EN_CAL_RW (0x01 << 6)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_EN_CAL_SHIFT 6
    /*
    * Sets the reference voltage for the filter calibration comparator. "010" sets 1V 
    * as the reference
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_CAL_SEL_RW (0x07 << 3)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_CAL_SEL_SHIFT 3
    /*
    * Powers down the filter calibration block
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_CAL_PD_RW (0x01 << 2)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_CAL_PD_SHIFT 2
    /*
    * Resets filter calibration circuit. Active Low
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_CAL_NRESET_RW (0x01 << 1)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_CAL_NRESET_SHIFT 1
    /*
    * Doubles filter tuning comparator bias current
    */
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_CAL_DOUB_RW (0x01 << 0)
    #define GLOBALREG_VDAC0_CTRL1_VDAC_FLT_CAL_DOUB_SHIFT 0
    /*
    * vdac Control2
    */
    #define GLOBALREG_VDAC0_CTRL2_REG1  (GLOBALREG_BASE_UNIT1 + 0x904)
    #define GLOBALREG_VDAC0_CTRL2_RESERVED_RW (0x0fffffff << 4)
    #define GLOBALREG_VDAC0_CTRL2_RESERVED_SHIFT 4
    /*
    * Selects the PLL clock used in waveform generator.
    * 2Õb00: clk0
    * 2Õb01: clk1
    * 2Õb10: clk2
    * 2Õb11: clk3
    */
    #define GLOBALREG_VDAC0_CTRL2_VDAC_CLKSEL_WG_RW (0x03 << 2)
    #define GLOBALREG_VDAC0_CTRL2_VDAC_CLKSEL_WG_SHIFT 2
    /*
    * Selects the PLL clock used in analog calibration.
    * 2Õb00: clk0
    * 2Õb01: clk1
    * 2Õb10: clk2
    * 2Õb11: clk3
    */
    #define GLOBALREG_VDAC0_CTRL2_VDAC_CLKSEL_TUNE_RW (0x03 << 0)
    #define GLOBALREG_VDAC0_CTRL2_VDAC_CLKSEL_TUNE_SHIFT 0
    /*
    * vdac Control3
    */
    #define GLOBALREG_VDAC0_CTRL3_REG1  (GLOBALREG_BASE_UNIT1 + 0x908)
    #define GLOBALREG_VDAC0_CTRL3_RESERVED_RW (0x01 << 31)
    #define GLOBALREG_VDAC0_CTRL3_RESERVED_SHIFT 31
    /*
    * Active low FIFO read reset. It resets the read pointer for each FIFO. This bit s
    * hould be used by SW or DENC to put the FIFO into a known state.
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_RD_RST_A_N_RW (0x01 << 30)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_RD_RST_A_N_SHIFT 30
    /*
    * Active low FIFO read reset. It resets the read pointer for each FIFO. This bit s
    * hould be used by SW or DENC to put the FIFO into a known state.
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_RD_RST_B_N_RW (0x01 << 29)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_RD_RST_B_N_SHIFT 29
    /*
    * Active low FIFO read reset. It resets the read pointer for each FIFO. This bit s
    * hould be used by SW or DENC to put the FIFO into a known state.
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_RD_RST_C_N_RW (0x01 << 28)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_RD_RST_C_N_SHIFT 28
    /*
    * Active low FIFO read reset. It resets the read pointer for each FIFO. This bit s
    * hould be used by SW or DENC to put the FIFO into a known state.
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_RD_RST_D_N_RW (0x01 << 27)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_RD_RST_D_N_SHIFT 27
    /*
    * Reserved
    */
    #define GLOBALREG_VDAC0_CTRL3_RESERVED5_RW (0x07fff << 12)
    #define GLOBALREG_VDAC0_CTRL3_RESERVED5_SHIFT 12
    /*
    * Selects the 594MHz clock (read clock) for each FIFO. 1Õb0 = M0PLL, 1Õb1 = HDPLL.
    * 
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLKSEL_A_RW (0x01 << 11)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLKSEL_A_SHIFT 11
    /*
    * Selects the 594MHz clock (read clock) for each FIFO. 1Õb0 = M0PLL, 1Õb1 = HDPLL.
    * 
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLKSEL_B_RW (0x01 << 10)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLKSEL_B_SHIFT 10
    /*
    * Selects the 594MHz clock (read clock) for each FIFO. 1Õb0 = M0PLL, 1Õb1 = HDPLL.
    * 
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLKSEL_C_RW (0x01 << 9)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLKSEL_C_SHIFT 9
    /*
    * Selects the 594MHz clock (read clock) for each FIFO. 1Õb0 = M0PLL, 1Õb1 = HDPLL.
    * 
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLKSEL_D_RW (0x01 << 8)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLKSEL_D_SHIFT 8
    /*
    * This is in addition to the vdac_clksel_* bits. This field selects one of the fou
    * r input data clocks (write clocks) to each FIFO
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLK1X_SEL_A_RW (0x03 << 6)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLK1X_SEL_A_SHIFT 6
    /*
    * This is in addition to the vdac_clksel_* bits. This field selects one of the fou
    * r input data clocks (write clocks) to each FIFO
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLK1X_SEL_B_RW (0x03 << 4)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLK1X_SEL_B_SHIFT 4
    /*
    * This is in addition to the vdac_clksel_* bits. This field selects one of the fou
    * r input data clocks (write clocks) to each FIFO
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLK1X_SEL_C_RW (0x03 << 2)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLK1X_SEL_C_SHIFT 2
    /*
    * This is in addition to the vdac_clksel_* bits. This field selects one of the fou
    * r input data clocks (write clocks) to each FIFO
    */
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLK1X_SEL_D_RW (0x03 << 0)
    #define GLOBALREG_VDAC0_CTRL3_VDAC_CLK1X_SEL_D_SHIFT 0
    /*
    * vdac Control4
    */
    #define GLOBALREG_VDAC0_CTRL4_REG1  (GLOBALREG_BASE_UNIT1 + 0x90c)
    /*
    * Reserved
    */
    #define GLOBALREG_VDAC0_CTRL4_RESERVED_RW (0x01ff << 23)
    #define GLOBALREG_VDAC0_CTRL4_RESERVED_SHIFT 23
    /*
    * Register field to bypass the upsample filters for channel D.
    * [0]: Bypass 1x to 2x upsample filter
    * [1]: Bypass 2x to 4x upsample filter
    */
    #define GLOBALREG_VDAC0_CTRL4_VDAC_BYPASS_FILTER_D_RW (0x03 << 21)
    #define GLOBALREG_VDAC0_CTRL4_VDAC_BYPASS_FILTER_D_SHIFT 21
    /*
    * Register field to bypass the upsample filters.
    * [0]: Bypass 1x to 2x upsample filter
    * [1]: Bypass 2x to 4x upsample filter
    * [2]: Bypass 4x to 8x upsample filter
    */
    #define GLOBALREG_VDAC0_CTRL4_VDAC_BYPASS_FILTER_A_RW (0x03 << 19)
    #define GLOBALREG_VDAC0_CTRL4_VDAC_BYPASS_FILTER_A_SHIFT 19
    /*
    * See vdac_bypass_filter_a
    */
    #define GLOBALREG_VDAC0_CTRL4_VDAC_BYPASS_FILTER_B_RW (0x03 << 17)
    #define GLOBALREG_VDAC0_CTRL4_VDAC_BYPASS_FILTER_B_SHIFT 17
    /*
    * See vdac_bypass_filter_a
    */
    #define GLOBALREG_VDAC0_CTRL4_VDAC_BYPASS_FILTER_C_RW (0x03 << 15)
    #define GLOBALREG_VDAC0_CTRL4_VDAC_BYPASS_FILTER_C_SHIFT 15
    /*
    * Low: r_offset is added to internally generated filter calibration code
    * High: r_offset is subtracted from internally generated filter calibration code
    */
    #define GLOBALREG_VDAC0_CTRL4_VDAC_ROFFSET_SUBTRACT_RW (0x01 << 14)
    #define GLOBALREG_VDAC0_CTRL4_VDAC_ROFFSET_SUBTRACT_SHIFT 14
    /*
    * Value is added to / subtracted from internally generated resistor calibration co
    * de
    */
    #define GLOBALREG_VDAC0_CTRL4_VDAC_R_OFFSET_RW (0x03f << 8)
    #define GLOBALREG_VDAC0_CTRL4_VDAC_R_OFFSET_SHIFT 8
    /*
    * Calibration code used for resistor calibration when rcal_ovrd is High
    */
    #define GLOBALREG_VDAC0_CTRL4_VDAC_RCODE_OVD_RW (0x01f << 3)
    #define GLOBALREG_VDAC0_CTRL4_VDAC_RCODE_OVD_SHIFT 3
    /*
    * Powers down the resistor calibration block.
    */
    #define GLOBALREG_VDAC0_CTRL4_VDAC_RCAL_PD_RW (0x01 << 2)
    #define GLOBALREG_VDAC0_CTRL4_VDAC_RCAL_PD_SHIFT 2
    /*
    * Enable override for resistor calibration code
    */
    #define GLOBALREG_VDAC0_CTRL4_VDAC_RCAL_OVRD_RW (0x01 << 1)
    #define GLOBALREG_VDAC0_CTRL4_VDAC_RCAL_OVRD_SHIFT 1
    /*
    * Resets resistor calibration circuit. Active Low.
    */
    #define GLOBALREG_VDAC0_CTRL4_VDAC_RCAL_NRESET_RW (0x01 << 0)
    #define GLOBALREG_VDAC0_CTRL4_VDAC_RCAL_NRESET_SHIFT 0
    /*
    * vdac Test Control
    */
    #define GLOBALREG_VDAC0_TEST_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x910)
    /*
    * Reserved
    */
    #define GLOBALREG_VDAC0_TEST_CTRL_RESERVED_RW (0x0fffff << 12)
    #define GLOBALREG_VDAC0_TEST_CTRL_RESERVED_SHIFT 12
    /*
    * Gain value of the wave generator.
    * 2Õb00: Full scale
    * 2Õb01: 1/2 scale
    * 2Õb10: 1/4 scale
    * 2Õb11: 1/8 scale
    */
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_WAV_GAIN_RW (0x03 << 10)
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_WAV_GAIN_SHIFT 10
    /*
    * Offset value for the wave generator:
    * 3Õb000: No offset
    * 3Õb001: +128
    * 3Õb010: +256
    * 3Õb011: +384
    * 3Õb100: -512
    * 3Õb101: -384
    * 3Õb110: -256
    * 3Õb111: -128
    */
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_WAV_OFFSET_RW (0x07 << 7)
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_WAV_OFFSET_SHIFT 7
    /*
    * Selects waveform gen mode for channel A
    * When test_en_a is High, clksel_a<1:0> and clksel_wg<1:0> MUST have the same sett
    * ing
    */
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_TEST_EN_A_RW (0x01 << 6)
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_TEST_EN_A_SHIFT 6
    /*
    * Selects waveform gen mode for channel B
    * When test_en_b is High, clksel_b<1:0> and clksel_wg<1:0> MUST have the same sett
    * ing
    */
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_TEST_EN_B_RW (0x01 << 5)
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_TEST_EN_B_SHIFT 5
    /*
    * Selects waveform gen mode for channel C
    * When test_en_c is High, clksel_c<1:0> and clksel_wg<1:0> MUST have the same sett
    * ing
    */
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_TEST_EN_C_RW (0x01 << 4)
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_TEST_EN_C_SHIFT 4
    /*
    * Selects waveform gen mode for channel D
    * When test_en_c is High, clksel_c<1:0> and clksel_wg<1:0> MUST have the same sett
    * ing
    */
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_TEST_EN_D_RW (0x01 << 3)
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_TEST_EN_D_SHIFT 3
    /*
    * Bit [1:0] selects the wave mode:
    * 2Õb00: Sine wave
    * 2Õb01: Ramp
    * 2Õb10: Square wave
    * 2Õb11: Chirp
    * Bit 2 selects the bypass upsample filter mode when wave generator is used:
    * 1Õb0: Bypass upsample filters
    * 1Õb1: Use upsample filters
    */
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_TEST_MODE_RW (0x07 << 0)
    #define GLOBALREG_VDAC0_TEST_CTRL_VDAC_TEST_MODE_SHIFT 0
    /*
    * vdac DTO Increment Value0
    */
    #define GLOBALREG_VDAC0_DTO_INCR0_REG1  (GLOBALREG_BASE_UNIT1 + 0x914)
    /*
    * DTO increment value for the sine wave generator for wave0
    */
    #define GLOBALREG_VDAC0_DTO_INCR0_VDAC_DTO_INCR0_RW (0x0ffffffff << 0)
    #define GLOBALREG_VDAC0_DTO_INCR0_VDAC_DTO_INCR0_SHIFT 0
    /*
    * vdac DTO Increment Value0
    */
    #define GLOBALREG_VDAC0_DTO_INCR1_REG1  (GLOBALREG_BASE_UNIT1 + 0x918)
    /*
    * DTO increment value for the sine wave generator for wave1
    */
    #define GLOBALREG_VDAC0_DTO_INCR1_VDAC_DTO_INCR1_RW (0x0ffffffff << 0)
    #define GLOBALREG_VDAC0_DTO_INCR1_VDAC_DTO_INCR1_SHIFT 0
    /*
    * vdac STATUS
    */
    #define GLOBALREG_VDAC0_STAT_REG1  (GLOBALREG_BASE_UNIT1 + 0x91c)
    /*
    * FIFO overflow detect status bit (register bit) for each FIFO. This status bit is
    *  used by SW (or DENC) to detect when to assert the write reset (vdac_wr_rst_*_n)
    *  due to unstable clocks. Using this field is optional.
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_FIFO_OVERFLOW_A_R (0x01 << 31)
    #define GLOBALREG_VDAC0_STAT_VDAC_FIFO_OVERFLOW_A_SHIFT 31
    /*
    * FIFO overflow detect status bit (register bit) for each FIFO. This status bit is
    *  used by SW (or DENC) to detect when to assert the write reset (vdac_wr_rst_*_n)
    *  due to unstable clocks. Using this field is optional.
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_FIFO_OVERFLOW_B_R (0x01 << 30)
    #define GLOBALREG_VDAC0_STAT_VDAC_FIFO_OVERFLOW_B_SHIFT 30
    /*
    * FIFO overflow detect status bit (register bit) for each FIFO. This status bit is
    *  used by SW (or DENC) to detect when to assert the write reset (vdac_wr_rst_*_n)
    *  due to unstable clocks. Using this field is optional.
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_FIFO_OVERFLOW_C_R (0x01 << 29)
    #define GLOBALREG_VDAC0_STAT_VDAC_FIFO_OVERFLOW_C_SHIFT 29
    /*
    * FIFO overflow detect status bit (register bit) for each FIFO. This status bit is
    *  used by SW (or DENC) to detect when to assert the write reset (vdac_wr_rst_*_n)
    *  due to unstable clocks. Using this field is optional.
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_FIFO_OVERFLOW_D_R (0x01 << 28)
    #define GLOBALREG_VDAC0_STAT_VDAC_FIFO_OVERFLOW_D_SHIFT 28
    /*
    * Capacitor codes obtained from calibration circuitry
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_CCODE_DRV_R (0x07 << 25)
    #define GLOBALREG_VDAC0_STAT_VDAC_CCODE_DRV_SHIFT 25
    /*
    * Output code obtained from RC calibration
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_FLT_CAL_CODE_R (0x03f << 19)
    #define GLOBALREG_VDAC0_STAT_VDAC_FLT_CAL_CODE_SHIFT 19
    /*
    * Indicates completion of filter calibration.
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_FLT_DONE_R (0x01 << 18)
    #define GLOBALREG_VDAC0_STAT_VDAC_FLT_DONE_SHIFT 18
    /*
    * Indicates completion of resistor calibration.
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_RCAL_DONE_R (0x01 << 17)
    #define GLOBALREG_VDAC0_STAT_VDAC_RCAL_DONE_SHIFT 17
    /*
    * Output code obtained from resistor calibration
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_RCODE_DRV_R (0x01f << 12)
    #define GLOBALREG_VDAC0_STAT_VDAC_RCODE_DRV_SHIFT 12
    /*
    * Spare output bits
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_SPARE_OUT_R (0x0ff << 4)
    #define GLOBALREG_VDAC0_STAT_VDAC_SPARE_OUT_SHIFT 4
    /*
    * Monitor Status output for channel A
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_STAT_OUT_A_R (0x01 << 3)
    #define GLOBALREG_VDAC0_STAT_VDAC_STAT_OUT_A_SHIFT 3
    /*
    * Monitor Status output for channel B
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_STAT_OUT_B_R (0x01 << 2)
    #define GLOBALREG_VDAC0_STAT_VDAC_STAT_OUT_B_SHIFT 2
    /*
    * Monitor Status output for channel C
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_STAT_OUT_C_R (0x01 << 1)
    #define GLOBALREG_VDAC0_STAT_VDAC_STAT_OUT_C_SHIFT 1
    /*
    * Monitor Status output for channel C
    */
    #define GLOBALREG_VDAC0_STAT_VDAC_STAT_OUT_D_R (0x01 << 0)
    #define GLOBALREG_VDAC0_STAT_VDAC_STAT_OUT_D_SHIFT 0
    /*
    * VDAC1 Control0
    */
    #define GLOBALREG_VDAC1_CTRL0_REG1  (GLOBALREG_BASE_UNIT1 + 0x920)
    /*
    * Reserved
    */
    #define GLOBALREG_VDAC1_CTRL0_RESERVED_RW (0x01f << 27)
    #define GLOBALREG_VDAC1_CTRL0_RESERVED_SHIFT 27
    /*
    * Value is added to / subtracted from internally generated filter calibration code
    *  
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_F_OFFSET_RW (0x03f << 21)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_F_OFFSET_SHIFT 21
    /*
    * Resets the digital portion of VDAC
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_RESET_N_RW (0x01 << 20)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_RESET_N_SHIFT 20
    /*
    * Spare input bits
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_SPARE_IN_RW (0x03 << 18)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_SPARE_IN_SHIFT 18
    /*
    * Set common mode voltage for the filter. High-> 750mV Low->650mV
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_BUFFER_SEL_1P0_RW (0x01 << 17)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_BUFFER_SEL_1P0_SHIFT 17
    /*
    * Program slope and value of bandgap voltage
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_BG_RW (0x07 << 14)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_BG_SHIFT 14
    /*
    * Set High to increase the bias current of the related block as follows:
    * <5> Not used
    * <4> Driver (1.5x)
    * <3> D2S (1.5x)
    * <2> Driver regulator (2x)
    * <1> D2S regulator (2x)
    * <0> Filter (2x)
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_ADJ_IBIAS_RW (0x03f << 8)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_ADJ_IBIAS_SHIFT 8
    /*
    * Power down Bandgap
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_BG_PD_RW (0x01 << 7)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_BG_PD_SHIFT 7
    /*
    * Power down filter/driver for channel A
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_A_RW (0x01 << 6)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_A_SHIFT 6
    /*
    * Power down filter/driver for channel B
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_B_RW (0x01 << 5)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_B_SHIFT 5
    /*
    * Power down filter/driver for channel C
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_C_RW (0x01 << 4)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_FLTDRV_C_SHIFT 4
    /*
    * Enable DAC channel A
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_A_RW (0x01 << 3)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_A_SHIFT 3
    /*
    * Enable DAC channel B
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_B_RW (0x01 << 2)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_B_SHIFT 2
    /*
    * Enable DAC channel C
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_C_RW (0x01 << 1)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_EN_C_SHIFT 1
    /*
    * Power down reference loop
    */
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_REF_RW (0x01 << 0)
    #define GLOBALREG_VDAC1_CTRL0_VDAC1_PD_REF_SHIFT 0
    /*
    * VDAC1 Control1
    */
    #define GLOBALREG_VDAC1_CTRL1_REG1  (GLOBALREG_BASE_UNIT1 + 0x924)
    /*
    * Reserved
    */
    #define GLOBALREG_VDAC1_CTRL1_RESERVED_RW (0x01 << 31)
    #define GLOBALREG_VDAC1_CTRL1_RESERVED_SHIFT 31
    /*
    * Program reference loop voltage. Full scale output voltage changes as follows:
    * 000 0.9v
    * 001 0.95v
    * 010 1.0v
    * 011 1.05v
    * 100 1.25v
    * 101 1.3v
    * 110 1.35v
    * 111 1.4v
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_VREF_SEL_RW (0x07 << 28)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_VREF_SEL_SHIFT 28
    /*
    * Enable override for compensation capacitor calibration code
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_CCAL_OVRD_RW (0x01 << 27)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_CCAL_OVRD_SHIFT 27
    /*
    * Calibration code used for compensation capacitors when ccal_ovrd is High
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_CCODE_OVRD_RW (0x07 << 24)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_CCODE_OVRD_SHIFT 24
    /*
    * Low: c_offset is added to internally generated capacitor calibration code
    * High: c_offset is subtracted from internally generated capacitor calibration cod
    * e
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_C_OFFSET_SUBTRACT_RW (0x01 << 23)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_C_OFFSET_SUBTRACT_SHIFT 23
    /*
    * Value is added to / subtracted from internally generated capacitor calibration c
    * ode
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_C_OFFSET_RW (0x07 << 20)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_C_OFFSET_SHIFT 20
    /*
    * Low: f_offset is added to internally generated filter calibration code
    * High: f_offset is subtracted from internally generated filter calibration code
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FOFFSET_SUBTRACT_RW (0x01 << 19)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FOFFSET_SUBTRACT_SHIFT 19
    /*
    * Reserved
    */
    #define GLOBALREG_VDAC1_CTRL1_RESERVED7_RW (0x01f << 14)
    #define GLOBALREG_VDAC1_CTRL1_RESERVED7_SHIFT 14
    /*
    * Calibration code used for filter calibration when flt_ovrd is High
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLTCODE_OVRD_RW (0x03f << 8)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLTCODE_OVRD_SHIFT 8
    /*
    * Enable override for filter calibration code
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_OVRD_RW (0x01 << 7)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_OVRD_SHIFT 7
    /*
    * Enables filter calibration
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_EN_CAL_RW (0x01 << 6)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_EN_CAL_SHIFT 6
    /*
    * Sets the reference voltage for the filter calibration comparator. "010" sets 1V 
    * as the reference
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_SEL_RW (0x07 << 3)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_SEL_SHIFT 3
    /*
    * Powers down the filter calibration block
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_PD_RW (0x01 << 2)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_PD_SHIFT 2
    /*
    * Resets filter calibration circuit. Active Low
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_NRESET_RW (0x01 << 1)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_NRESET_SHIFT 1
    /*
    * Doubles filter tuning comparator bias current
    */
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_DOUB_RW (0x01 << 0)
    #define GLOBALREG_VDAC1_CTRL1_VDAC1_FLT_CAL_DOUB_SHIFT 0
    /*
    * VDAC1 Control2
    */
    #define GLOBALREG_VDAC1_CTRL2_REG1  (GLOBALREG_BASE_UNIT1 + 0x928)
    /*
    * VDAC1 Control3
    */
    #define GLOBALREG_VDAC1_CTRL3_REG1  (GLOBALREG_BASE_UNIT1 + 0x92c)
    /*
    * VDAC1 Control4
    */
    #define GLOBALREG_VDAC1_CTRL4_REG1  (GLOBALREG_BASE_UNIT1 + 0x930)
    /*
    * VDAC1 Test Control
    */
    #define GLOBALREG_VDAC1_TEST_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0x934)
    /*
    * VDAC1 DTO Increment Value0
    */
    #define GLOBALREG_VDAC1_DTO_INCR0_REG1  (GLOBALREG_BASE_UNIT1 + 0x938)
    /*
    * VDAC1 DTO Increment Value0
    */
    #define GLOBALREG_VDAC1_DTO_INCR1_REG1  (GLOBALREG_BASE_UNIT1 + 0x93c)

    /*
    * SADC1 CONTROL
    */
    #define GLOBALREG_SADC1_CTRL_REG1  (GLOBALREG_BASE_UNIT1 + 0xa00)
    /*
    * Reserved
    */
    #define GLOBALREG_SADC1_CTRL_RESERVED_RW (0x03fffff << 10)
    #define GLOBALREG_SADC1_CTRL_RESERVED_SHIFT 10
    #define GLOBALREG_SADC1_CTRL_SADC1_CLK_SEL_RW (0x01 << 9)
    #define GLOBALREG_SADC1_CTRL_SADC1_CLK_SEL_SHIFT 9
    #define GLOBALREG_SADC1_CTRL_SADC1_FILTER_BW_I_RW (0x03 << 7)
    #define GLOBALREG_SADC1_CTRL_SADC1_FILTER_BW_I_SHIFT 7
    #define GLOBALREG_SADC1_CTRL_SADC1_FILTER_BYPASS_I_RW (0x03 << 5)
    #define GLOBALREG_SADC1_CTRL_SADC1_FILTER_BYPASS_I_SHIFT 5
    #define GLOBALREG_SADC1_CTRL_SADC1_FILTER_OFF_I_RW (0x01 << 4)
    #define GLOBALREG_SADC1_CTRL_SADC1_FILTER_OFF_I_SHIFT 4
    #define GLOBALREG_SADC1_CTRL_SADC1_STDBY_ADC_I_RW (0x01 << 3)
    #define GLOBALREG_SADC1_CTRL_SADC1_STDBY_ADC_I_SHIFT 3
    #define GLOBALREG_SADC1_CTRL_SADC1_STDBYALL_I_RW (0x01 << 2)
    #define GLOBALREG_SADC1_CTRL_SADC1_STDBYALL_I_SHIFT 2
    #define GLOBALREG_SADC1_CTRL_SADC1_TST_I_RW (0x03 << 0)
    #define GLOBALREG_SADC1_CTRL_SADC1_TST_I_SHIFT 0
    /*
    * LDPC PLL CONTROL 0
    */
    #define GLOBALREG_LDPCPLL_CRTL0_REG1  (GLOBALREG_BASE_UNIT1 + 0xa04)
    /*
    * Reserved
    */
    #define GLOBALREG_LDPCPLL_CRTL0_RESERVED_RW (0x03ff << 22)
    #define GLOBALREG_LDPCPLL_CRTL0_RESERVED_SHIFT 22
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_BANDSEL_RW (0x01 << 21)
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_BANDSEL_SHIFT 21
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_BYPASS_RW (0x01 << 20)
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_BYPASS_SHIFT 20
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_CLKEN_RW (0x01 << 19)
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_CLKEN_SHIFT 19
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_DIRECTI_RW (0x01 << 18)
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_DIRECTI_SHIFT 18
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_DIRECTO_RW (0x01 << 17)
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_DIRECTO_SHIFT 17
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_FRM_RW (0x01 << 16)
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_FRM_SHIFT 16
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_INSELI_RW (0x03f << 10)
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_INSELI_SHIFT 10
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_INSELP_RW (0x01f << 5)
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_INSELP_SHIFT 5
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_INSELR_RW (0x0f << 1)
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_INSELR_SHIFT 1
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_LIMUP_OFF_RW (0x01 << 0)
    #define GLOBALREG_LDPCPLL_CRTL0_LDPCPLL_LIMUP_OFF_SHIFT 0
    /*
    * LDPC PLL CONTROL 1
    */
    #define GLOBALREG_LDPCPLL_CTRL1_REG1  (GLOBALREG_BASE_UNIT1 + 0xa08)
    #define GLOBALREG_LDPCPLL_CTRL1_RESERVED_RW (0x07 << 29)
    #define GLOBALREG_LDPCPLL_CTRL1_RESERVED_SHIFT 29
    #define GLOBALREG_LDPCPLL_CTRL1_LDPCPLL_MDEC_RW (0x01ffff << 12)
    #define GLOBALREG_LDPCPLL_CTRL1_LDPCPLL_MDEC_SHIFT 12
    #define GLOBALREG_LDPCPLL_CTRL1_LDPCPLL_MREQ_RW (0x01 << 11)
    #define GLOBALREG_LDPCPLL_CTRL1_LDPCPLL_MREQ_SHIFT 11
    #define GLOBALREG_LDPCPLL_CTRL1_LDPCPLL_NDEC_RW (0x03ff << 1)
    #define GLOBALREG_LDPCPLL_CTRL1_LDPCPLL_NDEC_SHIFT 1
    #define GLOBALREG_LDPCPLL_CTRL1_LDPCPLL_NREQ_RW (0x01 << 0)
    #define GLOBALREG_LDPCPLL_CTRL1_LDPCPLL_NREQ_SHIFT 0
    /*
    * LDPC PLL CONTROL 2
    */
    #define GLOBALREG_LDPCPLL_CTRL2_REG1  (GLOBALREG_BASE_UNIT1 + 0xa0c)
    /*
    * Reserved
    */
    #define GLOBALREG_LDPCPLL_CTRL2_RESERVED_RW (0x0ff << 24)
    #define GLOBALREG_LDPCPLL_CTRL2_RESERVED_SHIFT 24
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_PDEC_RW (0x07f << 17)
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_PDEC_SHIFT 17
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_PD_RW (0x01 << 16)
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_PD_SHIFT 16
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_PREQ_RW (0x01 << 15)
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_PREQ_SHIFT 15
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_SELI_RW (0x03f << 9)
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_SELI_SHIFT 9
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_SELP_RW (0x01f << 4)
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_SELP_SHIFT 4
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_SELR_RW (0x0f << 0)
    #define GLOBALREG_LDPCPLL_CTRL2_LDPCPLL_SELR_SHIFT 0
    /*
    * TSENSER CONTROL
    */
    #define GLOBALREG_TSENS_CTRL0_REG  (GLOBALREG_BASE_UNIT1 + 0xa20)
    /*
    * Reserved
    */
    #define GLOBALREG_TSENS_CTRL0_RESERVED_RW (0x03 << 30)
    #define GLOBALREG_TSENS_CTRL0_RESERVED_SHIFT 30
    #define GLOBALREG_TSENS_CTRL0_TSENSE_AMP_CHOP_CLK_EN_RW (0x01 << 29)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_AMP_CHOP_CLK_EN_SHIFT 29
    /*
    * Sets delta sigma ADC stage1 feedback DAC output current
    * 3'b000: off
    * 3'b001: 1.6uA
    * 3'b010: 3.1uA (default)
    * 3'b011: 4.7uA
    * 3'b100: 6.3uA
    * 3'b101: 7.8uA
    * 3'b110: 9.4uA
    * 3'b111: 10.9uA
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_I_DAC1_CTL_RW (0x07 << 26)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_I_DAC1_CTL_SHIFT 26
    /*
    * Sets delta sigma ADC stage2 feedback DAC output current
    * 3'b000: off
    * 3'b001: 260nA
    * 3'b010: 520nA (default)
    * 3'b011: 780nA
    * 3'b100: 1uA
    * 3'b101: 1.3uA
    * 3'b110: 1.6uA
    * 3'b111: 1.8uA
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_I_DAC2_CTL_RW (0x07 << 23)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_I_DAC2_CTL_SHIFT 23
    /*
    * clock divider reset active low
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_DIV_RESET_N_RW (0x01 << 22)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_DIV_RESET_N_SHIFT 22
    /*
    * tsense ADC clock divider
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_DIV_VAL_RW (0x0f << 18)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_DIV_VAL_SHIFT 18
    /*
    * Used to clear the done bit.
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_CLEAR_DONE_RW (0x01 << 17)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_CLEAR_DONE_SHIFT 17
    /*
    * Power down unity gain buffer amplifier. 
    * 1'b0: powered up
    * 1'b1: powered down
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_AMP_PD_RW (0x01 << 16)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_AMP_PD_SHIFT 16
    /*
    * When HI, the Temperature Sensor digital block in the AFE resets the ADC instead 
    * of using the external reset signal (tsense_test_ctl[4])
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_AUTO_ADC_RESET_RW (0x01 << 15)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_AUTO_ADC_RESET_SHIFT 15
    /*
    * Setting for bandgap output voltage temperature coefficient
    * 3'b000: most negative temperature coefficient
    * 3'bx11: flat 
    * 3'b110: most positive temperature coefficient
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_BG_RW (0x07 << 12)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_BG_SHIFT 12
    /*
    * Enable chop clock of bandgap amplifier
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_BG_CLK_EN_RW (0x01 << 11)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_BG_CLK_EN_SHIFT 11
    /*
    * Power down bandgap
    * 1'b0: powered up
    * 1'b1: powered down
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_BG_PDN_RW (0x01 << 10)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_BG_PDN_SHIFT 10
    /*
    * 2'b00: Manual Mode
    * 2'b01: Auto Mode
    * 2'b1x: Calibration mode for sensing
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_CALC_MODE_RW (0x03 << 8)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_CALC_MODE_SHIFT 8
    /*
    * Sets bias current for ADC integrators and reference (agnd) generator
    * 2'b00: minimum current
    * 2'b01: 5uA (default)
    * 2'b10: medium current
    * 2'b11: maximum current
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_ADC_BIAS_CTL_RW (0x03 << 6)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_ADC_BIAS_CTL_SHIFT 6
    /*
    * Changes clock edge used to sample ADC output data in the digital part of the Tem
    * perature Sensor:
    * 1'b0: Rising edge is used to capture data
    * 1'b1: Falling edge is used to capture data
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_ADC_CLK_POL_RW (0x01 << 5)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_ADC_CLK_POL_SHIFT 5
    /*
    * Power down Signal for ADC
    * 1'b0: powered down
    * 1'b1: powered up
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_ADC_PD_BAR_RW (0x01 << 4)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_ADC_PD_BAR_SHIFT 4
    /*
    * Control of analog ground setting for ADC integrators
    * 2'b00: 0.475V
    * 2'b01: 0.5V 
    * 2'b10: 0.525V
    * 2'b11: psupa_1p0/2
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_ADC_AGND_CTL_RW (0x03 << 2)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_ADC_AGND_CTL_SHIFT 2
    /*
    * Controls length of accumalation of ADC output.
    * 2'b00 : 8K
    * 2'b01 : 16K
    * 2'b10 : 32K
    * 2'b11 : 64K
    */
    #define GLOBALREG_TSENS_CTRL0_TSENSE_ACCUM_MODE_RW (0x03 << 0)
    #define GLOBALREG_TSENS_CTRL0_TSENSE_ACCUM_MODE_SHIFT 0
    /*
    * TSENSER CONTROL
    */
    #define GLOBALREG_TSENS_CTRL1_REG  (GLOBALREG_BASE_UNIT1 + 0xa24)
    /*
    * Reserved
    */
    #define GLOBALREG_TSENS_CTRL1_RESERVED_RW (0x03ff << 22)
    #define GLOBALREG_TSENS_CTRL1_RESERVED_SHIFT 22
    /*
    * Select bits for scaled Vbg
    * Assuming Vbg = 1.2V, then:
    * 3'b000: vbg_sc and vbg_ext_sc=0.375V
    * 3'b001: vbg_sc and vbg_ext_sc=0.4V
    * 3'b010: vbg_sc and vbg_ext_sc=0.425V
    * 3'b011: vbg_sc and vbg_ext_sc=0.45V
    * 3'b100: vbg_sc and vbg_ext_sc=0.475V
    * 3'b101: vbg_sc and vbg_ext_sc=0.5V (default)
    * 3'b110: vbg_sc and vbg_ext_sc=0.525V
    * 3'b111: vbg_sc and vbg_ext_sc=0.55V
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_VBG_SC_SEL_RW (0x07 << 19)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_VBG_SC_SEL_SHIFT 19
    /*
    * Control bit for Bandgap Chop circuit.
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_BG_CLK_RW (0x01 << 18)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_BG_CLK_SHIFT 18
    /*
    * Internal calibration control (MUX select). To be used in manual mode only to mak
    * e measurements and for test control.
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_SEL_A_RW (0x01 << 17)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_SEL_A_SHIFT 17
    /*
    * Internal calibration control (MUX select). To be used in manual mode only to mak
    * e measurements and for test control.
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_SEL_B_RW (0x01 << 16)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_SEL_B_SHIFT 16
    /*
    * Internal calibration control (MUX select). To be used in manual mode only to mak
    * e measurements and for test control.
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_SEL_C_RW (0x01 << 15)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_SEL_C_SHIFT 15
    /*
    * Internal calibration control (MUX select). To be used in manual mode only to mak
    * e measurements and for test control.
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_SEL_D_RW (0x01 << 14)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_SEL_D_SHIFT 14
    /*
    * Internal calibration control (MUX select). To be used in manual mode only to mak
    * e measurements and for test control.
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_SEL_P_RW (0x01 << 13)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_SW_SEL_P_SHIFT 13
    /*
    * Active High reset for digital logic
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_RESET_RW (0x01 << 12)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_RESET_SHIFT 12
    /*
    * Used to start temperature measurement. Rising edge sensitive.
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_START_RW (0x01 << 11)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_START_SHIFT 11
    /*
    * trim high/low range setting,
    * sets the trim DAC output current
    * range to be in a high or low range
    * 1'b0: high range
    * 1'b1 low range
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_I_TRIM_LO_RNG_RW (0x01 << 10)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_I_TRIM_LO_RNG_SHIFT 10
    /*
    * Used to control the TRIM DAC that adjusts the negative offset of the temperature
    *  measurement
    * 4'b0000 = Max current/Max offset
    * 4'b1111 = off
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_I_TRIM_MINUS_BAR_RW (0x0f << 6)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_I_TRIM_MINUS_BAR_SHIFT 6
    /*
    * Used to control the TRIM DAC that adjusts the positive offset of the temperature
    *  measurement
    * 4'b0000 = Max current/Max offset
    * 4'b1111 = off
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_I_TRIM_PLUS_BAR_RW (0x0f << 2)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_I_TRIM_PLUS_BAR_SHIFT 2
    /*
    * Used to indicate how many clock cycles to wait before accumulation starts.
    * 2Õb00: 512 cycles
    * 2Õb01: 1k cycles (default)
    * 2Õb10: 4k cycles
    * 2Õb11: 8k cycles
    */
    #define GLOBALREG_TSENS_CTRL1_TSENSE_INIT_WAIT_MODE_RW (0x03 << 0)
    #define GLOBALREG_TSENS_CTRL1_TSENSE_INIT_WAIT_MODE_SHIFT 0
    /*
    * TSENSER PROCESS OFFSET
    */
    #define GLOBALREG_TSENS_K_REG  (GLOBALREG_BASE_UNIT1 + 0xa28)
    /*
    * process offset coefficient set by software, default = 0.765, final value to be d
    * etermined from bench characterization
    * Note: offset coefficient/8*2^15 = binary setting for this register
    */
    #define GLOBALREG_TSENS_K_TSENSE_K1_RW (0x0ffff << 16)
    #define GLOBALREG_TSENS_K_TSENSE_K1_SHIFT 16
    /*
    * process offset coefficient set by software, default = 0.832, final value to be d
    * etermined from bench characterization
    * Note: offset coefficient/8*2^15 = binary setting for this register
    */
    #define GLOBALREG_TSENS_K_TSENSE_K2_RW (0x0ffff << 0)
    #define GLOBALREG_TSENS_K_TSENSE_K2_SHIFT 0
    /*
    * TSENSER TEST CONTROL
    */
    #define GLOBALREG_TSENS_TEST_CTRL_REG  (GLOBALREG_BASE_UNIT1 + 0xa2c)
    /*
    * Reserved
    */
    #define GLOBALREG_TSENS_TEST_CTRL_RESERVED_RW (0x0fffff << 12)
    #define GLOBALREG_TSENS_TEST_CTRL_RESERVED_SHIFT 12
    /*
    * [11:5]: Not used, Do not connect
    * [4]: Resets the ADC
    *  1'b0: ADC not reset (default)
    *  1'b1: ADC reset
    * [3]: Enable for ADC clock
    *  1'b0: ADC clock disabled
    *  1'b1: ADC clock enabled (default)
    * [2]: Control Bits for Test MUX
    *  3Õb000: status<1:0> = HiZ
    *  3Õb001: status<1:0> = buf_in_b
    *  3Õb010: status<1:0> = adc_inp
    *  3Õb011: status<1:0> = nsupa
    *  3Õb100: status<1:0> = buf_in_a
    *  3Õb101: status<1:0> = adc_inm 
    *  3Õb110: status<1:0> = vbg_1p2
    *  3Õb111: status<1:0> = psupa_1p0
    */
    #define GLOBALREG_TSENS_TEST_CTRL_TSENSE_TEST_CTL_RW (0x0fff << 0)
    #define GLOBALREG_TSENS_TEST_CTRL_TSENSE_TEST_CTL_SHIFT 0
    /*
    * TSENSER CALIB
    */
    #define GLOBALREG_TSENS_CALIB_REG  (GLOBALREG_BASE_UNIT1 + 0xa30)
    /*
    * Reserved
    */
    #define GLOBALREG_TSENS_CALIB_RESERVED_RW (0x0ffff << 16)
    #define GLOBALREG_TSENS_CALIB_RESERVED_SHIFT 16
    /*
    * 16 bit input from the Fuses to adjust for process offset
    */
    #define GLOBALREG_TSENS_CALIB_TSENSE_CALIB_RW (0x0ffff << 0)
    #define GLOBALREG_TSENS_CALIB_TSENSE_CALIB_SHIFT 0
    /*
    * TSENSER CALIB
    */
    #define GLOBALREG_TSENS_RESULT_REG  (GLOBALREG_BASE_UNIT1 + 0xa34)
    /*
    * Reserved
    */
    #define GLOBALREG_TSENS_RESULT_RESERVED_R (0x07fff << 17)
    #define GLOBALREG_TSENS_RESULT_RESERVED_SHIFT 17
    /*
    * Output high indicates temperature calculation complete.
    */
    #define GLOBALREG_TSENS_RESULT_TSENSE_DONE_R (0x01 << 16)
    #define GLOBALREG_TSENS_RESULT_TSENSE_DONE_SHIFT 16
    /*
    * Result of the accumulated ADC output.
    */
    #define GLOBALREG_TSENS_RESULT_TSENSE_ACCUM_RESULT_R (0x0ffff << 0)
    #define GLOBALREG_TSENS_RESULT_TSENSE_ACCUM_RESULT_SHIFT 0
    /*
    * TSENSER CALIB
    */
    #define GLOBALREG_PLL_OBS_REG  (GLOBALREG_BASE_UNIT1 + 0xa38)
    /*
    * Reserved
    */
    #define GLOBALREG_PLL_OBS_RESERVED_R (0x07fff << 17)
    #define GLOBALREG_PLL_OBS_RESERVED_SHIFT 17
    #define GLOBALREG_PLL_OBS_SPLL_FR_R (0x01 << 16)
    #define GLOBALREG_PLL_OBS_SPLL_FR_SHIFT 16
    #define GLOBALREG_PLL_OBS_SPLL_LOCK_R (0x01 << 15)
    #define GLOBALREG_PLL_OBS_SPLL_LOCK_SHIFT 15
    #define GLOBALREG_PLL_OBS_SPLL_LOCK3_R (0x01 << 14)
    #define GLOBALREG_PLL_OBS_SPLL_LOCK3_SHIFT 14
    #define GLOBALREG_PLL_OBS_SPLL_MACK_R (0x01 << 13)
    #define GLOBALREG_PLL_OBS_SPLL_MACK_SHIFT 13
    #define GLOBALREG_PLL_OBS_SPLL_NACK_R (0x01 << 12)
    #define GLOBALREG_PLL_OBS_SPLL_NACK_SHIFT 12
    #define GLOBALREG_PLL_OBS_SPLL_PACK_R (0x01 << 11)
    #define GLOBALREG_PLL_OBS_SPLL_PACK_SHIFT 11
    #define GLOBALREG_PLL_OBS_FTMPLL_PFR_R (0x01 << 10)
    #define GLOBALREG_PLL_OBS_FTMPLL_PFR_SHIFT 10
    #define GLOBALREG_PLL_OBS_FTMPLL_LOCK_R (0x01 << 9)
    #define GLOBALREG_PLL_OBS_FTMPLL_LOCK_SHIFT 9
    #define GLOBALREG_PLL_OBS_FTMPLL_MACK_R (0x01 << 8)
    #define GLOBALREG_PLL_OBS_FTMPLL_MACK_SHIFT 8
    #define GLOBALREG_PLL_OBS_FTMPLL_NACK_R (0x01 << 7)
    #define GLOBALREG_PLL_OBS_FTMPLL_NACK_SHIFT 7
    #define GLOBALREG_PLL_OBS_FTMPLL_PACK_R (0x01 << 6)
    #define GLOBALREG_PLL_OBS_FTMPLL_PACK_SHIFT 6
    #define GLOBALREG_PLL_OBS_FTMPLLFRAC_ACK_R (0x01 << 5)
    #define GLOBALREG_PLL_OBS_FTMPLLFRAC_ACK_SHIFT 5
    #define GLOBALREG_PLL_OBS_LDPCPLL_PFR_R (0x01 << 4)
    #define GLOBALREG_PLL_OBS_LDPCPLL_PFR_SHIFT 4
    #define GLOBALREG_PLL_OBS_LDPCPLL_LOCK_R (0x01 << 3)
    #define GLOBALREG_PLL_OBS_LDPCPLL_LOCK_SHIFT 3
    #define GLOBALREG_PLL_OBS_LDPCPLL_MACK_R (0x01 << 2)
    #define GLOBALREG_PLL_OBS_LDPCPLL_MACK_SHIFT 2
    #define GLOBALREG_PLL_OBS_LDPCPLL_NACK_R (0x01 << 1)
    #define GLOBALREG_PLL_OBS_LDPCPLL_NACK_SHIFT 1
    #define GLOBALREG_PLL_OBS_LDPCPLL_PACK_R (0x01 << 0)
    #define GLOBALREG_PLL_OBS_LDPCPLL_PACK_SHIFT 0
   /*
   * General purpose (32 scratch pad registers, n = 0-31)
   */
   #define GLOBALREG_SCRATCH_REG(n) (GLOBALREG_BASE_UNIT1 + 0xd00 + ((n)*4))
   /*
   * 32bit writable and readable register.They are not supposed to be reset, so that 
   * their values survive a reset and allow passing of info through a reset .
   */
   #define GLOBALREG_SCRATCH_VAL_RW    (0xffffffff << 0)
   #define GLOBALREG_SCRATCH_VAL_SHIFT 0

   /*
   * 12bit semaphore (16 semaphores, n = 0-15)
   */
   #define GLOBALREG_SEMAPHORE_REG(n)  (GLOBALREG_BASE_UNIT1 + 0xe00 + ((n)*4))
   /*
   * Reserved
   */
   #define GLOBALREG_SEMAPHORE_RESERVED_RW    (0x000fffff << 12)
   #define GLOBALREG_SEMAPHORE_RESERVED_SHIFT 12
   /*
   * Writing to this field is only accepted when its current content is zero or when 
   * the data to be written is zero.
   */
   #define GLOBALREG_SEMAPHORE_VAL_RW    (0xfff << 0)
   #define GLOBALREG_SEMAPHORE_VAL_SHIFT 0

   /* 8 IPC registers, n = 0-7 */
   #define GLOBALREG_IPC_BASE(n) (GLOBALREG_BASE_UNIT1 + 0xf00 + ((n)*0x20))
    /*
    * Interrupt clear enable for first IPC
    */
   #define GLOBALREG_IPC_INTERRUPT_CLR_ENABLE_REG(n) (GLOBALREG_IPC_BASE(n) + 0x00)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_CLR_ENABLE_RESERVED_W (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_CLR_ENABLE_RESERVED_SHIFT 8
   /*
   * IPC: clear interrupt enable bits of 8 interrupt bits; bits are under SW control
   *  for inter processor communication (IPC)
   */
   #define GLOBALREG_IPC_INTERRUPT_CLR_ENABLE_VAL_W     (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_CLR_ENABLE_VAL_SHIFT 0
   /*
   * Interrupt set enable for IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_ENABLE_REG1(n) (GLOBALREG_IPC_BASE(n) + 0x04)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_ENABLE_RESERVED_W (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_SET_ENABLE_RESERVED_SHIFT 8
   /*
   * IPC: set interrupt enable bits of 8 interrupt bits
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_ENABLE_VAL_W      (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_SET_ENABLE_VAL_SHIFT  0
   /*
   * Interrupt status for IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_STATUS_REG1(n)  (GLOBALREG_IPC_BASE(n) + 0x08)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_STATUS_RESERVED_R (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_STATUS_RESERVED_SHIFT 8
   /*
   * IPC: interrupt status of the 8 interrupt bits
   */
   #define GLOBALREG_IPC_INTERRUPT_STATUS_VAL_R      (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_STATUS_VAL_SHIFT  0
   /*
   * Interrupt enable for IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_ENABLE_REG(n) (GLOBALREG_IPC_BASE(n) + 0x0c)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_ENABLE_RESERVED_R (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_ENABLE_RESERVED_SHIFT 8
   /*
   * IPC: enable up to 8 interrupt bits
   */
   #define GLOBALREG_IPC_INTERRUPT_ENABLE_VAL_R     (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_ENABLE_VAL_SHIFT 0
   /*
   * Interrupt clear for IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_CLEAR_REG(n)  (GLOBALREG_IPC_BASE(n) + 0x10)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_CLEAR_RESERVED_W (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_CLEAR_RESERVED_SHIFT 8
   /*
   * IPC: clear up to 8 interrupt bits
   */
   #define GLOBALREG_IPC_INTERRUPT_CLEAR_VAL_W      (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_CLEAR_VAL_SHIFT  0
   /*
   * Interrupt set for IPC
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_REG(n)  (GLOBALREG_IPC_BASE(n) + 0x14)
   /*
   * Reserved
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_RESERVED_W (0x00ffffff << 8)
   #define GLOBALREG_IPC_INTERRUPT_SET_RESERVED_SHIFT 8
   /*
   * IPC: set up to 8 interrupt bits
   */
   #define GLOBALREG_IPC_INTERRUPT_SET_VAL_W      (0x0ff << 0)
   #define GLOBALREG_IPC_INTERRUPT_SET_VAL_SHIFT  0

    /*
    * Memory Size Select
    */
    #define GLOBALREG_MEM_SIZE_SEL_REG1  (GLOBALREG_BASE_UNIT1 + 0xff8)
    /*
    * Memory Size Select (no output)
    */
    #define GLOBALREG_MEM_SIZE_SEL_MEM_SIZE_SEL_RW (0x0ffffffff << 0)
    #define GLOBALREG_MEM_SIZE_SEL_MEM_SIZE_SEL_SHIFT 0
    /*
    * Global register module identification
    */
    #define GLOBALREG_MODULE_ID_REG1  (GLOBALREG_BASE_UNIT1 + 0xffc)
    /*
    * Unique 16-bit code.
    * This is 0xA150 for Kronos.
    * Variants identified by minor revision bit.
    */
    #define GLOBALREG_MODULE_ID_MODULE_ID_R (0x0ffff << 16)
    #define GLOBALREG_MODULE_ID_MODULE_ID_SHIFT 16
    /*
    * Major Revision Number
    */
    #define GLOBALREG_MODULE_ID_MAJOR_REV_R (0x0f << 12)
    #define GLOBALREG_MODULE_ID_MAJOR_REV_SHIFT 12
    /*
    * Minor Revision Number
    */
    #define GLOBALREG_MODULE_ID_MINOR_REV_R (0x0f << 8)
    #define GLOBALREG_MODULE_ID_MINOR_REV_SHIFT 8
    /*
    * Encoded as: Aperture size = 4K*(bit_value+1). The bit value is reset to 0 meanin
    * g a 4K aperture for the global register
    * module according to the formula above.
    */
    #define GLOBALREG_MODULE_ID_MODULE_APERTURE_SIZE_R (0x0ff << 0)
    #define GLOBALREG_MODULE_ID_MODULE_APERTURE_SIZE_SHIFT 0

#endif // PHMODIPGLOBALREG_H
