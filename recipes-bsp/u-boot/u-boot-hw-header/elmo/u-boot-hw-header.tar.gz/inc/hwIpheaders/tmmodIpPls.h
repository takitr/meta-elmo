/****************************************************************************/
/* CONEXANT PROPRIETARY AND CONFIDENTIAL                                    */
/* SOFTWARE FILE/MODULE HEADER                                              */
/* Conexant Systems Inc. (c) 2006-2007                                      */
/* Austin, TX                                                               */
/* All Rights Reserved                                                      */
/****************************************************************************/
/*
* Filename: pls_pecos.h
*
*
* Description: Public header file defining hardware-specific values
* (such as register addresses, bit definitions, etc.) for Pulse Timer module
*
* Author: Rajani Tirumalasetty & Arun Kumar Gogineni  
*
****************************************************************************/
/* $Id: tmmodIpPls.h 116549 2009-09-10 10:57:15Z balanid $
****************************************************************************/

#ifndef _TMMODIPPLS_H_
#define _TMMODIPPLS_H_

/*******************************************************************************
 *
 *     PLS_CONTROL_REG                                       (PLS_BASE + 0x00)
 *     PLS_FILTER_CLK_DIV_REG                                (PLS_BASE + 0x04)
 *     PLS_PULSE_TIMER_DIV_REG                               (PLS_BASE + 0x08)
 *     PLS_STATUS_REG                                        (PLS_BASE + 0x0C)
 *     PLS_FIFO_DATA_REG                                     (PLS_BASE + 0x10)
 *
 ******************************************************************************/

/* Macros allowing access to registers in different PLS instances */

#define PLS_CONTROL_REG                                      (PLS_BASE + 0x00)
#define PLS_CONTROL_REG_ADDR(iBank)          (PLS_CONTROL_REG +  \
                                             (iBank)*PLS_BANK_SIZE)
#define     PLS_CONTROL_ENABLE_MASK                               0x00000001
#define     PLS_CONTROL_ENABLE_SHIFT                                     0
#define        PLS_CONTROL_ENABLE_TRUE                               (1UL<<0)
#define        PLS_CONTROL_ENABLE_FALSE                              (0UL<<0)     
#define     PLS_CONTROL_FIFO_INT_CNTL_MASK                        0x00000002
#define     PLS_CONTROL_FIFO_INT_CNTL_SHIFT                              1
/* To do (for softwaer team): current code use this definition and should 
   be changed and remove this line. -- Lisa Fu */
#define        PLS_FIFO_INT_NOT_EMPTY                  1
#define        PLS_CONTROL_FIFO_INT_CNTL_NOT_EMPTY                   (1UL<<1)
#define        PLS_CONTROL_FIFO_INT_CNTL_HALF_FULL                   (0UL<<1)     
#define     PLS_CONTROL_EDGE_CNTL_MASK                            0x0000000C
#define     PLS_CONTROL_EDGE_CNTL_SHIFT                                  2
#define        PLS_CONTROL_EDGE_CNTL_DISABLED                        (0UL<<2)
#define        PLS_CONTROL_EDGE_CNTL_FALLING_EDGE                    (1UL<<2)
#define        PLS_CONTROL_EDGE_CNTL_RISING_EDGE                     (2UL<<2)
#define        PLS_CONTROL_EDGE_CNTL_EITHER_EDGE                     (3UL<<2)
/* To do (for software team): current code use this value unshifted. We should 
   change the code to use shifted value PLS_CONTROL_EDGE_CNTL_EITHER_EDGE 
   and remove this line. --Lisa Fu */
#define PLS_EDGE_DISABLE        0x00
#define PLS_EDGE_FALLING        0x01
#define PLS_EDGE_RISING         0x02   
#define PLS_EDGE_EITHER         0x03
#define     PLS_CONTROL_FIFO_INT_ENABLE_MASK                      0x00000010
#define     PLS_CONTROL_FIFO_INT_ENABLE_SHIFT                            4
#define        PLS_CONTROL_FIFO_INT_ENABLE_ENABLED                   (1UL<<4)
#define        PLS_CONTROL_FIFO_INT_ENABLE_DISABLED                  (0UL<<4)
#define     PLS_CONTROL_OVERRUN_INT_ENABLE_MASK                   0x00000020
#define     PLS_CONTROL_OVERRUN_INT_ENABLE_SHIFT                         5
#define        PLS_CONTROL_OVERRUN_INT_ENABLE_ENABLED                (1UL<<5)
#define        PLS_CONTROL_OVERRUN_INT_ENABLE_DISABLED               (0UL<<5)
#define     PLS_CONTROL_TIMEOUT_INT_ENABLE_MASK                   0x00000040
#define     PLS_CONTROL_TIMEOUT_INT_ENABLE_SHIFT                         6
#define        PLS_CONTROL_TIMEOUT_INT_ENABLE_ENABLED                (1UL<<6)
#define        PLS_CONTROL_TIMEOUT_INT_ENABLE_DISABLED               (0UL<<6)
#define     PLS_CONTROL_PULSE_DELAY_FILTER_ENABLE_MASK            0x00000080
#define     PLS_CONTROL_PULSE_DELAY_FILTER_ENABLE_SHIFT                  7
#define        PLS_CONTROL_PULSE_DELAY_FILTER_ENABLE_DELAY           (1UL<<7)
#define        PLS_CONTROL_PULSE_DELAY_FILTER_ENABLE_LEGACY          (0UL<<7)
#define     PLS_CONTROL_PULSE_INTEG_FILTER_ENABLE_MASK            0x00000100
#define     PLS_CONTROL_PULSE_INTEG_FILTER_ENABLE_SHIFT                  8
#define        PLS_CONTROL_PULSE_INTEG_FILTER_ENABLE_UPDOWN_COUNTER  (1UL<<8)
#define        PLS_CONTROL_PULSE_INTEG_FILTER_ENABLE_IGNORE_PULSES   (0UL<<8)

#define PLS_FILTER_CLK_DIV_REG                               (PLS_BASE + 0x04)
#define PLS_FILTER_CLK_DIV_REG_ADDR(iBank)   (PLS_FILTER_CLK_DIV_REG  +  \
                                             (iBank)*PLS_BANK_SIZE)
#define     PLS_FILTER_CLK_DIV_MODULUS_VALUE_MASK                 0x0000FFFF
#define     PLS_FILTER_CLK_DIV_MODULUS_VALUE_SHIFT                       0

#define PLS_PULSE_TIMER_DIV_REG                              (PLS_BASE + 0x08)
#define PLS_PULSE_TIMER_DIV_REG_ADDR(iBank)  (PLS_PULSE_TIMER_DIV_REG +  \
                                             (iBank)*PLS_BANK_SIZE)
#define     PLS_PULSE_TIMER_DIV_CLOCK_DIVIDER_MASK                0x0000FFFF
#define     PLS_PULSE_TIMER_DIV_CLOCK_DIVIDER_SHIFT                      0

#define PLS_STATUS_REG                                       (PLS_BASE + 0x0C)
#define PLS_STATUS_REG_ADDR(iBank)           (PLS_STATUS_REG +  \
                                             (iBank)*PLS_BANK_SIZE)
#define     PLS_STATUS_FIFO_SERVICE_MASK                          0x00000001
#define     PLS_STATUS_FIFO_SERVICE_SHIFT                                0
#define        PLS_STATUS_FIFO_SERVICE_FIFO_NOT_EMPTY                (1UL<<0)
#define        PLS_STATUS_FIFO_SERVICE_FIFO_EMPTY                    (0UL<<0)
#define     PLS_STATUS_FIFO_OVERRUN_MASK                          0x00000002
#define     PLS_STATUS_FIFO_OVERRUN_SHIFT                                1
#define        PLS_STATUS_FIFO_OVERRUN_EXPERIENCED                   (1UL<<1)
#define        PLS_STATUS_FIFO_OVERRUN_NOT_EXPERIENCED               (0UL<<1)
#define     PLS_STATUS_TIMEOUT_MASK                               0x00000004
#define     PLS_STATUS_TIMEOUT_SHIFT                                     2
#define        PLS_STATUS_TIMEOUT_LIMIT_REACHED                      (1UL<<2)
#define        PLS_STATUS_TIMEOUT_LIMIT_NOT_REACHED                  (0UL<<2)
#define     PLS_STATUS_BUSY_MASK                                  0x00000008
#define     PLS_STATUS_BUSY_SHIFT                                        3
#define        PLS_STATUS_BUSY_PT_BUSY                               (1UL<<3)
#define        PLS_STATUS_BUSY_PT_IDLE                               (0UL<<3)


#define PLS_FIFO_DATA_REG                                    (PLS_BASE + 0x10)
#define PLS_FIFO_DATA_REG_ADDR(iBank)        (PLS_FIFO_DATA_REG+  \
                                             (iBank)*PLS_BANK_SIZE)
#define     PLS_FIFO_DATA_WIDTH_MEASUREMENT_MASK                  0x0000FFFF
#define     PLS_FIFO_DATA_WIDTH_MEASUREMENT_SHIFT                        0
#define     PLS_FIFO_DATA_PIN_LEVEL_MASK                          0x00010000
#define     PLS_FIFO_DATA_PIN_LEVEL_SHIFT                                16
#define        PLS_FIFO_DATA_PIN_LEVEL_HIGH                          (1UL<<16)
#define        PLS_FIFO_DATA_PIN_LEVEL_LOW                           (0UL<<16)
#define     PLS_FIFO_DATA_NEXT_DATA_VALID_MASK                    0x00020000
#define     PLS_FIFO_DATA_NEXT_DATA_VALID_SHIFT                          17
#define        PLS_FIFO_DATA_NEXT_DATA_VALID_FIFO_NOT_EMPTY          (1UL<<17)
#define        PLS_FIFO_DATA_NEXT_DATA_VALID_FIFO_EMPTY              (0UL<<17)

/* Absolute values for writing the whole register at once */
/* To do (for software team): move these definitions to next to their 
   reigsters. */
#define PLS_DATA_MASK  0x0000FFFF
#define PLS_BIT_LEVEL  0x00010000
#define PLS_DATA_AVAIL 0x00020000

#endif /* _TMMODIPPLS_H_ */


/****************************************************************************
* Modifications:
* $Log$
*
*****************************************************************************/

