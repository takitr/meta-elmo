////////////////////////////////////////////////////////////////////// 
//                                                                  // 
// (c) NXP B.V 2009                                                 // 
//                                                                  // 
// All rights are reserved. Reproduction in whole or in part is     // 
// prohibited without the prior written consent of the copy-right   // 
// owner.                                                           // 
// The information presented in this document does not form part of // 
// any quotation or contract, is believed to be accurate and        // 
// reliable and may be changed without notice. No liability will be // 
// accepted by the publisher for any consequence of its use.        //
// Publication thereof does not convey nor imply any license under  //
// patent- or other industrial or intellectual property rights.     //
////////////////////////////////////////////////////////////////////// 
 
/*! 
 *  @brief Header file for SPI
 *  @file phmodIpSpi.h *
 *  <pre>
 *  $Author: kumarh4 $
 *  $Revision: 119719 $
 *  $Date: 2009-09-23 05:02:39 -0500 (Wed, 23 Sep 2009) $
 *
 *  Revision history
 *  $Log: $
 *  
 *
 *  $KeysEnd$
 *  </pre>
 *
 */ 


#ifndef PHMODIPSPI_H
#define PHMODIPSPI_H
	
	/*
	* SPI Configuration Register
	*/
	#define SPI_CONFIG_REG  (SPI_BASE + 0x0)
	/*
	* The minimum delay between 2 transfers to different slaves (in clk cycles), (min 
	* = 1)
	*/
	#define SPI_CONFIG_INTER_SLAVE_DLY_RW (0x07fff << 16)
	#define SPI_CONFIG_INTER_SLAVE_DLY_SHIFT 16
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_CONFIG_RESERVED9_RES (0x07f << 8)
	#define SPI_CONFIG_RESERVED9_SHIFT 8
	/*
	* Update enable (0: current value in SLAVE_ENABLE used for tx, 1: newly written va
	* lue in SLAVE_ENABLE not used for tx yet)
	*/
	#define SPI_CONFIG_UPDATE_ENABLE_RW (0x01 << 7)
	#define SPI_CONFIG_UPDATE_ENABLE_SHIFT 7
	#define SPI_CONFIG_UPDATE_ENABLE_VAL0 0x00
	#define SPI_CONFIG_UPDATE_ENABLE_VAL1 0x01
	/*
	* Software Reset (1: resets SPI, self-clearing)
	*/
	#define SPI_CONFIG_SOFTWARE_RESET_RW (0x01 << 6)
	#define SPI_CONFIG_SOFTWARE_RESET_SHIFT 6
	#define SPI_CONFIG_SOFTWARE_RESET_VAL0 0x00
	#define SPI_CONFIG_SOFTWARE_RESET_VAL1 0x01
	/*
	* Timer triggering enable (0: trigger pulses are ignored, 1: trigger pulses enable
	*  SPI)
	*/
	#define SPI_CONFIG_TIMER_TRIGGER_RW (0x01 << 5)
	#define SPI_CONFIG_TIMER_TRIGGER_SHIFT 5
	#define SPI_CONFIG_TIMER_TRIGGER_VAL0 0x00
	#define SPI_CONFIG_TIMER_TRIGGER_VAL1 0x01
	/*
	* Slave output disable, only relevant in slave mode (0: slave can drive its tx dat
	* a, 1: slave must not drive its tx data)
	*/
	#define SPI_CONFIG_SLAVE_DISABLE_RW (0x01 << 4)
	#define SPI_CONFIG_SLAVE_DISABLE_SHIFT 4
	#define SPI_CONFIG_SLAVE_DISABLE_VAL0 0x00
	#define SPI_CONFIG_SLAVE_DISABLE_VAL1 0x01
	/*
	* Transmit mode (0: normal, 1: sequential multi-slave)
	*/
	#define SPI_CONFIG_TRANSMIT_MODE_RW (0x01 << 3)
	#define SPI_CONFIG_TRANSMIT_MODE_SHIFT 3
	#define SPI_CONFIG_TRANSMIT_MODE_VAL0 0x00
	#define SPI_CONFIG_TRANSMIT_MODE_VAL1 0x01
	/*
	* Loopback mode (0: normal serial interface, 1: tx data internally looped back)
	*/
	#define SPI_CONFIG_LOOPBACK_MODE_RW (0x01 << 2)
	#define SPI_CONFIG_LOOPBACK_MODE_SHIFT 2
	#define SPI_CONFIG_LOOPBACK_MODE_VAL0 0x00
	#define SPI_CONFIG_LOOPBACK_MODE_VAL1 0x01
	/*
	* Master/Slave mode bit (0: master, 1: slave)
	*/
	#define SPI_CONFIG_MS_MODE_RW (0x01 << 1)
	#define SPI_CONFIG_MS_MODE_SHIFT 1
	#define SPI_CONFIG_MS_MODE_VAL0 0x00
	#define SPI_CONFIG_MS_MODE_VAL1 0x01
	/*
	* SPI enable bit (0: enable, 1: disable)
	*/
	#define SPI_CONFIG_SPI_ENABLE_RW (0x01 << 0)
	#define SPI_CONFIG_SPI_ENABLE_SHIFT 0
	#define SPI_CONFIG_SPI_ENABLE_VAL0 0x00
	#define SPI_CONFIG_SPI_ENABLE_VAL1 0x01
	/*
	* Slave Enable Register
	*/
	#define SPI_SLAVE_ENABLE_REG  (SPI_BASE + 0x4)
	/*
	* Slave Enable Register
	*/
	#define SPI_SLAVE_ENABLE_SLAVE_ENABLE_RW (0x07fffffff << 0)
	#define SPI_SLAVE_ENABLE_SLAVE_ENABLE_SHIFT 0
	/*
	* Transmit FIFO Flush Register
	*/
	#define SPI_TX_FIFO_FLUSH_REG  (SPI_BASE + 0x8)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_TX_FIFO_FLUSH_RESERVED1_RES (0x03fffffff << 1)
	#define SPI_TX_FIFO_FLUSH_RESERVED1_SHIFT 1
	/*
	* Tx Flush bit (0: no action, 1: flush tx FIFO)
	*/
	#define SPI_TX_FIFO_FLUSH_TX_FIFO_FLUSH_W (0x01 << 0)
	#define SPI_TX_FIFO_FLUSH_TX_FIFO_FLUSH_SHIFT 0
	#define SPI_TX_FIFO_FLUSH_TX_FIFO_FLUSH_VAL0 0x00
	#define SPI_TX_FIFO_FLUSH_TX_FIFO_FLUSH_VAL1 0x01
	/*
	* FIFO Data Register
	*/
	#define SPI_FIFO_DATA_REG  (SPI_BASE + 0xc)
	/*
	* FIFO Data Register
	*/
	#define SPI_FIFO_DATA_FIFO_DATA_RW (0x07fffffff << 0)
	#define SPI_FIFO_DATA_FIFO_DATA_SHIFT 0
	/*
	* NHP POP Register
	*/
	#define SPI_NHP_POP_REG  (SPI_BASE + 0x10)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_NHP_POP_RESERVED1_RES (0x03fffffff << 1)
	#define SPI_NHP_POP_RESERVED1_SHIFT 1
	/*
	* Setting this bit will pop the first element from the rx FIFO
	*/
	#define SPI_NHP_POP_NHP_POP_W (0x01 << 0)
	#define SPI_NHP_POP_NHP_POP_SHIFT 0
	#define SPI_NHP_POP_NHP_POP_VAL0 0x00
	#define SPI_NHP_POP_NHP_POP_VAL1 0x01
	/*
	* NHP Mode Register
	*/
	#define SPI_NHP_MODE_REG  (SPI_BASE + 0x14)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_NHP_MODE_RESERVED1_RES (0x03fffffff << 1)
	#define SPI_NHP_MODE_RESERVED1_SHIFT 1
	/*
	* NHP mode enable (0: disables NHP mode, 1: enables NHP mode)
	*/
	#define SPI_NHP_MODE_NHP_MODE_RW (0x01 << 0)
	#define SPI_NHP_MODE_NHP_MODE_SHIFT 0
	#define SPI_NHP_MODE_NHP_MODE_VAL0 0x00
	#define SPI_NHP_MODE_NHP_MODE_VAL1 0x01
	/*
	* DMA Settings Register
	*/
	#define SPI_DMA_SETTINGS_REG  (SPI_BASE + 0x18)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_DMA_SETTINGS_RESERVED4_RES (0x07fffff << 8)
	#define SPI_DMA_SETTINGS_RESERVED4_SHIFT 8
	/*
	* DMA burst will be requested when FIFO contains a number of free spaces defined b
	* y this field
	*/
	#define SPI_DMA_SETTINGS_TX_DMA_BURST_RW (0x03 << 5)
	#define SPI_DMA_SETTINGS_TX_DMA_BURST_SHIFT 5
	#define SPI_DMA_SETTINGS_TX_DMA_BURST_VAL0 0x00
	#define SPI_DMA_SETTINGS_TX_DMA_BURST_VAL1 0x01
	#define SPI_DMA_SETTINGS_TX_DMA_BURST_VAL2 0x02
	#define SPI_DMA_SETTINGS_TX_DMA_BURST_VAL3 0x03
	/*
	* DMA burst will be requested when FIFO contains a number of elements defined by t
	* his field
	*/
	#define SPI_DMA_SETTINGS_RX_DMA_BURST_RW (0x03 << 2)
	#define SPI_DMA_SETTINGS_RX_DMA_BURST_SHIFT 2
	#define SPI_DMA_SETTINGS_RX_DMA_BURST_VAL0 0x00
	#define SPI_DMA_SETTINGS_RX_DMA_BURST_VAL1 0x01
	#define SPI_DMA_SETTINGS_RX_DMA_BURST_VAL2 0x02
	#define SPI_DMA_SETTINGS_RX_DMA_BURST_VAL3 0x03
	/*
	* Enable tx DMA (0: tx DMA disabled, 1: tx DMA enabled)
	*/
	#define SPI_DMA_SETTINGS_TX_DMA_ENABLE_RW (0x01 << 1)
	#define SPI_DMA_SETTINGS_TX_DMA_ENABLE_SHIFT 1
	#define SPI_DMA_SETTINGS_TX_DMA_ENABLE_VAL0 0x00
	#define SPI_DMA_SETTINGS_TX_DMA_ENABLE_VAL1 0x01
	/*
	* Enable rx DMA (0: rx DMA disabled, 1: rx DMA enabled)
	*/
	#define SPI_DMA_SETTINGS_RX_DMA_ENABLE_RW (0x01 << 0)
	#define SPI_DMA_SETTINGS_RX_DMA_ENABLE_SHIFT 0
	#define SPI_DMA_SETTINGS_RX_DMA_ENABLE_VAL0 0x00
	#define SPI_DMA_SETTINGS_RX_DMA_ENABLE_VAL1 0x01
	/*
	* Status Register
	*/
	#define SPI_STATUS_REG  (SPI_BASE + 0x1c)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_STATUS_RESERVED6_RES (0x01ffffff << 6)
	#define SPI_STATUS_RESERVED6_SHIFT 6
	/*
	* Sequential multi-slave mode busy flag (0:SPI is not busy transmitting in sequent
	* ial multi-slave mode, 1: busy, self-clearing when done)
	*/
	#define SPI_STATUS_SMS_MODE_BUSY_R (0x01 << 5)
	#define SPI_STATUS_SMS_MODE_BUSY_SHIFT 5
	#define SPI_STATUS_SMS_MODE_BUSY_VAL0 0x00
	#define SPI_STATUS_SMS_MODE_BUSY_VAL1 0x01
	/*
	* SPI busy flag (0: SPI is idle, 1: SPI is transmitting/receiving or tx FIFO is no
	* t empty)
	*/
	#define SPI_STATUS_SPI_BUSY_R (0x01 << 4)
	#define SPI_STATUS_SPI_BUSY_SHIFT 4
	#define SPI_STATUS_SPI_BUSY_VAL0 0x00
	#define SPI_STATUS_SPI_BUSY_VAL1 0x01
	/*
	* Receive FIFO full (0: rx FIFO not full, 1: rx FIFO full)
	*/
	#define SPI_STATUS_RX_FIFO_FULL_R (0x01 << 3)
	#define SPI_STATUS_RX_FIFO_FULL_SHIFT 3
	#define SPI_STATUS_RX_FIFO_FULL_VAL0 0x00
	#define SPI_STATUS_RX_FIFO_FULL_VAL1 0x01
	/*
	* Receive FIFO empty (0: rx FIFO not empty, 1: rx FIFO empty)
	*/
	#define SPI_STATUS_RX_FIFO_EMPTY_R (0x01 << 2)
	#define SPI_STATUS_RX_FIFO_EMPTY_SHIFT 2
	#define SPI_STATUS_RX_FIFO_EMPTY_VAL0 0x00
	#define SPI_STATUS_RX_FIFO_EMPTY_VAL1 0x01
	/*
	* Transmit FIFO full (0: tx FIFO not full, 1: tx FIFO full)
	*/
	#define SPI_STATUS_TX_FIFO_FULL_R (0x01 << 1)
	#define SPI_STATUS_TX_FIFO_FULL_SHIFT 1
	#define SPI_STATUS_TX_FIFO_FULL_VAL0 0x00
	#define SPI_STATUS_TX_FIFO_FULL_VAL1 0x01
	/*
	* Transmit FIFO empty (0: tx FIFO not empty, 1: tx FIFO empty)
	*/
	#define SPI_STATUS_TX_FIFO_EMPTY_R (0x01 << 0)
	#define SPI_STATUS_TX_FIFO_EMPTY_SHIFT 0
	#define SPI_STATUS_TX_FIFO_EMPTY_VAL0 0x00
	#define SPI_STATUS_TX_FIFO_EMPTY_VAL1 0x01
	/*
	* Hardware Information Register
	*/
	#define SPI_HW_INFO_REG  (SPI_BASE + 0x20)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_HW_INFO_RESERVED6_RES (0x01 << 31)
	#define SPI_HW_INFO_RESERVED6_SHIFT 31
	#define SPI_HW_INFO_RESERVED6_VAL0 0x00
	#define SPI_HW_INFO_RESERVED6_VAL1 0x01
	/*
	* The memory implementation (0: flipflops, 1: SRAM)
	*/
	#define SPI_HW_INFO_FIFOIMPL_R (0x01 << 30)
	#define SPI_HW_INFO_FIFOIMPL_SHIFT 30
	#define SPI_HW_INFO_FIFOIMPL_VAL0 0x00
	#define SPI_HW_INFO_FIFOIMPL_VAL1 0x01
	/*
	* The maximum number of slaves supported (minus 1 encoded)
	*/
	#define SPI_HW_INFO_NUM_SLAVES_R (0x07 << 26)
	#define SPI_HW_INFO_NUM_SLAVES_SHIFT 26
	#define SPI_HW_INFO_NUM_SLAVES_VAL0 0x00
	#define SPI_HW_INFO_NUM_SLAVES_VAL1 0x01
	#define SPI_HW_INFO_NUM_SLAVES_VAL2 0x02
	#define SPI_HW_INFO_NUM_SLAVES_VAL3 0x03
	#define SPI_HW_INFO_NUM_SLAVES_VAL4 0x04
	#define SPI_HW_INFO_NUM_SLAVES_VAL5 0x05
	#define SPI_HW_INFO_NUM_SLAVES_VAL6 0x06
	#define SPI_HW_INFO_NUM_SLAVES_VAL7 0x07
	/*
	* The width of the transmit FIFO (minus 1 encoded)
	*/
	#define SPI_HW_INFO_TX_FIFO_WIDTH_R (0x0f << 21)
	#define SPI_HW_INFO_TX_FIFO_WIDTH_SHIFT 21
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL0 0x00
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL1 0x01
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL2 0x02
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL3 0x03
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL4 0x04
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL5 0x05
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL6 0x06
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL7 0x07
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL8 0x08
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL9 0x09
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL10 0x0a
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL11 0x0b
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL12 0x0c
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL13 0x0d
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL14 0x0e
	#define SPI_HW_INFO_TX_FIFO_WIDTH_VAL15 0x0f
	/*
	* The width of the receive FIFO (minus 1 encoded)
	*/
	#define SPI_HW_INFO_RX_FIFO_WIDTH_R (0x0f << 16)
	#define SPI_HW_INFO_RX_FIFO_WIDTH_SHIFT 16
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL0 0x00
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL1 0x01
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL2 0x02
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL3 0x03
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL4 0x04
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL5 0x05
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL6 0x06
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL7 0x07
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL8 0x08
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL9 0x09
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL10 0x0a
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL11 0x0b
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL12 0x0c
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL13 0x0d
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL14 0x0e
	#define SPI_HW_INFO_RX_FIFO_WIDTH_VAL15 0x0f
	/*
	* The depth of the transmit FIFO (minus 1 encoded)
	*/
	#define SPI_HW_INFO_TX_FIFO_DEPTH_R (0x07f << 8)
	#define SPI_HW_INFO_TX_FIFO_DEPTH_SHIFT 8
	/*
	* The depth of the receive FIFO (minus 1 encoded)
	*/
	#define SPI_HW_INFO_RX_FIFO_DEPTH_R (0x0ff << 0)
	#define SPI_HW_INFO_RX_FIFO_DEPTH_SHIFT 0
	/*
	* Slave Settings Register 1 for slave loop
	*/
	#define SPI_SLV0_SETTINGS1_REG  (SPI_BASE + 0x24)
	/*
	* The delay between transfers to slave loop (in serial clk cycles) (only relevant 
	* in master mode)
	*/
	#define SPI_SLV0_SETTINGS1_INTER_TRANSFER_DLY_RW (0x07f << 24)
	#define SPI_SLV0_SETTINGS1_INTER_TRANSFER_DLY_SHIFT 24
	/*
	* Number of words to send in sequential multi-slave mode (only relevant in master 
	* mode) (minus 1 encoded)
	*/
	#define SPI_SLV0_SETTINGS1_NUMBER_WORDS_RW (0x07f << 16)
	#define SPI_SLV0_SETTINGS1_NUMBER_WORDS_SHIFT 16
	/*
	* Serial clock divisor 2 (min = 2)
	*/
	#define SPI_SLV0_SETTINGS1_CLK_DIVISOR2_RW (0x07f << 8)
	#define SPI_SLV0_SETTINGS1_CLK_DIVISOR2_SHIFT 8
	/*
	* Serial clock divisor 1
	*/
	#define SPI_SLV0_SETTINGS1_CLK_DIVISOR1_RW (0x0ff << 0)
	#define SPI_SLV0_SETTINGS1_CLK_DIVISOR1_SHIFT 0
	/*
	* Slave Settings Register 2 for slave loop
	*/
	#define SPI_SLV0_SETTINGS2_REG  (SPI_BASE + 0x28)
	/*
	* Programmable delay occuring twice in a transfer (in clk cycles) (minus 1 encoded
	* )
	*/
	#define SPI_SLV0_SETTINGS2_PRE_POST_CS_DLY_RW (0x07f << 24)
	#define SPI_SLV0_SETTINGS2_PRE_POST_CS_DLY_SHIFT 24
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_SLV0_SETTINGS2_RESERVED6_RES (0x03fff << 9)
	#define SPI_SLV0_SETTINGS2_RESERVED6_SHIFT 9
	/*
	* Chip-Select value between back-to-back transfers(0: CS is steady state low value
	*  between transfers, 1: CS is steady state high value between transfers)
	*/
	#define SPI_SLV0_SETTINGS2_CS_VALUE_RW (0x01 << 8)
	#define SPI_SLV0_SETTINGS2_CS_VALUE_SHIFT 8
	#define SPI_SLV0_SETTINGS2_CS_VALUE_VAL0 0x00
	#define SPI_SLV0_SETTINGS2_CS_VALUE_VAL1 0x01
	/*
	* Format of transfer (0:SSI, 1: SPI)
	*/
	#define SPI_SLV0_SETTINGS2_TRANSFER_FORMAT_RW (0x01 << 7)
	#define SPI_SLV0_SETTINGS2_TRANSFER_FORMAT_SHIFT 7
	#define SPI_SLV0_SETTINGS2_TRANSFER_FORMAT_VAL0 0x00
	#define SPI_SLV0_SETTINGS2_TRANSFER_FORMAT_VAL1 0x01
	/*
	* Serial clock polarity (0: Clk is steady state low value between transfers, 1: Cl
	* k is steady state high value between transfers)
	*/
	#define SPI_SLV0_SETTINGS2_SPO_RW (0x01 << 6)
	#define SPI_SLV0_SETTINGS2_SPO_SHIFT 6
	#define SPI_SLV0_SETTINGS2_SPO_VAL0 0x00
	#define SPI_SLV0_SETTINGS2_SPO_VAL1 0x01
	/*
	* Serial clock phase (0: First data bit is captured on first clock edge of new tra
	* nsfer, 1: First data bit captured on second clock edge)
	*/
	#define SPI_SLV0_SETTINGS2_SPH_RW (0x01 << 5)
	#define SPI_SLV0_SETTINGS2_SPH_SHIFT 5
	#define SPI_SLV0_SETTINGS2_SPH_VAL0 0x00
	#define SPI_SLV0_SETTINGS2_SPH_VAL1 0x01
	/*
	* Datasize of transfers to slave loop (minus 1 encoded)
	*/
	#define SPI_SLV0_SETTINGS2_DATASIZE_RW (0x01f << 0)
	#define SPI_SLV0_SETTINGS2_DATASIZE_SHIFT 0
	/*
	* Slave Settings Register 1 for slave loop
	*/
	#define SPI_SLV1_SETTINGS1_REG  (SPI_BASE + 0x2c)
	/*
	* The delay between transfers to slave loop (in serial clk cycles) (only relevant 
	* in master mode)
	*/
	#define SPI_SLV1_SETTINGS1_INTER_TRANSFER_DLY_RW (0x07f << 24)
	#define SPI_SLV1_SETTINGS1_INTER_TRANSFER_DLY_SHIFT 24
	/*
	* Number of words to send in sequential multi-slave mode (only relevant in master 
	* mode) (minus 1 encoded)
	*/
	#define SPI_SLV1_SETTINGS1_NUMBER_WORDS_RW (0x07f << 16)
	#define SPI_SLV1_SETTINGS1_NUMBER_WORDS_SHIFT 16
	/*
	* Serial clock divisor 2 (min = 2)
	*/
	#define SPI_SLV1_SETTINGS1_CLK_DIVISOR2_RW (0x07f << 8)
	#define SPI_SLV1_SETTINGS1_CLK_DIVISOR2_SHIFT 8
	/*
	* Serial clock divisor 1
	*/
	#define SPI_SLV1_SETTINGS1_CLK_DIVISOR1_RW (0x0ff << 0)
	#define SPI_SLV1_SETTINGS1_CLK_DIVISOR1_SHIFT 0
	/*
	* Slave Settings Register 2 for slave loop
	*/
	#define SPI_SLV1_SETTINGS2_REG  (SPI_BASE + 0x30)
	/*
	* Programmable delay occuring twice in a transfer (in clk cycles) (minus 1 encoded
	* )
	*/
	#define SPI_SLV1_SETTINGS2_PRE_POST_CS_DLY_RW (0x07f << 24)
	#define SPI_SLV1_SETTINGS2_PRE_POST_CS_DLY_SHIFT 24
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_SLV1_SETTINGS2_RESERVED6_RES (0x03fff << 9)
	#define SPI_SLV1_SETTINGS2_RESERVED6_SHIFT 9
	/*
	* Chip-Select value between back-to-back transfers(0: CS is steady state low value
	*  between transfers, 1: CS is steady state high value between transfers)
	*/
	#define SPI_SLV1_SETTINGS2_CS_VALUE_RW (0x01 << 8)
	#define SPI_SLV1_SETTINGS2_CS_VALUE_SHIFT 8
	#define SPI_SLV1_SETTINGS2_CS_VALUE_VAL0 0x00
	#define SPI_SLV1_SETTINGS2_CS_VALUE_VAL1 0x01
	/*
	* Format of transfer (0:SSI, 1: SPI)
	*/
	#define SPI_SLV1_SETTINGS2_TRANSFER_FORMAT_RW (0x01 << 7)
	#define SPI_SLV1_SETTINGS2_TRANSFER_FORMAT_SHIFT 7
	#define SPI_SLV1_SETTINGS2_TRANSFER_FORMAT_VAL0 0x00
	#define SPI_SLV1_SETTINGS2_TRANSFER_FORMAT_VAL1 0x01
	/*
	* Serial clock polarity (0: Clk is steady state low value between transfers, 1: Cl
	* k is steady state high value between transfers)
	*/
	#define SPI_SLV1_SETTINGS2_SPO_RW (0x01 << 6)
	#define SPI_SLV1_SETTINGS2_SPO_SHIFT 6
	#define SPI_SLV1_SETTINGS2_SPO_VAL0 0x00
	#define SPI_SLV1_SETTINGS2_SPO_VAL1 0x01
	/*
	* Serial clock phase (0: First data bit is captured on first clock edge of new tra
	* nsfer, 1: First data bit captured on second clock edge)
	*/
	#define SPI_SLV1_SETTINGS2_SPH_RW (0x01 << 5)
	#define SPI_SLV1_SETTINGS2_SPH_SHIFT 5
	#define SPI_SLV1_SETTINGS2_SPH_VAL0 0x00
	#define SPI_SLV1_SETTINGS2_SPH_VAL1 0x01
	/*
	* Datasize of transfers to slave loop (minus 1 encoded)
	*/
	#define SPI_SLV1_SETTINGS2_DATASIZE_RW (0x01f << 0)
	#define SPI_SLV1_SETTINGS2_DATASIZE_SHIFT 0
	/*
	* Slave Settings Register 1 for slave loop
	*/
	#define SPI_SLV2_SETTINGS1_REG  (SPI_BASE + 0x34)
	/*
	* The delay between transfers to slave loop (in serial clk cycles) (only relevant 
	* in master mode)
	*/
	#define SPI_SLV2_SETTINGS1_INTER_TRANSFER_DLY_RW (0x07f << 24)
	#define SPI_SLV2_SETTINGS1_INTER_TRANSFER_DLY_SHIFT 24
	/*
	* Number of words to send in sequential multi-slave mode (only relevant in master 
	* mode) (minus 1 encoded)
	*/
	#define SPI_SLV2_SETTINGS1_NUMBER_WORDS_RW (0x07f << 16)
	#define SPI_SLV2_SETTINGS1_NUMBER_WORDS_SHIFT 16
	/*
	* Serial clock divisor 2 (min = 2)
	*/
	#define SPI_SLV2_SETTINGS1_CLK_DIVISOR2_RW (0x07f << 8)
	#define SPI_SLV2_SETTINGS1_CLK_DIVISOR2_SHIFT 8
	/*
	* Serial clock divisor 1
	*/
	#define SPI_SLV2_SETTINGS1_CLK_DIVISOR1_RW (0x0ff << 0)
	#define SPI_SLV2_SETTINGS1_CLK_DIVISOR1_SHIFT 0
	/*
	* Slave Settings Register 2 for slave loop
	*/
	#define SPI_SLV2_SETTINGS2_REG  (SPI_BASE + 0x38)
	/*
	* Programmable delay occuring twice in a transfer (in clk cycles) (minus 1 encoded
	* )
	*/
	#define SPI_SLV2_SETTINGS2_PRE_POST_CS_DLY_RW (0x07f << 24)
	#define SPI_SLV2_SETTINGS2_PRE_POST_CS_DLY_SHIFT 24
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_SLV2_SETTINGS2_RESERVED6_RES (0x03fff << 9)
	#define SPI_SLV2_SETTINGS2_RESERVED6_SHIFT 9
	/*
	* Chip-Select value between back-to-back transfers(0: CS is steady state low value
	*  between transfers, 1: CS is steady state high value between transfers)
	*/
	#define SPI_SLV2_SETTINGS2_CS_VALUE_RW (0x01 << 8)
	#define SPI_SLV2_SETTINGS2_CS_VALUE_SHIFT 8
	#define SPI_SLV2_SETTINGS2_CS_VALUE_VAL0 0x00
	#define SPI_SLV2_SETTINGS2_CS_VALUE_VAL1 0x01
	/*
	* Format of transfer (0:SSI, 1: SPI)
	*/
	#define SPI_SLV2_SETTINGS2_TRANSFER_FORMAT_RW (0x01 << 7)
	#define SPI_SLV2_SETTINGS2_TRANSFER_FORMAT_SHIFT 7
	#define SPI_SLV2_SETTINGS2_TRANSFER_FORMAT_VAL0 0x00
	#define SPI_SLV2_SETTINGS2_TRANSFER_FORMAT_VAL1 0x01
	/*
	* Serial clock polarity (0: Clk is steady state low value between transfers, 1: Cl
	* k is steady state high value between transfers)
	*/
	#define SPI_SLV2_SETTINGS2_SPO_RW (0x01 << 6)
	#define SPI_SLV2_SETTINGS2_SPO_SHIFT 6
	#define SPI_SLV2_SETTINGS2_SPO_VAL0 0x00
	#define SPI_SLV2_SETTINGS2_SPO_VAL1 0x01
	/*
	* Serial clock phase (0: First data bit is captured on first clock edge of new tra
	* nsfer, 1: First data bit captured on second clock edge)
	*/
	#define SPI_SLV2_SETTINGS2_SPH_RW (0x01 << 5)
	#define SPI_SLV2_SETTINGS2_SPH_SHIFT 5
	#define SPI_SLV2_SETTINGS2_SPH_VAL0 0x00
	#define SPI_SLV2_SETTINGS2_SPH_VAL1 0x01
	/*
	* Datasize of transfers to slave loop (minus 1 encoded)
	*/
	#define SPI_SLV2_SETTINGS2_DATASIZE_RW (0x01f << 0)
	#define SPI_SLV2_SETTINGS2_DATASIZE_SHIFT 0
	/*
	* Slave Settings Register 1 for slave loop
	*/
	#define SPI_SLV3_SETTINGS1_REG  (SPI_BASE + 0x3c)
	/*
	* The delay between transfers to slave loop (in serial clk cycles) (only relevant 
	* in master mode)
	*/
	#define SPI_SLV3_SETTINGS1_INTER_TRANSFER_DLY_RW (0x07f << 24)
	#define SPI_SLV3_SETTINGS1_INTER_TRANSFER_DLY_SHIFT 24
	/*
	* Number of words to send in sequential multi-slave mode (only relevant in master 
	* mode) (minus 1 encoded)
	*/
	#define SPI_SLV3_SETTINGS1_NUMBER_WORDS_RW (0x07f << 16)
	#define SPI_SLV3_SETTINGS1_NUMBER_WORDS_SHIFT 16
	/*
	* Serial clock divisor 2 (min = 2)
	*/
	#define SPI_SLV3_SETTINGS1_CLK_DIVISOR2_RW (0x07f << 8)
	#define SPI_SLV3_SETTINGS1_CLK_DIVISOR2_SHIFT 8
	/*
	* Serial clock divisor 1
	*/
	#define SPI_SLV3_SETTINGS1_CLK_DIVISOR1_RW (0x0ff << 0)
	#define SPI_SLV3_SETTINGS1_CLK_DIVISOR1_SHIFT 0
	/*
	* Slave Settings Register 2 for slave loop
	*/
	#define SPI_SLV3_SETTINGS2_REG  (SPI_BASE + 0x40)
	/*
	* Programmable delay occuring twice in a transfer (in clk cycles) (minus 1 encoded
	* )
	*/
	#define SPI_SLV3_SETTINGS2_PRE_POST_CS_DLY_RW (0x07f << 24)
	#define SPI_SLV3_SETTINGS2_PRE_POST_CS_DLY_SHIFT 24
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_SLV3_SETTINGS2_RESERVED6_RES (0x03fff << 9)
	#define SPI_SLV3_SETTINGS2_RESERVED6_SHIFT 9
	/*
	* Chip-Select value between back-to-back transfers(0: CS is steady state low value
	*  between transfers, 1: CS is steady state high value between transfers)
	*/
	#define SPI_SLV3_SETTINGS2_CS_VALUE_RW (0x01 << 8)
	#define SPI_SLV3_SETTINGS2_CS_VALUE_SHIFT 8
	#define SPI_SLV3_SETTINGS2_CS_VALUE_VAL0 0x00
	#define SPI_SLV3_SETTINGS2_CS_VALUE_VAL1 0x01
	/*
	* Format of transfer (0:SSI, 1: SPI)
	*/
	#define SPI_SLV3_SETTINGS2_TRANSFER_FORMAT_RW (0x01 << 7)
	#define SPI_SLV3_SETTINGS2_TRANSFER_FORMAT_SHIFT 7
	#define SPI_SLV3_SETTINGS2_TRANSFER_FORMAT_VAL0 0x00
	#define SPI_SLV3_SETTINGS2_TRANSFER_FORMAT_VAL1 0x01
	/*
	* Serial clock polarity (0: Clk is steady state low value between transfers, 1: Cl
	* k is steady state high value between transfers)
	*/
	#define SPI_SLV3_SETTINGS2_SPO_RW (0x01 << 6)
	#define SPI_SLV3_SETTINGS2_SPO_SHIFT 6
	#define SPI_SLV3_SETTINGS2_SPO_VAL0 0x00
	#define SPI_SLV3_SETTINGS2_SPO_VAL1 0x01
	/*
	* Serial clock phase (0: First data bit is captured on first clock edge of new tra
	* nsfer, 1: First data bit captured on second clock edge)
	*/
	#define SPI_SLV3_SETTINGS2_SPH_RW (0x01 << 5)
	#define SPI_SLV3_SETTINGS2_SPH_SHIFT 5
	#define SPI_SLV3_SETTINGS2_SPH_VAL0 0x00
	#define SPI_SLV3_SETTINGS2_SPH_VAL1 0x01
	/*
	* Datasize of transfers to slave loop (minus 1 encoded)
	*/
	#define SPI_SLV3_SETTINGS2_DATASIZE_RW (0x01f << 0)
	#define SPI_SLV3_SETTINGS2_DATASIZE_SHIFT 0
	/*
	* Slave Settings Register 1 for slave loop
	*/
	#define SPI_SLV4_SETTINGS1_REG  (SPI_BASE + 0x44)
	/*
	* The delay between transfers to slave loop (in serial clk cycles) (only relevant 
	* in master mode)
	*/
	#define SPI_SLV4_SETTINGS1_INTER_TRANSFER_DLY_RW (0x07f << 24)
	#define SPI_SLV4_SETTINGS1_INTER_TRANSFER_DLY_SHIFT 24
	/*
	* Number of words to send in sequential multi-slave mode (only relevant in master 
	* mode) (minus 1 encoded)
	*/
	#define SPI_SLV4_SETTINGS1_NUMBER_WORDS_RW (0x07f << 16)
	#define SPI_SLV4_SETTINGS1_NUMBER_WORDS_SHIFT 16
	/*
	* Serial clock divisor 2 (min = 2)
	*/
	#define SPI_SLV4_SETTINGS1_CLK_DIVISOR2_RW (0x07f << 8)
	#define SPI_SLV4_SETTINGS1_CLK_DIVISOR2_SHIFT 8
	/*
	* Serial clock divisor 1
	*/
	#define SPI_SLV4_SETTINGS1_CLK_DIVISOR1_RW (0x0ff << 0)
	#define SPI_SLV4_SETTINGS1_CLK_DIVISOR1_SHIFT 0
	/*
	* Slave Settings Register 2 for slave loop
	*/
	#define SPI_SLV4_SETTINGS2_REG  (SPI_BASE + 0x48)
	/*
	* Programmable delay occuring twice in a transfer (in clk cycles) (minus 1 encoded
	* )
	*/
	#define SPI_SLV4_SETTINGS2_PRE_POST_CS_DLY_RW (0x07f << 24)
	#define SPI_SLV4_SETTINGS2_PRE_POST_CS_DLY_SHIFT 24
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_SLV4_SETTINGS2_RESERVED6_RES (0x03fff << 9)
	#define SPI_SLV4_SETTINGS2_RESERVED6_SHIFT 9
	/*
	* Chip-Select value between back-to-back transfers(0: CS is steady state low value
	*  between transfers, 1: CS is steady state high value between transfers)
	*/
	#define SPI_SLV4_SETTINGS2_CS_VALUE_RW (0x01 << 8)
	#define SPI_SLV4_SETTINGS2_CS_VALUE_SHIFT 8
	#define SPI_SLV4_SETTINGS2_CS_VALUE_VAL0 0x00
	#define SPI_SLV4_SETTINGS2_CS_VALUE_VAL1 0x01
	/*
	* Format of transfer (0:SSI, 1: SPI)
	*/
	#define SPI_SLV4_SETTINGS2_TRANSFER_FORMAT_RW (0x01 << 7)
	#define SPI_SLV4_SETTINGS2_TRANSFER_FORMAT_SHIFT 7
	#define SPI_SLV4_SETTINGS2_TRANSFER_FORMAT_VAL0 0x00
	#define SPI_SLV4_SETTINGS2_TRANSFER_FORMAT_VAL1 0x01
	/*
	* Serial clock polarity (0: Clk is steady state low value between transfers, 1: Cl
	* k is steady state high value between transfers)
	*/
	#define SPI_SLV4_SETTINGS2_SPO_RW (0x01 << 6)
	#define SPI_SLV4_SETTINGS2_SPO_SHIFT 6
	#define SPI_SLV4_SETTINGS2_SPO_VAL0 0x00
	#define SPI_SLV4_SETTINGS2_SPO_VAL1 0x01
	/*
	* Serial clock phase (0: First data bit is captured on first clock edge of new tra
	* nsfer, 1: First data bit captured on second clock edge)
	*/
	#define SPI_SLV4_SETTINGS2_SPH_RW (0x01 << 5)
	#define SPI_SLV4_SETTINGS2_SPH_SHIFT 5
	#define SPI_SLV4_SETTINGS2_SPH_VAL0 0x00
	#define SPI_SLV4_SETTINGS2_SPH_VAL1 0x01
	/*
	* Datasize of transfers to slave loop (minus 1 encoded)
	*/
	#define SPI_SLV4_SETTINGS2_DATASIZE_RW (0x01f << 0)
	#define SPI_SLV4_SETTINGS2_DATASIZE_SHIFT 0
	/*
	* Slave Settings Register 1 for slave loop
	*/
	#define SPI_SLV5_SETTINGS1_REG  (SPI_BASE + 0x4c)
	/*
	* The delay between transfers to slave loop (in serial clk cycles) (only relevant 
	* in master mode)
	*/
	#define SPI_SLV5_SETTINGS1_INTER_TRANSFER_DLY_RW (0x07f << 24)
	#define SPI_SLV5_SETTINGS1_INTER_TRANSFER_DLY_SHIFT 24
	/*
	* Number of words to send in sequential multi-slave mode (only relevant in master 
	* mode) (minus 1 encoded)
	*/
	#define SPI_SLV5_SETTINGS1_NUMBER_WORDS_RW (0x07f << 16)
	#define SPI_SLV5_SETTINGS1_NUMBER_WORDS_SHIFT 16
	/*
	* Serial clock divisor 2 (min = 2)
	*/
	#define SPI_SLV5_SETTINGS1_CLK_DIVISOR2_RW (0x07f << 8)
	#define SPI_SLV5_SETTINGS1_CLK_DIVISOR2_SHIFT 8
	/*
	* Serial clock divisor 1
	*/
	#define SPI_SLV5_SETTINGS1_CLK_DIVISOR1_RW (0x0ff << 0)
	#define SPI_SLV5_SETTINGS1_CLK_DIVISOR1_SHIFT 0
	/*
	* Slave Settings Register 2 for slave loop
	*/
	#define SPI_SLV5_SETTINGS2_REG  (SPI_BASE + 0x50)
	/*
	* Programmable delay occuring twice in a transfer (in clk cycles) (minus 1 encoded
	* )
	*/
	#define SPI_SLV5_SETTINGS2_PRE_POST_CS_DLY_RW (0x07f << 24)
	#define SPI_SLV5_SETTINGS2_PRE_POST_CS_DLY_SHIFT 24
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_SLV5_SETTINGS2_RESERVED6_RES (0x03fff << 9)
	#define SPI_SLV5_SETTINGS2_RESERVED6_SHIFT 9
	/*
	* Chip-Select value between back-to-back transfers(0: CS is steady state low value
	*  between transfers, 1: CS is steady state high value between transfers)
	*/
	#define SPI_SLV5_SETTINGS2_CS_VALUE_RW (0x01 << 8)
	#define SPI_SLV5_SETTINGS2_CS_VALUE_SHIFT 8
	#define SPI_SLV5_SETTINGS2_CS_VALUE_VAL0 0x00
	#define SPI_SLV5_SETTINGS2_CS_VALUE_VAL1 0x01
	/*
	* Format of transfer (0:SSI, 1: SPI)
	*/
	#define SPI_SLV5_SETTINGS2_TRANSFER_FORMAT_RW (0x01 << 7)
	#define SPI_SLV5_SETTINGS2_TRANSFER_FORMAT_SHIFT 7
	#define SPI_SLV5_SETTINGS2_TRANSFER_FORMAT_VAL0 0x00
	#define SPI_SLV5_SETTINGS2_TRANSFER_FORMAT_VAL1 0x01
	/*
	* Serial clock polarity (0: Clk is steady state low value between transfers, 1: Cl
	* k is steady state high value between transfers)
	*/
	#define SPI_SLV5_SETTINGS2_SPO_RW (0x01 << 6)
	#define SPI_SLV5_SETTINGS2_SPO_SHIFT 6
	#define SPI_SLV5_SETTINGS2_SPO_VAL0 0x00
	#define SPI_SLV5_SETTINGS2_SPO_VAL1 0x01
	/*
	* Serial clock phase (0: First data bit is captured on first clock edge of new tra
	* nsfer, 1: First data bit captured on second clock edge)
	*/
	#define SPI_SLV5_SETTINGS2_SPH_RW (0x01 << 5)
	#define SPI_SLV5_SETTINGS2_SPH_SHIFT 5
	#define SPI_SLV5_SETTINGS2_SPH_VAL0 0x00
	#define SPI_SLV5_SETTINGS2_SPH_VAL1 0x01
	/*
	* Datasize of transfers to slave loop (minus 1 encoded)
	*/
	#define SPI_SLV5_SETTINGS2_DATASIZE_RW (0x01f << 0)
	#define SPI_SLV5_SETTINGS2_DATASIZE_SHIFT 0
	/*
	* Tx/Rx threshold Interrupt Level Register
	*/
	#define SPI_INT_THRESHOLD_REG  (SPI_BASE + 0xfd4)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_INT_THRESHOLD_RESERVED2_RES (0x07fff << 16)
	#define SPI_INT_THRESHOLD_RESERVED2_SHIFT 16
	/*
	* A transmit threshold interrupt is requested when the tx FIFO contains less than 
	* this number of elements
	*/
	#define SPI_INT_THRESHOLD_TX_THRESHOLD_RW (0x07f << 8)
	#define SPI_INT_THRESHOLD_TX_THRESHOLD_SHIFT 8
	/*
	* A receive threshold interrupt is requested when the rx FIFO contains less than t
	* his number of elements
	*/
	#define SPI_INT_THRESHOLD_RX_THRESHOLD_RW (0x0ff << 0)
	#define SPI_INT_THRESHOLD_RX_THRESHOLD_SHIFT 0
	/*
	* Interrupt Enable Clear Register
	*/
	#define SPI_INT_CLR_ENABLE_REG  (SPI_BASE + 0xfd8)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_INT_CLR_ENABLE_RESERVED5_RES (0x03ffffff << 5)
	#define SPI_INT_CLR_ENABLE_RESERVED5_SHIFT 5
	/*
	* '1' clears sequential multi-slave mode ready interrupt bit in INT_ENABLE
	*/
	#define SPI_INT_CLR_ENABLE_CLR_SMS_INT_ENABLE_W (0x01 << 4)
	#define SPI_INT_CLR_ENABLE_CLR_SMS_INT_ENABLE_SHIFT 4
	#define SPI_INT_CLR_ENABLE_CLR_SMS_INT_ENABLE_VAL0 0x00
	#define SPI_INT_CLR_ENABLE_CLR_SMS_INT_ENABLE_VAL1 0x01
	/*
	* '1' clears transmit threshold level interrupt bit in INT_ENABLE
	*/
	#define SPI_INT_CLR_ENABLE_CLR_TX_INT_ENABLE_W (0x01 << 3)
	#define SPI_INT_CLR_ENABLE_CLR_TX_INT_ENABLE_SHIFT 3
	#define SPI_INT_CLR_ENABLE_CLR_TX_INT_ENABLE_VAL0 0x00
	#define SPI_INT_CLR_ENABLE_CLR_TX_INT_ENABLE_VAL1 0x01
	/*
	* '1' clears receive threshold level interrupt bit in INT_ENABLE
	*/
	#define SPI_INT_CLR_ENABLE_CLR_RX_INT_ENABLE_W (0x01 << 2)
	#define SPI_INT_CLR_ENABLE_CLR_RX_INT_ENABLE_SHIFT 2
	#define SPI_INT_CLR_ENABLE_CLR_RX_INT_ENABLE_VAL0 0x00
	#define SPI_INT_CLR_ENABLE_CLR_RX_INT_ENABLE_VAL1 0x01
	/*
	* '1' clears receive time-out interrupt bit in INT_ENABLE
	*/
	#define SPI_INT_CLR_ENABLE_CLR_TO_INT_ENABLE_W (0x01 << 1)
	#define SPI_INT_CLR_ENABLE_CLR_TO_INT_ENABLE_SHIFT 1
	#define SPI_INT_CLR_ENABLE_CLR_TO_INT_ENABLE_VAL0 0x00
	#define SPI_INT_CLR_ENABLE_CLR_TO_INT_ENABLE_VAL1 0x01
	/*
	* '1' clears receive FIFO overrun interrupt bit in INT_ENABLE
	*/
	#define SPI_INT_CLR_ENABLE_CLR_OV_INT_ENABLE_W (0x01 << 0)
	#define SPI_INT_CLR_ENABLE_CLR_OV_INT_ENABLE_SHIFT 0
	#define SPI_INT_CLR_ENABLE_CLR_OV_INT_ENABLE_VAL0 0x00
	#define SPI_INT_CLR_ENABLE_CLR_OV_INT_ENABLE_VAL1 0x01
	/*
	* Interrupt Enable Set Register
	*/
	#define SPI_INT_SET_ENABLE_REG  (SPI_BASE + 0xfdc)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_INT_SET_ENABLE_RESERVED5_RES (0x03ffffff << 5)
	#define SPI_INT_SET_ENABLE_RESERVED5_SHIFT 5
	/*
	* '1' sets sequential multi-slave mode ready interrupt bit in INT_ENABLE
	*/
	#define SPI_INT_SET_ENABLE_SET_SMS_INT_ENABLE_W (0x01 << 4)
	#define SPI_INT_SET_ENABLE_SET_SMS_INT_ENABLE_SHIFT 4
	#define SPI_INT_SET_ENABLE_SET_SMS_INT_ENABLE_VAL0 0x00
	#define SPI_INT_SET_ENABLE_SET_SMS_INT_ENABLE_VAL1 0x01
	/*
	* '1' sets transmit threshold level interrupt bit in INT_ENABLE
	*/
	#define SPI_INT_SET_ENABLE_SET_TX_INT_ENABLE_W (0x01 << 3)
	#define SPI_INT_SET_ENABLE_SET_TX_INT_ENABLE_SHIFT 3
	#define SPI_INT_SET_ENABLE_SET_TX_INT_ENABLE_VAL0 0x00
	#define SPI_INT_SET_ENABLE_SET_TX_INT_ENABLE_VAL1 0x01
	/*
	* '1' sets receive threshold level interrupt bit in INT_ENABLE
	*/
	#define SPI_INT_SET_ENABLE_SET_RX_INT_ENABLE_W (0x01 << 2)
	#define SPI_INT_SET_ENABLE_SET_RX_INT_ENABLE_SHIFT 2
	#define SPI_INT_SET_ENABLE_SET_RX_INT_ENABLE_VAL0 0x00
	#define SPI_INT_SET_ENABLE_SET_RX_INT_ENABLE_VAL1 0x01
	/*
	* '1' sets receive time-out interrupt bit in INT_ENABLE
	*/
	#define SPI_INT_SET_ENABLE_SET_TO_INT_ENABLE_W (0x01 << 1)
	#define SPI_INT_SET_ENABLE_SET_TO_INT_ENABLE_SHIFT 1
	#define SPI_INT_SET_ENABLE_SET_TO_INT_ENABLE_VAL0 0x00
	#define SPI_INT_SET_ENABLE_SET_TO_INT_ENABLE_VAL1 0x01
	/*
	* '1' sets receive FIFO overrun interrupt bit in INT_ENABLE
	*/
	#define SPI_INT_SET_ENABLE_SET_OV_INT_ENABLE_W (0x01 << 0)
	#define SPI_INT_SET_ENABLE_SET_OV_INT_ENABLE_SHIFT 0
	#define SPI_INT_SET_ENABLE_SET_OV_INT_ENABLE_VAL0 0x00
	#define SPI_INT_SET_ENABLE_SET_OV_INT_ENABLE_VAL1 0x01
	/*
	* Interrupt Status Register
	*/
	#define SPI_INT_STATUS_REG  (SPI_BASE + 0xfe0)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_INT_STATUS_RESERVED5_RES (0x03ffffff << 5)
	#define SPI_INT_STATUS_RESERVED5_SHIFT 5
	/*
	* sequential multi-slave mode ready interrupt status
	*/
	#define SPI_INT_STATUS_SMS_INT_STATUS_R (0x01 << 4)
	#define SPI_INT_STATUS_SMS_INT_STATUS_SHIFT 4
	#define SPI_INT_STATUS_SMS_INT_STATUS_VAL0 0x00
	#define SPI_INT_STATUS_SMS_INT_STATUS_VAL1 0x01
	/*
	* transmit threshold level interrupt status
	*/
	#define SPI_INT_STATUS_TX_INT_STATUS_R (0x01 << 3)
	#define SPI_INT_STATUS_TX_INT_STATUS_SHIFT 3
	#define SPI_INT_STATUS_TX_INT_STATUS_VAL0 0x00
	#define SPI_INT_STATUS_TX_INT_STATUS_VAL1 0x01
	/*
	* receive threshold level interrupt status
	*/
	#define SPI_INT_STATUS_RX_INT_STATUS_R (0x01 << 2)
	#define SPI_INT_STATUS_RX_INT_STATUS_SHIFT 2
	#define SPI_INT_STATUS_RX_INT_STATUS_VAL0 0x00
	#define SPI_INT_STATUS_RX_INT_STATUS_VAL1 0x01
	/*
	* receive time-out interrupt status
	*/
	#define SPI_INT_STATUS_TO_INT_STATUS_R (0x01 << 1)
	#define SPI_INT_STATUS_TO_INT_STATUS_SHIFT 1
	#define SPI_INT_STATUS_TO_INT_STATUS_VAL0 0x00
	#define SPI_INT_STATUS_TO_INT_STATUS_VAL1 0x01
	/*
	* receive FIFO overrun interrupt status
	*/
	#define SPI_INT_STATUS_OV_INT_STATUS_R (0x01 << 0)
	#define SPI_INT_STATUS_OV_INT_STATUS_SHIFT 0
	#define SPI_INT_STATUS_OV_INT_STATUS_VAL0 0x00
	#define SPI_INT_STATUS_OV_INT_STATUS_VAL1 0x01
	/*
	* Interrupt Enable Register
	*/
	#define SPI_INT_ENABLE_REG  (SPI_BASE + 0xfe4)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_INT_ENABLE_RESERVED5_RES (0x03ffffff << 5)
	#define SPI_INT_ENABLE_RESERVED5_SHIFT 5
	/*
	* sequential multi-slave mode ready interrupt enable
	*/
	#define SPI_INT_ENABLE_SMS_INT_ENABLE_R (0x01 << 4)
	#define SPI_INT_ENABLE_SMS_INT_ENABLE_SHIFT 4
	#define SPI_INT_ENABLE_SMS_INT_ENABLE_VAL0 0x00
	#define SPI_INT_ENABLE_SMS_INT_ENABLE_VAL1 0x01
	/*
	* transmit threshold level interrupt enable
	*/
	#define SPI_INT_ENABLE_TX_INT_ENABLE_R (0x01 << 3)
	#define SPI_INT_ENABLE_TX_INT_ENABLE_SHIFT 3
	#define SPI_INT_ENABLE_TX_INT_ENABLE_VAL0 0x00
	#define SPI_INT_ENABLE_TX_INT_ENABLE_VAL1 0x01
	/*
	* receive threshold level interrupt enable
	*/
	#define SPI_INT_ENABLE_RX_INT_ENABLE_R (0x01 << 2)
	#define SPI_INT_ENABLE_RX_INT_ENABLE_SHIFT 2
	#define SPI_INT_ENABLE_RX_INT_ENABLE_VAL0 0x00
	#define SPI_INT_ENABLE_RX_INT_ENABLE_VAL1 0x01
	/*
	* receive time-out interrupt enable
	*/
	#define SPI_INT_ENABLE_TO_INT_ENABLE_R (0x01 << 1)
	#define SPI_INT_ENABLE_TO_INT_ENABLE_SHIFT 1
	#define SPI_INT_ENABLE_TO_INT_ENABLE_VAL0 0x00
	#define SPI_INT_ENABLE_TO_INT_ENABLE_VAL1 0x01
	/*
	* receive FIFO overrun interrupt enable
	*/
	#define SPI_INT_ENABLE_OV_INT_ENABLE_R (0x01 << 0)
	#define SPI_INT_ENABLE_OV_INT_ENABLE_SHIFT 0
	#define SPI_INT_ENABLE_OV_INT_ENABLE_VAL0 0x00
	#define SPI_INT_ENABLE_OV_INT_ENABLE_VAL1 0x01
	/*
	* Interrupt Status Clear Register
	*/
	#define SPI_INT_CLR_STATUS_REG  (SPI_BASE + 0xfe8)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_INT_CLR_STATUS_RESERVED5_RES (0x03ffffff << 5)
	#define SPI_INT_CLR_STATUS_RESERVED5_SHIFT 5
	/*
	* '1' clears sequential multi-slave mode ready interrupt bit in INT_STATUS
	*/
	#define SPI_INT_CLR_STATUS_CLR_SMS_INT_STATUS_W (0x01 << 4)
	#define SPI_INT_CLR_STATUS_CLR_SMS_INT_STATUS_SHIFT 4
	#define SPI_INT_CLR_STATUS_CLR_SMS_INT_STATUS_VAL0 0x00
	#define SPI_INT_CLR_STATUS_CLR_SMS_INT_STATUS_VAL1 0x01
	/*
	* '1' clears transmit threshold level interrupt bit in INT_STATUS
	*/
	#define SPI_INT_CLR_STATUS_CLR_TX_INT_STATUS_W (0x01 << 3)
	#define SPI_INT_CLR_STATUS_CLR_TX_INT_STATUS_SHIFT 3
	#define SPI_INT_CLR_STATUS_CLR_TX_INT_STATUS_VAL0 0x00
	#define SPI_INT_CLR_STATUS_CLR_TX_INT_STATUS_VAL1 0x01
	/*
	* '1' clears receive threshold level interrupt bit in INT_STATUS
	*/
	#define SPI_INT_CLR_STATUS_CLR_RX_INT_STATUS_W (0x01 << 2)
	#define SPI_INT_CLR_STATUS_CLR_RX_INT_STATUS_SHIFT 2
	#define SPI_INT_CLR_STATUS_CLR_RX_INT_STATUS_VAL0 0x00
	#define SPI_INT_CLR_STATUS_CLR_RX_INT_STATUS_VAL1 0x01
	/*
	* '1' clears receive time-out interrupt bit in INT_STATUS
	*/
	#define SPI_INT_CLR_STATUS_CLR_TO_INT_STATUS_W (0x01 << 1)
	#define SPI_INT_CLR_STATUS_CLR_TO_INT_STATUS_SHIFT 1
	#define SPI_INT_CLR_STATUS_CLR_TO_INT_STATUS_VAL0 0x00
	#define SPI_INT_CLR_STATUS_CLR_TO_INT_STATUS_VAL1 0x01
	/*
	* '1' clears receive FIFO overrun interrupt bit in INT_STATUS
	*/
	#define SPI_INT_CLR_STATUS_CLR_OV_INT_STATUS_W (0x01 << 0)
	#define SPI_INT_CLR_STATUS_CLR_OV_INT_STATUS_SHIFT 0
	#define SPI_INT_CLR_STATUS_CLR_OV_INT_STATUS_VAL0 0x00
	#define SPI_INT_CLR_STATUS_CLR_OV_INT_STATUS_VAL1 0x01
	/*
	* Interrupt Status Set Register
	*/
	#define SPI_INT_SET_STATUS_REG  (SPI_BASE + 0xfec)
	/*
	* Automatically generated bitfield for padding
	*/
	#define SPI_INT_SET_STATUS_RESERVED5_RES (0x03ffffff << 5)
	#define SPI_INT_SET_STATUS_RESERVED5_SHIFT 5
	/*
	* '1' sets sequential multi-slave mode ready interrupt bit in INT_STATUS
	*/
	#define SPI_INT_SET_STATUS_SET_SMS_INT_STATUS_W (0x01 << 4)
	#define SPI_INT_SET_STATUS_SET_SMS_INT_STATUS_SHIFT 4
	#define SPI_INT_SET_STATUS_SET_SMS_INT_STATUS_VAL0 0x00
	#define SPI_INT_SET_STATUS_SET_SMS_INT_STATUS_VAL1 0x01
	/*
	* '1' sets transmit threshold level interrupt bit in INT_STATUS
	*/
	#define SPI_INT_SET_STATUS_SET_TX_INT_STATUS_W (0x01 << 3)
	#define SPI_INT_SET_STATUS_SET_TX_INT_STATUS_SHIFT 3
	#define SPI_INT_SET_STATUS_SET_TX_INT_STATUS_VAL0 0x00
	#define SPI_INT_SET_STATUS_SET_TX_INT_STATUS_VAL1 0x01
	/*
	* '1' sets receive threshold level interrupt bit in INT_STATUS
	*/
	#define SPI_INT_SET_STATUS_SET_RX_INT_STATUS_W (0x01 << 2)
	#define SPI_INT_SET_STATUS_SET_RX_INT_STATUS_SHIFT 2
	#define SPI_INT_SET_STATUS_SET_RX_INT_STATUS_VAL0 0x00
	#define SPI_INT_SET_STATUS_SET_RX_INT_STATUS_VAL1 0x01
	/*
	* '1' sets receive time-out interrupt bit in INT_STATUS
	*/
	#define SPI_INT_SET_STATUS_SET_TO_INT_STATUS_W (0x01 << 1)
	#define SPI_INT_SET_STATUS_SET_TO_INT_STATUS_SHIFT 1
	#define SPI_INT_SET_STATUS_SET_TO_INT_STATUS_VAL0 0x00
	#define SPI_INT_SET_STATUS_SET_TO_INT_STATUS_VAL1 0x01
	/*
	* '1' sets receive FIFO overrun interrupt bit in INT_STATUS
	*/
	#define SPI_INT_SET_STATUS_SET_OV_INT_STATUS_W (0x01 << 0)
	#define SPI_INT_SET_STATUS_SET_OV_INT_STATUS_SHIFT 0
	#define SPI_INT_SET_STATUS_SET_OV_INT_STATUS_VAL0 0x00
	#define SPI_INT_SET_STATUS_SET_OV_INT_STATUS_VAL1 0x01
	/*
	* Module Identification Register
	*/
	#define SPI_MODULE_ID_REG  (SPI_BASE + 0xffc)
	/*
	* Unique identification number, assigned by RTG
	*/
	#define SPI_MODULE_ID_ID_R (0x07fff << 16)
	#define SPI_MODULE_ID_ID_SHIFT 16
	/*
	* Major revision number
	*/
	#define SPI_MODULE_ID_MAJOR_R (0x07 << 12)
	#define SPI_MODULE_ID_MAJOR_SHIFT 12
	#define SPI_MODULE_ID_MAJOR_VAL0 0x00
	#define SPI_MODULE_ID_MAJOR_VAL1 0x01
	#define SPI_MODULE_ID_MAJOR_VAL2 0x02
	#define SPI_MODULE_ID_MAJOR_VAL3 0x03
	#define SPI_MODULE_ID_MAJOR_VAL4 0x04
	#define SPI_MODULE_ID_MAJOR_VAL5 0x05
	#define SPI_MODULE_ID_MAJOR_VAL6 0x06
	#define SPI_MODULE_ID_MAJOR_VAL7 0x07
	/*
	* Minor revision number
	*/
	#define SPI_MODULE_ID_MINOR_R (0x07 << 8)
	#define SPI_MODULE_ID_MINOR_SHIFT 8
	#define SPI_MODULE_ID_MINOR_VAL0 0x00
	#define SPI_MODULE_ID_MINOR_VAL1 0x01
	#define SPI_MODULE_ID_MINOR_VAL2 0x02
	#define SPI_MODULE_ID_MINOR_VAL3 0x03
	#define SPI_MODULE_ID_MINOR_VAL4 0x04
	#define SPI_MODULE_ID_MINOR_VAL5 0x05
	#define SPI_MODULE_ID_MINOR_VAL6 0x06
	#define SPI_MODULE_ID_MINOR_VAL7 0x07
	/*
	* Encoded as (aperture/4K)-1
	*/
	#define SPI_MODULE_ID_APERTURE_R (0x0ff << 0)
	#define SPI_MODULE_ID_APERTURE_SHIFT 0

#endif // PHMODIPSPI_H
