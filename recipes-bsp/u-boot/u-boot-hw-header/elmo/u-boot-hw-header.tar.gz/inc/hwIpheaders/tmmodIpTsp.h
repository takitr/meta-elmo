/******************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                    */
/*                        SOFTWARE FILE/MODULE HEADER                         */
/*                Copyright Conexant Systems, Inc. 2006-2008                  */
/*                                 Austin, TX                                 */
/*                            All Rights Reserved                             */
/******************************************************************************/
/*
 * Filename:        tmmodIpTsp.h
 *
 *
 * Description:     Public header file defining hardware-specific values (such
 *                  as register addresses, bit definitions, etc.) for TSP Unit.
 *
 *
 * Author:          Srinivasan Venkataraman
 *
 ******************************************************************************/
/* $Id: tmmodIpTsp.h 211608 2011-06-20 03:06:42Z prasadl1 $
 ******************************************************************************/

#ifndef _TMMODIPTSP_H_
#define _TMMODIPTSP_H_

/****************************************************************************/
/*                            DEMULTIPLEXER - TSP DEFINITIONS               */
/****************************************************************************/

/*********************/
/* TSP definitions   */
/*********************/

/*****************************************
 * Playback Event Descriptor Definitions *
 *****************************************/



#define TSP_SIZE                                        (0x10000)

#define TSP_RAM_EXT_MEM_MAP_OFFSET                      (0x20000)


#define TEMPEST_TSP_MAP(x)                              (TEMPEST_COMMON_MAP + 0x10000)

#define TSP_RAM(x)                                      (TEMPEST_TSP_MAP(x) + 0x0000)
#define TSP_LOCAL_IO(x)                                 (TEMPEST_TSP_MAP(x) + 0x5000)
#define TSP_FILTER_RAM(x)                               (TEMPEST_TSP_MAP(x) + 0x6000)
#define TSP_KEY_RAM(x)                                  (TEMPEST_TSP_MAP(x) + 0x7800)
#define TSP_BASE(x)                                     (TEMPEST_TSP_MAP(x) + 0x8000)

#define TSP_RAM_EXT_MEM_MAP(x)                          (TEMPEST_COMMON_MAP + TSP_RAM_EXT_MEM_MAP_OFFSET)

//#define TEMPEST_TSP_DMA_IN(x)                           (TEMPEST_BASE + 0x100000 + ((x)*0x20000))
//#define TEMPEST_TSP_DMA_OUT(x)                          (TEMPEST_BASE + 0x110000 + ((x)*0x20000))

#define TSP_PARSER_STATUS_REG(unit)                     (TSP_RAM(unit) + 0x0020)
#define    TSP_PARSER_STATUS_READY_MASK                 (0x1)

#if (!ISAPOLLO)
#define TSP_MESSAGE_FILTER_TABLE_DESCRIPTOR_REG(unit)   (TSP_RAM(unit) + 0x002C)
#endif
#define TSP_PID_TABLE_DESCRIPTOR_REG(unit)              (TSP_RAM(unit) + 0x003C)
#define TSP_PSI_BUFFER_TABLE_DESCRIPTOR_REG(unit)       (TSP_RAM(unit) + 0x0044)
#define TSP_XPRT_BUFFER_TABLE_DESCRIPTOR_REG(unit)      (TSP_RAM(unit) + 0x0048)
#define TSP_EVENT_LOG_BUFFER_TABLE_DESCRIPTOR_REG(unit) (TSP_RAM(unit) + 0x004C)
#if (!ISAPOLLO)
#define TSP_ES_BUFFER_TABLE_DESCRIPTOR_REG(unit)        (TSP_RAM(unit) + 0x0058)
#define TSP_PTS_BUFFER_TABLE_DESCRIPTOR_REG(unit)       (TSP_RAM(unit) + 0x005C)
#define TSP_AUDIO_DATA_TABLE_DESCRIPTOR_REG(unit)       (TSP_RAM(unit) + 0x0090)
#endif
#if (ISAPOLLO)
#define TSP_OOB_BUFFER_TABLE_DESCRIPTOR_REG(unit)       (TSP_RAM(unit) + 0x0090)
#endif
#define TSP_STC_INDEX_TABLE_DESCRIPTOR_REG(unit)        (TSP_RAM(unit) + 0x0094)
#if (!ISAPOLLO)
#define TSP_PCR_TABLE_DESCRIPTOR_REG(unit)              (TSP_RAM(unit) + 0x0098)
#endif
#define TSP_TBL_OFFSET_MASK                             (0x0000FFFF)
#define TSP_TBL_OFFSET_SHIFT                            (0)
#define TSP_TBL_DESC_SIZE_MASK                          (0x00FF0000)
#define TSP_TBL_DESC_SIZE_SHIFT                         (16)
#define TSP_TBL_NO_DESCRIPTORS_MASK                     (0xFF000000)
#define TSP_TBL_NO_DESCRIPTORS_SHIFT                    (24)
#define TSP_RECORD_INDEXING_EVENT_LOG_BUFFER_INDEX      (0)
#define TSP_PLAYBACK_INDEXING_EVENT_LOG_BUFFER_INDEX    (1)


/* dmx - Dmx physical Unit number, index - key index, size - key size(in bits), polarity - even(0), odd(1), number - word number */
#define TSP_KEY_WORD_ADDR(dmx,index,size,polarity,number)          (TEMPEST_TSP_MAP(dmx) + 0x7800 + (index * (size/4))+ (polarity * (size/8))+(number * 0x04))

#define TSP_KEY_ADDR_LOW_EVEN(dmx,index)                (TEMPEST_TSP_MAP(dmx) + 0x7800 + (index*16))
#define TSP_KEY_ADDR_HIGH_EVEN(dmx,index)               (TEMPEST_TSP_MAP(dmx) + 0x7804 + (index*16))
#define TSP_KEY_ADDR_LOW_ODD(dmx,index)                 (TEMPEST_TSP_MAP(dmx) + 0x7808 + (index*16))
#define TSP_KEY_ADDR_HIGH_ODD(dmx,index)                (TEMPEST_TSP_MAP(dmx) + 0x780C + (index*16))

/************************************************
 * TSP Buffer Descriptor Definitions and Macros *
 ************************************************/

#define TSP_BUFF_DESC_WRITE_OFFSET          (0)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_BUFF_DESC_WRITE_MASK            (0xFFFFFFFF) /* Mask for the valid data */
#define TSP_BUFF_DESC_READ_OFFSET           (1)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_BUFF_DESC_READ_MASK             (0xFFFFFFFF) /* Mask for the valid data */
#define TSP_BUFF_DESC_START_OFFSET          (2)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_BUFF_DESC_START_MASK            (0xFFFFFFFF) /* Mask for the valid data */
#define TSP_BUFF_DESC_END_OFFSET            (3)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_BUFF_DESC_END_MASK              (0xFFFFFFFF) /* Mask for the valid data */
#define TSP_BUFF_DESC_INT_INTERVAL_OFFSET   (4)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_BUFF_DESC_INT_INTERVAL_MASK     (0xFFFFFFFF) /* Mask for the valid data */
#define TSP_BUFF_DESC_COUNT_OFFSET          (5)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_BUFF_DESC_COUNT_MASK            (0xFFFFFFFF) /* Mask for the valid data */

/* Macro:      CNXT_TSP_BUFF_GET_WRITE_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write address of the buffer.                                         */
#define CNXT_TSP_BUFF_GET_WRITE_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_BUFF_DESC_WRITE_OFFSET,TSP_BUFF_DESC_WRITE_MASK))

/* Macro:      CNXT_TSP_BUFF_SET_WRITE_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write address of this buffer.     */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_BUFF_SET_WRITE_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_BUFF_DESC_WRITE_OFFSET,TSP_BUFF_DESC_WRITE_MASK,(value)))

/* Macro:      CNXT_TSP_BUFF_GET_READ_ADDRESS                                           */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The read address of the buffer.                                          */
#define CNXT_TSP_BUFF_GET_READ_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_BUFF_DESC_READ_OFFSET,TSP_BUFF_DESC_START_MASK))

/* Macro:      CNXT_TSP_BUFF_SET_READ_ADDRESS                                           */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the read address of this buffer.      */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_BUFF_SET_READ_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_BUFF_DESC_READ_OFFSET,TSP_BUFF_DESC_READ_MASK,(value)))

/* Macro:      CNXT_TSP_BUFF_GET_START_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The start address of the buffer.                                         */
#define CNXT_TSP_BUFF_GET_START_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_BUFF_DESC_START_OFFSET,TSP_BUFF_DESC_START_MASK))

/* Macro:      CNXT_TSP_BUFF_SET_START_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the start address of this buffer.     */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_BUFF_SET_START_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_BUFF_DESC_START_OFFSET,TSP_BUFF_DESC_START_MASK,(value)))

/* Macro:      CNXT_TSP_BUFF_GET_END_ADDRESS                                            */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The end address of the buffer.                                           */
#define CNXT_TSP_BUFF_GET_END_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_BUFF_DESC_END_OFFSET,TSP_BUFF_DESC_END_MASK))

/* Macro:      CNXT_TSP_BUFF_SET_END_ADDRESS                                            */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the end address of this buffer.       */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_BUFF_SET_END_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_BUFF_DESC_END_OFFSET,TSP_BUFF_DESC_END_MASK,(value)))

/* Macro:      CNXT_TSP_BUFF_SET_INTERRUPT_INTERVAL                                     */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the interrupt interval of this buffer.*/
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_BUFF_SET_INTERRUPT_INTERVAL(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_BUFF_DESC_INT_INTERVAL_OFFSET,TSP_BUFF_DESC_INT_INTERVAL_MASK,(value)))

/* Macro:      CNXT_TSP_BUFF_RESET_COUNT                                                */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_BUFF_RESET_COUNT(buff_desc_addr) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_BUFF_DESC_COUNT_OFFSET,TSP_BUFF_DESC_COUNT_MASK,0))


#if (!ISAPOLLO)
#define TSP_BUFF_DESC_WRITE_PRIME_OFFSET    (5)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_BUFF_DESC_WRITE_PRIME_MASK      (0xFFFFFFFF) /* Mask for the valid data */


/* Macro:      CNXT_TSP_BUFF_GET_WRITE_PRIME_ADDRESS                                    */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write prime address of the buffer.                                   */
#define CNXT_TSP_BUFF_GET_WRITE_PRIME_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_BUFF_DESC_WRITE_PRIME_OFFSET,TSP_BUFF_DESC_WRITE_PRIME_MASK))

/* Macro:      CNXT_TSP_BUFF_SET_WRITE_PRIME_ADDRESS                                    */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write prime address of this buffer.*/
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_BUFF_SET_WRITE_PRIME_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_BUFF_DESC_WRITE_PRIME_OFFSET,TSP_BUFF_DESC_WRITE_PRIME_MASK,(value)))
#endif


/************************************************
 * TSP XPRT Buffer Descriptor Definitions and Macros *
 ************************************************/

#define TSP_XPRT_BUFF_DESC_WRITE_OFFSET          (0)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_XPRT_BUFF_DESC_WRITE_MASK            (0x3FFFFFFF) /* Mask for the valid data */
#define TSP_XPRT_BUFF_DESC_READ_OFFSET           (1)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_XPRT_BUFF_DESC_READ_MASK             (0x3FFFFFFF) /* Mask for the valid data */
#define TSP_XPRT_BUFF_DESC_START_OFFSET          (2)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_XPRT_BUFF_DESC_START_MASK            (0x3FFFFFFF) /* Mask for the valid data */
#define TSP_XPRT_BUFF_DESC_END_OFFSET            (3)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_XPRT_BUFF_DESC_END_MASK              (0x3FFFFFFF) /* Mask for the valid data */

#define TSP_XPRT_BUFF_DESC_WRITE_WRAP_CNT_OFFSET (0)          /* The number of words offset this address is from the base of the buffer descriptor */
#define TSP_XPRT_BUFF_DESC_WRITE_WRAP_CNT_MASK   (0xC0000000) /* Mask for the valid data */
#define TSP_XPRT_BUFF_DESC_READ_WRAP_CNT_OFFSET  (1)          /* The number of words offset this address is from the base of the buffer descriptor */
#define TSP_XPRT_BUFF_DESC_READ_WRAP_CNT_MASK    (0xC0000000) /* Mask for the valid data */

#define TSP_XPRT_BUFF_DESC_INT_INTERVAL_OFFSET   (4)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_XPRT_BUFF_DESC_INT_INTERVAL_MASK     (0xFFFFFFFF) /* Mask for the valid data */

#define TSP_XPRT_BUFF_DESC_WORD_MASK             (0xFFFFFFFF) /* Mask for the entire word */

/* Macro:      CNXT_TSP_XPRT_BUFF_GET_WRITE_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write address of the buffer.                                         */
#define CNXT_TSP_XPRT_BUFF_GET_WRITE_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_WRITE_OFFSET,TSP_XPRT_BUFF_DESC_WRITE_MASK))

/* Macro:      CNXT_TSP_XPRT_BUFF_SET_WRITE_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write address of this buffer.     */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_XPRT_BUFF_SET_WRITE_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_WRITE_OFFSET,TSP_XPRT_BUFF_DESC_WRITE_MASK,(value)))

/* Macro:      CNXT_TSP_XPRT_BUFF_SET_WRITE_ADDR_AND_WRAP_CNT                           */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write address of this buffer.     */
/*                      wrap_cnt - the new wrap cnt value                               */      
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_XPRT_BUFF_SET_WRITE_ADDR_AND_WRAP_CNT(buff_desc_addr,value,wrap_cnt) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_WRITE_OFFSET,(TSP_XPRT_BUFF_DESC_WORD_MASK),((value) + ((wrap_cnt)<<30))))

/* Macro:      CNXT_TSP_XPRT_BUFF_GET_WRITE_ADDR_AND_WRAP_CNT                           */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write pointer including wrap count.                                  */
#define CNXT_TSP_XPRT_BUFF_GET_WRITE_ADDR_AND_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_WRITE_OFFSET,(TSP_XPRT_BUFF_DESC_WORD_MASK)))

/* Macro:      CNXT_TSP_XPRT_BUFF_GET_READ_ADDRESS                                           */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The read address of the buffer.                                          */
#define CNXT_TSP_XPRT_BUFF_GET_READ_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_READ_OFFSET,TSP_XPRT_BUFF_DESC_START_MASK))

/* Macro:      CNXT_TSP_XPRT_BUFF_SET_READ_ADDRESS                                           */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the read address of this buffer.      */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_XPRT_BUFF_SET_READ_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_READ_OFFSET,TSP_XPRT_BUFF_DESC_READ_MASK,(value)))

/* Macro:      CNXT_TSP_XPRT_BUFF_SET_READ_ADDR_AND_WRAP_CNT                            */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the read address of this buffer.      */
/*                      wrap_cnt - the new wrap cnt value                               */      
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_XPRT_BUFF_SET_READ_ADDR_AND_WRAP_CNT(buff_desc_addr,value,wrap_cnt) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_READ_OFFSET,(TSP_XPRT_BUFF_DESC_WORD_MASK),((value) + ((wrap_cnt)<<30))))

/* Macro:      CNXT_TSP_XPRT_BUFF_GET_READ_ADDR_AND_WRAP_CNT                           */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The read pointer including wrap count.                                  */
#define CNXT_TSP_XPRT_BUFF_GET_READ_ADDR_AND_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_READ_OFFSET,(TSP_XPRT_BUFF_DESC_WORD_MASK)))

/* Macro:      CNXT_TSP_XPRT_BUFF_GET_START_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The start address of the buffer.                                         */
#define CNXT_TSP_XPRT_BUFF_GET_START_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_START_OFFSET,TSP_XPRT_BUFF_DESC_START_MASK))

/* Macro:      CNXT_TSP_XPRT_BUFF_SET_START_ADDRESS                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the start address of this buffer.     */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_XPRT_BUFF_SET_START_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_START_OFFSET,TSP_XPRT_BUFF_DESC_START_MASK,(value)))

/* Macro:      CNXT_TSP_XPRT_BUFF_GET_END_ADDRESS                                            */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The end address of the buffer.                                           */
#define CNXT_TSP_XPRT_BUFF_GET_END_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_END_OFFSET,TSP_XPRT_BUFF_DESC_END_MASK))

/* Macro:      CNXT_TSP_XPRT_BUFF_SET_END_ADDRESS                                            */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the end address of this buffer.       */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_XPRT_BUFF_SET_END_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_END_OFFSET,TSP_XPRT_BUFF_DESC_END_MASK,(value)))

/* Macro:      CNXT_TSP_XPRT_BUFF_GET_WRITE_WRAP_CNT                                         */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write wrap count of the buffer.                                      */
#define CNXT_TSP_XPRT_BUFF_GET_WRITE_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_WRITE_WRAP_CNT_OFFSET,TSP_XPRT_BUFF_DESC_WRITE_WRAP_CNT_MASK))

/* Macro:      CNXT_TSP_XPRT_BUFF_SET_WRITE_WRAP_CNT                                         */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write wrap count of this buffer.  */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_XPRT_BUFF_SET_WRITE_WRAP_CNT(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_WRITE_WRAP_CNT_OFFSET,TSP_XPRT_BUFF_DESC_WRITE_WRAP_CNT_MASK,(value)))

/* Macro:      CNXT_TSP_XPRT_BUFF_GET_READ_WRAP_CNT                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The read wrap count of the buffer.                                       */
#define CNXT_TSP_XPRT_BUFF_GET_READ_WRAP_CNT(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_READ_WRAP_CNT_OFFSET,TSP_XPRT_BUFF_DESC_READ_WRAP_CNT_MASK))

/* Macro:      CNXT_TSP_XPRT_BUFF_SET_READ_WRAP_CNT                                          */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the read wrap count of this buffer.   */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_XPRT_BUFF_SET_READ_WRAP_CNT(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_READ_WRAP_CNT_OFFSET,TSP_XPRT_BUFF_DESC_READ_WRAP_CNT_MASK,(value)))

/* Macro:      CNXT_TSP_XPRT_BUFF_SET_INTERRUPT_INTERVAL                                     */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the interrupt interval of this buffer.*/
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_XPRT_BUFF_SET_INTERRUPT_INTERVAL(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_INT_INTERVAL_OFFSET,TSP_XPRT_BUFF_DESC_INT_INTERVAL_MASK,(value)))

#if (!ISAPOLLO)
/************************************************
 * TSP ES Buffer Descriptor Definitions and Macros *
 ************************************************/

/* LOW Watermark */
#define TSP_ES_BUFF_DESC_LOW_WATERMARK_OFFSET       (4)          /* The number of words offset this address is from the base of the buffer descriptor */
#define TSP_ES_BUFF_DESC_LOW_WATERMARK_MASK         (0xFFFFFFFF)   /* Mask for Low watermark */

/* Macro:      CNXT_TSP_ES_BUFF_SET_LOW_WATERMARK                                       */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the low watermark of this buffer.     */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_ES_BUFF_SET_LOW_WATERMARK(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_ES_BUFF_DESC_LOW_WATERMARK_OFFSET,TSP_ES_BUFF_DESC_LOW_WATERMARK_MASK,(value)))

/* Macro:      CNXT_TSP_ES_BUFF_GET_LOW_WATERMARK                                       */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The low watermark of the buffer.                                         */
#define CNXT_TSP_ES_BUFF_GET_LOW_WATERMARK(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_ES_BUFF_DESC_LOW_WATERMARK_OFFSET,TSP_ES_BUFF_DESC_LOW_WATERMARK_MASK))


/* write prime offset for ES & XPRT buffers */
#define TSP_XPRT_BUFF_DESC_WRITE_PRIME_OFFSET    (5)          /* The number of words offset this address 
                         is from the base of the buffer descriptor */
#define TSP_XPRT_BUFF_DESC_WRITE_PRIME_MASK      (0x3FFFFFFF) /* Mask for the valid data */


/* Macro:      CNXT_TSP_XPRT_BUFF_GET_WRITE_PRIME_ADDRESS                               */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The write prime address of the buffer.                                   */
#define CNXT_TSP_XPRT_BUFF_GET_WRITE_PRIME_ADDRESS(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_WRITE_PRIME_OFFSET,TSP_XPRT_BUFF_DESC_WRITE_PRIME_MASK))

/* Macro:      CNXT_TSP_XPRT_BUFF_SET_WRITE_PRIME_ADDRESS                               */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the write prime address of this buffer.*/
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_XPRT_BUFF_SET_WRITE_PRIME_ADDRESS(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_XPRT_BUFF_DESC_WRITE_PRIME_OFFSET,TSP_XPRT_BUFF_DESC_WRITE_PRIME_MASK,(value)))


/* HIGH Watermark */
#define TSP_ES_BUFF_DESC_HIGH_WATERMARK_OFFSET      (6)          /* The number of words offset this address is from the base of the buffer descriptor */
#define TSP_ES_BUFF_DESC_HIGH_WATERMARK_MASK        (0xFFFFFFFF)   /* Mask for Low watermark */

/* Macro:      CNXT_TSP_ES_BUFF_SET_HIGH_WATERMARK                                      */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/*                      value - the new value for the high watermark of this buffer.    */
/* Returns:    Nothing.                                                                 */
#define CNXT_TSP_ES_BUFF_SET_HIGH_WATERMARK(buff_desc_addr,value) \
         (CNXT_SET_VAL((buff_desc_addr)+TSP_ES_BUFF_DESC_HIGH_WATERMARK_OFFSET,TSP_ES_BUFF_DESC_HIGH_WATERMARK_MASK,(value)))

/* Macro:      CNXT_TSP_ES_BUFF_GET_HIGH_WATERMARK                                      */
/* Parameters: buff_desc_addr - this is a pointer to the base of the buffer descriptor. */
/* Returns:    The high watermark of the buffer.                                        */
#define CNXT_TSP_ES_BUFF_GET_HIGH_WATERMARK(buff_desc_addr) \
         (CNXT_GET_VAL((buff_desc_addr)+TSP_ES_BUFF_DESC_HIGH_WATERMARK_OFFSET,TSP_ES_BUFF_DESC_HIGH_WATERMARK_MASK))

#endif

         
/************************************************
 * TSP PID Descriptor Definitions and Macros *
 ************************************************/

#define TSP_PID_DESC_INDEX_MAP_OFFSET     (1)          /* The number of words offset this 
                            address is from the base of the buffer descriptor */
#define TSP_PID_DESC_INDEX_MAP_MASK       (0x000000FF) /* Mask for the valid data */

/* Macro:      CNXT_TSP_PID_GET_INDEX_MAP                                          */
/* Parameters: pid_desc_addr - this is a pointer to the base of the pid descriptor. */
/* Returns:    The Index Mapping of the descriptor.                                         */
#define CNXT_TSP_PID_DESC_GET_INDEX_MAP(pid_desc_addr) \
         (CNXT_GET_VAL((pid_desc_addr)+TSP_PID_DESC_INDEX_MAP_OFFSET,TSP_PID_DESC_INDEX_MAP_MASK))

/* TSP Control Register */
#define TSP_HOST_CTL_REG(unit)            ((volatile HW_DWORD *)(TSP_BASE(unit)+0x00))
#define    TSP_ENABLE                     (1UL<<0)  /* 0=Disable 1=Enable */
#define    TSP_RUN                        (1UL<<1)  /* 0=Reset TSP 1=Run TSP */
#define    TSP_BREAK                      (1UL<<3)  /* 0=Run 1=TSP Break */
#define    TSP_LOW_POW_CLK_DIV_SHIFT      (4)       /* Low power clock divide ratio */
#define    TSP_LOW_POW_CLK_DIV_MASK       (0x000000F0)
#define    TSP_DMA_TSIN_ENDIAN            (1UL<<8)  /* 0=little endian 1=big endian */
#define    TSP_DMA_TSOUT_ENDIAN           (1UL<<9)  /* 0=little endian 1=big endian */
#define    TSP_TSIN_ENABLE                (1UL<<10) /* 0=disable 1=enable */
#define    TSP_TSOUT_ENABLE               (1UL<<11) /* 0=disable 1=enable */
#define    TSP_TSIN_SOURCE                (1UL<<12) /* 0=NIM 1=DMA */
#define    TSP_TSOUT_SOURCE               (1UL<<13) /* 0=NIM 1=DMA */
#define    TSP_TSIN_DMA_REQ_ENABLE        (1UL<<14) /* 0=disable 1=enable */
#define    TSP_TSOUT_DMA_REQ_ENABLE       (1UL<<15) /* 0=disable 1=enable */
#define    TSP_TSIN_DMA_THRES             (16)      /* ts_in DMA threshold 00=16, 01=32, 10=48, 11=64  */
#define    TSP_TSIN_DMA_THRES_MASK        (0x00030000)
#define    TSP_TSOUT_DMA_THRES            (18)      /* ts_out DMA threshold 00=16, 01=32, 10=48, 11=64  */
#define    TSP_TSOUT_DMA_THRES_MASK       (0x000C0000)
#define    TSP_TSOUT_PACE_ENABLE          (1UL<<20) /* 0=Free run 1=Wait on tso_out FIFO full */
#define    TSP_TSOUT_WAIT_ENABLE          (1UL<<21) /* 0=Free run 1=Wait on ready from TSS */
#define    TSP_TSIN_READY_THRES           (22)      /* TSI Ready Thresh 00=0+8 or more, 01=64+8, 10=128+8, 11=192+8  */
#define    TSP_TSIN_READY_THRES_MASK      (0x00C00000)
#define    TSP_TSIN_READY_0_BYTES_FREE      (0) /* TSI Ready Threshold 00 = 0+8  */
#define    TSP_TSIN_READY_64_BYTES_FREE     (1) /* TSI Ready Threshold 01 = 64+8  */
#define    TSP_TSIN_READY_128_BYTES_FREE    (2) /* TSI Ready Threshold 10 = 128+8  */
#define    TSP_TSIN_READY_192_BYTES_FREE    (3) /* TSI Ready Threshold  11 = 192 +8  */

#define    TSP_TSOUT_PACE_SLEEP           (1UL<<24) /* 0=Disabled 1=Enter low power mode when stalled due to pacing. */

#define    TSP_KEY_RAM_PAGE_SELECT        (25) /* select set of 128 64 bit keys memory mapped through the HTI.*/
#define    TSP_KEY_RAM_PAGE_SELECT_MASK   (0x0E000000)

#define    TSP_KEY_RAM_READ_DISABLE      (28) /* 1 = Disable, 0 = enable */
#define    TSP_KEY_RAM_WRITE_DISABLE     (29) /* 1 = Disable, 0 = enable */

#define    TSP_FILTER_RAM_OVERLAY_ENABLE     (1UL << 30)
#define    TSP_KEY_RAM_SEPARATION_MODE_ENABLE   (1UL << 31)

/* TSP status register */
#define TSP_STATUS_REG(unit)              ((volatile HW_DWORD *)(TSP_BASE(unit)+0x04))
#define    TSP_STATUS_READY               (1UL<<0)  /* 1 = TSP ready for operation, 
                                                       0 = TSP in reset ot coming out of reset. */

/* TSP HOST interupt Enable Register (Enables H/W interrupts to the HOST) */
#define TSP_HOST_INT_ENABLE_REG(unit)     ((volatile HW_DWORD *)(TSP_BASE(unit)+0x10))
#define    TSP_HOST_INT_ENABLE_MASK       (0x000001FD)
/* Notes : TSP_HOST_INT_ENABLE_REG
 * bits
 * 31:9 Reserved
 * 8:0 0=Disable interrupt 1=Enable interrupt
 *     Enables hardware sourced interrupts to the host.
 *
 * See status register for bit definitions (below).
 */

/* TSP HOST interupt Status Register */
#define TSP_HOST_INT_STATUS_REG(unit)        ((volatile HW_DWORD *)(TSP_BASE(unit)+0x14))
#define    TSP_EXCEPTION                     (1UL<<0)
#define    TSP_ECP_ERR                       (1UL<<2)
#define    TSP_HSX_ERR                       (1UL<<3)
#define    TSP_TSI_FIFO_OVRFLW               (1UL<<4)
#define    TSP_TSO_FIFO_OVRFLW               (1UL<<5)
#define    TSP_DMA_FIFO_OVRFLW               (1UL<<6)
#define    TSP_UCODE_INT                     (1UL<<7)
#define    TSP_CAM_ECM_INT                   (1UL<<8)
/* Notes : TSP_HOST_INT_STATUS_REG
 * bits
 * 0 TSP Processor Exception
 * 1 reserved
 * 2 ECP HSX Bus Error (ECP FIFO Access)
 * 3 TSP HSX Bus Error (SCP System Bus Access)
 * 4 TSI FIFO Overflow
 * 5 TSO FIFO Overflow
 * 6 DMA FIFO Overflow
 * 7 Microcode Interrupt
 * 8 CAM ECM Interrupt
 * 31:9 Reserved
 *
 * If a bit is 1 the interrupt is asserted. Writing a 1 clears the interrupt for bits 6:0 !!GRB_TODO correction of tempest spec!!,
 * the other bits are cleared automatically when the appropriate status register is cleared.
 * If any bit is set in both the status and enable registers the interrupt line to the host
 * CPU (ARM) will be asserted.
 */

/* TSP Microcode Interrupt Enable Register */
#define TSP_UCODE_INT_ENABLE_REG(unit)       ((volatile HW_DWORD *)(TSP_BASE(unit)+0x20))
#define    TSP_UCODE_INT_ENABLE_REG_MASK     (0xFFFFFFFF)
/* Notes : TSP_UCODE_INT_ENABLE_REG
 *   The use of these bits is microcode defined.
 */

/* TSP Microcode Interrupt Reset Status Register */
#define TSP_UCODE_INT_RESET_STATUS_REG(unit) ((volatile HW_DWORD *)(TSP_BASE(unit)+0x24))
/* Notes : TSP_UCODE_INT_RESET_STATUS_REG
 * Microcode interrupts are interrupts to the host issued by the microcode. The use of these bits
 * is microcode defined. This register is intended to be written by the HOST.
 */

/* TSP Microcode Interrupt Set Status Register */
#define TSP_UCODE_INT_SET_STATUS_REG(unit)   ((volatile HW_DWORD *)(TSP_BASE(unit)+0x28))
/* Notes : TSP_UCODE_INT_SET_STATUS_REG
 * These are the bit definitions for the microcode interrupt enable and status
 * registers in the host/transport interface. The TSP_UCODE_INT_SET_STATUS_REG
 * is intended to be written via the UCODE.
 */

#define TSP_UCODE_INT_TSP_READY        (1UL<<0)  /* TSP Ready (reset or abort complete) */
#define TSP_UCODE_INT_TSP_BRK_PT       (1UL<<1)  /* TSP Breakpoint */
#define TSP_UCODE_INT_TSP_INT_ERR      (1UL<<2)  /* TSP Internal Error */
#define TSP_UCODE_INT_TSP_RESV         (1UL<<3)  /* TSP Reserved (for unit test complete) */
#define TSP_UCODE_INT_TSP_GRP_MASK     (TSP_UCODE_INT_TSP_READY | TSP_UCODE_INT_TSP_BRK_PT /* | TSP_UCODE_INT_TSP_INT_ERR -> GRB-TSP_ERR this is handled in demux ISR directly now. */ | TSP_UCODE_INT_TSP_RESV)

#define TSP_UCODE_INT_TS_ACQ           (1UL<<4)  /* Transport Stream Acquired (data now present on input) */
#define TSP_UCODE_INT_TS_LOST          (1UL<<5)  /* Transport Stream Lost (data no longer present on input)  */
#define TSP_UCODE_INT_TS_SYNC_ACQ      (1UL<<6)  /* Sync Acquired (regained sync with transport stream input) */
#define TSP_UCODE_INT_TS_SYNC_LOST     (1UL<<7)  /* Sync Lost (lost sync with transport stream input) */
#define TSP_UCODE_INT_NIM_ERR          (1UL<<8)  /* NIM Error (NIM reports network error) */
#define TSP_UCODE_INT_TPH_ERR          (1UL<<9)  /* TPH Error (Error reported in transport packet header) */
#define TSP_UCODE_INT_STREAM_GRP_MASK  (TSP_UCODE_INT_TS_ACQ|TSP_UCODE_INT_TS_LOST|TSP_UCODE_INT_TS_SYNC_ACQ| \
                                        TSP_UCODE_INT_TS_SYNC_LOST|TSP_UCODE_INT_NIM_ERR|TSP_UCODE_INT_TPH_ERR)

#define TSP_UCODE_INT_CMD_ACCEPT       (1UL<<10) /* Command Accepted */
#define TSP_UCODE_INT_CMD_BUF_EMPTY    (1UL<<11) /* Command Buffer Empty */
#define TSP_UCODE_INT_CMD_GRP_MASK     (TSP_UCODE_INT_CMD_ACCEPT|TSP_UCODE_INT_CMD_BUF_EMPTY)

#define TSP_UCODE_INT_MSG_RDY          (1UL<<12) /* Message Ready */
#define TSP_UCODE_INT_MSG_BUF_OVRFLW   (1UL<<13) /* Message Buffer Overflow */
#define TSP_UCODE_INT_MSG_GRP_MASK     (TSP_UCODE_INT_MSG_RDY|TSP_UCODE_INT_MSG_BUF_OVRFLW)

#define TSP_UCODE_INT_RESERVED         (1UL<<14) /* Reserved */

/* TSP Command Preempt Enable Register */
#define TSP_CMD_PREEMPT_ENABLE_REG(unit)   ((volatile HW_DWORD *)(TSP_BASE(unit)+0x30))
/* TSP Command Set Status Register */
#define TSP_CMD_SET_STATUS_REG(unit)       ((volatile HW_DWORD *)(TSP_BASE(unit)+0x34))
/* Notes :
 * Commands are interrupts to the microcode from the host.
 * The use of these bits is microcode defined.
 * This register is intended to be written by the host.
 */
/* Interupts to Ucode from the Host, Used by the Host */
#define TSP_CMD_TSP_ABORT              (1UL<<0)  /* 1=TSP Abort, Abort means return to reset state 
                        in cleanest possible manner by microcode means.   */
#define TSP_CMD_TSP_PKT_CMD_RDY        (1UL<<1)  /* 1=TSP Packet Command Word Ready,
                                                 * Packet command word ready means a command word has been placed in the
                                                 * RAM-based command buffer by the host.
                                                 * The command will be executed at the end of the current packet. It is
                                                 * intended that the associated bit in the command preempt enable register
                                                 * is not set for this bit.
                                                 */

/* TSP Command Reset Status Register */
#define TSP_CMD_RESET_STATUS_REG(unit)          ((volatile HW_DWORD *)(TSP_BASE(unit)+0x38))
/* Notes : This register is used by the Parser
 * bit
 *  3:0  write 0 = no affect
 *             1 = resets the status bit.
 *       read  0 = status bit is clear.
 *             1 = status bit is set.
 *  31:4 reserved
 */

/* Inter processor Communication Registers : Not used by Host */
#define TSP_IPC_EVENT_ENABLE_REG(unit)          ((volatile HW_DWORD *)(TSP_BASE(unit)+0x40))
#define TSP_IPC_EVENT_SET_STATUS_REG(unit)      ((volatile HW_DWORD *)(TSP_BASE(unit)+0x44))
#define TSP_IPC_EVENT_RESET_STATUS_REG(unit)    ((volatile HW_DWORD *)(TSP_BASE(unit)+0x48))

#define TSP_CAM_ECM_INT_ENABLE_REG(unit)        ((volatile HW_DWORD *)(TSP_BASE(unit)+0x50))
/* Notes : TSP_CAM_ECM_INT_ENABLE_REG
 * bit
 * 31:8 reserved
 * 7:0 0=disbled interrupt 1=enable interrupt
 * The use of these bits is microcode defined, but is intended for NDS ICAM ECM interrupts.
 */
#define TSP_CAM_ECM_RESET_STATUS_REG(unit)      ((volatile HW_DWORD *)(TSP_BASE(unit)+0x54))
/* Notes : TSP_CAM_ECM_RESET_STATUS_REG
 * bit
 * 31:8 reserved
 * 7:0 write 0 = no effect
 *           1 = resets the status bit
 *     read  0 = status bit is clear
 *           1 = status bit is set
 *
 * The use of these bits is microcode defined. This register is intended to be written by the host.
 */
#define TSP_CAM_ECM_SET_STATUS_REG(unit)        ((volatile HW_DWORD *)(TSP_BASE(unit)+0x58))
/* Notes : TSP_CAM_ECM_SET_STATUS_REG
 * bit
 * 31:4 reserved
 * 3:0 write 0 = no effect
 *           1 = sets the status bit
 *     read  0 = status bit is clear
 *           1 = status bit is set
 *  The use of these bits is microcode defined. This register is intended to be written by the parser.
 */

/* New definitions for ICAM 2.2 Pecos Rev. B  */
/* ECM Interrupt Status register per TSR/TSP */
#define TSP_CAM_ECM_INT_STATUS_REG(unit)        ((volatile HW_DWORD *)(TSP_BASE(unit)+0x5C))
/* Macro to extract source stream 32-bit value */
#define TSP_CAM_ECM_GET_INT_SOURCE_STREAM(unit) (CNXT_GET_VAL(TSP_CAM_ECM_INT_STATUS_REG(unit), TSP_CAM_ECM_REG_MASK))

#define TSP_CAM_N_SET_STATUS_REG(unit, strmIdx) ((volatile HW_DWORD *)((TSP_BASE(unit)+0x84) + (strmIdx * 0x8)))
#define TSP_CAM_N_RESET_STATUS_REG(unit, strmIdx) ((volatile HW_DWORD *)((TSP_BASE(unit)+0x80) + (strmIdx * 0x8)))

#define  TSP_CAM_ECM_REG_MASK                   (0x000000FF)

/* FIFO registers */
#define TSP_TSI_FIFO_FREE_REG(unit)             ((volatile HW_DWORD *)(TSP_BASE(unit)+0x60))
#define TSP_TSO_FIFO_FREE_REG(unit)             ((volatile HW_DWORD *)(TSP_BASE(unit)+0x64))
#define TSP_DMA_FIFO_FREE_REG(unit)             ((volatile HW_DWORD *)(TSP_BASE(unit)+0x68))
#define FIFO_FREE_REG_MASK                      (0x000001FF)
/* Notes : TSP_TSI_FIFO_FREE_REG,TSP_TSO_FIFO_FREE_REG,TSP_DMAI_FIFO_FREE_REG
 *
 * bits
 * 8:0 bytes free in FIFO
 * All these FIFO's are 256 Bytes.
 */

/* Misc. Registers */
#define TSP_ESA_SELECT(unit)                    ((volatile HW_DWORD *)(TSP_BASE(unit)+0x7C))
#define    TSP_ESA_SELECT_DEFAULT               0xF
 
#define TSP_OUTPUT_CONTROL_ADDR_REG(unit)               (TSP_RAM(unit) + 0x0090 )
   #define TSP_OUTPUT_CONTROL_ADDR_REG_MASK             (0xFFFFFFFF)

   /*
    * Header definitions
    */
#define TSP_PLY_EVENT_STREAM_INDEX_MASK            (0xF0000000)
   
#define TSP_PLY_EVENT_PICT_CODING_MASK             (0x0C000000)
#define    TSP_PLY_EVENT_PICT_CODING_I_PICT        (1UL<<26)
#define    TSP_PLY_EVENT_PICT_CODING_P_PICT        (2UL<<26)
#define    TSP_PLY_EVENT_PICT_CODING_B_PICT        (3UL<<26)
   
#define TSP_PLY_EVENT_PICT_STRUCT_MASK             (0x03000000)
#define    TSP_PLY_EVENT_PICT_STRUCT_TOP_FIELD     (1UL<<24)
#define    TSP_PLY_EVENT_PICT_STRUCT_BOTTOM_FIELD  (2UL<<24)
#define    TSP_PLY_EVENT_PICT_STRUCT_FRAME         (3UL<<24)
   
#define    TSP_PLY_EVENT_REPEAT_FIRST_FIELD        (1UL<<23)
#define    TSP_PLY_EVENT_HEADER_ERROR              (1UL<<22)
#define    TSP_PLY_EVENT_PICT_HEADER               (1UL<<21)
#define    TSP_PLY_EVENT_GOP_HEADER                (1UL<<20)
#define    TSP_PLY_EVENT_SEQ_HEADER                (1UL<<19)
   
#define TSP_PLY_EVENT_MPEG_STD_MASK                (0x00040000)
#define    TSP_PLY_EVENT_MPEG_STD_1                (0UL<<18)
#define    TSP_PLY_EVENT_MPEG_STD_2                (1UL<<18)
   
#define TSP_PLY_EVENT_FIELD_ORDER_MASK             (0x00020000)
#define    TSP_PLY_EVENT_BOTTOM_FIELD_FIRST        (0UL<<17)
#define    TSP_PLY_EVENT_TOP_FIELD_FIRST           (1UL<<17)
   
#define TSP_PLY_EVENT_PROGRESSIVE_FRAME_MASK       (0x00010000)
#define    TSP_PLY_EVENT_INTERLACED_FRAME          (0UL<<16)
#define    TSP_PLY_EVENT_PROGRESSIVE_FRAME         (1UL<<16)
   
#define    TSP_PLY_EVENT_PTS_VALID                 (1UL<<15)
   
#define TSP_PLY_EVENT_RESERVED_MASK                (0x0000E000)
   
#define TSP_PLY_EVENT_PID_MASK                     (0x00001FFF)
   
   /*
    * Picture Header Definitions
    */
   /* Workaround to get PictureCoding from the PictureHeader. */
#define TSP_PLY_EVENT_PICT_HEADER_TYPE_MASK             (0x00180000)

   
#endif /*_TMMODIPTSP_H_*/
