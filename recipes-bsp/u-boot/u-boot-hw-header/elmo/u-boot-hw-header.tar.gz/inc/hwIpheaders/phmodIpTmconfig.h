////////////////////////////////////////////////////////////////////// 
//                                                                  // 
// (c) NXP B.V 2009                                                 // 
//                                                                  // 
// All rights are reserved. Reproduction in whole or in part is     // 
// prohibited without the prior written consent of the copy-right   // 
// owner.                                                           // 
// The information presented in this document does not form part of // 
// any quotation or contract, is believed to be accurate and        // 
// reliable and may be changed without notice. No liability will be // 
// accepted by the publisher for any consequence of its use.        //
// Publication thereof does not convey nor imply any license under  //
// patent- or other industrial or intellectual property rights.     //
////////////////////////////////////////////////////////////////////// 
 
/*! 
 *  @brief Header file for TMCONFIG
 *  @file phmodIpTmconfig.h *
 *  <pre>
 *  $Author: pershaa $
 *  $Revision: 128834 $
 *  $Date: 2009-11-09 23:07:20 -0600 (Mon, 09 Nov 2009) $
 *
 *  Revision history
 *  $Log: $
 *  
 *
 *  $KeysEnd$
 *  </pre>
 *
 */ 


#ifndef PHMODIPTMCONFIG_H
#define PHMODIPTMCONFIG_H
	
//	#define MMIO_BASE 0xE0600000    /* Hard Coded value for APOLLO  */
//	#define TMCONFIG_BASE_UNIT1 (MMIO_BASE + 0x1e0000)
//	#define TMCONFIG_BASE_UNIT2 (MMIO_BASE + 0x190000)
	
	/*
	* Select four cache-related events for counting.
	*/
	#define TMCONFIG_MEM_EVENTS_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc)
	/*
	* Select the source for timer CACHE4 source
	*/
	#define TMCONFIG_MEM_EVENTS_EVENT4_RW (0x0ff << 24)
	#define TMCONFIG_MEM_EVENTS_EVENT4_SHIFT 24
	/*
	* Select the source for timer CACHE3 source
	*/
	#define TMCONFIG_MEM_EVENTS_EVENT3_RW (0x0ff << 16)
	#define TMCONFIG_MEM_EVENTS_EVENT3_SHIFT 16
	/*
	* Select the source for timer CACHE2 source
	*/
	#define TMCONFIG_MEM_EVENTS_EVENT2_RW (0x0ff << 8)
	#define TMCONFIG_MEM_EVENTS_EVENT2_SHIFT 8
	/*
	* Select the source for timer CACHE1 source
	*/
	#define TMCONFIG_MEM_EVENTS_EVENT1_RW (0x0ff << 0)
	#define TMCONFIG_MEM_EVENTS_EVENT1_SHIFT 0
	/*
	* Data cache locking enable and aperture control.
	*/
	#define TMCONFIG_DC_LOCK_CTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x10)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_DC_LOCK_CTL_RESERVED3_RES (0x07fff << 17)
	#define TMCONFIG_DC_LOCK_CTL_RESERVED3_SHIFT 17
	#define TMCONFIG_DC_LOCK_CTL_DC_LOCK_BUSY_R (0x01 << 16)
	#define TMCONFIG_DC_LOCK_CTL_DC_LOCK_BUSY_SHIFT 16
	#define TMCONFIG_DC_LOCK_CTL_DC_LOCK_BUSY_VAL0 0x00
	#define TMCONFIG_DC_LOCK_CTL_DC_LOCK_BUSY_VAL1 0x01
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_DC_LOCK_CTL_RESERVED4_RES (0x01ff << 7)
	#define TMCONFIG_DC_LOCK_CTL_RESERVED4_SHIFT 7
	/*
	* Aperture1 control
	*/
	#define TMCONFIG_DC_LOCK_CTL_APERTURE_CONTROL_RW (0x03 << 5)
	#define TMCONFIG_DC_LOCK_CTL_APERTURE_CONTROL_SHIFT 5
	#define TMCONFIG_DC_LOCK_CTL_APERTURE_CONTROL_VAL0 0x00
	#define TMCONFIG_DC_LOCK_CTL_APERTURE_CONTROL_VAL1 0x01
	#define TMCONFIG_DC_LOCK_CTL_APERTURE_CONTROL_VAL2 0x02
	#define TMCONFIG_DC_LOCK_CTL_APERTURE_CONTROL_VAL3 0x03
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_RES (0x0f << 1)
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_SHIFT 1
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL0 0x00
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL1 0x01
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL2 0x02
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL3 0x03
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL4 0x04
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL5 0x05
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL6 0x06
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL7 0x07
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL8 0x08
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL9 0x09
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL10 0x0a
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL11 0x0b
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL12 0x0c
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL13 0x0d
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL14 0x0e
	#define TMCONFIG_DC_LOCK_CTL_RESERVED5_VAL15 0x0f
	/*
	* Enable data cache lock
	*/
	#define TMCONFIG_DC_LOCK_CTL_DC_LOCK_ENABLE_RW (0x01 << 0)
	#define TMCONFIG_DC_LOCK_CTL_DC_LOCK_ENABLE_SHIFT 0
	#define TMCONFIG_DC_LOCK_CTL_DC_LOCK_ENABLE_VAL0 0x00
	#define TMCONFIG_DC_LOCK_CTL_DC_LOCK_ENABLE_VAL1 0x01
	/*
	* Start of address range that will be locked into the data cache.
	*/
	#define TMCONFIG_DC_LOCK_ADDR_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x14)
	/*
	* Low address of the data cache address lock range.
	*/
	#define TMCONFIG_DC_LOCK_ADDR_DC_LOCK_ADDRESS_RW (0x07ffff << 13)
	#define TMCONFIG_DC_LOCK_ADDR_DC_LOCK_ADDRESS_SHIFT 13
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_DC_LOCK_ADDR_RESERVED1_RES (0x01fff << 0)
	#define TMCONFIG_DC_LOCK_ADDR_RESERVED1_SHIFT 0
	/*
	* Size of address range that will be locked into the data cache.
	*/
	#define TMCONFIG_DC_LOCK_SIZE_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x18)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_DC_LOCK_SIZE_RESERVED1_RES (0x07ffff << 13)
	#define TMCONFIG_DC_LOCK_SIZE_RESERVED1_SHIFT 13
	/*
	* Size of the address range to be locked.
	*/
	#define TMCONFIG_DC_LOCK_SIZE_DC_LOCK_SIZE_RW (0x03f << 7)
	#define TMCONFIG_DC_LOCK_SIZE_DC_LOCK_SIZE_SHIFT 7
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_DC_LOCK_SIZE_RESERVED2_RES (0x07f << 0)
	#define TMCONFIG_DC_LOCK_SIZE_RESERVED2_SHIFT 0
	/*
	* Data cache geometry (block size, associativity, # of sets).
	*/
	#define TMCONFIG_DC_PARAMS_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x1c)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_DC_PARAMS_RESERVED3_RES (0x03f << 26)
	#define TMCONFIG_DC_PARAMS_RESERVED3_SHIFT 26
	#define TMCONFIG_DC_PARAMS_BLOCKSIZE_R (0x03ff << 16)
	#define TMCONFIG_DC_PARAMS_BLOCKSIZE_SHIFT 16
	#define TMCONFIG_DC_PARAMS_ASSOCIATIVITY_R (0x01f << 11)
	#define TMCONFIG_DC_PARAMS_ASSOCIATIVITY_SHIFT 11
	#define TMCONFIG_DC_PARAMS_NUMBER_OF_SETS_R (0x07ff << 0)
	#define TMCONFIG_DC_PARAMS_NUMBER_OF_SETS_SHIFT 0
	/*
	* Instruction cache geometry (block size, associativity, # of sets)
	*/
	#define TMCONFIG_IC_PARAMS_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x20)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_IC_PARAMS_RESERVED3_RES (0x03f << 26)
	#define TMCONFIG_IC_PARAMS_RESERVED3_SHIFT 26
	#define TMCONFIG_IC_PARAMS_BLOCKSIZE_R (0x03ff << 16)
	#define TMCONFIG_IC_PARAMS_BLOCKSIZE_SHIFT 16
	#define TMCONFIG_IC_PARAMS_ASSOCIATIVITY_R (0x01f << 11)
	#define TMCONFIG_IC_PARAMS_ASSOCIATIVITY_SHIFT 11
	#define TMCONFIG_IC_PARAMS_NUMBER_OF_SETS_R (0x07ff << 0)
	#define TMCONFIG_IC_PARAMS_NUMBER_OF_SETS_SHIFT 0
	/*
	* TMConfig Control.
	*/
	#define TMCONFIG_TM32_CTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x30)
	/*
	* Stop and reset or start the TMConfig.
	*/
	#define TMCONFIG_TM32_CTL_ACTION_RW (0x03 << 30)
	#define TMCONFIG_TM32_CTL_ACTION_SHIFT 30
	#define TMCONFIG_TM32_CTL_ACTION_VAL0 0x00
	#define TMCONFIG_TM32_CTL_ACTION_VAL1 0x01
	#define TMCONFIG_TM32_CTL_ACTION_VAL2 0x02
	#define TMCONFIG_TM32_CTL_ACTION_VAL3 0x03
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TM32_CTL_RESERVED1_RES (0x03fffffff << 0)
	#define TMCONFIG_TM32_CTL_RESERVED1_SHIFT 0
	/*
	* Lowest DRAM address that TMConfig can access.
	*/
	#define TMCONFIG_TM32_DRAM_LO_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x34)
	/*
	* Lowest DRAM address that TMConfig can access
	*/
	#define TMCONFIG_TM32_DRAM_LO_TM32_DRAM_LO_RW (0x0ffff << 16)
	#define TMCONFIG_TM32_DRAM_LO_TM32_DRAM_LO_SHIFT 16
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TM32_DRAM_LO_RESERVED1_RES (0x0ffff << 0)
	#define TMCONFIG_TM32_DRAM_LO_RESERVED1_SHIFT 0
	/*
	* Highest DRAM address that TMConfig can access +1.
	*/
	#define TMCONFIG_TM32_DRAM_HI_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x38)
	/*
	* The last byte of the DRAM aperture is at address TM32_DRAM_HI-1>
	*/
	#define TMCONFIG_TM32_DRAM_HI_TM32_DRAM_HI_RW (0x0ffff << 16)
	#define TMCONFIG_TM32_DRAM_HI_TM32_DRAM_HI_SHIFT 16
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TM32_DRAM_HI_RESERVED1_RES (0x0ffff << 0)
	#define TMCONFIG_TM32_DRAM_HI_RESERVED1_SHIFT 0
	/*
	* Start of non-cacheable region in DRAM.
	*/
	#define TMCONFIG_TM32_DRAM_CLIMIT_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x3c)
	/*
	* Start of non-cacheable region in DRAM
	*/
	#define TMCONFIG_TM32_DRAM_CLIMIT_TM32_DRAM_CLIMIT_RW (0x0ffff << 16)
	#define TMCONFIG_TM32_DRAM_CLIMIT_TM32_DRAM_CLIMIT_SHIFT 16
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TM32_DRAM_CLIMIT_RESERVED1_RES (0x0ffff << 0)
	#define TMCONFIG_TM32_DRAM_CLIMIT_RESERVED1_SHIFT 0
	/*
	* Lowest TMconfig address for Aperture1 access.
	*/
	#define TMCONFIG_TM32_APERT1_LO_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x40)
	/*
	* Lowest Aperture1 address that TMconfig can access
	*/
	#define TMCONFIG_TM32_APERT1_LO_TM32_APERT1_LO_RW (0x0ffff << 16)
	#define TMCONFIG_TM32_APERT1_LO_TM32_APERT1_LO_SHIFT 16
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TM32_APERT1_LO_RESERVED1_RES (0x0ffff << 0)
	#define TMCONFIG_TM32_APERT1_LO_RESERVED1_SHIFT 0
	/*
	* Highest TMConfig address that resolves to an Aperture1 access + 1.
	*/
	#define TMCONFIG_TM32_APERT1_HI_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x44)
	/*
	* The last byte of Aperture1 is at address TM32_APERT1_HI - 1
	*/
	#define TMCONFIG_TM32_APERT1_HI_TM32_APERT1_HI_RW (0x0ffff << 16)
	#define TMCONFIG_TM32_APERT1_HI_TM32_APERT1_HI_SHIFT 16
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TM32_APERT1_HI_RESERVED1_RES (0x0ffff << 0)
	#define TMCONFIG_TM32_APERT1_HI_RESERVED1_SHIFT 0
	/*
	* Address where TMConfig execution starts.
	*/
	#define TMCONFIG_TM32_START_ADDR_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x48)
	/*
	* Address that TMConfig execution starts from upon START.
	*/
	#define TMCONFIG_TM32_START_ADDR_TM32_START_ADDR_RW (0x03ffffff << 6)
	#define TMCONFIG_TM32_START_ADDR_TM32_START_ADDR_SHIFT 6
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TM32_START_ADDR_RESERVED1_RES (0x03f << 0)
	#define TMCONFIG_TM32_START_ADDR_RESERVED1_SHIFT 0
	/*
	* TMConfig program counter.
	*/
	#define TMCONFIG_TM32_PC_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x4c)
	/*
	* TMConfig program counter.
	*/
	#define TMCONFIG_TM32_PC_TM32_PC_R (0x0ffffffff << 0)
	#define TMCONFIG_TM32_PC_TM32_PC_SHIFT 0
	/*
	* Reserved exception cause.
	*/
	#define TMCONFIG_RSE_CAUSE_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x50)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_RSE_CAUSE_RESERVED8_RES (0x0fff << 20)
	#define TMCONFIG_RSE_CAUSE_RESERVED8_SHIFT 20
	/*
	* Enable for ILSTM exception
	*/
	#define TMCONFIG_RSE_CAUSE_ILSTM_EN_RW (0x01 << 19)
	#define TMCONFIG_RSE_CAUSE_ILSTM_EN_SHIFT 19
	#define TMCONFIG_RSE_CAUSE_ILSTM_EN_VAL0 0x00
	#define TMCONFIG_RSE_CAUSE_ILSTM_EN_VAL1 0x01
	/*
	* Enable for ILOP exception
	*/
	#define TMCONFIG_RSE_CAUSE_ILOP_EN_RW (0x01 << 18)
	#define TMCONFIG_RSE_CAUSE_ILOP_EN_SHIFT 18
	#define TMCONFIG_RSE_CAUSE_ILOP_EN_VAL0 0x00
	#define TMCONFIG_RSE_CAUSE_ILOP_EN_VAL1 0x01
	/*
	* Enable for ILSTO exception
	*/
	#define TMCONFIG_RSE_CAUSE_ILSTO_EN_RW (0x01 << 17)
	#define TMCONFIG_RSE_CAUSE_ILSTO_EN_SHIFT 17
	#define TMCONFIG_RSE_CAUSE_ILSTO_EN_VAL0 0x00
	#define TMCONFIG_RSE_CAUSE_ILSTO_EN_VAL1 0x01
	/*
	* Enable for ILJMP exception
	*/
	#define TMCONFIG_RSE_CAUSE_ILJMP_EN_RW (0x01 << 16)
	#define TMCONFIG_RSE_CAUSE_ILJMP_EN_SHIFT 16
	#define TMCONFIG_RSE_CAUSE_ILJMP_EN_VAL0 0x00
	#define TMCONFIG_RSE_CAUSE_ILJMP_EN_VAL1 0x01
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_RSE_CAUSE_RESERVED9_RES (0x0fff << 4)
	#define TMCONFIG_RSE_CAUSE_RESERVED9_SHIFT 4
	/*
	* Illegal store (to MMIO) exception
	*/
	#define TMCONFIG_RSE_CAUSE_ILSTM_RW (0x01 << 3)
	#define TMCONFIG_RSE_CAUSE_ILSTM_SHIFT 3
	#define TMCONFIG_RSE_CAUSE_ILSTM_VAL0 0x00
	#define TMCONFIG_RSE_CAUSE_ILSTM_VAL1 0x01
	/*
	* Illegal operation exception
	*/
	#define TMCONFIG_RSE_CAUSE_ILOP_RW (0x01 << 2)
	#define TMCONFIG_RSE_CAUSE_ILOP_SHIFT 2
	#define TMCONFIG_RSE_CAUSE_ILOP_VAL0 0x00
	#define TMCONFIG_RSE_CAUSE_ILOP_VAL1 0x01
	/*
	* Illegal store (to memory hole) exception
	*/
	#define TMCONFIG_RSE_CAUSE_ILSTO_RW (0x01 << 1)
	#define TMCONFIG_RSE_CAUSE_ILSTO_SHIFT 1
	#define TMCONFIG_RSE_CAUSE_ILSTO_VAL0 0x00
	#define TMCONFIG_RSE_CAUSE_ILSTO_VAL1 0x01
	/*
	* Illegal jump exception
	*/
	#define TMCONFIG_RSE_CAUSE_ILJMP_RW (0x01 << 0)
	#define TMCONFIG_RSE_CAUSE_ILJMP_SHIFT 0
	#define TMCONFIG_RSE_CAUSE_ILJMP_VAL0 0x00
	#define TMCONFIG_RSE_CAUSE_ILJMP_VAL1 0x01
	/*
	* Reserved-exception program counter.
	*/
	#define TMCONFIG_RSE_PC_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x54)
	/*
	* Reserved-exception program counter.
	*/
	#define TMCONFIG_RSE_PC_RSE_PC_R (0x0ffffffff << 0)
	#define TMCONFIG_RSE_PC_RSE_PC_SHIFT 0
	/*
	* Value to be available at core CPU boundary.
	*/
	#define TMCONFIG_OBSERVE_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x60)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_OBSERVE_RESERVED1_RES (0x07fffffff << 1)
	#define TMCONFIG_OBSERVE_RESERVED1_SHIFT 1
	/*
	* The value of this bit is visible on the TMconfig output pin tm_observe
	*/
	#define TMCONFIG_OBSERVE_OBSERVE_RW (0x01 << 0)
	#define TMCONFIG_OBSERVE_OBSERVE_SHIFT 0
	#define TMCONFIG_OBSERVE_OBSERVE_VAL0 0x00
	#define TMCONFIG_OBSERVE_OBSERVE_VAL1 0x01
	/*
	* Partial power down.
	*/
	#define TMCONFIG_POWER_DOWN_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x108)
	/*
	* Partial power down.
	*/
	#define TMCONFIG_POWER_DOWN_POWER_DOWN_R (0x0ffffffff << 0)
	#define TMCONFIG_POWER_DOWN_POWER_DOWN_SHIFT 0
	/*
	* Instruction cache locking enable control.
	*/
	#define TMCONFIG_IC_LOCK_CTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x210)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_IC_LOCK_CTL_RESERVED2_RES (0x07fff << 17)
	#define TMCONFIG_IC_LOCK_CTL_RESERVED2_SHIFT 17
	#define TMCONFIG_IC_LOCK_CTL_IC_LOCK_BUSY_R (0x01 << 16)
	#define TMCONFIG_IC_LOCK_CTL_IC_LOCK_BUSY_SHIFT 16
	#define TMCONFIG_IC_LOCK_CTL_IC_LOCK_BUSY_VAL0 0x00
	#define TMCONFIG_IC_LOCK_CTL_IC_LOCK_BUSY_VAL1 0x01
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_IC_LOCK_CTL_RESERVED3_RES (0x07fff << 1)
	#define TMCONFIG_IC_LOCK_CTL_RESERVED3_SHIFT 1
	/*
	* Enable instruction cache locking.
	*/
	#define TMCONFIG_IC_LOCK_CTL_IC_LOCK_ENABLE_RW (0x01 << 0)
	#define TMCONFIG_IC_LOCK_CTL_IC_LOCK_ENABLE_SHIFT 0
	#define TMCONFIG_IC_LOCK_CTL_IC_LOCK_ENABLE_VAL0 0x00
	#define TMCONFIG_IC_LOCK_CTL_IC_LOCK_ENABLE_VAL1 0x01
	/*
	* Instruction cache lock start address.
	*/
	#define TMCONFIG_IC_LOCK_ADDR_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x214)
	/*
	* Sets lower address of the instruction cache lock address range.
	*/
	#define TMCONFIG_IC_LOCK_ADDR_IC_LOCK_ADDRESS_RW (0x03ffff << 14)
	#define TMCONFIG_IC_LOCK_ADDR_IC_LOCK_ADDRESS_SHIFT 14
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_IC_LOCK_ADDR_RESERVED1_RES (0x03fff << 0)
	#define TMCONFIG_IC_LOCK_ADDR_RESERVED1_SHIFT 0
	/*
	* Instruction cache lock size.
	*/
	#define TMCONFIG_IC_LOCK_SIZE_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x218)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_IC_LOCK_SIZE_RESERVED1_RES (0x03ffff << 14)
	#define TMCONFIG_IC_LOCK_SIZE_RESERVED1_SHIFT 14
	/*
	* Size of the address range to be locked.
	*/
	#define TMCONFIG_IC_LOCK_SIZE_IC_LOCK_SIZE_RW (0x07f << 7)
	#define TMCONFIG_IC_LOCK_SIZE_IC_LOCK_SIZE_SHIFT 7
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_IC_LOCK_SIZE_RESERVED2_RES (0x07f << 0)
	#define TMCONFIG_IC_LOCK_SIZE_RESERVED2_SHIFT 0
	/*
	* Instruction cache LRU update control.
	*/
	#define TMCONFIG_IC_LRU_UPDATE_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x220)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_IC_LRU_UPDATE_RESERVED1_RES (0x07fffffff << 1)
	#define TMCONFIG_IC_LRU_UPDATE_RESERVED1_SHIFT 1
	#define TMCONFIG_IC_LRU_UPDATE_IC_LRU_UPDATE_R (0x01 << 0)
	#define TMCONFIG_IC_LRU_UPDATE_IC_LRU_UPDATE_SHIFT 0
	#define TMCONFIG_IC_LRU_UPDATE_IC_LRU_UPDATE_VAL0 0x00
	#define TMCONFIG_IC_LRU_UPDATE_IC_LRU_UPDATE_VAL1 0x01
	/*
	* Start address for prefetch region 0.
	*/
	#define TMCONFIG_PF0_START_ADDR_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x400)
	/*
	* Start address of the prefetch region
	*/
	#define TMCONFIG_PF0_START_ADDR_ADDR_RW (0x01ffffff << 7)
	#define TMCONFIG_PF0_START_ADDR_ADDR_SHIFT 7
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_PF0_START_ADDR_RESERVED1_RES (0x07f << 0)
	#define TMCONFIG_PF0_START_ADDR_RESERVED1_SHIFT 0
	/*
	* End address for prefetch region 0.
	*/
	#define TMCONFIG_PF0_END_ADDR_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x404)
	/*
	* End address of the prefetch region
	*/
	#define TMCONFIG_PF0_END_ADDR_ADDR_RW (0x01ffffff << 7)
	#define TMCONFIG_PF0_END_ADDR_ADDR_SHIFT 7
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_PF0_END_ADDR_RESERVED1_RES (0x07f << 0)
	#define TMCONFIG_PF0_END_ADDR_RESERVED1_SHIFT 0
	/*
	* Control register for prefetch region 0.
	*/
	#define TMCONFIG_PF0_CTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x408)
	/*
	* Prefetch region active
	*/
	#define TMCONFIG_PF0_CTL_ACTIVE_RW (0x01 << 31)
	#define TMCONFIG_PF0_CTL_ACTIVE_SHIFT 31
	#define TMCONFIG_PF0_CTL_ACTIVE_VAL0 0x00
	#define TMCONFIG_PF0_CTL_ACTIVE_VAL1 0x01
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_PF0_CTL_RESERVED2_RES (0x03fff << 17)
	#define TMCONFIG_PF0_CTL_RESERVED2_SHIFT 17
	/*
	* Prefetch region stride
	*/
	#define TMCONFIG_PF0_CTL_STRIDE_RW (0x01ffff << 0)
	#define TMCONFIG_PF0_CTL_STRIDE_SHIFT 0
	/*
	* Start address for prefetch region 1.
	*/
	#define TMCONFIG_PF1_START_ADDR_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x410)
	/*
	* Start address of the prefetch region
	*/
	#define TMCONFIG_PF1_START_ADDR_ADDR_RW (0x01ffffff << 7)
	#define TMCONFIG_PF1_START_ADDR_ADDR_SHIFT 7
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_PF1_START_ADDR_RESERVED1_RES (0x07f << 0)
	#define TMCONFIG_PF1_START_ADDR_RESERVED1_SHIFT 0
	/*
	* End address for prefetch region 1.
	*/
	#define TMCONFIG_PF1_END_ADDR_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x414)
	/*
	* End address of the prefetch region
	*/
	#define TMCONFIG_PF1_END_ADDR_ADDR_RW (0x01ffffff << 7)
	#define TMCONFIG_PF1_END_ADDR_ADDR_SHIFT 7
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_PF1_END_ADDR_RESERVED1_RES (0x07f << 0)
	#define TMCONFIG_PF1_END_ADDR_RESERVED1_SHIFT 0
	/*
	* Control register for prefetch region 1.
	*/
	#define TMCONFIG_PF1_CTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x418)
	/*
	* Prefetch region active
	*/
	#define TMCONFIG_PF1_CTL_ACTIVE_RW (0x01 << 31)
	#define TMCONFIG_PF1_CTL_ACTIVE_SHIFT 31
	#define TMCONFIG_PF1_CTL_ACTIVE_VAL0 0x00
	#define TMCONFIG_PF1_CTL_ACTIVE_VAL1 0x01
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_PF1_CTL_RESERVED2_RES (0x03fff << 17)
	#define TMCONFIG_PF1_CTL_RESERVED2_SHIFT 17
	/*
	* Prefetch region stride
	*/
	#define TMCONFIG_PF1_CTL_STRIDE_RW (0x01ffff << 0)
	#define TMCONFIG_PF1_CTL_STRIDE_SHIFT 0
	/*
	* Semaphore assist device.
	*/
	#define TMCONFIG_SEM_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x500)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_SEM_RESERVED1_RES (0x0fffff << 12)
	#define TMCONFIG_SEM_RESERVED1_SHIFT 12
	/*
	* A simple MP semaphore-assist device
	*/
	#define TMCONFIG_SEM_SEM_RW (0x0fff << 0)
	#define TMCONFIG_SEM_SEM_SHIFT 0
	/*
	* Interrupt vector (handler start address) for exceptions.
	*/
	#define TMCONFIG_EXCVEC_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x800)
	/*
	* Interrupt vector (handler start address) for exceptions.
	*/
	#define TMCONFIG_EXCVEC_EXCVEC_RW (0x0ffffffff << 0)
	#define TMCONFIG_EXCVEC_EXCVEC_SHIFT 0
	/*
	* Interrupt mode and priority settings
	*/
	#define TMCONFIG_ISETTING0_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x810)
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING0_MP7_RW (0x0f << 28)
	#define TMCONFIG_ISETTING0_MP7_SHIFT 28
	#define TMCONFIG_ISETTING0_MP7_VAL0 0x00
	#define TMCONFIG_ISETTING0_MP7_VAL1 0x01
	#define TMCONFIG_ISETTING0_MP7_VAL2 0x02
	#define TMCONFIG_ISETTING0_MP7_VAL3 0x03
	#define TMCONFIG_ISETTING0_MP7_VAL4 0x04
	#define TMCONFIG_ISETTING0_MP7_VAL5 0x05
	#define TMCONFIG_ISETTING0_MP7_VAL6 0x06
	#define TMCONFIG_ISETTING0_MP7_VAL7 0x07
	#define TMCONFIG_ISETTING0_MP7_VAL8 0x08
	#define TMCONFIG_ISETTING0_MP7_VAL9 0x09
	#define TMCONFIG_ISETTING0_MP7_VAL10 0x0a
	#define TMCONFIG_ISETTING0_MP7_VAL11 0x0b
	#define TMCONFIG_ISETTING0_MP7_VAL12 0x0c
	#define TMCONFIG_ISETTING0_MP7_VAL13 0x0d
	#define TMCONFIG_ISETTING0_MP7_VAL14 0x0e
	#define TMCONFIG_ISETTING0_MP7_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING0_MP6_RW (0x0f << 24)
	#define TMCONFIG_ISETTING0_MP6_SHIFT 24
	#define TMCONFIG_ISETTING0_MP6_VAL0 0x00
	#define TMCONFIG_ISETTING0_MP6_VAL1 0x01
	#define TMCONFIG_ISETTING0_MP6_VAL2 0x02
	#define TMCONFIG_ISETTING0_MP6_VAL3 0x03
	#define TMCONFIG_ISETTING0_MP6_VAL4 0x04
	#define TMCONFIG_ISETTING0_MP6_VAL5 0x05
	#define TMCONFIG_ISETTING0_MP6_VAL6 0x06
	#define TMCONFIG_ISETTING0_MP6_VAL7 0x07
	#define TMCONFIG_ISETTING0_MP6_VAL8 0x08
	#define TMCONFIG_ISETTING0_MP6_VAL9 0x09
	#define TMCONFIG_ISETTING0_MP6_VAL10 0x0a
	#define TMCONFIG_ISETTING0_MP6_VAL11 0x0b
	#define TMCONFIG_ISETTING0_MP6_VAL12 0x0c
	#define TMCONFIG_ISETTING0_MP6_VAL13 0x0d
	#define TMCONFIG_ISETTING0_MP6_VAL14 0x0e
	#define TMCONFIG_ISETTING0_MP6_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING0_MP5_RW (0x0f << 20)
	#define TMCONFIG_ISETTING0_MP5_SHIFT 20
	#define TMCONFIG_ISETTING0_MP5_VAL0 0x00
	#define TMCONFIG_ISETTING0_MP5_VAL1 0x01
	#define TMCONFIG_ISETTING0_MP5_VAL2 0x02
	#define TMCONFIG_ISETTING0_MP5_VAL3 0x03
	#define TMCONFIG_ISETTING0_MP5_VAL4 0x04
	#define TMCONFIG_ISETTING0_MP5_VAL5 0x05
	#define TMCONFIG_ISETTING0_MP5_VAL6 0x06
	#define TMCONFIG_ISETTING0_MP5_VAL7 0x07
	#define TMCONFIG_ISETTING0_MP5_VAL8 0x08
	#define TMCONFIG_ISETTING0_MP5_VAL9 0x09
	#define TMCONFIG_ISETTING0_MP5_VAL10 0x0a
	#define TMCONFIG_ISETTING0_MP5_VAL11 0x0b
	#define TMCONFIG_ISETTING0_MP5_VAL12 0x0c
	#define TMCONFIG_ISETTING0_MP5_VAL13 0x0d
	#define TMCONFIG_ISETTING0_MP5_VAL14 0x0e
	#define TMCONFIG_ISETTING0_MP5_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING0_MP4_RW (0x0f << 16)
	#define TMCONFIG_ISETTING0_MP4_SHIFT 16
	#define TMCONFIG_ISETTING0_MP4_VAL0 0x00
	#define TMCONFIG_ISETTING0_MP4_VAL1 0x01
	#define TMCONFIG_ISETTING0_MP4_VAL2 0x02
	#define TMCONFIG_ISETTING0_MP4_VAL3 0x03
	#define TMCONFIG_ISETTING0_MP4_VAL4 0x04
	#define TMCONFIG_ISETTING0_MP4_VAL5 0x05
	#define TMCONFIG_ISETTING0_MP4_VAL6 0x06
	#define TMCONFIG_ISETTING0_MP4_VAL7 0x07
	#define TMCONFIG_ISETTING0_MP4_VAL8 0x08
	#define TMCONFIG_ISETTING0_MP4_VAL9 0x09
	#define TMCONFIG_ISETTING0_MP4_VAL10 0x0a
	#define TMCONFIG_ISETTING0_MP4_VAL11 0x0b
	#define TMCONFIG_ISETTING0_MP4_VAL12 0x0c
	#define TMCONFIG_ISETTING0_MP4_VAL13 0x0d
	#define TMCONFIG_ISETTING0_MP4_VAL14 0x0e
	#define TMCONFIG_ISETTING0_MP4_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING0_MP3_RW (0x0f << 12)
	#define TMCONFIG_ISETTING0_MP3_SHIFT 12
	#define TMCONFIG_ISETTING0_MP3_VAL0 0x00
	#define TMCONFIG_ISETTING0_MP3_VAL1 0x01
	#define TMCONFIG_ISETTING0_MP3_VAL2 0x02
	#define TMCONFIG_ISETTING0_MP3_VAL3 0x03
	#define TMCONFIG_ISETTING0_MP3_VAL4 0x04
	#define TMCONFIG_ISETTING0_MP3_VAL5 0x05
	#define TMCONFIG_ISETTING0_MP3_VAL6 0x06
	#define TMCONFIG_ISETTING0_MP3_VAL7 0x07
	#define TMCONFIG_ISETTING0_MP3_VAL8 0x08
	#define TMCONFIG_ISETTING0_MP3_VAL9 0x09
	#define TMCONFIG_ISETTING0_MP3_VAL10 0x0a
	#define TMCONFIG_ISETTING0_MP3_VAL11 0x0b
	#define TMCONFIG_ISETTING0_MP3_VAL12 0x0c
	#define TMCONFIG_ISETTING0_MP3_VAL13 0x0d
	#define TMCONFIG_ISETTING0_MP3_VAL14 0x0e
	#define TMCONFIG_ISETTING0_MP3_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING0_MP2_RW (0x0f << 8)
	#define TMCONFIG_ISETTING0_MP2_SHIFT 8
	#define TMCONFIG_ISETTING0_MP2_VAL0 0x00
	#define TMCONFIG_ISETTING0_MP2_VAL1 0x01
	#define TMCONFIG_ISETTING0_MP2_VAL2 0x02
	#define TMCONFIG_ISETTING0_MP2_VAL3 0x03
	#define TMCONFIG_ISETTING0_MP2_VAL4 0x04
	#define TMCONFIG_ISETTING0_MP2_VAL5 0x05
	#define TMCONFIG_ISETTING0_MP2_VAL6 0x06
	#define TMCONFIG_ISETTING0_MP2_VAL7 0x07
	#define TMCONFIG_ISETTING0_MP2_VAL8 0x08
	#define TMCONFIG_ISETTING0_MP2_VAL9 0x09
	#define TMCONFIG_ISETTING0_MP2_VAL10 0x0a
	#define TMCONFIG_ISETTING0_MP2_VAL11 0x0b
	#define TMCONFIG_ISETTING0_MP2_VAL12 0x0c
	#define TMCONFIG_ISETTING0_MP2_VAL13 0x0d
	#define TMCONFIG_ISETTING0_MP2_VAL14 0x0e
	#define TMCONFIG_ISETTING0_MP2_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING0_MP1_RW (0x0f << 4)
	#define TMCONFIG_ISETTING0_MP1_SHIFT 4
	#define TMCONFIG_ISETTING0_MP1_VAL0 0x00
	#define TMCONFIG_ISETTING0_MP1_VAL1 0x01
	#define TMCONFIG_ISETTING0_MP1_VAL2 0x02
	#define TMCONFIG_ISETTING0_MP1_VAL3 0x03
	#define TMCONFIG_ISETTING0_MP1_VAL4 0x04
	#define TMCONFIG_ISETTING0_MP1_VAL5 0x05
	#define TMCONFIG_ISETTING0_MP1_VAL6 0x06
	#define TMCONFIG_ISETTING0_MP1_VAL7 0x07
	#define TMCONFIG_ISETTING0_MP1_VAL8 0x08
	#define TMCONFIG_ISETTING0_MP1_VAL9 0x09
	#define TMCONFIG_ISETTING0_MP1_VAL10 0x0a
	#define TMCONFIG_ISETTING0_MP1_VAL11 0x0b
	#define TMCONFIG_ISETTING0_MP1_VAL12 0x0c
	#define TMCONFIG_ISETTING0_MP1_VAL13 0x0d
	#define TMCONFIG_ISETTING0_MP1_VAL14 0x0e
	#define TMCONFIG_ISETTING0_MP1_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING0_MP0_RW (0x0f << 0)
	#define TMCONFIG_ISETTING0_MP0_SHIFT 0
	#define TMCONFIG_ISETTING0_MP0_VAL0 0x00
	#define TMCONFIG_ISETTING0_MP0_VAL1 0x01
	#define TMCONFIG_ISETTING0_MP0_VAL2 0x02
	#define TMCONFIG_ISETTING0_MP0_VAL3 0x03
	#define TMCONFIG_ISETTING0_MP0_VAL4 0x04
	#define TMCONFIG_ISETTING0_MP0_VAL5 0x05
	#define TMCONFIG_ISETTING0_MP0_VAL6 0x06
	#define TMCONFIG_ISETTING0_MP0_VAL7 0x07
	#define TMCONFIG_ISETTING0_MP0_VAL8 0x08
	#define TMCONFIG_ISETTING0_MP0_VAL9 0x09
	#define TMCONFIG_ISETTING0_MP0_VAL10 0x0a
	#define TMCONFIG_ISETTING0_MP0_VAL11 0x0b
	#define TMCONFIG_ISETTING0_MP0_VAL12 0x0c
	#define TMCONFIG_ISETTING0_MP0_VAL13 0x0d
	#define TMCONFIG_ISETTING0_MP0_VAL14 0x0e
	#define TMCONFIG_ISETTING0_MP0_VAL15 0x0f
	/*
	* Interrupt vector (handler start address) for exceptions.
	*/
	#define TMCONFIG_ISETTING1_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x814)
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING1_MP7_RW (0x0f << 28)
	#define TMCONFIG_ISETTING1_MP7_SHIFT 28
	#define TMCONFIG_ISETTING1_MP7_VAL0 0x00
	#define TMCONFIG_ISETTING1_MP7_VAL1 0x01
	#define TMCONFIG_ISETTING1_MP7_VAL2 0x02
	#define TMCONFIG_ISETTING1_MP7_VAL3 0x03
	#define TMCONFIG_ISETTING1_MP7_VAL4 0x04
	#define TMCONFIG_ISETTING1_MP7_VAL5 0x05
	#define TMCONFIG_ISETTING1_MP7_VAL6 0x06
	#define TMCONFIG_ISETTING1_MP7_VAL7 0x07
	#define TMCONFIG_ISETTING1_MP7_VAL8 0x08
	#define TMCONFIG_ISETTING1_MP7_VAL9 0x09
	#define TMCONFIG_ISETTING1_MP7_VAL10 0x0a
	#define TMCONFIG_ISETTING1_MP7_VAL11 0x0b
	#define TMCONFIG_ISETTING1_MP7_VAL12 0x0c
	#define TMCONFIG_ISETTING1_MP7_VAL13 0x0d
	#define TMCONFIG_ISETTING1_MP7_VAL14 0x0e
	#define TMCONFIG_ISETTING1_MP7_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING1_MP6_RW (0x0f << 24)
	#define TMCONFIG_ISETTING1_MP6_SHIFT 24
	#define TMCONFIG_ISETTING1_MP6_VAL0 0x00
	#define TMCONFIG_ISETTING1_MP6_VAL1 0x01
	#define TMCONFIG_ISETTING1_MP6_VAL2 0x02
	#define TMCONFIG_ISETTING1_MP6_VAL3 0x03
	#define TMCONFIG_ISETTING1_MP6_VAL4 0x04
	#define TMCONFIG_ISETTING1_MP6_VAL5 0x05
	#define TMCONFIG_ISETTING1_MP6_VAL6 0x06
	#define TMCONFIG_ISETTING1_MP6_VAL7 0x07
	#define TMCONFIG_ISETTING1_MP6_VAL8 0x08
	#define TMCONFIG_ISETTING1_MP6_VAL9 0x09
	#define TMCONFIG_ISETTING1_MP6_VAL10 0x0a
	#define TMCONFIG_ISETTING1_MP6_VAL11 0x0b
	#define TMCONFIG_ISETTING1_MP6_VAL12 0x0c
	#define TMCONFIG_ISETTING1_MP6_VAL13 0x0d
	#define TMCONFIG_ISETTING1_MP6_VAL14 0x0e
	#define TMCONFIG_ISETTING1_MP6_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING1_MP5_RW (0x0f << 20)
	#define TMCONFIG_ISETTING1_MP5_SHIFT 20
	#define TMCONFIG_ISETTING1_MP5_VAL0 0x00
	#define TMCONFIG_ISETTING1_MP5_VAL1 0x01
	#define TMCONFIG_ISETTING1_MP5_VAL2 0x02
	#define TMCONFIG_ISETTING1_MP5_VAL3 0x03
	#define TMCONFIG_ISETTING1_MP5_VAL4 0x04
	#define TMCONFIG_ISETTING1_MP5_VAL5 0x05
	#define TMCONFIG_ISETTING1_MP5_VAL6 0x06
	#define TMCONFIG_ISETTING1_MP5_VAL7 0x07
	#define TMCONFIG_ISETTING1_MP5_VAL8 0x08
	#define TMCONFIG_ISETTING1_MP5_VAL9 0x09
	#define TMCONFIG_ISETTING1_MP5_VAL10 0x0a
	#define TMCONFIG_ISETTING1_MP5_VAL11 0x0b
	#define TMCONFIG_ISETTING1_MP5_VAL12 0x0c
	#define TMCONFIG_ISETTING1_MP5_VAL13 0x0d
	#define TMCONFIG_ISETTING1_MP5_VAL14 0x0e
	#define TMCONFIG_ISETTING1_MP5_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING1_MP4_RW (0x0f << 16)
	#define TMCONFIG_ISETTING1_MP4_SHIFT 16
	#define TMCONFIG_ISETTING1_MP4_VAL0 0x00
	#define TMCONFIG_ISETTING1_MP4_VAL1 0x01
	#define TMCONFIG_ISETTING1_MP4_VAL2 0x02
	#define TMCONFIG_ISETTING1_MP4_VAL3 0x03
	#define TMCONFIG_ISETTING1_MP4_VAL4 0x04
	#define TMCONFIG_ISETTING1_MP4_VAL5 0x05
	#define TMCONFIG_ISETTING1_MP4_VAL6 0x06
	#define TMCONFIG_ISETTING1_MP4_VAL7 0x07
	#define TMCONFIG_ISETTING1_MP4_VAL8 0x08
	#define TMCONFIG_ISETTING1_MP4_VAL9 0x09
	#define TMCONFIG_ISETTING1_MP4_VAL10 0x0a
	#define TMCONFIG_ISETTING1_MP4_VAL11 0x0b
	#define TMCONFIG_ISETTING1_MP4_VAL12 0x0c
	#define TMCONFIG_ISETTING1_MP4_VAL13 0x0d
	#define TMCONFIG_ISETTING1_MP4_VAL14 0x0e
	#define TMCONFIG_ISETTING1_MP4_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING1_MP3_RW (0x0f << 12)
	#define TMCONFIG_ISETTING1_MP3_SHIFT 12
	#define TMCONFIG_ISETTING1_MP3_VAL0 0x00
	#define TMCONFIG_ISETTING1_MP3_VAL1 0x01
	#define TMCONFIG_ISETTING1_MP3_VAL2 0x02
	#define TMCONFIG_ISETTING1_MP3_VAL3 0x03
	#define TMCONFIG_ISETTING1_MP3_VAL4 0x04
	#define TMCONFIG_ISETTING1_MP3_VAL5 0x05
	#define TMCONFIG_ISETTING1_MP3_VAL6 0x06
	#define TMCONFIG_ISETTING1_MP3_VAL7 0x07
	#define TMCONFIG_ISETTING1_MP3_VAL8 0x08
	#define TMCONFIG_ISETTING1_MP3_VAL9 0x09
	#define TMCONFIG_ISETTING1_MP3_VAL10 0x0a
	#define TMCONFIG_ISETTING1_MP3_VAL11 0x0b
	#define TMCONFIG_ISETTING1_MP3_VAL12 0x0c
	#define TMCONFIG_ISETTING1_MP3_VAL13 0x0d
	#define TMCONFIG_ISETTING1_MP3_VAL14 0x0e
	#define TMCONFIG_ISETTING1_MP3_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING1_MP2_RW (0x0f << 8)
	#define TMCONFIG_ISETTING1_MP2_SHIFT 8
	#define TMCONFIG_ISETTING1_MP2_VAL0 0x00
	#define TMCONFIG_ISETTING1_MP2_VAL1 0x01
	#define TMCONFIG_ISETTING1_MP2_VAL2 0x02
	#define TMCONFIG_ISETTING1_MP2_VAL3 0x03
	#define TMCONFIG_ISETTING1_MP2_VAL4 0x04
	#define TMCONFIG_ISETTING1_MP2_VAL5 0x05
	#define TMCONFIG_ISETTING1_MP2_VAL6 0x06
	#define TMCONFIG_ISETTING1_MP2_VAL7 0x07
	#define TMCONFIG_ISETTING1_MP2_VAL8 0x08
	#define TMCONFIG_ISETTING1_MP2_VAL9 0x09
	#define TMCONFIG_ISETTING1_MP2_VAL10 0x0a
	#define TMCONFIG_ISETTING1_MP2_VAL11 0x0b
	#define TMCONFIG_ISETTING1_MP2_VAL12 0x0c
	#define TMCONFIG_ISETTING1_MP2_VAL13 0x0d
	#define TMCONFIG_ISETTING1_MP2_VAL14 0x0e
	#define TMCONFIG_ISETTING1_MP2_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING1_MP1_RW (0x0f << 4)
	#define TMCONFIG_ISETTING1_MP1_SHIFT 4
	#define TMCONFIG_ISETTING1_MP1_VAL0 0x00
	#define TMCONFIG_ISETTING1_MP1_VAL1 0x01
	#define TMCONFIG_ISETTING1_MP1_VAL2 0x02
	#define TMCONFIG_ISETTING1_MP1_VAL3 0x03
	#define TMCONFIG_ISETTING1_MP1_VAL4 0x04
	#define TMCONFIG_ISETTING1_MP1_VAL5 0x05
	#define TMCONFIG_ISETTING1_MP1_VAL6 0x06
	#define TMCONFIG_ISETTING1_MP1_VAL7 0x07
	#define TMCONFIG_ISETTING1_MP1_VAL8 0x08
	#define TMCONFIG_ISETTING1_MP1_VAL9 0x09
	#define TMCONFIG_ISETTING1_MP1_VAL10 0x0a
	#define TMCONFIG_ISETTING1_MP1_VAL11 0x0b
	#define TMCONFIG_ISETTING1_MP1_VAL12 0x0c
	#define TMCONFIG_ISETTING1_MP1_VAL13 0x0d
	#define TMCONFIG_ISETTING1_MP1_VAL14 0x0e
	#define TMCONFIG_ISETTING1_MP1_VAL15 0x0f
	/*
	* Mode and priority fields
	*/
	#define TMCONFIG_ISETTING1_MP0_RW (0x0f << 0)
	#define TMCONFIG_ISETTING1_MP0_SHIFT 0
	#define TMCONFIG_ISETTING1_MP0_VAL0 0x00
	#define TMCONFIG_ISETTING1_MP0_VAL1 0x01
	#define TMCONFIG_ISETTING1_MP0_VAL2 0x02
	#define TMCONFIG_ISETTING1_MP0_VAL3 0x03
	#define TMCONFIG_ISETTING1_MP0_VAL4 0x04
	#define TMCONFIG_ISETTING1_MP0_VAL5 0x05
	#define TMCONFIG_ISETTING1_MP0_VAL6 0x06
	#define TMCONFIG_ISETTING1_MP0_VAL7 0x07
	#define TMCONFIG_ISETTING1_MP0_VAL8 0x08
	#define TMCONFIG_ISETTING1_MP0_VAL9 0x09
	#define TMCONFIG_ISETTING1_MP0_VAL10 0x0a
	#define TMCONFIG_ISETTING1_MP0_VAL11 0x0b
	#define TMCONFIG_ISETTING1_MP0_VAL12 0x0c
	#define TMCONFIG_ISETTING1_MP0_VAL13 0x0d
	#define TMCONFIG_ISETTING1_MP0_VAL14 0x0e
	#define TMCONFIG_ISETTING1_MP0_VAL15 0x0f
	/*
	* Interrupt pending status bits for interrupt sources 0-15.
	*/
	#define TMCONFIG_IPENDING_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x820)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_IPENDING_RESERVED1_RES (0x0ffff << 16)
	#define TMCONFIG_IPENDING_RESERVED1_SHIFT 16
	/*
	* Interrupt pending status bits
	*/
	#define TMCONFIG_IPENDING_IPENDING_RW (0x0ffff << 0)
	#define TMCONFIG_IPENDING_IPENDING_SHIFT 0
	/*
	* Interrupt clear bits for interrupt sources 0-15.
	*/
	#define TMCONFIG_ICLEAR_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x824)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_ICLEAR_RESERVED1_RES (0x0ffff << 16)
	#define TMCONFIG_ICLEAR_RESERVED1_SHIFT 16
	/*
	* Interrupt clear bits for interrupt sources 0-15
	*/
	#define TMCONFIG_ICLEAR_ICLEAR_RW (0x0ffff << 0)
	#define TMCONFIG_ICLEAR_ICLEAR_SHIFT 0
	/*
	* Interrupt mask bits for interrupt sources 0-15.
	*/
	#define TMCONFIG_IMASK_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x828)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_IMASK_RESERVED1_RES (0x0ffff << 16)
	#define TMCONFIG_IMASK_RESERVED1_SHIFT 16
	/*
	* Interrupt mask bits
	*/
	#define TMCONFIG_IMASK_IMASK_RW (0x0ffff << 0)
	#define TMCONFIG_IMASK_IMASK_SHIFT 0
	/*
	* Interrupt polarity bits for interrupt sources 0-15.
	*/
	#define TMCONFIG_IPOLARITY_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x82c)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_IPOLARITY_RESERVED1_RES (0x0ffff << 16)
	#define TMCONFIG_IPOLARITY_RESERVED1_SHIFT 16
	/*
	* Interrupt polarity bits
	*/
	#define TMCONFIG_IPOLARITY_IPOLARITY_RW (0x0ffff << 0)
	#define TMCONFIG_IPOLARITY_IPOLARITY_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 0.
	*/
	#define TMCONFIG_INTVEC0_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x880)
	/*
	* Interrupt vector (handler start address) for source 0.
	*/
	#define TMCONFIG_INTVEC0_INTVEC0_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC0_INTVEC0_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 1.
	*/
	#define TMCONFIG_INTVEC1_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x884)
	/*
	* Interrupt vector (handler start address) for source 1.
	*/
	#define TMCONFIG_INTVEC1_INTVEC1_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC1_INTVEC1_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 2.
	*/
	#define TMCONFIG_INTVEC2_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x888)
	/*
	* Interrupt vector (handler start address) for source 2.
	*/
	#define TMCONFIG_INTVEC2_INTVEC2_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC2_INTVEC2_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 3.
	*/
	#define TMCONFIG_INTVEC3_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x88c)
	/*
	* Interrupt vector (handler start address) for source 3.
	*/
	#define TMCONFIG_INTVEC3_INTVEC3_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC3_INTVEC3_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 4.
	*/
	#define TMCONFIG_INTVEC4_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x890)
	/*
	* Interrupt vector (handler start address) for source 4.
	*/
	#define TMCONFIG_INTVEC4_INTVEC4_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC4_INTVEC4_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 5.
	*/
	#define TMCONFIG_INTVEC5_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x894)
	/*
	* Interrupt vector (handler start address) for source 5.
	*/
	#define TMCONFIG_INTVEC5_INTVEC5_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC5_INTVEC5_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 6.
	*/
	#define TMCONFIG_INTVEC6_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x898)
	/*
	* Interrupt vector (handler start address) for source 6.
	*/
	#define TMCONFIG_INTVEC6_INTVEC6_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC6_INTVEC6_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 7.
	*/
	#define TMCONFIG_INTVEC7_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x89c)
	/*
	* Interrupt vector (handler start address) for source 7.
	*/
	#define TMCONFIG_INTVEC7_INTVEC7_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC7_INTVEC7_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 8.
	*/
	#define TMCONFIG_INTVEC8_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x8a0)
	/*
	* Interrupt vector (handler start address) for source 8.
	*/
	#define TMCONFIG_INTVEC8_INTVEC8_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC8_INTVEC8_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 9.
	*/
	#define TMCONFIG_INTVEC9_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x8a4)
	/*
	* Interrupt vector (handler start address) for source 9.
	*/
	#define TMCONFIG_INTVEC9_INTVEC9_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC9_INTVEC9_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 10.
	*/
	#define TMCONFIG_INTVEC10_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x8a8)
	/*
	* Interrupt vector (handler start address) for source 10.
	*/
	#define TMCONFIG_INTVEC10_INTVEC10_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC10_INTVEC10_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 11.
	*/
	#define TMCONFIG_INTVEC11_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x8ac)
	/*
	* Interrupt vector (handler start address) for source 11.
	*/
	#define TMCONFIG_INTVEC11_INTVEC11_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC11_INTVEC11_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 12.
	*/
	#define TMCONFIG_INTVEC12_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x8b0)
	/*
	* Interrupt vector (handler start address) for source 12.
	*/
	#define TMCONFIG_INTVEC12_INTVEC12_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC12_INTVEC12_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 13.
	*/
	#define TMCONFIG_INTVEC13_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x8b4)
	/*
	* Interrupt vector (handler start address) for source 13.
	*/
	#define TMCONFIG_INTVEC13_INTVEC13_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC13_INTVEC13_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 14.
	*/
	#define TMCONFIG_INTVEC14_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x8b8)
	/*
	* Interrupt vector (handler start address) for source 14.
	*/
	#define TMCONFIG_INTVEC14_INTVEC14_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC14_INTVEC14_SHIFT 0
	/*
	* Interrupt vector (handler start address) for source 15.
	*/
	#define TMCONFIG_INTVEC15_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x8bc)
	/*
	* Interrupt vector (handler start address) for source 15.
	*/
	#define TMCONFIG_INTVEC15_INTVEC15_RW (0x0ffffffff << 0)
	#define TMCONFIG_INTVEC15_INTVEC15_SHIFT 0
	/*
	* Contains: (maximum count value for system timer) + 1.
	*/
	#define TMCONFIG_SYSTIMER_TMODULUS_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc00)
	/*
	* Contains: (maximum count value for system timer) + 1.
	*/
	#define TMCONFIG_SYSTIMER_TMODULUS_SYSTIMER_TMODULUS_RW (0x0ffffffff << 0)
	#define TMCONFIG_SYSTIMER_TMODULUS_SYSTIMER_TMODULUS_SHIFT 0
	/*
	* Current value of system timer/counter.
	*/
	#define TMCONFIG_SYSTIMER_TVALUE_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc04)
	/*
	* Current value of system timer/counter.
	*/
	#define TMCONFIG_SYSTIMER_TVALUE_SYSTIMER_TVALUE_RW (0x0ffffffff << 0)
	#define TMCONFIG_SYSTIMER_TVALUE_SYSTIMER_TVALUE_SHIFT 0
	/*
	* System timer control (prescale value, source select, run bit).
	*/
	#define TMCONFIG_SYSTIMER_TCTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc08)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED3_RES (0x0fff << 20)
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED3_SHIFT 20
	/*
	* Prescale value
	*/
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_RW (0x0f << 16)
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_SHIFT 16
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL0 0x00
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL1 0x01
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL2 0x02
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL3 0x03
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL4 0x04
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL5 0x05
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL6 0x06
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL7 0x07
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL8 0x08
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL9 0x09
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL10 0x0a
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL11 0x0b
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL12 0x0c
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL13 0x0d
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL14 0x0e
	#define TMCONFIG_SYSTIMER_TCTL_PRESCALE_VAL15 0x0f
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_RES (0x0f << 12)
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_SHIFT 12
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL0 0x00
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL1 0x01
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL2 0x02
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL3 0x03
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL4 0x04
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL5 0x05
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL6 0x06
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL7 0x07
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL8 0x08
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL9 0x09
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL10 0x0a
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL11 0x0b
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL12 0x0c
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL13 0x0d
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL14 0x0e
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED4_VAL15 0x0f
	/*
	* Source select
	*/
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_RW (0x0f << 8)
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_SHIFT 8
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL0 0x00
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL1 0x01
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL2 0x02
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL3 0x03
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL4 0x04
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL5 0x05
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL6 0x06
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL7 0x07
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL8 0x08
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL9 0x09
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL10 0x0a
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL11 0x0b
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL12 0x0c
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL13 0x0d
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL14 0x0e
	#define TMCONFIG_SYSTIMER_TCTL_SOURCE_VAL15 0x0f
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED5_RES (0x07f << 1)
	#define TMCONFIG_SYSTIMER_TCTL_RESERVED5_SHIFT 1
	/*
	* Run the timer
	*/
	#define TMCONFIG_SYSTIMER_TCTL_RUN_RW (0x01 << 0)
	#define TMCONFIG_SYSTIMER_TCTL_RUN_SHIFT 0
	#define TMCONFIG_SYSTIMER_TCTL_RUN_VAL0 0x00
	#define TMCONFIG_SYSTIMER_TCTL_RUN_VAL1 0x01
	/*
	* Contains: (maximum count value for timer 1) + 1.
	*/
	#define TMCONFIG_TIMER1_TMODULUS_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc20)
	/*
	* Contains: (maximum count value for timer 1) + 1.
	*/
	#define TMCONFIG_TIMER1_TMODULUS_TIMER1_TMODULUS_RW (0x0ffffffff << 0)
	#define TMCONFIG_TIMER1_TMODULUS_TIMER1_TMODULUS_SHIFT 0
	/*
	* Current value of timer 1 counter.
	*/
	#define TMCONFIG_TIMER1_TVALUE_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc24)
	/*
	* Current value of timer 1 counter.
	*/
	#define TMCONFIG_TIMER1_TVALUE_TIMER1_TVALUE_RW (0x0ffffffff << 0)
	#define TMCONFIG_TIMER1_TVALUE_TIMER1_TVALUE_SHIFT 0
	/*
	* Timer 1 control (prescale value, source select, run bit).
	*/
	#define TMCONFIG_TIMER1_TCTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc28)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TIMER1_TCTL_RESERVED3_RES (0x0fff << 20)
	#define TMCONFIG_TIMER1_TCTL_RESERVED3_SHIFT 20
	/*
	* Prescale value
	*/
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_RW (0x0f << 16)
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_SHIFT 16
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL0 0x00
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL1 0x01
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL2 0x02
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL3 0x03
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL4 0x04
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL5 0x05
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL6 0x06
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL7 0x07
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL8 0x08
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL9 0x09
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL10 0x0a
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL11 0x0b
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL12 0x0c
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL13 0x0d
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL14 0x0e
	#define TMCONFIG_TIMER1_TCTL_PRESCALE_VAL15 0x0f
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_RES (0x0f << 12)
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_SHIFT 12
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL0 0x00
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL1 0x01
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL2 0x02
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL3 0x03
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL4 0x04
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL5 0x05
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL6 0x06
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL7 0x07
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL8 0x08
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL9 0x09
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL10 0x0a
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL11 0x0b
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL12 0x0c
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL13 0x0d
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL14 0x0e
	#define TMCONFIG_TIMER1_TCTL_RESERVED4_VAL15 0x0f
	/*
	* Source select
	*/
	#define TMCONFIG_TIMER1_TCTL_SOURCE_RW (0x0f << 8)
	#define TMCONFIG_TIMER1_TCTL_SOURCE_SHIFT 8
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL0 0x00
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL1 0x01
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL2 0x02
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL3 0x03
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL4 0x04
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL5 0x05
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL6 0x06
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL7 0x07
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL8 0x08
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL9 0x09
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL10 0x0a
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL11 0x0b
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL12 0x0c
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL13 0x0d
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL14 0x0e
	#define TMCONFIG_TIMER1_TCTL_SOURCE_VAL15 0x0f
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TIMER1_TCTL_RESERVED5_RES (0x07f << 1)
	#define TMCONFIG_TIMER1_TCTL_RESERVED5_SHIFT 1
	/*
	* Run the timer
	*/
	#define TMCONFIG_TIMER1_TCTL_RUN_RW (0x01 << 0)
	#define TMCONFIG_TIMER1_TCTL_RUN_SHIFT 0
	#define TMCONFIG_TIMER1_TCTL_RUN_VAL0 0x00
	#define TMCONFIG_TIMER1_TCTL_RUN_VAL1 0x01
	/*
	* Contains: (maximum count value for timer 2) + 1.
	*/
	#define TMCONFIG_TIMER2_TMODULUS_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc40)
	/*
	* Contains: (maximum count value for timer 2) + 1.
	*/
	#define TMCONFIG_TIMER2_TMODULUS_TIMER2_TMODULUS_RW (0x0ffffffff << 0)
	#define TMCONFIG_TIMER2_TMODULUS_TIMER2_TMODULUS_SHIFT 0
	/*
	* Current value of timer 2 counter.
	*/
	#define TMCONFIG_TIMER2_TVALUE_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc44)
	/*
	* Current value of timer 2 counter.
	*/
	#define TMCONFIG_TIMER2_TVALUE_TIMER2_TVALUE_RW (0x0ffffffff << 0)
	#define TMCONFIG_TIMER2_TVALUE_TIMER2_TVALUE_SHIFT 0
	/*
	* Timer 2 control (prescale value, source select, run bit).
	*/
	#define TMCONFIG_TIMER2_TCTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc48)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TIMER2_TCTL_RESERVED3_RES (0x0fff << 20)
	#define TMCONFIG_TIMER2_TCTL_RESERVED3_SHIFT 20
	/*
	* Prescale value
	*/
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_RW (0x0f << 16)
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_SHIFT 16
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL0 0x00
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL1 0x01
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL2 0x02
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL3 0x03
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL4 0x04
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL5 0x05
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL6 0x06
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL7 0x07
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL8 0x08
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL9 0x09
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL10 0x0a
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL11 0x0b
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL12 0x0c
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL13 0x0d
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL14 0x0e
	#define TMCONFIG_TIMER2_TCTL_PRESCALE_VAL15 0x0f
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_RES (0x0f << 12)
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_SHIFT 12
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL0 0x00
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL1 0x01
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL2 0x02
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL3 0x03
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL4 0x04
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL5 0x05
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL6 0x06
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL7 0x07
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL8 0x08
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL9 0x09
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL10 0x0a
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL11 0x0b
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL12 0x0c
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL13 0x0d
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL14 0x0e
	#define TMCONFIG_TIMER2_TCTL_RESERVED4_VAL15 0x0f
	/*
	* Source select
	*/
	#define TMCONFIG_TIMER2_TCTL_SOURCE_RW (0x0f << 8)
	#define TMCONFIG_TIMER2_TCTL_SOURCE_SHIFT 8
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL0 0x00
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL1 0x01
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL2 0x02
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL3 0x03
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL4 0x04
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL5 0x05
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL6 0x06
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL7 0x07
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL8 0x08
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL9 0x09
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL10 0x0a
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL11 0x0b
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL12 0x0c
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL13 0x0d
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL14 0x0e
	#define TMCONFIG_TIMER2_TCTL_SOURCE_VAL15 0x0f
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TIMER2_TCTL_RESERVED5_RES (0x07f << 1)
	#define TMCONFIG_TIMER2_TCTL_RESERVED5_SHIFT 1
	/*
	* Run the timer
	*/
	#define TMCONFIG_TIMER2_TCTL_RUN_RW (0x01 << 0)
	#define TMCONFIG_TIMER2_TCTL_RUN_SHIFT 0
	#define TMCONFIG_TIMER2_TCTL_RUN_VAL0 0x00
	#define TMCONFIG_TIMER2_TCTL_RUN_VAL1 0x01
	/*
	* Contains: (maximum count value for timer 3) + 1.
	*/
	#define TMCONFIG_TIMER3_TMODULUS_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc60)
	/*
	* Contains: (maximum count value for timer 3) + 1.
	*/
	#define TMCONFIG_TIMER3_TMODULUS_TIMER3_TMODULUS_RW (0x0ffffffff << 0)
	#define TMCONFIG_TIMER3_TMODULUS_TIMER3_TMODULUS_SHIFT 0
	/*
	* Current value of timer 3 counter.
	*/
	#define TMCONFIG_TIMER3_TVALUE_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc64)
	/*
	* Current value of timer 3 counter.
	*/
	#define TMCONFIG_TIMER3_TVALUE_TIMER3_TVALUE_RW (0x0ffffffff << 0)
	#define TMCONFIG_TIMER3_TVALUE_TIMER3_TVALUE_SHIFT 0
	/*
	* Timer 3 control (prescale value, source select, run bit).
	*/
	#define TMCONFIG_TIMER3_TCTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xc68)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TIMER3_TCTL_RESERVED3_RES (0x0fff << 20)
	#define TMCONFIG_TIMER3_TCTL_RESERVED3_SHIFT 20
	/*
	* Prescale value
	*/
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_RW (0x0f << 16)
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_SHIFT 16
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL0 0x00
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL1 0x01
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL2 0x02
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL3 0x03
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL4 0x04
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL5 0x05
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL6 0x06
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL7 0x07
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL8 0x08
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL9 0x09
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL10 0x0a
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL11 0x0b
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL12 0x0c
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL13 0x0d
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL14 0x0e
	#define TMCONFIG_TIMER3_TCTL_PRESCALE_VAL15 0x0f
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_RES (0x0f << 12)
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_SHIFT 12
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL0 0x00
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL1 0x01
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL2 0x02
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL3 0x03
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL4 0x04
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL5 0x05
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL6 0x06
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL7 0x07
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL8 0x08
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL9 0x09
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL10 0x0a
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL11 0x0b
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL12 0x0c
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL13 0x0d
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL14 0x0e
	#define TMCONFIG_TIMER3_TCTL_RESERVED4_VAL15 0x0f
	/*
	* Source select
	*/
	#define TMCONFIG_TIMER3_TCTL_SOURCE_RW (0x0f << 8)
	#define TMCONFIG_TIMER3_TCTL_SOURCE_SHIFT 8
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL0 0x00
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL1 0x01
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL2 0x02
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL3 0x03
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL4 0x04
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL5 0x05
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL6 0x06
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL7 0x07
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL8 0x08
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL9 0x09
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL10 0x0a
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL11 0x0b
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL12 0x0c
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL13 0x0d
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL14 0x0e
	#define TMCONFIG_TIMER3_TCTL_SOURCE_VAL15 0x0f
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_TIMER3_TCTL_RESERVED5_RES (0x07f << 1)
	#define TMCONFIG_TIMER3_TCTL_RESERVED5_SHIFT 1
	/*
	* Run the timer
	*/
	#define TMCONFIG_TIMER3_TCTL_RUN_RW (0x01 << 0)
	#define TMCONFIG_TIMER3_TCTL_RUN_SHIFT 0
	#define TMCONFIG_TIMER3_TCTL_RUN_VAL0 0x00
	#define TMCONFIG_TIMER3_TCTL_RUN_VAL1 0x01
	/*
	* TMConfig module ID.
	*/
	#define TMCONFIG_TM32_MODULE_ID_REG(n)  (TMCONFIG_BASE_UNIT##n + 0xffc)
	/*
	* Designates TMConfig
	*/
	#define TMCONFIG_TM32_MODULE_ID_MOD_R (0x0ffff << 16)
	#define TMCONFIG_TM32_MODULE_ID_MOD_SHIFT 16
	/*
	* Major Revision
	*/
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_R (0x0f << 12)
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_SHIFT 12
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL0 0x00
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL1 0x01
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL2 0x02
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL3 0x03
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL4 0x04
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL5 0x05
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL6 0x06
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL7 0x07
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL8 0x08
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL9 0x09
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL10 0x0a
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL11 0x0b
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL12 0x0c
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL13 0x0d
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL14 0x0e
	#define TMCONFIG_TM32_MODULE_ID_MAJOR_REV_VAL15 0x0f
	/*
	* Minor Revision
	*/
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_R (0x0f << 8)
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_SHIFT 8
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL0 0x00
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL1 0x01
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL2 0x02
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL3 0x03
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL4 0x04
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL5 0x05
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL6 0x06
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL7 0x07
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL8 0x08
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL9 0x09
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL10 0x0a
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL11 0x0b
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL12 0x0c
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL13 0x0d
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL14 0x0e
	#define TMCONFIG_TM32_MODULE_ID_MINOR_REV_VAL15 0x0f
	/*
	* Aperture Size
	*/
	#define TMCONFIG_TM32_MODULE_ID_SIZE_R (0x0ff << 0)
	#define TMCONFIG_TM32_MODULE_ID_SIZE_SHIFT 0
	/*
	* Instruction breakpoint control.
	*/
	#define TMCONFIG_BICTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x1000)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_BICTL_RESERVED2_RES (0x07fffff << 9)
	#define TMCONFIG_BICTL_RESERVED2_SHIFT 9
	/*
	* Instruction address control
	*/
	#define TMCONFIG_BICTL_IAC_RW (0x01 << 8)
	#define TMCONFIG_BICTL_IAC_SHIFT 8
	#define TMCONFIG_BICTL_IAC_VAL0 0x00
	#define TMCONFIG_BICTL_IAC_VAL1 0x01
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_BICTL_RESERVED3_RES (0x07f << 1)
	#define TMCONFIG_BICTL_RESERVED3_SHIFT 1
	/*
	* Instruction control bit
	*/
	#define TMCONFIG_BICTL_IC_RW (0x01 << 0)
	#define TMCONFIG_BICTL_IC_SHIFT 0
	#define TMCONFIG_BICTL_IC_VAL0 0x00
	#define TMCONFIG_BICTL_IC_VAL1 0x01
	/*
	* Start of address range that causes instruction breakpoints.
	*/
	#define TMCONFIG_BINSTLOW_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x1004)
	/*
	* Start of address range that causes instruction breakpoints.
	*/
	#define TMCONFIG_BINSTLOW_BINSTLOW_RW (0x0ffffffff << 0)
	#define TMCONFIG_BINSTLOW_BINSTLOW_SHIFT 0
	/*
	* End of address range that causes instruction breakpoints.
	*/
	#define TMCONFIG_BINSTHIGH_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x1008)
	/*
	* End of address range that causes instruction breakpoints.
	*/
	#define TMCONFIG_BINSTHIGH_BINSTHIGH_RW (0x0ffffffff << 0)
	#define TMCONFIG_BINSTHIGH_BINSTHIGH_SHIFT 0
	/*
	* Data breakpoint control.
	*/
	#define TMCONFIG_BDCTL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x1020)
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_BDCTL_RESERVED5_RES (0x07fff << 17)
	#define TMCONFIG_BDCTL_RESERVED5_SHIFT 17
	/*
	* Data Value Control
	*/
	#define TMCONFIG_BDCTL_DVC_RW (0x01 << 16)
	#define TMCONFIG_BDCTL_DVC_SHIFT 16
	#define TMCONFIG_BDCTL_DVC_VAL0 0x00
	#define TMCONFIG_BDCTL_DVC_VAL1 0x01
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_BDCTL_RESERVED6_RES (0x07f << 9)
	#define TMCONFIG_BDCTL_RESERVED6_SHIFT 9
	/*
	* Data Address Control
	*/
	#define TMCONFIG_BDCTL_DAC_RW (0x01 << 8)
	#define TMCONFIG_BDCTL_DAC_SHIFT 8
	#define TMCONFIG_BDCTL_DAC_VAL0 0x00
	#define TMCONFIG_BDCTL_DAC_VAL1 0x01
	/*
	* Automatically generated bitfield for padding
	*/
	#define TMCONFIG_BDCTL_RESERVED7_RES (0x0f << 4)
	#define TMCONFIG_BDCTL_RESERVED7_SHIFT 4
	#define TMCONFIG_BDCTL_RESERVED7_VAL0 0x00
	#define TMCONFIG_BDCTL_RESERVED7_VAL1 0x01
	#define TMCONFIG_BDCTL_RESERVED7_VAL2 0x02
	#define TMCONFIG_BDCTL_RESERVED7_VAL3 0x03
	#define TMCONFIG_BDCTL_RESERVED7_VAL4 0x04
	#define TMCONFIG_BDCTL_RESERVED7_VAL5 0x05
	#define TMCONFIG_BDCTL_RESERVED7_VAL6 0x06
	#define TMCONFIG_BDCTL_RESERVED7_VAL7 0x07
	#define TMCONFIG_BDCTL_RESERVED7_VAL8 0x08
	#define TMCONFIG_BDCTL_RESERVED7_VAL9 0x09
	#define TMCONFIG_BDCTL_RESERVED7_VAL10 0x0a
	#define TMCONFIG_BDCTL_RESERVED7_VAL11 0x0b
	#define TMCONFIG_BDCTL_RESERVED7_VAL12 0x0c
	#define TMCONFIG_BDCTL_RESERVED7_VAL13 0x0d
	#define TMCONFIG_BDCTL_RESERVED7_VAL14 0x0e
	#define TMCONFIG_BDCTL_RESERVED7_VAL15 0x0f
	/*
	* Break on store
	*/
	#define TMCONFIG_BDCTL_BS_RW (0x01 << 3)
	#define TMCONFIG_BDCTL_BS_SHIFT 3
	#define TMCONFIG_BDCTL_BS_VAL0 0x00
	#define TMCONFIG_BDCTL_BS_VAL1 0x01
	/*
	* Break on load
	*/
	#define TMCONFIG_BDCTL_BL_RW (0x01 << 2)
	#define TMCONFIG_BDCTL_BL_SHIFT 2
	#define TMCONFIG_BDCTL_BL_VAL0 0x00
	#define TMCONFIG_BDCTL_BL_VAL1 0x01
	/*
	* Data Control
	*/
	#define TMCONFIG_BDCTL_DC_RW (0x03 << 0)
	#define TMCONFIG_BDCTL_DC_SHIFT 0
	#define TMCONFIG_BDCTL_DC_VAL0 0x00
	#define TMCONFIG_BDCTL_DC_VAL1 0x01
	#define TMCONFIG_BDCTL_DC_VAL2 0x02
	#define TMCONFIG_BDCTL_DC_VAL3 0x03
	/*
	* Start of address range that causes data breakpoints.
	*/
	#define TMCONFIG_BDATAALOW_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x1030)
	/*
	* Start of address range that causes data breakpoints.
	*/
	#define TMCONFIG_BDATAALOW_BDATAALOW_RW (0x0ffffffff << 0)
	#define TMCONFIG_BDATAALOW_BDATAALOW_SHIFT 0
	/*
	* End of address range that causes data breakpoints.
	*/
	#define TMCONFIG_BDATAAHIGH_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x1034)
	/*
	* End of address range that causes data breakpoints.
	*/
	#define TMCONFIG_BDATAAHIGH_BDATAAHIGH_RW (0x0ffffffff << 0)
	#define TMCONFIG_BDATAAHIGH_BDATAAHIGH_SHIFT 0
	/*
	* Comparison value for data breakpoints.
	*/
	#define TMCONFIG_BDATAVAL_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x1038)
	/*
	* Comparison value for data breakpoints.
	*/
	#define TMCONFIG_BDATAVAL_BDATAVAL_RW (0x0ffffffff << 0)
	#define TMCONFIG_BDATAVAL_BDATAVAL_SHIFT 0
	/*
	* Mask for data breakpoint comparison value.
	*/
	#define TMCONFIG_BDATAMASK_REG(n)  (TMCONFIG_BASE_UNIT##n + 0x103c)
	/*
	* Mask for data breakpoint comparison value.
	*/
	#define TMCONFIG_BDATAMASK_BDATAMASK_RW (0x0ffffffff << 0)
	#define TMCONFIG_BDATAMASK_BDATAMASK_SHIFT 0

#endif // PHMODIPTMCONFIG_H
