 ///////////////////////////////////////////////////////////////////// 
//                                                                  / 
// (c) NXP B.V 2009                                                / 
//                                                                  / 
// All rights are reserved. Reproduction in whole or in part is     / 
// prohibited without the prior written consent of the copy-right   / 
// owner.                                                           / 
// The information presented in this document does not form part of / 
// any quotation or contract, is believed to be accurate and        / 
// reliable and may be changed without notice. No liability will be / 
// accepted by the publisher for any consequence of its use.        / 
// Publication thereof does not convey nor imply any license under  / 
// patent- or other industrial or intellectual property rights.     / 
 ///////////////////////////////////////////////////////////////////// 
 
/*! 
 *  @brief Header file for 
dvispdo *  @file phmodIpDvispdo.h *
 *  <pre>
 *  $Author: gargn $
 *  $Revision: 99754 $
 *  $Date: 2009-06-25 17:40:42 -0500 (Thu, 25 Jun 2009) $
 *
 *  Revision history
 *  $Log: $
 *  
 *
 *  $KeysEnd$
 *  </pre>
 *
 */ 


#ifndef PHMODIPDVISPDO_H
#define PHMODIPDVISPDO_H
	
	
	/*
	* SPDIF Out Status
	*/
	#define DVISPDO_SPDO_STATUS_REG  (DVISPDO_BASE + 0x0)
	#define DVISPDO_SPDO_STATUS_RESERVED_R (0x01ffffff << 6)
	#define DVISPDO_SPDO_STATUS_RESERVED_SHIFT 6
	/*
	* This flag gets set when a IEC60958 block is sent. It is used in combination with
	*  the interupt controlled via BLOCK_SENT_INTEN;in case continuoulsy changing user
	*  data; channel status information has to be fed to the SPDO.
	*/
	#define DVISPDO_SPDO_STATUS_BLOCK_SENT_R (0x01 << 5)
	#define DVISPDO_SPDO_STATUS_BLOCK_SENT_SHIFT 5
	#define DVISPDO_SPDO_STATUS_BLOCK_SENT_VAL0 0x00
	#define DVISPDO_SPDO_STATUS_BLOCK_SENT_VAL1 0x01
	/*
	* This flag gets set if the hardware is currently emitting DMA buffer 1 data; and 
	* is negated when emitting DMA buffer 2 data.
	*/
	#define DVISPDO_SPDO_STATUS_BUF1_ACTIVE_R (0x01 << 4)
	#define DVISPDO_SPDO_STATUS_BUF1_ACTIVE_SHIFT 4
	#define DVISPDO_SPDO_STATUS_BUF1_ACTIVE_VAL0 0x00
	#define DVISPDO_SPDO_STATUS_BUF1_ACTIVE_VAL1 0x01
	/*
	* This flag gets set if both DMA buffers were emptied before a new full buffer was
	*  assigned by software. The hardware has performed a normal buffer switch over an
	* d is emitting old data. It can only be cleared by software write to ACK_UDR.
	*/
	#define DVISPDO_SPDO_STATUS_UNDERRUN_R (0x01 << 3)
	#define DVISPDO_SPDO_STATUS_UNDERRUN_SHIFT 3
	#define DVISPDO_SPDO_STATUS_UNDERRUN_VAL0 0x00
	#define DVISPDO_SPDO_STATUS_UNDERRUN_VAL1 0x01
	/*
	* Bandwidth Error. This flag gets set if the internal buffers in SPDO were emptied
	*  before new memory data was brought in. This flag can be cleared only by a softw
	* are write to ACK_HBE.
	*/
	#define DVISPDO_SPDO_STATUS_HBE_R (0x01 << 2)
	#define DVISPDO_SPDO_STATUS_HBE_SHIFT 2
	#define DVISPDO_SPDO_STATUS_HBE_VAL0 0x00
	#define DVISPDO_SPDO_STATUS_HBE_VAL1 0x01
	/*
	* This flag gets set if DMA buffer 2 has been emptied by the SPDO hardware. The fl
	* ag can be cleared only by a software write to ACK_BUF2.
	*/
	#define DVISPDO_SPDO_STATUS_BUF2_EMPTY_R (0x01 << 1)
	#define DVISPDO_SPDO_STATUS_BUF2_EMPTY_SHIFT 1
	#define DVISPDO_SPDO_STATUS_BUF2_EMPTY_VAL0 0x00
	#define DVISPDO_SPDO_STATUS_BUF2_EMPTY_VAL1 0x01
	/*
	* This flag gets set if DMA buffer 1 has been emptied by the SPDO hardware. The fl
	* ag can be cleared only by a software write to ACK_BUF1.
	*/
	#define DVISPDO_SPDO_STATUS_BUF1_EMPTY_R (0x01 << 0)
	#define DVISPDO_SPDO_STATUS_BUF1_EMPTY_SHIFT 0
	#define DVISPDO_SPDO_STATUS_BUF1_EMPTY_VAL0 0x00
	#define DVISPDO_SPDO_STATUS_BUF1_EMPTY_VAL1 0x01
	/*
	* SPDIF Out general control register
	*/
	#define DVISPDO_SPDO_CTL_REG  (DVISPDO_BASE + 0x4)
	/*
	* 1 =Software Reset. Immediately resets the SPDO block. This should be used with e
	* xtreme caution. Any ongoing transmission will be interrupted; and receivers may 
	* be left in a strange state.
	*/
	#define DVISPDO_SPDO_CTL_RESET_W (0x01 << 31)
	#define DVISPDO_SPDO_CTL_RESET_SHIFT 31
	#define DVISPDO_SPDO_CTL_RESET_VAL0 0x00
	#define DVISPDO_SPDO_CTL_RESET_VAL1 0x01
	/*
	* 1 =Enables transmission as per the selected mode. In IEC-60958 mode; with PACK_M
	* ODE being 01 or 10; the sample at address BASE1 is transmitted with a B-preamble
	* ;0 =Transmission Disabled. Stops any ongoing transmission after completing any a
	* ctions related to the current data descriptor word.
	*/
	#define DVISPDO_SPDO_CTL_TRANS_ENABLE_RW (0x01 << 30)
	#define DVISPDO_SPDO_CTL_TRANS_ENABLE_SHIFT 30
	#define DVISPDO_SPDO_CTL_TRANS_ENABLE_VAL0 0x00
	#define DVISPDO_SPDO_CTL_TRANS_ENABLE_VAL1 0x01
	/*
	* Transmission mode. Other codes are reserved for future extensions. Note: The tra
	* nsmission mode should only be changed while transmission is disabled.
	*/
	#define DVISPDO_SPDO_CTL_TRANS_MODE_RW (0x03 << 27)
	#define DVISPDO_SPDO_CTL_TRANS_MODE_SHIFT 27
	#define DVISPDO_SPDO_CTL_TRANS_MODE_VAL0 0x00
	#define DVISPDO_SPDO_CTL_TRANS_MODE_VAL1 0x01
	#define DVISPDO_SPDO_CTL_TRANS_MODE_VAL2 0x02
	#define DVISPDO_SPDO_CTL_TRANS_MODE_VAL3 0x03
	#define DVISPDO_SPDO_CTL_RESERVED_RW (0x03fff << 12)
	#define DVISPDO_SPDO_CTL_RESERVED_SHIFT 12
	/*
	* Byte swap control; allows to adjust to the endianess mode under software control
	* ;1 = swap lsbyte and msbyte inside a 16bit word;0 = no swap
	*/
	#define DVISPDO_SPDO_CTL_FORMAT_ENDIAN_R (0x01 << 11)
	#define DVISPDO_SPDO_CTL_FORMAT_ENDIAN_SHIFT 11
	#define DVISPDO_SPDO_CTL_FORMAT_ENDIAN_VAL0 0x00
	#define DVISPDO_SPDO_CTL_FORMAT_ENDIAN_VAL1 0x01
	/*
	* Memory format selection for IEC60958 16bit packing mode; left/right samples can 
	* be swapped inside a 32 bit memory word;0 = ; LEFT[15:0]; RIGHT[15:0] ; (default)
	* ;1 = ; RIGHT[15:0]; LEFT[15:0] ;Memory
	*/
	#define DVISPDO_SPDO_CTL_LR_FORMAT_MODE_RW (0x01 << 10)
	#define DVISPDO_SPDO_CTL_LR_FORMAT_MODE_SHIFT 10
	#define DVISPDO_SPDO_CTL_LR_FORMAT_MODE_VAL0 0x00
	#define DVISPDO_SPDO_CTL_LR_FORMAT_MODE_VAL1 0x01
	#define DVISPDO_SPDO_CTL_ACK_BLOCK_SENT_W (0x01 << 9)
	#define DVISPDO_SPDO_CTL_ACK_BLOCK_SENT_SHIFT 9
	#define DVISPDO_SPDO_CTL_ACK_BLOCK_SENT_VAL0 0x00
	#define DVISPDO_SPDO_CTL_ACK_BLOCK_SENT_VAL1 0x01
	/*
	* If BLOCK_SENT_INTEN = 1 and BLOCK_SENT = 1; an interrupt is asserted to the chip
	*  level interrupt controller.
	*/
	#define DVISPDO_SPDO_CTL_BLOCK_SENT_INTEN_R (0x01 << 8)
	#define DVISPDO_SPDO_CTL_BLOCK_SENT_INTEN_SHIFT 8
	#define DVISPDO_SPDO_CTL_BLOCK_SENT_INTEN_VAL0 0x00
	#define DVISPDO_SPDO_CTL_BLOCK_SENT_INTEN_VAL1 0x01
	/*
	* If UDR_INTEN = 1 and UNDERRUN = 1; an interrupt is asserted to the chip level in
	* terrupt controller.
	*/
	#define DVISPDO_SPDO_CTL_UDR_INTEN_RW (0x01 << 7)
	#define DVISPDO_SPDO_CTL_UDR_INTEN_SHIFT 7
	#define DVISPDO_SPDO_CTL_UDR_INTEN_VAL0 0x00
	#define DVISPDO_SPDO_CTL_UDR_INTEN_VAL1 0x01
	/*
	* If HBE_INTEN = 1 and HBE = 1; an interrupt is asserted to the chip level interru
	* pt controller.
	*/
	#define DVISPDO_SPDO_CTL_HBE_INTEN_RW (0x01 << 6)
	#define DVISPDO_SPDO_CTL_HBE_INTEN_SHIFT 6
	#define DVISPDO_SPDO_CTL_HBE_INTEN_VAL0 0x00
	#define DVISPDO_SPDO_CTL_HBE_INTEN_VAL1 0x01
	/*
	* If BUF2_INTEN = 1 and BUF2_EMPTY = 1; an interrupt is asserted to the chip level
	*  interrupt controller.
	*/
	#define DVISPDO_SPDO_CTL_BUF2_INTEN_RW (0x01 << 5)
	#define DVISPDO_SPDO_CTL_BUF2_INTEN_SHIFT 5
	#define DVISPDO_SPDO_CTL_BUF2_INTEN_VAL0 0x00
	#define DVISPDO_SPDO_CTL_BUF2_INTEN_VAL1 0x01
	/*
	* If BUF1_INTEN = 1 and BUF1_EMPTY = 1; an interrupt is asserted to the chip level
	*  interrupt controller.
	*/
	#define DVISPDO_SPDO_CTL_BUF1_INTEN_RW (0x01 << 4)
	#define DVISPDO_SPDO_CTL_BUF1_INTEN_SHIFT 4
	#define DVISPDO_SPDO_CTL_BUF1_INTEN_VAL0 0x00
	#define DVISPDO_SPDO_CTL_BUF1_INTEN_VAL1 0x01
	/*
	* 1= Clear UNDERRUN. ;0=No effect. Always reads as 0.
	*/
	#define DVISPDO_SPDO_CTL_ACK_UDR_W (0x01 << 3)
	#define DVISPDO_SPDO_CTL_ACK_UDR_SHIFT 3
	#define DVISPDO_SPDO_CTL_ACK_UDR_VAL0 0x00
	#define DVISPDO_SPDO_CTL_ACK_UDR_VAL1 0x01
	/*
	* 1= Clear HBE. ;0= No effect.Always reads as 0
	*/
	#define DVISPDO_SPDO_CTL_ACK_HBE_W (0x01 << 2)
	#define DVISPDO_SPDO_CTL_ACK_HBE_SHIFT 2
	#define DVISPDO_SPDO_CTL_ACK_HBE_VAL0 0x00
	#define DVISPDO_SPDO_CTL_ACK_HBE_VAL1 0x01
	#define DVISPDO_SPDO_CTL_ACK_BUF2_W (0x01 << 1)
	#define DVISPDO_SPDO_CTL_ACK_BUF2_SHIFT 1
	#define DVISPDO_SPDO_CTL_ACK_BUF2_VAL0 0x00
	#define DVISPDO_SPDO_CTL_ACK_BUF2_VAL1 0x01
	/*
	* 1= Clear BUF1_EMPTY. Informs SPDO that DMA buffer 1 is ;0= No effect. Always rea
	* ds as 0
	*/
	#define DVISPDO_SPDO_CTL_ACK_BUF1_W (0x01 << 0)
	#define DVISPDO_SPDO_CTL_ACK_BUF1_SHIFT 0
	#define DVISPDO_SPDO_CTL_ACK_BUF1_VAL0 0x00
	#define DVISPDO_SPDO_CTL_ACK_BUF1_VAL1 0x01
	/*
	* Base address of buffer1
	*/
	#define DVISPDO_SPDO_BASE1_REG  (DVISPDO_BASE + 0xc)
	/*
	* Contains the memory address of DMA buffer 1.
	*/
	#define DVISPDO_SPDO_BASE1_SPDO_BASE1_RW (0x01ffffff << 6)
	#define DVISPDO_SPDO_BASE1_SPDO_BASE1_SHIFT 6
	/*
	* Always reads as 0.
	*/
	#define DVISPDO_SPDO_BASE1_RESERVED_R (0x03f << 0)
	#define DVISPDO_SPDO_BASE1_RESERVED_SHIFT 0
	/*
	* Base address of buffer2
	*/
	#define DVISPDO_SPDO_BASE2_REG  (DVISPDO_BASE + 0x10)
	/*
	* Contains the memory address of DMA buffer 2.
	*/
	#define DVISPDO_SPDO_BASE2_SPDO_BASE2_RW (0x01ffffff << 6)
	#define DVISPDO_SPDO_BASE2_SPDO_BASE2_SHIFT 6
	/*
	* Always reads as 0.
	*/
	#define DVISPDO_SPDO_BASE2_RESERVED_R (0x03f << 0)
	#define DVISPDO_SPDO_BASE2_RESERVED_SHIFT 0
	/*
	* Size of the buffers
	*/
	#define DVISPDO_SPDO_SIZE_REG  (DVISPDO_BASE + 0x14)
	/*
	* Determines the size; in bytes; of both DMA buffers
	*/
	#define DVISPDO_SPDO_SIZE_SPDO_SIZE_RW (0x01ffffff << 6)
	#define DVISPDO_SPDO_SIZE_SPDO_SIZE_SHIFT 6
	/*
	* Always reads as 0.
	*/
	#define DVISPDO_SPDO_SIZE_RESERVED_R (0x03f << 0)
	#define DVISPDO_SPDO_SIZE_RESERVED_SHIFT 0
	/*
	* Channel status bits for frames 0 to 31;The bits are sent out imsb first n sub-se
	* quent IEC60958 sub-frames with msb first (bit 31 in a sub-frame with B-preamble)
	* 
	*/
	#define DVISPDO_CBITS0_REG  (DVISPDO_BASE + 0x18)
	/*
	* Channel status bits for frames 0 to 31 .;The bits are sent out imsb first n sub-
	* sequent IEC60958 sub-frames;with msb first (bit 31 in a sub-frame with B-preambl
	* e)
	*/
	#define DVISPDO_CBITS0_CBITS_RW (0x07fffffff << 0)
	#define DVISPDO_CBITS0_CBITS_SHIFT 0
	/*
	* Channel status bits for frames 32 to 63;The bits are sent out imsb first in sub-
	* sequent IEC60958 subframes.
	*/
	#define DVISPDO_CBITS1_REG  (DVISPDO_BASE + 0x1c)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_CBITS1_CBITS_RW (0x07fffffff << 0)
	#define DVISPDO_CBITS1_CBITS_SHIFT 0
	/*
	* Channel status bits for frames 64 to 95;The bits are sent out imsb first in sub-
	* sequent IEC60958 subframes.
	*/
	#define DVISPDO_CBITS2_REG  (DVISPDO_BASE + 0x20)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_CBITS2_CBITS_RW (0x07fffffff << 0)
	#define DVISPDO_CBITS2_CBITS_SHIFT 0
	/*
	* Channel status bits for frames 96 to 127;The bits are sent out imsb first in sub
	* -sequent IEC60958 subframes.
	*/
	#define DVISPDO_CBITS3_REG  (DVISPDO_BASE + 0x24)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_CBITS3_CBITS_RW (0x07fffffff << 0)
	#define DVISPDO_CBITS3_CBITS_SHIFT 0
	/*
	* Channel status bits for frames 128 to 159;The bits are sent out imsb first in su
	* b-sequent IEC60958 subframes.
	*/
	#define DVISPDO_CBITS4_REG  (DVISPDO_BASE + 0x28)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_CBITS4_CBITS_RW (0x07fffffff << 0)
	#define DVISPDO_CBITS4_CBITS_SHIFT 0
	/*
	* Channel status bits for frames 160 to 191;The bits are sent out imsb first in su
	* b-sequent IEC60958 subframes.
	*/
	#define DVISPDO_CBITS5_REG  (DVISPDO_BASE + 0x2c)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_CBITS5_CBITS_RW (0x07fffffff << 0)
	#define DVISPDO_CBITS5_CBITS_SHIFT 0
	/*
	* User bits for frames 0 to 15;The bits are sent out imsb first n sub-sequent IEC6
	* 0958 sub-frames with msb first (bit 31 in a sub-frame with B-preamble). Bit 0 is
	*  the first bit transmitted (in the B-sub-frame of frame 0).
	*/
	#define DVISPDO_UBITS0_REG  (DVISPDO_BASE + 0x30)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames;with msb firs
	* t (bit 31 in a sub-frame with B-preamble). Bit 0 is the;first bit transmitted (i
	* n the B-sub-frame of frame 0).
	*/
	#define DVISPDO_UBITS0_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS0_UBITS_SHIFT 0
	/*
	* User bits for frames 16 to 31;The bits are sent out imsb first in sub-sequent IE
	* C60958 subframes.
	*/
	#define DVISPDO_UBITS1_REG  (DVISPDO_BASE + 0x34)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_UBITS1_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS1_UBITS_SHIFT 0
	/*
	* User bits for frames 32 to 47;The bits are sent out imsb first in sub-sequent IE
	* C60958 subframes.
	*/
	#define DVISPDO_UBITS2_REG  (DVISPDO_BASE + 0x38)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_UBITS2_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS2_UBITS_SHIFT 0
	/*
	* User bits for frames 48 to 63 .;The bits are sent out imsb first in sub-sequent 
	* IEC60958 subframes.
	*/
	#define DVISPDO_UBITS3_REG  (DVISPDO_BASE + 0x3c)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_UBITS3_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS3_UBITS_SHIFT 0
	/*
	* User bits for frames 64 to 79;The bits are sent out imsb first in sub-sequent IE
	* C60958 subframes.
	*/
	#define DVISPDO_UBITS4_REG  (DVISPDO_BASE + 0x40)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_UBITS4_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS4_UBITS_SHIFT 0
	/*
	* User bits for frames 80 to 95;The bits are sent out imsb first in sub-sequent IE
	* C60958 subframes.
	*/
	#define DVISPDO_UBITS5_REG  (DVISPDO_BASE + 0x44)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_UBITS5_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS5_UBITS_SHIFT 0
	/*
	* User bits for frames 96 to 111;The bits are sent out imsb first in sub-sequent I
	* EC60958 subframes.
	*/
	#define DVISPDO_UBITS6_REG  (DVISPDO_BASE + 0x48)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_UBITS6_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS6_UBITS_SHIFT 0
	/*
	* User bits for frames 112 to 127;The bits are sent out imsb first in sub-sequent 
	* IEC60958 subframes.
	*/
	#define DVISPDO_UBITS7_REG  (DVISPDO_BASE + 0x4c)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_UBITS7_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS7_UBITS_SHIFT 0
	/*
	* User bits for frames 128 to 143;The bits are sent out imsb first in sub-sequent 
	* IEC60958 subframes.
	*/
	#define DVISPDO_UBITS8_REG  (DVISPDO_BASE + 0x50)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_UBITS8_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS8_UBITS_SHIFT 0
	/*
	* User bits for frames 144 to 159;The bits are sent out imsb first in sub-sequent 
	* IEC60958 subframes.
	*/
	#define DVISPDO_UBITS9_REG  (DVISPDO_BASE + 0x54)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_UBITS9_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS9_UBITS_SHIFT 0
	/*
	* User bits for frames 160 to 175;The bits are sent out imsb first in sub-sequent 
	* IEC60958 subframes.
	*/
	#define DVISPDO_UBITS10_REG  (DVISPDO_BASE + 0x58)
	/*
	* The bits are sent out imsb first n sub-sequent IEC60958 sub-frames.
	*/
	#define DVISPDO_UBITS10_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS10_UBITS_SHIFT 0
	/*
	* User bits for frames 176 to 191;The bits are sent out imsb first in sub-sequent 
	* IEC60958 subframes.
	*/
	#define DVISPDO_UBITS11_REG  (DVISPDO_BASE + 0x5c)
	/*
	* User bits for frames 176 to 191;The bits are sent out imsb first in sub-sequent 
	* IEC60958 subframes.
	*/
	#define DVISPDO_UBITS11_UBITS_RW (0x07fffffff << 0)
	#define DVISPDO_UBITS11_UBITS_SHIFT 0
	/*
	* IEC60958 hardware packing enabling and frame definition
	*/
	#define DVISPDO_FRAME_DEF_REG  (DVISPDO_BASE + 0x60)
	#define DVISPDO_FRAME_DEF_RESERVED_RW (0x0fffffff << 3)
	#define DVISPDO_FRAME_DEF_RESERVED_SHIFT 3
	/*
	* Validity bit according to IEC60958 inserted into the bit stream; when hardware p
	* acking is enabled
	*/
	#define DVISPDO_FRAME_DEF_VBIT_RW (0x01 << 2)
	#define DVISPDO_FRAME_DEF_VBIT_SHIFT 2
	#define DVISPDO_FRAME_DEF_VBIT_VAL0 0x00
	#define DVISPDO_FRAME_DEF_VBIT_VAL1 0x01
	/*
	* The PACK_MODE bits define the SPDIF related IEC60958 hardware packing mode;00 = 
	* no packing in hardware; software has to provide pre-formatted sub-frames;01 = pa
	* cking of 16 bit data audio data or IEC61937 data;10 = packing of 24 bit data aud
	* io data
	*/
	#define DVISPDO_FRAME_DEF_PACK_MODE_RW (0x03 << 0)
	#define DVISPDO_FRAME_DEF_PACK_MODE_SHIFT 0
	#define DVISPDO_FRAME_DEF_PACK_MODE_VAL0 0x00
	#define DVISPDO_FRAME_DEF_PACK_MODE_VAL1 0x01
	#define DVISPDO_FRAME_DEF_PACK_MODE_VAL2 0x02
	#define DVISPDO_FRAME_DEF_PACK_MODE_VAL3 0x03
	/*
	* Content Protection; write only
	*/
	#define DVISPDO_SPDO_CPR_REG  (DVISPDO_BASE + 0x70)
	/*
	* A read returns 0x0.
	*/
	#define DVISPDO_SPDO_CPR_RESERVED_W (0x01fffff << 10)
	#define DVISPDO_SPDO_CPR_RESERVED_SHIFT 10
	/*
	* Protected encoded content; a read returns 0x0; 0 = non protected content; 1 = pr
	* otected encoded content.
	*/
	#define DVISPDO_SPDO_CPR_PEC_W (0x01 << 9)
	#define DVISPDO_SPDO_CPR_PEC_SHIFT 9
	#define DVISPDO_SPDO_CPR_PEC_VAL0 0x00
	#define DVISPDO_SPDO_CPR_PEC_VAL1 0x01
	/*
	* Protected decoded content; a read returns 0x0; 0 = non protected content; 1 = pr
	* otected decoded content.
	*/
	#define DVISPDO_SPDO_CPR_PDC_W (0x01 << 8)
	#define DVISPDO_SPDO_CPR_PDC_SHIFT 8
	#define DVISPDO_SPDO_CPR_PDC_VAL0 0x00
	#define DVISPDO_SPDO_CPR_PDC_VAL1 0x01
	/*
	* Content ID;write only; a read returns 0x00.
	*/
	#define DVISPDO_SPDO_CPR_CONT_ID_W (0x0ff << 0)
	#define DVISPDO_SPDO_CPR_CONT_ID_SHIFT 0
	#define DVISPDO_SPDO_PWR_DWN_REG  (DVISPDO_BASE + 0xff4)
	/*
	* Always reads as 0.
	*/
	#define DVISPDO_SPDO_PWR_DWN_UNUSED_RW (0x03fffffff << 1)
	#define DVISPDO_SPDO_PWR_DWN_UNUSED_SHIFT 1
	/*
	* Used to provide power control status for system software block power management.
	* 
	*/
	#define DVISPDO_SPDO_PWR_DWN_PWR_DWN_RW (0x01 << 0)
	#define DVISPDO_SPDO_PWR_DWN_PWR_DWN_SHIFT 0
	#define DVISPDO_SPDO_PWR_DWN_PWR_DWN_VAL0 0x00
	#define DVISPDO_SPDO_PWR_DWN_PWR_DWN_VAL1 0x01
	#define DVISPDO_SPDO_MODULE_ID_REG  (DVISPDO_BASE + 0xffc)
	/*
	* Module ID. This field identifies the block as type SPDO. ID=0x0121
	*/
	#define DVISPDO_SPDO_MODULE_ID_ID_R (0x07fff << 16)
	#define DVISPDO_SPDO_MODULE_ID_ID_SHIFT 16
	/*
	* Major Revision ID. This field is incremented by 1 when changes introduced in the
	*  block result in software incompatibility with the previous version of the block
	* . First version default = 0
	*/
	#define DVISPDO_SPDO_MODULE_ID_MAJ_REV_R (0x07 << 12)
	#define DVISPDO_SPDO_MODULE_ID_MAJ_REV_SHIFT 12
	#define DVISPDO_SPDO_MODULE_ID_MAJ_REV_VAL0 0x00
	#define DVISPDO_SPDO_MODULE_ID_MAJ_REV_VAL1 0x01
	#define DVISPDO_SPDO_MODULE_ID_MAJ_REV_VAL2 0x02
	#define DVISPDO_SPDO_MODULE_ID_MAJ_REV_VAL3 0x03
	#define DVISPDO_SPDO_MODULE_ID_MAJ_REV_VAL4 0x04
	#define DVISPDO_SPDO_MODULE_ID_MAJ_REV_VAL5 0x05
	#define DVISPDO_SPDO_MODULE_ID_MAJ_REV_VAL6 0x06
	#define DVISPDO_SPDO_MODULE_ID_MAJ_REV_VAL7 0x07
	/*
	* Minor Revision ID. This field is incremented by 1 when changes introduced in the
	*  block result in software compatibility with the previous version of the block. 
	* First version default = 0.
	*/
	#define DVISPDO_SPDO_MODULE_ID_MIN_REV_R (0x07 << 8)
	#define DVISPDO_SPDO_MODULE_ID_MIN_REV_SHIFT 8
	#define DVISPDO_SPDO_MODULE_ID_MIN_REV_VAL0 0x00
	#define DVISPDO_SPDO_MODULE_ID_MIN_REV_VAL1 0x01
	#define DVISPDO_SPDO_MODULE_ID_MIN_REV_VAL2 0x02
	#define DVISPDO_SPDO_MODULE_ID_MIN_REV_VAL3 0x03
	#define DVISPDO_SPDO_MODULE_ID_MIN_REV_VAL4 0x04
	#define DVISPDO_SPDO_MODULE_ID_MIN_REV_VAL5 0x05
	#define DVISPDO_SPDO_MODULE_ID_MIN_REV_VAL6 0x06
	#define DVISPDO_SPDO_MODULE_ID_MIN_REV_VAL7 0x07
	/*
	* Aperture size. Identifies the MMIO aperture size in units of 4 kB for the SPDO b
	* lock. SPDO has an MMIO aperture size of 4kB. APERTURE = 0: 4kB
	*/
	#define DVISPDO_SPDO_MODULE_ID_APERTURE_R (0x0ff << 0)
	#define DVISPDO_SPDO_MODULE_ID_APERTURE_SHIFT 0

#endif // PHMODIPDVISPDO_H
