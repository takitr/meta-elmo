/*-------------------------------------------------------------------------*/
/* Copyright 2010 Trident Microsystems (Far East) Ltd. All rights reserved */
/*-------------------------------------------------------------------------*/

#ifndef _KRONOS_H_
#define _KRONOS_H_

/****************************************************************************/
/* This header contains definitions for all registers and their contents as */
/* both #defines and C-bitfield types.  Compiler directives are used to     */
/* control the module definitions included.                                 */
/*                                                                          */
/* Naming conventions                                                       */
/* ------------------                                                       */
/*                                                                          */
/* Definitions of register addresses are relative to a base address         */
/* for the module. Base addresses are defined as xxx_BASE where xxx is      */
/* module identifier listed below.                                          */
/*                                                                          */
/* Register address xxx_<description>_REG                                   */
/*                                                                          */
/* Register definition typedef xxx_<description> (ie. register address      */
/* without the _REG).                                                       */
/****************************************************************************/
#define ISAPOLLO     (0)
#define ISKRONOS     (1)
#define ITC_TYPE    CORTEX_A9

#if (CHIP_REV==AUTOSENSE)
   #define IS_APOLLO_M0(ChipID, ChipRevID)         ((ChipID == APOLLO) && (ChipRevID == REV_M0))
   #define IS_SHINER_S_M0(ChipID, ChipRevID)       ((ChipID == SHINER_S) && (ChipRevID == REV_M0))
   #define IS_SHINER_IP_M0(ChipID, ChipRevID)      ((ChipID == SHINER_IP) && (ChipRevID == REV_M0))
   #define IS_HELIOS_M0(ChipID, ChipRevID)         ((ChipID == HELIOS) && (ChipRevID == REV_M0))

   #define IS_APOLLO_M1(ChipID, ChipRevID)         ((ChipID == APOLLO) && (ChipRevID == REV_M1))
   #define IS_SHINER_S_M1(ChipID, ChipRevID)       ((ChipID == SHINER_S) && (ChipRevID == REV_M1))
   #define IS_SHINER_IP_M1(ChipID, ChipRevID)      ((ChipID == SHINER_IP) && (ChipRevID == REV_M1))
   #define IS_HELIOS_M1(ChipID, ChipRevID)         ((ChipID == HELIOS) && (ChipRevID == REV_M1))

   #define IS_ATLEAST_M1(ChipID, ChipRevID)        (ChipRevID >= REV_M1) 
#else
   #define IS_APOLLO_M0(ChipID, ChipRevID)         ((CHIP_NAME == APOLLO) && (CHIP_REV == REV_M0))
   #define IS_SHINER_S_M0(ChipID, ChipRevID)       ((CHIP_NAME == SHINER_S) && (CHIP_REV == REV_M0))
   #define IS_SHINER_IP_M0(ChipID, ChipRevID)      ((CHIP_NAME == SHINER_IP) && (CHIP_REV == REV_M0))
   #define IS_HELIOS_M0(ChipID, ChipRevID)         ((CHIP_NAME == HELIOS) && (CHIP_REV == REV_M0))
   #define IS_KRONOS_M0(ChipID, ChipRevID)         ((CHIP_NAME == KRONOS) && (CHIP_REV == REV_M0))

   #define IS_APOLLO_M1(ChipID, ChipRevID)         ((CHIP_NAME == APOLLO) && (CHIP_REV == REV_M1))
   #define IS_SHINER_S_M1(ChipID, ChipRevID)       ((CHIP_NAME == SHINER_S) && (CHIP_REV == REV_M1))
   #define IS_SHINER_IP_M1(ChipID, ChipRevID)      ((CHIP_NAME == SHINER_IP) && (CHIP_REV == REV_M1))
   #define IS_HELIOS_M1(ChipID, ChipRevID)         ((CHIP_NAME == HELIOS) && (CHIP_REV == REV_M1))
   #define IS_KRONOS_M1(ChipID, ChipRevID)         ((CHIP_NAME == KRONOS) && (CHIP_REV == REV_M1))

   #define IS_ATLEAST_M1(ChipID, ChipRevID)        (CHIP_REV >= REV_M1) 
#endif   

/*********************************/
/* General Types used everywhere */
/*********************************/
/* Setup FLAG for Linux Kernel Builds vs. normal Edwards builds */
#if !defined (__STBCFG_H__) && defined (__KERNEL__)
   #define ENABLE_LINUX_KERNEL_CODE 1

#else
   #define ENABLE_LINUX_KERNEL_CODE 0

#endif

#ifndef __ASSEMBLY__
#if ENABLE_LINUX_KERNEL_CODE
   typedef unsigned long HW_DWORD;
   typedef unsigned short HW_WORD;
   typedef unsigned char HW_BYTE;
#endif /* #if ENABLE_LINUX_KERNEL_CODE */
   typedef volatile HW_DWORD *LPREG; /*HW_DWORD defined Hwconfig.h*/
#endif /* __ASSEMBLY__ */

/* RTC timer 15 is fixed for Edwards KAL watchdog functionality */
#define KAL_WATCHDOG_TIMER 15

/**************************************************/
/* Cortex A9 Internal Peripheral IP               */
/**************************************************/
#define MMIO_HOST_ARM_MMIO_BASE             0xE0600000
#define APOLLO_CORTEX_A9_PERIPHBASE         0xE0100000
#define APOLLO_CORTEX_A9_SCU_OFFSET         0x0000
#define APOLLO_CORTEX_A9_INTC_OFFSET        0x0100
#define APOLLO_CORTEX_A9_GLOB_TIMER_OFFSET  0x0200
#define APOLLO_CORTEX_A9_PRIV_TIMER_OFFSET  0x0600
#define APOLLO_CORTEX_A9_DISTR_OFFSET       0x1000
#define APOLLO_CORTEX_A9_INTC_BASE          (APOLLO_CORTEX_A9_PERIPHBASE + APOLLO_CORTEX_A9_INTC_OFFSET)
#define APOLLO_CORTEX_A9_TIMER_BASE         (APOLLO_CORTEX_A9_PERIPHBASE + APOLLO_CORTEX_A9_PRIV_TIMER_OFFSET)
#define APOLLO_CORTEX_A9_DISTR_BASE         (APOLLO_CORTEX_A9_PERIPHBASE + APOLLO_CORTEX_A9_DISTR_OFFSET)

#include "hwIpheaders/phmodIpCortexa9.h"

/************************/
/* Cortex A9 ITC        */
/************************/
#define A9_NUM_ITC_BANKS 8
#define ITC_A9_BANK_SIZE 4 
#define ITC_A9_GROUP_SIZE  0x20

#define ITC_A9_BASE                   APOLLO_CORTEX_A9_DISTR_BASE
#define ITC_ENASET_REG(bankNum)       (ITC_A9_BASE +  \
                                                (bankNum)*ITC_A9_BANK_SIZE + 0x100)
#define ITC_ENACLEAR_REG(bankNum)     (ITC_A9_BASE +  \
                                                (bankNum)*ITC_A9_BANK_SIZE + 0x180)
#define ITC_A9_PENDSET_REG(bankNum)   (ITC_A9_BASE +  \
                                                (bankNum)*ITC_A9_BANK_SIZE + 0x200)
#define ITC_A9_PENDCLEAR_REG(bankNum) (ITC_A9_BASE +  \
                                                (bankNum)*ITC_A9_BANK_SIZE + 0x280)
#define ITC_A9_ACTSTATUS_REG(bankNum) (ITC_A9_BASE +  \
                                                (bankNum)*ITC_A9_BANK_SIZE + 0x300)
#define ITC_A9_SGIPRIO_REG(bankNum)   (ITC_A9_BASE +  \
                                                (bankNum)*ITC_A9_BANK_SIZE + 0x400)
#define ITC_A9_PPIPRIO_REG(bankNum)   (ITC_A9_BASE +  \
                                                (bankNum)*ITC_A9_BANK_SIZE + 0x418)
#define ITC_A9_SPIPRIO_REG(bankNum)   (ITC_A9_BASE +  \
                                                (bankNum)*ITC_A9_BANK_SIZE + 0x420)
                                                
/**************************************************/
/* MIMO Devices                                   */
/**************************************************/
#define MMIO_BASE                (0xE0600000)

/**************************************************/
/* System Registers PLLs and Clocking             */ 
/**************************************************/
/* IP header file need to be included.  */
#define CLK_OFFSET               (0x6A000)
#define CLK_BASE                 (MMIO_BASE + CLK_OFFSET)

/**************************************************/
/* CGU                                            */
/**************************************************/
#define CRYSTAL_FREQUENCY        50000000
#define HOST_CGU_OFFSET          (0x6A000)
#define HOST_CGU_BASE            (MMIO_BASE + HOST_CGU_OFFSET)
#define HM_CGU_OFFSET            (0x6B000)
#define HM_CGU_BASE              (MMIO_BASE + HM_CGU_OFFSET)
#define CGU_OFFSET               (0xB8000)
#define CGU_BASE                 (MMIO_BASE + CGU_OFFSET)
#include "hwIpheaders/phmodIpCgu_kronos.h"


/**************************************************/
/* GCS FLASH Network                            */ 
/**************************************************/
/*************************   Details of Flash Network ******************************/
/* (IPBGCSFLSHNTWK_IP_2016)NOR_BASE  *************** (IPBGCSFLSHNTWK_BASE + 0x0000)*/       
/*                                   *             *                               */
/*                                   *             *                               */
/* (IPBGCSFLSHNTWK_IP_2017)NAND_BASE *************** (IPBGCSFLSHNTWK_BASE + 0x1000)*/
/*                                   *             *                               */
/*                                   *             *                               */
/* (IPBGCSFLSHNTWK_IP_SFC)SFC_BASE   *************** (IPBGCSFLSHNTWK_BASE + 0x2000)*/
/*                                   *             *                               */
/*                                   *             *                               */
/* (IPBGCSFLSHNTWK_IP_SFC)ISA_BASE   *************** (IPBGCSFLSHNTWK_BASE + 0x3000)*/
/*                                   *             *                               */
/*                                   *             *                               */
/* (IPBGCSFLSHNTWK_IP_SFC)DMA_BASE   *************** (IPBGCSFLSHNTWK_BASE + 0x4000)*/
/*                                   *             *                               */
/*                                   *             *                               */
/***********************************************************************************/

/**************************************************/
/* GCS                                            */ 
/**************************************************/
/* IP header file need to be included.  */
#define GCS_OFFSET               (0x30000)
#define GCS_BASE                 (MMIO_BASE + GCS_OFFSET) 

#define IPBGCSFLSHNTWK_OFFSET    (GCS_OFFSET + 0x0000)
#define IPBGCSFLSHNTWK_BASE      (MMIO_BASE + IPBGCSFLSHNTWK_OFFSET)

#include "hwIpheaders/phmodIpgcsflshntwk.h"
 
/**************************************************/
/* GCS DMAC                                       */ 
/**************************************************/
/* IP header file need to be included.  */
#define GCS_DMAC_OFFSET          (GCS_OFFSET + 0x4000)                   
#define GCS_DMAC_BASE            (MMIO_BASE + GCS_DMAC_OFFSET)

/**************************************************/
/* GCS ISA                                        */ 
/**************************************************/
/* IP header file need to be included.  */
#define ISA_OFFSET               (GCS_OFFSET + 0x3000)                   
#define ISA_BASE                 (MMIO_BASE + ISA_OFFSET)

/***************************************************/
/* RTC TIMER                                       */  
/***************************************************/
/* IP header file need to be included.  */
#define RTC_TIMER_OFFSET         (0x8B000)
#define RTC_TIMER_BASE           (MMIO_BASE + RTC_TIMER_OFFSET)

/***************************************************/
/* GPIO                                            */  
/***************************************************/
/* GPIO LEFT */
#define GPIO_BASE_UNIT1            (MMIO_BASE + 0xAB000)
/* GPIO RIGHT */
#define GPIO_BASE_UNIT2            (MMIO_BASE + 0x69000)

#include "hwIpheaders/phmodIpGpio.h"

/**************************************************/
/* SATA                                           */ 
/**************************************************/
/* IP header file need to be included.  */
#define SATA_OFFSET               (0x38000)                   
#define SATA_BASE                 (MMIO_BASE + SATA_OFFSET)  

/**************************************************/
/* DDR IP2036                                     */
/**************************************************/
#define DDR0_OFFSET              (0x64000)
#define DDR220542036_BASE_0      (MMIO_BASE + DDR0_OFFSET)

#include "hwIpheaders/phmodIpDdr220542036.h"

/**************************************************/
/* DDR Characterization Engine - 2090             */
/**************************************************/
#define IP2090_BASE_UNIT1         (MMIO_BASE + 0x65000)
    
#include "hwIpheaders/phmodIp2090.h"

/******************************************************
 *                   MCX/TEMPEST BLOCK                *
 ******************************************************/

#define MCX_OFFSET               0x0C0000

#define TEMPEST_COMMON_MAP       (0xE0600000 + MCX_OFFSET)
#define TEMPEST_BASE             TEMPEST_COMMON_MAP

#define TSX_BASE                 (TEMPEST_COMMON_MAP + 0xA000)
#define TSX_COMMON_BASE         (TSX_BASE + 0x600)

#define STC_1W_BASE             (TEMPEST_COMMON_MAP + 0xB000)
#define STC_4W_BASE             (TEMPEST_COMMON_MAP + 0xB800)

#define NUM_STC_BLOCKS           4
#define SIZE_STC_BLOCK           0x40
#define STC_A_B_REG_OFFSET       0x10

#include "hwIpheaders/tmmodIpStc.h"

/**************************************/
/* TSA Global Configuration Registers */
/**************************************/
#include "hwIpheaders/tmmodIpTsaGlobalReg.h"


/**************************************************/
/* SPI                                            */
/**************************************************/

#define SPI_OFFSET                (0xB0000)
#define SPI_BASE                  (MMIO_BASE + SPI_OFFSET)

#include "hwIpheaders/phmodIpSpi.h"
#define NO_PCI

/*******************************************/
/*         TSX,HSDP                        */
/*******************************************/

/*
 * In order to maintain proper unit numbering, TSX_HSDP_BASE always points to
 * the register bank for HSDP0, even if that port does not actually exist. Any
 * nonexistent ports are also indicated in TSX_HSDP_NUM_BANKS so that loops to
 * span all HSDP ports will work correctly. To indicate where no physical HSDP
 * port exists, TSX_HSDP_BANK_MAP is a bit map indicating valid ports within
 * the span 0-(TSX_HSDP_NUM_BANKS-1).
 */
#define TSX_HSDP_BASE            (TSX_BASE + 0x0000)
#define TSX_HSDP_BANK_SIZE       0x20
#define TSX_HSDP_NUM_BANKS       5
#define TSX_HSDP_BANK_MAP        0x0FF

#define TSX_TSP_IN_BASE          (TSX_BASE + 0x0200)
#define TSX_TSP_IN_BANK_SIZE     0x20
#define TSX_TSP_IN_NUM_BANKS     2 

#define TSX_TSP_OUT_BASE         (TSX_BASE + 0x0400)
#define TSX_TSP_OUT_BANK_SIZE    0x20
#define TSX_TSP_OUT_NUM_BANKS    3 

#define TSX_IMP_BASE             (TSX_BASE + 0x500)
#define TSX_IMP_BANK_SIZE        0x20
#define TSX_IMP_NUM_BANKS        1 

/*Base address of each kind of TSX HSDP register*/
#define TSX_HSDP_PORT_CTRL_BASE         (TSX_HSDP_BASE + 0x00)
#define TSX_HSDP_PACKET_CTRL_BASE       (TSX_HSDP_BASE + 0x04)
#define TSX_HSDP_MUX_CTRL_BASE          (TSX_HSDP_BASE + 0x08)
#define TSX_HSDP_CLOCK_CTRL_BASE        (TSX_HSDP_BASE + 0x0C)
#define TSX_HSDP_PORT_STS_BASE          (TSX_HSDP_BASE + 0x10)
#define TSX_HSDP_INTR_ENA_BASE          (TSX_HSDP_BASE + 0x14)
#define TSX_HSDP_FIFO_STATUS_BASE       (TSX_HSDP_BASE + 0x18)

#include "hwIpheaders/tmmodIpTsx.h"

/***********************/
/* TSP-TSR definitions */
/***********************/
#define TSP_NUM_DEMUXES       (1) 

/* 5 Live TSS and 4 DMA inputs into to the TSR */
#define DMX_NUM_TSS_INPUTS       ( 3 )  /* This represents the number of TSS inputs per TSP/TSR unit */
#define DMX_NUM_DMA_INPUTS       ( 3 )  /* This represents the number of DMA inputs per TSP/TSR unit */
#define DMX_NUM_MULTIPLEXED_DMA_INPUTS DMX_NUM_DMA_INPUTS
#define DMX_NUM_STREAMS          (12)
#define DMX_FILTER_BANKS_SUPPORT YES

#include "hwIpheaders/tmmodIpTsp.h"
#include "hwIpheaders/tmmodIpTsr.h"

/***********************/
/* Key Table definitions */
/***********************/
#define TSA_KEY_TABLE_BASE       (TEMPEST_COMMON_MAP + 0x1000)

#include "hwIpheaders/tmmodIpTspKT.h"

/**************************************************/
/* AUDIO SUB SYSTEM                               */
/**************************************************/
/* IP header file need to be included.  */
#define DVISPDO_OFFSET           (0x109000)
#define DVISPDO_BASE             (MMIO_BASE + DVISPDO_BASE)

#include "hwIpheaders/phmodIpDvispdo.h"

#define TPSAO_OFFSET             (0x110000)
#define TPSAO_BASE               (MMIO_BASE + AO_OFFSET)

#include "hwIpheaders/phmodIpTpsao.h"

#define AO_TO_HDMI_OFFSET        (0x112000) 
#define AO_TO_HDMI_BASE          (MMIO_BASE + AO_TO_HDMI_OFFSET) 

#define AUDIO_DSP_CACHE_TAGS_OFFSET  (0x180000) 
#define AUDIO_DSP_CACHE_TAGS_BASE    (MMIO_BASE + AUDIO_DSP_CACHE_TAGS_OFFSET) 
#define AUDIO_DSP_OFFSET             (0x190000) 
#define AUDIO_DSP_BASE               (MMIO_BASE + AUDIO_DSP_OFFSET) 

#define TMCONFIG_BASE_UNIT2      (MMIO_BASE + 0x190000)
#include "hwIpheaders/phmodIpTmconfig.h"

/* Audio Decoder framework definitions */
#define SCRATCH_REG1_DECDESC_BASE_PTR 0xE06BBD04
#define SCRATCH_REG2_DECREADYSTATUS   0xE06BBD08
#define SCRATCH_REG3_DECESDESCBUF_PTR 0xE06BBD0C

//#include "hwIpheaders/tmmodIpAudio.h"

/*****************************************************************************/
/*                               VSM DMA                                     */
/*****************************************************************************/
#define VSM_DMA_CRYPTO_BASE      0xE0624300
#define VSM_DMA_TSP_OFFSET       0X19800
#define VSM_DMA_TSP_BASE         (TEMPEST_COMMON_MAP + VSM_DMA_TSP_OFFSET )

#include "hwIpheaders/tmmodIpVsmDma.h"

/***************************************************/
/* GLOBAL REGISTERS                                */  
/***************************************************/
#define GLOBAL_REG_OFFSET        (0xBB000) 
#define GLOBALREG_BASE_UNIT1     (MMIO_BASE + GLOBAL_REG_OFFSET)
 
#include "hwIpheaders/phmodIpGlobalreg_kronos.h"

/***************************************************/
/* RGU                                             */  
/***************************************************/
#define RGU_OFFSET               (0xAF000) 
#define RESET_BASE_UNIT1         (MMIO_BASE + RGU_OFFSET)
 
#include "hwIpheaders/phmodIpReset.h"

/***************************************************/
/* Malone                                          */  
/***************************************************/
/* IP header file need to be included.  */
#define MALONE_OFFSET            (0x1C0000)                                
#define MSD_BASE                 (MMIO_BASE + MALONE_OFFSET


/***************************************************/
/* SMART CARD                                      */  
/***************************************************/

#define SMC_TYPE   APOLLO
#include "hwIpheaders/phmodIpSmc.h"

#define SMC_BASE                 (MMIO_BASE + 0x89000)

#define CNXT_SMC_MAX_NUM_UNITS   2
#define SMC_BANK_SIZE            0x1000
#define NUM_SMC_DATA             16

/***************************************************/
/*CRYPTO                                           */  
/***************************************************/
/* IP header file need to be included.  */
#define SECCRYPTO_OFFSET         (0x24000)                                
#define SECCRYPTO_BASE           (MMIO_BASE + SECCRYPTO_OFFSET)               

#include "hwIpheaders/phmodIpSeccrypto.h"

/***************************************************/
/* Infrared                                        */  
/***************************************************/
#define IRD_OFFSET               (0xBC000)
#define IRD_BASE                 (MMIO_BASE + IRD_OFFSET )

#include "hwIpheaders/tmmodIpIrd.h"

/***************************************************/
/* Pulse Timer                                	   */
/***************************************************/
#define PLS_OFFSET		         (0xB9000)
#define PLS_BASE            	 (MMIO_BASE + PLS_OFFSET)
#define PLS_BANK_SIZE       	 (0x1000)
#define NUM_PLS_BANKS       	 (2)

#include "hwIpheaders/tmmodIpPls.h"


/***************************************************/
/* GMAC                                  	   */
/***************************************************/
#define GMAC_UNIT1_OFFSET        (0x7C000)
#define GMAC_UNIT2_OFFSET        (0xA4000)
#define GMAC_BASE_UNIT1          (MMIO_BASE + GMAC_UNIT1_OFFSET)
#define GMAC_BASE_UNIT2          (MMIO_BASE + GMAC_UNIT2_OFFSET)

#include "hwIpheaders/phmodIpGmac.h"

/***************************************************/
/* UART                                  	   */
/***************************************************/
#define UART_UNIT1_OFFSET        (0xB2000)
#define UART_UNIT2_OFFSET        (0xB3000)
#define UART_UNIT3_OFFSET        (0xB4000)

#define UART_BASE_UNIT1          (MMIO_BASE + UART_UNIT1_OFFSET)
#define UART_BASE_UNIT2          (MMIO_BASE + UART_UNIT2_OFFSET)
#define UART_BASE_UNIT3          (MMIO_BASE + UART_UNIT3_OFFSET)

#include "hwIpheaders/phmodIpUart.h"

/***************************************************/
/* PMAN                                  	   */
/***************************************************/

/* PMAN_CONTROL */
#define PMANCONFIG_OFFSET        (0x62000) 
#define PMANCONFIG_BASE          (MMIO_BASE + PMANCONFIG_OFFSET)
#include "hwIpheaders/phmodIpPmanconfig.h"

/* PMAN_HUB0_1040 */
#define PMANHUB01040_OFFSET      (0x3f000)
#define PMANHUB01040_BASE        (MMIO_BASE + PMANHUB01040_OFFSET)
#include "hwIpheaders/phmodIpPmanhub01040.h"
/* PMAN_ARB0-1010 */
#define PMANH0I51010_OFFSET      (0x3c000)
#define PMANH0I51010_BASE        (MMIO_BASE + PMANH0I51010_OFFSET)
#include "hwIpheaders/phmodIpPmanh0i51010.h"
/* PMAN_ARB1-1010 */
#define PMANH1I51010_OFFSET      (0x3d000)
#define PMANH1I51010_BASE        (MMIO_BASE + PMANH1I51010_OFFSET )
#include "hwIpheaders/phmodIpPmanh1i51010.h"
/* PMAN_ARB2-1010 */ 
#define PMANH2I01010_OFFSET      (0x3e000)
#define PMANH2I01010_BASE        (MMIO_BASE + PMANH2I01010_OFFSET)
#include "hwIpheaders/phmodIpPmanh2i01010.h"

/****************************************************************************/
/*                         NSK  module                                      */
/****************************************************************************/
#define NSK_OFFSET               (0x10000)
#define NSK_BASE                 (MMIO_BASE + NSK_OFFSET)
#define NSK_BASE_INSTANCE(x)     NSK_BASE

#include "nsk_apollo.h"

/****************************************************************************/
/*                         Timer  module                                    */
/****************************************************************************/
#define TIMER_OFFSET             (0x8b000)
#define TIMER_BASE               (MMIO_BASE + TIMER_OFFSET)

#include "hwIpheaders/phmodIpTimer.h"


#endif   /* #ifdef _KRONOS_H_*/
