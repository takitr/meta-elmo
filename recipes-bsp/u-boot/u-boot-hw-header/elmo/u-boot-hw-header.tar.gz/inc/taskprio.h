/******************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                    */
/*                        SOFTWARE FILE/MODULE HEADER                         */
/*                 Copyright Conexant Systems Inc. 2004-2006                  */
/*                            All Rights Reserved                             */
/******************************************************************************/
/*
 * Filename:        taskprio.h
 *
 *
 * Description:     Public header file containing task names and priority definitions
 *
 *
 * Author:          Xin Golden
 *
 ******************************************************************************/
/* $Id: taskprio.h 211608 2011-06-20 03:06:42Z prasadl1 $
 ******************************************************************************/

#ifndef _TASKPRIO_H_
#define _TASKPRIO_H_

/* NDS Reserved Priorities (KAL style, not UCOS style) in uCOS Kernel 2 */
/* Reserved:  UCOS 0-7     = KAL 248-255 */
/* Reserved:  UCOS 24-31   = KAL 224-231 */
/* Reserved:  UCOS 40-47   = KAL 208-215 */
/* Reserved:  UCOS 56-71   = KAL 184-199 */
/* Reserved:  UCOS 88-111  = KAL 144-167 */
/* Reserved:  UCOS 128-175 = KAL 80-127  */
/* Reserved:  UCOS 192-231 = KAL 24-63   */
/* Reserved:  UCOS 240-255 = KAL 0-15    */

/* Available:                KAL 232-246 */
/* Available:                KAL 216-223 */
/* Available:                KAL 200-207 */
/* Available:                KAL 168-183 */
/* Available:                KAL 128-143 */
/* Available:                KAL 64-79   */
/* Available:                KAL 16-23   */


/* Priorities reserved for application use in uCOS */
#define APP_RESERVED_PRIO_10                 243
#define APP_RESERVED_PRIO_9                  242
#define APP_RESERVED_PRIO_8                  241
#define APP_RESERVED_PRIO_7                  238
#define APP_RESERVED_PRIO_6                  234
#define APP_RESERVED_PRIO_5                  201
#define APP_RESERVED_PRIO_4                  177
#define APP_RESERVED_PRIO_3                  172
#define APP_RESERVED_PRIO_2                  138
#define APP_RESERVED_PRIO_1                  137
#define APP_RESERVED_PRIO_0                  136

/* Priority used for uCOS root task */
#define ROOT_THREAD_PRIORITY                 71

/* ************** */
/*    !!NOTE!!    */
/* ************** */
/* Since uCOS requires task priorities to be unique, if any more
 * priority definitions are added, care should be taken that they
 * are unique i.e. no two tasks (that could run at the same time)
 * should have the same priority values for uCOS, including the 
 * values assigned to the APP_RESERVED_PRIO_N constants above.
 *
 * The uCOS priority value is the second parameter of the macro -
 * CNXT_KAL_THREAD_PRIO(non_uCOSPrio, uCOSPrio) used below
 */

/* Priorities used for KalTest threads */
#define PRIO_TASK1_PRIORITY                  CNXT_KAL_THREAD_PRIO(CNXT_KAL_MIN_THREAD_PRIORITY,   \
                                                                  APP_RESERVED_PRIO_1)
#define PRIO_TASK2_PRIORITY                  CNXT_KAL_THREAD_PRIO(CNXT_KAL_MIN_THREAD_PRIORITY+1, \
                                                                  APP_RESERVED_PRIO_2)
#define QU_TASK_PRIORITY                     CNXT_KAL_THREAD_PRIO(CNXT_KAL_MIN_THREAD_PRIORITY,   \
                                                                  APP_RESERVED_PRIO_3)
#define CONF_TASK_PRIORITY                   CNXT_KAL_THREAD_PRIO(CNXT_KAL_MIN_THREAD_PRIORITY,   \
                                                                  APP_RESERVED_PRIO_6)
#define SLEEP_TASK_PRIORITY                  CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+5),  \
                                                                  APP_RESERVED_PRIO_6)

/* Priority used for TestHarness thread */
/* The TESTH_TASK_PRIORITY is reduced by value 10 because on Linux the async callback thread priority is lower */
/* than that of TESTH thread priority. Some places we have tight loop (while 1) and in those cases, async callback mechanism */
/* is not working. For this reason TESTH priority is reduced */
#define TESTH_TASK_PRIORITY                  CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+5 - 10), \
                                                                  (APP_RESERVED_PRIO_4))

/* NDSCore HDI Task (NDSCore only) */
#define HDI_TASK_NAME                        "HDIINT"
#define HDI_TASK_PRIORITY                    CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, \
                                                                  APP_RESERVED_PRIO_9)
#define HDI_TASK_STACK_SIZE                  0x1000

/* SCART controller polling task (NB: Duplicate of NDSCore ID for now!) */
#define SCRT_TASK_NAME                        "SCART"
#define SCRT_TASK_PRIORITY                    CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, \
                                                                   APP_RESERVED_PRIO_9)
#define SCRT_TASK_STACK_SIZE                  0x1000

/*NDS CA Task priorities */
#define NDSC_TASK_PRIORITY                   CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 129)
#define NDSCAM_TASK_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 135)

/* NDSCore OSD Fade Task (NDSCore only) */        
/* Needs to run very timely, but doesn't do much */
#define OSFT_TASK_NAME                       "OSFT"
#define OSFT_TASK_PRIORITY                   CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, APP_RESERVED_PRIO_8)
#define OSFT_TASK_STACK_SIZE                 0x0600

/* The following are for NDS ICAM related tasks (these and the above are NOT used at the same time!!) */ 
/*
 * The priority of the NDS tasks are in the 200+ range going to
 * 218.  The NDS task is the task that feeds these NDS tasks inside
 * the verifier with new ECM and EMM packets.  It *has* to be at
 * at least the priority of the NDS tasks to ensure the latency
 * is kept to a minimum to avoid buffer overflow for both the
 * ECM's and EMM's.  Do not change the priority of this task.  It
 * is a well-formed non-premptive queue driven task.
 */

#define  NDS_ICAM_TASK_NAME                  "NDS"
#define  NDS_ICAM_TASK_PRIORITY              CNXT_KAL_THREAD_PRIO(220, 60)
#define  NDS_ICAM_TASK_STACK_SIZE            0x1000

/* 
 * The NDS Smart Card Task supplies Smart Card events to the other 
 * NDS tasks. This task cannot wait for too long. So this task has to be higher
 * than other system tasks 
 */
#define NSCT_ICAM_TASK_NAME                  "NSCT"
#define NSCT_ICAM_TASK_PRIORITY              CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+11), 56)
#define NSCT_ICAM_TASK_STACK_SIZE            0x0800


#define SATA_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+15), 247)
#define SATA_STACK_SIZE                      (1024*16)

#define SATA_EH_THREAD_PRIORITY              CNXT_KAL_THREAD_PRIO((SATA_THREAD_PRIORITY + 15), 247 + 15)
#define SATA_EH_STACK_SIZE                   CNXT_KAL_DEFAULT_STACK_SIZE

#define PATA_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+15), 240)
#define PATA_STACK_SIZE                      (1024*16)

/* Callback Thread Priority High Priority, No Block */
#define CBHINB_THREAD_PRIORITY               CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+20), 239)
/* Callback Thread Priority High Priority */
#define CBHI_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+20), 237)

#define VIDEO_NOKALCB_THREAD_PRIORITY        CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+15), 236)
#define VIDEO_STACK_SIZE                     (1024*16)

#define UI_CONTROLS_NOTIFY_THREAD_PRIORITY   CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 223)
#define UI_CONTROLS_NOTIFY_THREAD_STACK_SIZE (1024*16)

#define DMX_UCODEEVT_THREAD_NAME             "DMX_UCODE"
#define DMX_UCODEEVT_THREAD_PRIORITY         CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+25), 222)
#define DMX_UCODEEVT_THREAD_STACK_SIZE       (1024*16)

#define DMX_SW_PROCESS0_THREAD_NAME          "DMX_SW0"
#define DMX_SW_PROCESS0_THREAD_PRIORITY      CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+25), 200)
#define DMX_SW_PROCESS0_THREAD_STACK_SIZE    (1024*16)

#define DMX_SW_PROCESS1_THREAD_NAME          "DMX_SW1"
#define DMX_SW_PROCESS1_THREAD_PRIORITY      CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+25), 206)
#define DMX_SW_PROCESS1_THREAD_STACK_SIZE    (1024*16)

#define DMX_DMAEVT_THREAD_NAME               "DMX_DMAEVT"
#define DMX_DMAEVT_THREAD_PRIORITY           CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+25), 223)
#define DMX_DMAEVT_THREAD_STACK_SIZE         (1024*16)

#define DMX_FCC_THREAD_NAME                  "DMX_FCC"
#define DMX_FCC_THREAD_PRIORITY              CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+25),200)
#define DMX_FCC_THREAD_STACK_SIZE            (1024*16)

#define DMX_OOB_THREAD_NAME                  "DMX_OOB"
#define DMX_OOB_THREAD_PRIORITY              CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+25),200)
#define DMX_OOB_THREAD_STACK_SIZE            (1024*16)

#define IOLIB_NOKALCB_THREAD_PRIORITY        CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 221)
#define IOLIB_STACK_SIZE                     (1024*16)

#define UI_CONTROLS_NOKALCB_THREAD_PRIORITY  CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 220)
#define UI_CONTROLS_STACK_SIZE               (1024*16)

#define AUDIO_NOKALCB_THREAD_PRIORITY        CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 219)
#define AUDIO_STACK_SIZE                     (1024*16)

#define DEMOD_NOKALCB_THREAD_PRIORITY        CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 218)
#define DEMOD_STACK_SIZE                     (1024*16)

#define PCM_NOKALCB_THREAD_PRIORITY          CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 217)
#define PCM_STACK_SIZE                       (1024*16)

#define PHANTOM_ACQT_TASK_PRIORITY           CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 181)
#define PHANTOM_ACQT_TASK_STACK_SIZE         CNXT_KAL_DEFAULT_STACK_SIZE

#define MUSTANG_ACQT_TASK_PRIORITY           CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 180)
#define MUSTANG_ACQT_TASK_STACK_SIZE         CNXT_KAL_DEFAULT_STACK_SIZE

#define STINGER_ACQT_TASK_PRIORITY           CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 182)
#define STINGER_ACQT_TASK_STACK_SIZE         CNXT_KAL_DEFAULT_STACK_SIZE

#define ALTAIR_ACQT_TASK_PRIORITY           CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 183)
#define ALTAIR_ACQT_TASK_STACK_SIZE         CNXT_KAL_DEFAULT_STACK_SIZE

/* Callback Thread Priority Low Priority, No Block */
#define CBLONB_THREAD_PRIORITY               CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 179)
/* Callback Thread Priority Low Priority */
#define CBLO_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 178)

#define FTIR_THREAD_NAME                     "FTIR"
#define FTIR_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 176)
#define FTIR_THREAD_STACK_SIZE               CNXT_KAL_DEFAULT_STACK_SIZE

#define BKIR_THREAD_NAME                     "BKIR"
#define BKIR_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 175)
#define BKIR_THREAD_STACK_SIZE               CNXT_KAL_DEFAULT_STACK_SIZE

#define HDCP_THREAD_NAME                     "HDCP"
#define HDCP_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 174)
#define HDCP_THREAD_STACK_SIZE               CNXT_KAL_DEFAULT_STACK_SIZE

#define QDTV_STARTUP_THREAD_NAME             "QDTV"
#define QDTV_STARTUP_THREAD_PRIORITY         CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 173)
#define QDTV_STACK_SIZE                      (1024*16)

#define CNXTV_STARTUP_THREAD_NAME             "CNXTV"
#define CNXTV_STARTUP_THREAD_PRIORITY         CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 173)
#define CNXTV_STACK_SIZE                      (1024*16)
/* __MULTI_REC_MULTI_PLY__ */
/* XCTL share same priority with QDTV */
#define CXTV_CTRL_THREAD_NAME                "XCTL"
#define CXTV_CTRL_THREAD_PRIORITY            CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 173)
#define CXTV_CTRL_THREAD_STACK_SIZE          (16*1024)

/* RECCTL share same priority with QDTV as they are Mutually Exclusive */
#define CXTV_REC_THREAD_NAME                "RECCTL"
#define CXTV_REC_THREAD_PRIORITY            CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY+1, 173)
#define CXTV_REC_THREAD_STACK_SIZE          (16*1024)

#define CXTV_PLY_THREAD_NAME                "PLYCTL"
#define CXTV_PLY_THREAD_PRIORITY            CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 172)
#define CXTV_PLY_THREAD_STACK_SIZE          (16*1024)


#define DVBLIB_THREAD_PRIORITY               CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 171)

#define TRICKMODE_THREAD_PRIORITY            CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 170)
#define TRICKMODE_STACK_SIZE                 CNXT_KAL_DEFAULT_STACK_SIZE

#define SVCLIST_DVB_THREAD_PRIORITY          CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 169)
#define SVCLIST_DVB_STACK_SIZE               (16*1024)

#define ACQT_TASK_PRIORITY                   CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 168)
#define ACQT_TASK_STACK_SIZE                 CNXT_KAL_DEFAULT_STACK_SIZE

#define BK2IR_THREAD_NAME                    "BK2IR"
#define BK2IR_THREAD_PRIORITY                CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 167)
#define BK2IR_THREAD_STACK_SIZE              CNXT_KAL_DEFAULT_STACK_SIZE

#define CXTV_THREAD_STARTUP_NAME             "XTVM"
#define CXTV_THREAD_STARTUP_PRIORITY         CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 143)
#define CXTV_THREAD_STARTUP_STACK_SIZE       CNXT_KAL_DEFAULT_STACK_SIZE

#define CHMD_TASK_NAME                       "CHMD"
#define CHMD_TASK_PRIORITY                   CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 142)
#define CHMD_TASK_STACK_SIZE                 CNXT_KAL_DEFAULT_STACK_SIZE

#define QDTV_THREAD0_PRIORITY                CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 141)
#define QDTV_THREAD1_PRIORITY                CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 140)

#define CNXTV_THREAD0_PRIORITY               CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 141)
#define CNXTV_THREAD1_PRIORITY                CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 140)

#define ISRH_THREAD_NAME                     "ISRH"
#define ISRH_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 139)
#define ISRH_THREAD_STACK_SIZE               (1024*5)

/* The following are reserved for a TBD USB Stack */
#define USB_RESERVED_0_THREAD_PRIORITY       CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 133)
#define USB_RESERVED_1_THREAD_PRIORITY       CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 132)
#define USB_RESERVED_2_THREAD_PRIORITY       CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 131)
#define USB_RESERVED_3_THREAD_PRIORITY       CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 130)

#define MIPIDLE_THREAD_NAME                  "MIP "
#define MIPIDLE_THREAD_PRIORITY              CNXT_KAL_THREAD_PRIO(CNXT_KAL_MIN_THREAD_PRIORITY, 1)
#define MIPIDLE_THREAD_STACK_SIZE            0x0400

#define MEMIDLE_THREAD_NAME                  "MEM "
#define MEMIDLE_THREAD_PRIORITY              CNXT_KAL_THREAD_PRIO(CNXT_KAL_MIN_THREAD_PRIORITY, 1)
#define MEMIDLE_THREAD_STACK_SIZE            0x0400

#define HDMI_THREAD_NAME                     "HDMI"
#define HDMI_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 75)
#define HDMI_THREAD_STACK_SIZE               0x0600

#define HDMIRX_THREAD_NAME                     "HDMIRX"
#define HDMI_RX_THREAD_PRIORITY           CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 76)
#define HDMI_THREAD_STACK_SIZE               0x0600

#define USBTX_THREAD_NAME                    "USBT"
#define USBTX_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 74)
#define USBTX_THREAD_STACK_SIZE               CNXT_KAL_DEFAULT_STACK_SIZE

#define USBRX_THREAD_NAME                    "USBR"
#define USBRX_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 73)
#define USBRX_THREAD_STACK_SIZE               CNXT_KAL_DEFAULT_STACK_SIZE

#define IRRX_THREAD_NAME                    "IRRX"
#define IRRX_NOKALCB_THREAD_PRIORITY        CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 72)
#define IRRX_THREAD_STACK_SIZE              CNXT_KAL_DEFAULT_STACK_SIZE

#define CLEN_THREAD_NAME                     "CLEN"
#define CLEN_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 134)
#define CLEN_THREAD_STACK_SIZE               0x0400

#define STCK_THREAD_NAME                     "STCK"
#define STCK_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 20)
#define STCK_THREAD_STACK_SIZE               (1024*5)

/* The following are priority for EMAC media check thread */
#define EMAC_MEDIA_CHECK_THREAD_NAME         "EMAC "
#define EMAC_MEDIA_CHECK_THREAD_PRIORITY     CNXT_KAL_THREAD_PRIO(CNXT_KAL_MIN_THREAD_PRIORITY, 2)
#define EMAC_MEDIA_CHECK_THREAD_STACK_SIZE            0x0400

#define SCD_THREAD_NAME                     "SCD"
#define SCD_THREAD_PRIORITY                 CNXT_KAL_THREAD_PRIO((CNXT_KAL_DEFAULT_PRIORITY+15), 233)
#define SCD_THREAD_STACK_SIZE               CNXT_KAL_DEFAULT_STACK_SIZE

#define IIC_THREAD_NAME                    "IIC"
#define IIC_THREAD_PRIORITY                CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 232) 
#define IIC_THREAD_STACK_SIZE              CNXT_KAL_DEFAULT_STACK_SIZE

#define DMA_THREAD_NAME                    "DMA"
#define DMA_THREAD_PRIORITY                CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 231)
#define DMA_THREAD_STACK_SIZE              CNXT_KAL_DEFAULT_STACK_SIZE

#define SPI_THREAD_NAME                    "SPI"
#define SPI_THREAD_PRIORITY                CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 233)
#define SPI_THREAD_STACK_SIZE              CNXT_KAL_DEFAULT_STACK_SIZE

/********************************************************************** 
   These priorities are used exclusively for the testh,
   they are normally priorities reserved for NDS and 
   SHOULD NEVER be used in production code other than
   the test harness.
   If used, always use the following comment in your
   code:                                                 */
/*The thread priorities TESTH_ONLY_THREAD_PRIOX are for exclusive use by the testh.
  These are NDS reserved priorities. */

#define TESTH_ONLY_THREAD_PRIO0             CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 235)
#define TESTH_ONLY_THREAD_PRIO1             CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 205)
#define TESTH_ONLY_THREAD_PRIO2             CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 204)
#define TESTH_ONLY_THREAD_PRIO3             CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 203)
#define TESTH_ONLY_THREAD_PRIO4             CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 202)
#define TESTH_ONLY_THREAD_PRIO5             CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 244)
#define TESTH_ONLY_THREAD_PRIO6             CNXT_KAL_THREAD_PRIO(CNXT_KAL_DEFAULT_PRIORITY, 245)

/*This macro can be used to get a different priority when spawing threads from inside
  a loop, where a is the loop count.*/
#define TESTH_ONLY_GET_THREAD_PRIO(a) (a == 0) ? TESTH_ONLY_THREAD_PRIO0 : \
                                      (a == 1) ? TESTH_ONLY_THREAD_PRIO1 : \
                                      (a == 2) ? TESTH_ONLY_THREAD_PRIO2 : \
                                      (a == 3) ? TESTH_ONLY_THREAD_PRIO3 : \
                                      (a == 4) ? TESTH_ONLY_THREAD_PRIO4 : \
                                      (a == 5) ? TESTH_ONLY_THREAD_PRIO5 : \
                                                 TESTH_ONLY_THREAD_PRIO6

/* CABLE MODEM */

/* CM_MUX - Cable Modem Packet MUX/DEMUX */
/* (Note: so far, i have not investigated using smaller stack sizes - D.M.)  */

/* Also note the relationship in the CM_MUX priorities (except for the */
/* debug print task) should be maintained.                             */
#define CM_MUX_BASE_PRIORITY        CNXT_KAL_DEFAULT_PRIORITY
#define CM_MUX_DEFAULT_STACK_SIZE   5120

/* This task brings up the Network and initiates a DHCP Boot then exits */
#define CM_MUX_DHCP_TASK_NAME           "DHCP"
#define CM_MUX_DHCP_PRIORITY            (CM_MUX_BASE_PRIORITY+4)
#define CM_MUX_DHCP_STACK_SIZE          CM_MUX_DEFAULT_STACK_SIZE*2 /* yes, needs a big stack */

/* This task prints diagnostics when compiled DEBUG */
#define CM_MUX_PRINT_TASK_NAME          "CMPT"
#define CM_MUX_PRINT_PRIORITY           (CM_MUX_BASE_PRIORITY-1)
#define CM_MUX_PRINT_STACK_SIZE         CM_MUX_DEFAULT_STACK_SIZE

/* This task drives ETHERNET frames upstream (to Headend Server) */
#define CM_MUX_NET_TX_TASK_NAME         "CMTT"
#define CM_MUX_NET_TX_PRIORITY          (CM_MUX_BASE_PRIORITY+3)
#define CM_MUX_NET_TX_STACK_SIZE        CM_MUX_DEFAULT_STACK_SIZE

/* This task drives UDP frames downstream (to IRD IP Stack) */
#define IPSTB_UDP_CLENT_RX_TASK_NAME    "UDPC"
#define IPSTB_UDP_CLENT_RX_PRIORITY     (CM_MUX_BASE_PRIORITY+5)
#define IPSTB_UDP_CLENT_RX_STACK_SIZE   CM_MUX_DEFAULT_STACK_SIZE

/* This task drives ETHERNET frames downstream (to IRD IP Stack) */
#define CM_MUX_NET_RX_TASK_NAME         "CMRT"
#define CM_MUX_NET_RX_PRIORITY          (CM_MUX_BASE_PRIORITY+4)
#define CM_MUX_NET_RX_STACK_SIZE        CM_MUX_DEFAULT_STACK_SIZE

/* This task drives CONTROL frames downstream (to IRD Control Clients) */
#define CM_MUX_CNTRL_MSG_TASK_NAME      "CMCT"
#define CM_MUX_CNTRL_MSG_PRIORITY       (CM_MUX_BASE_PRIORITY+4)
#define CM_MUX_CNTRL_MSG_STACK_SIZE     CM_MUX_DEFAULT_STACK_SIZE

/* This task drives OOB frames downstream (to IRD OOB handler) */
#define CM_MUX_OOB_RX_TASK_NAME         "OOBR"
#define CM_MUX_OOB_RX_PRIORITY          (CM_MUX_BASE_PRIORITY+4)
#define CM_MUX_OOB_RX_STACK_SIZE        CM_MUX_DEFAULT_STACK_SIZE

/* This task drives DSG IP frames downstream (to Host DSG App) */
#define CM_MUX_DSG_OOB_RX_TASK_NAME     "DSGR"
#define CM_MUX_DSG_OOB_RX_PRIORITY      (CM_MUX_BASE_PRIORITY+4)
#define CM_MUX_DSG_OOB_RX_STACK_SIZE    CM_MUX_DEFAULT_STACK_SIZE

/* CM_END - VxW Ethernet over Cable Modem Enhanced Network Driver  */
/* (Note: so far, i have not investigated using smaller stack sizes - D.M.)  */

/* This task prints diagnostics when compiled DEBUG */
#define CM_END_PRINT_TASK_NAME          "CMEP"
#define CM_END_PRINT_PRIORITY           CM_MUX_BASE_PRIORITY
#define CM_END_PRINT_STACK_SIZE         CM_MUX_DEFAULT_STACK_SIZE

/* END of CABLE MODEM */
#endif /* _TASKPRIO_H_ */

/****************************************************************************
 * Modifications:
 * $Log$
 *
 ****************************************************************************/


