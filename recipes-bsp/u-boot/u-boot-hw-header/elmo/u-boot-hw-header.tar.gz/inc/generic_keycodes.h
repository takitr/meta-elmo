/****************************************************************************/
/*                   CONEXANT PROPRIETARY AND CONFIDENTIAL                  */
/*                       SOFTWARE FILE/MODULE HEADER                        */
/*                   Conexant Systems Inc. (c) 1998 - 2007                  */
/*                               Austin, TX                                 */
/*                            All Rights Reserved                           */
/****************************************************************************/
/*
 * Filename:       generic_keycodes.h
 *
 *
 * Description:    Generic keycodes for IR and front panel devices.
 *
 *
 * Author:         Dave Wilson
 *
 ****************************************************************************/
/* $Id: generic_keycodes.h 196371 2011-03-07 19:37:19Z gargn $
 ****************************************************************************/

/****************************************************************************/
/* Note:                                                                    */
/*                                                                          */
/*   As far as possible, ASCII codes are used here for basic printable      */
/*   characters below 0x7F. Codes above 0x7F are used for control codes and */
/*   functions specific to various front panels and remote controls.        */
/*                                                                          */
/****************************************************************************/
  
#ifndef _GENERIC_KEYCODES_H_
#define _GENERIC_KEYCODES_H_

/* ASCII-like printing characters and control codes */

#define CNXT_KEYCODE_NUL          0x0
#define CNXT_KEYCODE_SOH          0x1
#define CNXT_KEYCODE_STX          0x2
#define CNXT_KEYCODE_ETX          0x3
#define CNXT_KEYCODE_EOT          0x4
#define CNXT_KEYCODE_ENQ          0x5
#define CNXT_KEYCODE_ACK          0x6
#define CNXT_KEYCODE_BEL          0x7
#define CNXT_KEYCODE_BS           0x8
#define CNXT_KEYCODE_HT           0x9
#define CNXT_KEYCODE_LF           0xa
#define CNXT_KEYCODE_VT           0xb
#define CNXT_KEYCODE_FF           0xc
#define CNXT_KEYCODE_CR           0xd
#define CNXT_KEYCODE_SO           0xe
#define CNXT_KEYCODE_SI           0xf
#define CNXT_KEYCODE_DLE          0x10
#define CNXT_KEYCODE_DC1          0x11
#define CNXT_KEYCODE_DC2          0x12
#define CNXT_KEYCODE_DC3          0x13
#define CNXT_KEYCODE_DC4          0x14
#define CNXT_KEYCODE_NAK          0x15
#define CNXT_KEYCODE_SYN          0x16
#define CNXT_KEYCODE_ETB          0x17
#define CNXT_KEYCODE_CAN          0x18
#define CNXT_KEYCODE_EM           0x19
#define CNXT_KEYCODE_SUB          0x1a
#define CNXT_KEYCODE_ESC          0x1b
#define CNXT_KEYCODE_FS           0x1c
#define CNXT_KEYCODE_GS           0x1d
#define CNXT_KEYCODE_RS           0x1e
#define CNXT_KEYCODE_US           0x1f
#define CNXT_KEYCODE_SP           0x20
#define CNXT_KEYCODE_EXCLAMATION  0x21
#define CNXT_KEYCODE_QUOTATION    0x22
#define CNXT_KEYCODE_POUND        0x23
#define CNXT_KEYCODE_DOLLAR       0x24
#define CNXT_KEYCODE_PERCENT      0x25
#define CNXT_KEYCODE_AMPERSAND    0x26
#define CNXT_KEYCODE_APOSTROPHE   0x27
#define CNXT_KEYCODE_LPARENTHESIS 0x28
#define CNXT_KEYCODE_RPARENTHESIS 0x29
#define CNXT_KEYCODE_ASTERISK     0x2a
#define CNXT_KEYCODE_PLUS         0x2b
#define CNXT_KEYCODE_COMMA        0x2c
#define CNXT_KEYCODE_HYPHEN       0x2d
#define CNXT_KEYCODE_PERIOD       0x2e
#define CNXT_KEYCODE_BACKSLASH    0x2f
#define CNXT_KEYCODE_0            0x30
#define CNXT_KEYCODE_1            0x31
#define CNXT_KEYCODE_2            0x32
#define CNXT_KEYCODE_3            0x33
#define CNXT_KEYCODE_4            0x34
#define CNXT_KEYCODE_5            0x35
#define CNXT_KEYCODE_6            0x36
#define CNXT_KEYCODE_7            0x37
#define CNXT_KEYCODE_8            0x38
#define CNXT_KEYCODE_9            0x39
#define CNXT_KEYCODE_COLON        0x3a
#define CNXT_KEYCODE_SEMICOLON    0x3b
#define CNXT_KEYCODE_LESSTHAN     0x3c
#define CNXT_KEYCODE_EQUALS       0x3d
#define CNXT_KEYCODE_GREATERTHAN  0x3e
#define CNXT_KEYCODE_QUESTION     0x3f
#define CNXT_KEYCODE_AT           0x40
#define CNXT_KEYCODE_CAPA         0x41
#define CNXT_KEYCODE_CAPB         0x42
#define CNXT_KEYCODE_CAPC         0x43
#define CNXT_KEYCODE_CAPD         0x44
#define CNXT_KEYCODE_CAPE         0x45
#define CNXT_KEYCODE_CAPF         0x46
#define CNXT_KEYCODE_CAPG         0x47
#define CNXT_KEYCODE_CAPH         0x48
#define CNXT_KEYCODE_CAPI         0x49
#define CNXT_KEYCODE_CAPJ         0x4a
#define CNXT_KEYCODE_CAPK         0x4b
#define CNXT_KEYCODE_CAPL         0x4c
#define CNXT_KEYCODE_CAPM         0x4d
#define CNXT_KEYCODE_CAPN         0x4e
#define CNXT_KEYCODE_CAPO         0x4f
#define CNXT_KEYCODE_CAPP         0x50
#define CNXT_KEYCODE_CAPQ         0x51
#define CNXT_KEYCODE_CAPR         0x52
#define CNXT_KEYCODE_CAPS         0x53
#define CNXT_KEYCODE_CAPT         0x54
#define CNXT_KEYCODE_CAPU         0x55
#define CNXT_KEYCODE_CAPV         0x56
#define CNXT_KEYCODE_CAPW         0x57
#define CNXT_KEYCODE_CAPX         0x58
#define CNXT_KEYCODE_CAPY         0x59
#define CNXT_KEYCODE_CAPZ         0x5a
#define CNXT_KEYCODE_LBRACKET     0x5b
#define CNXT_KEYCODE_REVSOLIDUS   0x5c
#define CNXT_KEYCODE_RBRACKET     0x5d
#define CNXT_KEYCODE_ACCENT       0x5e
#define CNXT_KEYCODE_LOWLINE      0x5f
#define CNXT_KEYCODE_GRAVEACCENT  0x60
#define CNXT_KEYCODE_LOWA         0x61
#define CNXT_KEYCODE_LOWB         0x62
#define CNXT_KEYCODE_LOWC         0x63
#define CNXT_KEYCODE_LOWD         0x64
#define CNXT_KEYCODE_LOWE         0x65
#define CNXT_KEYCODE_LOWF         0x66
#define CNXT_KEYCODE_LOWG         0x67
#define CNXT_KEYCODE_LOWH         0x68
#define CNXT_KEYCODE_LOWI         0x69
#define CNXT_KEYCODE_LOWJ         0x6a
#define CNXT_KEYCODE_LOWK         0x6b
#define CNXT_KEYCODE_LOWL         0x6c
#define CNXT_KEYCODE_LOWM         0x6d
#define CNXT_KEYCODE_LOWN         0x6e
#define CNXT_KEYCODE_LOWO         0x6f
#define CNXT_KEYCODE_LOWP         0x70
#define CNXT_KEYCODE_LOWQ         0x71
#define CNXT_KEYCODE_LOWR         0x72
#define CNXT_KEYCODE_LOWS         0x73
#define CNXT_KEYCODE_LOWT         0x74
#define CNXT_KEYCODE_LOWU         0x75
#define CNXT_KEYCODE_LOWV         0x76
#define CNXT_KEYCODE_LOWW         0x77
#define CNXT_KEYCODE_LOWX         0x78
#define CNXT_KEYCODE_LOWY         0x79
#define CNXT_KEYCODE_LOWZ         0x7a
#define CNXT_KEYCODE_LBRACE       0x7b
#define CNXT_KEYCODE_VERTLINE     0x7c
#define CNXT_KEYCODE_RBRACE       0x7d
#define CNXT_KEYCODE_TILDE        0x7e
#define CNXT_KEYCODE_DELETE       0x7f

/* Control codes and other non-printing characters */

#define CNXT_KEYCODE_CAPLOCK      0x80
#define CNXT_KEYCODE_LSHIFT       0x81
#define CNXT_KEYCODE_RSHIFT       0x82
#define CNXT_KEYCODE_LCTRL        0x83
#define CNXT_KEYCODE_LALT         0x84
#define CNXT_KEYCODE_RALT         0x85
#define CNXT_KEYCODE_INSERT       0x86
#define CNXT_KEYCODE_LARROW       0x87
#define CNXT_KEYCODE_HOME         0x88
#define CNXT_KEYCODE_END          0x89
#define CNXT_KEYCODE_UPARROW      0x8a
#define CNXT_KEYCODE_DOWNARROW    0x8b
#define CNXT_KEYCODE_PAGEUP       0x8c
#define CNXT_KEYCODE_PAGEDOWN     0x8d
#define CNXT_KEYCODE_RARROW       0x8e
#define CNXT_KEYCODE_NUMLOCK      0x8f
#define CNXT_KEYCODE_F1           0x90
#define CNXT_KEYCODE_F2           0x91
#define CNXT_KEYCODE_F3           0x92
#define CNXT_KEYCODE_F4           0x93
#define CNXT_KEYCODE_F5           0x94
#define CNXT_KEYCODE_F6           0x95
#define CNXT_KEYCODE_F7           0x96
#define CNXT_KEYCODE_F8           0x97
#define CNXT_KEYCODE_F9           0x98
#define CNXT_KEYCODE_F10          0x99
#define CNXT_KEYCODE_F11          0x9a
#define CNXT_KEYCODE_F12          0x9b
#define CNXT_KEYCODE_PRINTSCREEN  0x9c
#define CNXT_KEYCODE_SCROLLLOCK   0x9d
#define CNXT_KEYCODE_PAUSE        0x9e
#define CNXT_KEYCODE_FN           0x9f
#define CNXT_KEYCODE_LWINDOWS     0xa0
#define CNXT_KEYCODE_APPLICATION  0xa1
#define CNXT_KEYCODE_RECORD       0xa2
#define CNXT_KEYCODE_EJECT        0xa3
#define CNXT_KEYCODE_SEARCH       0xa4
#define CNXT_KEYCODE_BATTERYLOW   0xa5
#define CNXT_KEYCODE_CUT          0xa6
#define CNXT_KEYCODE_PASTE        0xa7
#define CNXT_KEYCODE_RESET        0xa8
#define CNXT_KEYCODE_VIDEO_FORMAT 0xa9
#define CNXT_KEYCODE_ACTIVE       0xaa
#define CNXT_KEYCODE_POWER        0xb0
#define CNXT_KEYCODE_FORWARD      0xb1
#define CNXT_KEYCODE_BUY          0xb2
#define CNXT_KEYCODE_GUIDE        0xb3
#define CNXT_KEYCODE_ENTER        0xb4
#define CNXT_KEYCODE_EXIT         0xb5
#define CNXT_KEYCODE_REVERSE      0xb6
#define CNXT_KEYCODE_WWW          0xb7
#define CNXT_KEYCODE_PLAY         0xb8
#define CNXT_KEYCODE_STOP         0xb9
#define CNXT_KEYCODE_MENU         0xba
#define CNXT_KEYCODE_PC           0xbb
#define CNXT_KEYCODE_HELP         0xbc
#define CNXT_KEYCODE_TVVCR        0xbd
#define CNXT_KEYCODE_LAST         0xbe
#define CNXT_KEYCODE_LOCK         0xbf
#define CNXT_KEYCODE_CABLE        0xc0
#define CNXT_KEYCODE_VOLUP        0xc1
#define CNXT_KEYCODE_VOLDN        0xc2
#define CNXT_KEYCODE_MUTE         0xc3
#define CNXT_KEYCODE_CHANUP       0xc4
#define CNXT_KEYCODE_CHANDN       0xc5
#define CNXT_KEYCODE_INFO         0xc6
#define CNXT_KEYCODE_TV           0xc7
#define CNXT_KEYCODE_RM_1         0xc8
#define CNXT_KEYCODE_RM_2         0xc9
#define CNXT_KEYCODE_RM_3         0xca
#define CNXT_KEYCODE_RM_4         0xcb
#define CNXT_KEYCODE_RM_5         0xcc
#define CNXT_KEYCODE_RM_6         0xcd
#define CNXT_KEYCODE_RM_7         0xce
#define CNXT_KEYCODE_RM_8         0xcf
#define CNXT_KEYCODE_RM_9         0xd0
#define CNXT_KEYCODE_RM_0         0xd1
#define CNXT_KEYCODE_TEXT         0xd2
#define CNXT_KEYCODE_UP           0xd3
#define CNXT_KEYCODE_DOWN         0xd4
#define CNXT_KEYCODE_LEFT         0xd5
#define CNXT_KEYCODE_RIGHT        0xd6
#define CNXT_KEYCODE_RED          0xd7
#define CNXT_KEYCODE_GREEN        0xd8
#define CNXT_KEYCODE_YELLOW       0xd9
#define CNXT_KEYCODE_BLUE         0xda
#define CNXT_KEYCODE_BOXOFFICE    0xdb
#define CNXT_KEYCODE_SERVICES     0xdc
#define CNXT_KEYCODE_SAT          0xdd
#define CNXT_KEYCODE_BACKUP       0xde
#define CNXT_KEYCODE_TVGUIDE      0xdf
#define CNXT_KEYCODE_INTERACTIVE  0xe0
#define CNXT_KEYCODE_EMAIL        0xe1
#define CNXT_KEYCODE_REFRESH      0xe2
#define CNXT_KEYCODE_PRINT        0xe3
#define CNXT_KEYCODE_INPUT        0xe4
#define CNXT_KEYCODE_SLEEP        0xe5
#define CNXT_KEYCODE_DISPLAY      0xe6
#define CNXT_KEYCODE_PARENT_CTL   0xe7
#define CNXT_KEYCODE_CANCEL       0xe8
#define CNXT_KEYCODE_RSV0         0xe9
#define CNXT_KEYCODE_RSV1         0xea
#define CNXT_KEYCODE_RSV2         0xeb
#define CNXT_KEYCODE_RSV3         0xec
#define CNXT_KEYCODE_RSV4         0xed
#define CNXT_KEYCODE_RSV5         0xee
#define CNXT_KEYCODE_RSV6         0xef
#define CNXT_KEYCODE_RSV7         0xf0
#define CNXT_KEYCODE_RSV8         0xf1
#define CNXT_KEYCODE_RSV9         0xf2
#define CNXT_KEYCODE_RSV10        0xf3
#define CNXT_KEYCODE_RSV11        0xf4
#define CNXT_KEYCODE_RSV12        0xf5
#define CNXT_KEYCODE_RSV13        0xf6
#define CNXT_KEYCODE_MODE         0xf7 
#define CNXT_KEYCODE_VIEW         0xf8
#define CNXT_KEYCODE_ADDRESS      0xf9 
#define CNXT_KEYCODE_RECALL       0xfa

/* Added for DIRECTV remote control */
#define CNXT_KEYCODE_SELECT       0xfb 
#define CNXT_KEYCODE_LIST         0xfc 
#define CNXT_KEYCODE_REPLAY       0xfd 
#define CNXT_KEYCODE_ADVANCE      0xfe 
#define CNXT_KEYCODE_FORMAT       0xff 
#define CNXT_KEYCODE_DTV_0X51     0x100
#define CNXT_KEYCODE_DTV_0X52     0x101 
#define CNXT_KEYCODE_DTV_0X53     0x102 
#define CNXT_KEYCODE_DTV_0X5A     0x103 
#define CNXT_KEYCODE_DTV_0X5B     0x104 
#define CNXT_KEYCODE_DTV_0X5C     0x105 
#define CNXT_KEYCODE_DTV_0X5D     0x106 
#define CNXT_KEYCODE_DTV_0X5E     0x107 
#define CNXT_KEYCODE_DTV_0X5F     0x108 
#define CNXT_KEYCODE_SPKR_LR      0x109		/* added for NEC RC */
#define CNXT_KEYCODE_GREY         0x10a		/* added for NEC RC */
#define CNXT_KEYCODE_TELETEXT     0x10b		/* added for NEC RC */
#define CNXT_KEYCODE_SUBTITLE     0x10c		/* added for NEC RC */

/* Added for RC5 remote control */
#define CNXT_KEYCODE_OK           0x10d
#define CNXT_KEYCODE_RADIO        0x10e
#define CNXT_KEYCODE_DTV          0x10f
#define CNXT_KEYCODE_TIMER        0x110

/* Added for XMP1 remote control */
#define CNXT_KEYCODE_PIP          0x112
#define CNXT_KEYCODE_PIPCHUP      0x113
#define CNXT_KEYCODE_PIPCHDN      0x114
#define CNXT_KEYCODE_PIPPAUSE     0x115
#define CNXT_KEYCODE_PIPSWAP      0x116
#define CNXT_KEYCODE_LANG         (CNXT_KEYCODE_LOCK)
#define CNXT_KEYCODE_FAV          0x117
#define CNXT_KEYCODE_AUDIOGAIN    0x120
#endif

/****************************************************************************
 * Modifications:
 * $Log$
 *
 ****************************************************************************/

