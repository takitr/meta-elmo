/*****************************************************************************
 * Copyright 2010 Trident Microsystems (Far East) Ltd.,
 * All rights reserved
 *
 * This source code and any compilation or derivative thereof is the
 * proprietary information and is confidential in nature.
 * Under no circumstances is this software to be exposed to or placed under an
 * Open Source License of any type without the expressed written permission of
 * Trident Microsystems (Far East) Ltd.
 *
 *  Name:        omx_callback.h
 *  Description: OpenMAX IL callback event definitions.
 ******************************************************************************/
/* $Id: omx_callback.h 218396 2011-08-01 14:11:43Z asethi $
 ******************************************************************************/

#ifndef __OMX_CALLBACK_H__
#define __OMX_CALLBACK_H__

#include "OMX_Core.h"

typedef enum
{
   EMPTY_BUFFER_DONE,
   FILL_BUFFER_DONE,
   DECODE_FRAME_DONE,
   FLUSH,
}CallbackEventType;

typedef struct 
{
   CallbackEventType    etype;
   OMX_BUFFERHEADERTYPE *pBuffer; 
   OMX_TICKS            nTimeStamp;
   OMX_U32              nFlags;
   OMX_U32              nBufIndx;  
   OMX_TICKS            nLocalStamp;
}CallbackEvent;

#endif
