/****************************************************************************
 * Copyright 2010 Trident Microsystems (Far East) Ltd.,
 * All rights reserved
 *
 * This source code and any compilation or derivative thereof is the
 * proprietary information and is confidential in nature.
 * Under no circumstances is this software to be exposed to or placed under an
 * Open Source License of any type without the expressed written permission of
 * Trident Microsystems (Far East) Ltd.
 *
 * Name:        omx_pipe_core.h
 * Description: Header file containing private information used by OMX-IL port 
 *              on top of pipeline manager.
 *
 *****************************************************************************/
/* $Id: omx_pipe_core.h 220697 2011-08-18 05:35:25Z asethi $
 *****************************************************************************/

#ifndef _OMX_PIPE_CORE_H_
#define _OMX_PIPE_CORE_H_

#include <string.h>
#include <pthread.h>
#include "graphics_gen.h"
#include "pipeline.h"
#include "presentation.h"
#include "pr_audio.h"
#include "kal.h"
#include "handle.h"
#include "cnxt_types.h"
#include "handle.h"

#include "OMX_Khronos.h"
#include "OMX_internal.h"

#define OMX_MAX_PIPELINE_INSTANCES  1

/* This can be more than 1 for mosaic */
#define OMX_MAX_VIDEO_SURFACES      1

#define OMX_VIDEO_INPUT_BUFFER_SIZE (2*512*1024)
#define OMX_AUDIO_INPUT_BUFFER_SIZE (2*128*1024)

#define OMX_VIDEO_OUTPUT_BUFFER_SIZE (1920*1080)
#define OMX_AUDIO_OUTPUT_BUFFER_SIZE (1024*1024)

#define OMX_FLUSH_DECODER_BEFORE_STOP  0

#define OMX_SYNC_WITH_FLASH_PROCESS 1

#define OMX_VIDEO_FP_USE_VIDEO_TEXTURE 0

#define OMX_VIDEO_FP_USE_DRIP_FEED_MODE 0

/* Logging  information start */
#define OMX_PRINT          1

#define ANDROID_LOG_INFO   4
#define ANDROID_LOG_WARN   5

#define TAG "TRD OMX"
#define ONLYNAME(x)  ({const char *p; p = strrchr((x), '/'); p = ((p == NULL) ? (x) : p + 1);}) 
#ifdef OMX_PRINT
#define LOGW(format, args...)  printf("omx warning:%s:%d:  " format, ONLYNAME(__FILE__),  __LINE__, ##args);
#define LOGI(format, args...)  printf("omx  loging:%s:%d:  " format, ONLYNAME(__FILE__),  __LINE__, ##args);
//#define LOGI(format, args...) 
#else
#define LOGI(...)
#define LOGW(...) 
#endif

/* Logging  information end */

#define OMX_MAX_AUDIO_TRACK 8
/* Structure used to copy media data */
typedef struct private_data
{
   struct 
   {
      OMX_U8   *pAudioBufferShadow;
      OMX_U8   *pAudioBuffer;
   }audioBuffer[OMX_MAX_AUDIO_TRACK];

   OMX_U8   *pVideoBuffer;
   OMX_U8   *pVideoBufferShadow;
} PIPE_PRIVATE_INFO;

typedef struct
{  
   u_int32          Y_start_offset;
   u_int32          UV_start_offset;
   u_int32          Y_stride;
   u_int32          UV_stride;
   u_int32          img_start_addr;
   u_int32          size;
   u_int32          PoolId;
   u_int32          BufIndx;
#if OMX_SYNC_WITH_FLASH_PROCESS
   u_int32          uLock;
#endif
}CNXT_PICT_PARAMS;

typedef struct _VPM_SURFACE_PARAM
{
   PIPE_VP_SURFACE_TYPE    surfaceType;
   PIPE_VP_SURFACE_OBJECT *pHDSurface;
   PIPE_VP_SURFACE_OBJECT *pSDSurface;
   OMX_BOOL                bEnabled;
   pthread_mutex_t         mutex;
}VPM_SURFACE_PARAM;

extern  PIPE_VP_DEVICE_OBJECT          *pAvHDDevice;
extern  PIPE_VP_DEVICE_OBJECT          *pAvSDDevice;
//extern  PIPE_VP_SURFACE_OBJECT         *pAvHDPrimVideoSurface[OMX_MAX_VIDEO_SURFACES];
//extern  PIPE_VP_SURFACE_OBJECT         *pAvSDPrimVideoSurface[OMX_MAX_VIDEO_SURFACES];
extern  PIPE_VP_SURFACE_OBJECT         *pAvHDSecVideoSurface[OMX_MAX_VIDEO_SURFACES];
extern  PIPE_VP_SURFACE_OBJECT         *pAvSDSecVideoSurface[OMX_MAX_VIDEO_SURFACES];

extern  PIPE_AUDIO_PRESENTATION_OBJECT *pAvAudioPresentation;
extern  PIPE_PRIVATE_INFO              AVdataBuffer[OMX_MAX_PIPELINE_INSTANCES];

#if 0
extern AUD_DEC_AAC_PARAMS  audio_aac;
extern DECODER_AUDIO_TYPE  audio_type;
#endif

extern int pipe_core_inject_data_video(OMX_U8 *buffer, 
                                       OMX_U32 length,
                                       PIPE_PIPELINE_OBJECT    *pAVPipeObjVideo,
                                       PIPE_VIDEO_OBJECT       *pAVvideoObj,
                                       OMX_U32 PtsLowbyte,    
                                       OMX_U32 PtsHighbyte,  
                                       OMX_U32 additional);

extern int pipe_core_inject_data_audio(OMX_U8 *buffer,         
                                       OMX_U32 length, 
                                       PIPE_PIPELINE_OBJECT   *pAVPipeObjAudio,
                                       PIPE_AUDIO_OBJECT      *pAVaudioObj,
                                       OMX_U32 flags, 
                                       OMX_U32 PtsLowbyte, 
                                       OMX_U32 PtsHighbyte,
                                       OMX_U8 *pCodecDataBuf,
                                       OMX_U32 codecDataBufLen
                                       );


extern void omx_send_vid_buffer_done(OMX_BUFFERHEADERTYPE *pBuffer);
extern void omx_send_aud_buffer_done(OMX_BUFFERHEADERTYPE *pBuffer);

extern OMX_ERRORTYPE startVideo( decoding_params_t    *DecodingParams, 
                                 PIPE_PIPELINE_OBJECT *pAVPipeObjVideo,
                                 PIPE_VIDEO_OBJECT    *pAVvideoObj,
                                 PIPE_DEMUX_OBJECT    *pAVdemuxObjVideo,
                                 VPM_SURFACE_PARAM    *vpmSurface,
                                 OMX_BOOL             bVideoPresOffloaded,
                                 OMX_BOOL             bUseDripFeedMode);

extern OMX_ERRORTYPE stopVideo(PIPE_PIPELINE_OBJECT   *pAVPipeObjVideo,
                               PIPE_VIDEO_OBJECT      *pAVvideoObj,
                               PIPE_DEMUX_OBJECT      *pAVdemuxObjVideo,
                               VPM_SURFACE_PARAM      *vpmSurface
                               );

extern OMX_ERRORTYPE startAudio(decoding_params_t     *params,
                                PIPE_PIPELINE_OBJECT  *pAVPipeObjAudio,
                                PIPE_AUDIO_OBJECT     *pAVaudioObj,
                                PIPE_DEMUX_OBJECT     *pAVdemuxObjAudio);

extern OMX_ERRORTYPE stopAudio(PIPE_PIPELINE_OBJECT   *pAVPipeObjAudio,
                               PIPE_AUDIO_OBJECT      *pAVaudioObj,
                               PIPE_DEMUX_OBJECT      *pAVdemuxObjAudio);

extern OMX_ERRORTYPE pauseAudio(PIPE_PIPELINE_OBJECT  *pAVPipeObjAudio);
extern OMX_ERRORTYPE pauseVideo(PIPE_PIPELINE_OBJECT  *pAVPipeObjVideo);
extern OMX_ERRORTYPE resumeAudio(PIPE_PIPELINE_OBJECT *pAVPipeObjAudio);
extern OMX_ERRORTYPE resumeVideo(PIPE_PIPELINE_OBJECT *pAVPipeObjVideo);
extern OMX_ERRORTYPE flushAudio(PIPE_PIPELINE_OBJECT  *pAVPipeObjAudio);
extern OMX_ERRORTYPE flushVideo(PIPE_PIPELINE_OBJECT  *pAVPipeObjVideo);

extern int pipe_core_get_stc( uint32_t             *STCLow, 
                              uint32_t             *STChigh,
                              PIPE_PIPELINE_OBJECT *pAVPipeObj );

extern int pipe_core_get_pts(bool                  bVideo, 
                             uint32_t              *PTSLow, 
                             uint32_t              *PTShigh,
                             PIPE_PIPELINE_OBJECT  *pAVPipeObj);

extern int pipe_core_get_es_attr(uint32_t          *usedspace, 
                                 uint32_t          *hwm,
                                 PIPE_VIDEO_OBJECT *pVPipeObj,
                                 PIPE_AUDIO_OBJECT *pAPipeObj);


OMX_ERRORTYPE pipe_core_vpm_init  (VPM_SURFACE_PARAM *vpmSurface); 
OMX_ERRORTYPE pipe_core_vpm_deinit(VPM_SURFACE_PARAM *vpmSurface);

#endif /* _OMX_PIPE_CORE_H_ */
