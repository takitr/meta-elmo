/****************************************************************************
 * Copyright 2010 Trident Microsystems (Far East) Ltd.,
 * All rights reserved
 *
 * This source code and any compilation or derivative thereof is the
 * proprietary information and is confidential in nature.
 * Under no circumstances is this software to be exposed to or placed under an
 * Open Source License of any type without the expressed written permission of
 * Trident Microsystems (Far East) Ltd.
 *
 * Name:        omx_trident_video.h
 * Description: 
 *
 *****************************************************************************/
/* $Id: omx_trident_video.h 219738 2011-08-09 14:13:26Z asethi $
 *****************************************************************************/

#ifndef _OMX_TRID_VIDEO_H_
#define _OMX_TRID_VIDEO_H_

#define VIDDEC_BUFFERMINCOUNT                   1
#define VIDDEC_PORT_ENABLED                     OMX_TRUE
#define VIDDEC_PORT_POPULATED                   OMX_FALSE
#define VIDDEC_PORT_DOMAIN                      OMX_PortDomainVideo

typedef enum VIDDEC_PORT_INDEX
{
   VIDDEC_PORT_MIN = 0,
   VIDDEC_INPUT_PORT = VIDDEC_PORT_MIN,
   VIDDEC_OUTPUT_PORT,
   VIDDEC_PORT_MAX
}VIDDEC_PORT_INDEX;

typedef enum VIDDEC_DEFAULT_INPUT_INDEX
{
   VIDDEC_DEFAULT_INPUT_INDEX_H264,
   VIDDEC_DEFAULT_INPUT_INDEX_MPEG2,
   VIDDEC_DEFAULT_INPUT_INDEX_WMV9,
   VIDDEC_DEFAULT_INPUT_INDEX_H263,
   VIDDEC_DEFAULT_INPUT_INDEX_MPEG4,
#ifdef VIDDEC_SPARK_CODE
   VIDDEC_DEFAULT_INPUT_INDEX_SPARK,
#endif
   VIDDEC_DEFAULT_INPUT_INDEX_MAX = 0x7ffffff
}VIDDEC_DEFAULT_INPUT_INDEX;

#endif /* _OMX_TRID_VIDEO_H_ */
