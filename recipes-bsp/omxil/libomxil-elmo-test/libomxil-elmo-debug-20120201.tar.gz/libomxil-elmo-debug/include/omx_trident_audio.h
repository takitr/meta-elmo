/****************************************************************************
 * Copyright 2010 Trident Microsystems (Far East) Ltd.,
 * All rights reserved
 *
 * This source code and any compilation or derivative thereof is the
 * proprietary information and is confidential in nature.
 * Under no circumstances is this software to be exposed to or placed under an
 * Open Source License of any type without the expressed written permission of
 * Trident Microsystems (Far East) Ltd.
 *
 * Name:        omx_trident_audio.h
 * Description: 
 *
 *****************************************************************************/
/* $Id: omx_trident_audio.h 219738 2011-08-09 14:13:26Z asethi $
 *****************************************************************************/

#ifndef _OMX_TRID_AUDIO_H_
#define _OMX_TRID_AUDIO_H_

#define AUDDEC_BUFFERMINCOUNT                   1
#define AUDDEC_PORT_ENABLED                     OMX_TRUE
#define AUDDEC_PORT_POPULATED                   OMX_FALSE
#define AUDDEC_PORT_DOMAIN                      OMX_PortDomainAudio

typedef enum AUDDEC_PORT_INDEX
{
   AUDDEC_PORT_MIN = 0,
   AUDDEC_INPUT_PORT = AUDDEC_PORT_MIN,
   AUDDEC_OUTPUT_PORT,
   AUDDEC_PORT_MAX
}AUDDEC_PORT_INDEX;

typedef enum AUDDEC_DEFAULT_INPUT_INDEX
{
   AUDDEC_DEFAULT_INPUT_INDEX_AAC,
   AUDDEC_DEFAULT_INPUT_INDEX_MP3,
   AUDDEC_DEFAULT_INPUT_INDEX_MAX = 0x7ffffff
}AUDDEC_DEFAULT_INPUT_INDEX;

#endif /* _OMX_TRID_AUDIO_H_ */
