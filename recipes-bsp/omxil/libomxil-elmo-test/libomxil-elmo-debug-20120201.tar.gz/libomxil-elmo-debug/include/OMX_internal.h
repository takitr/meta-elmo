/*****************************************************************************
 * Copyright 2010 Trident Microsystems (Far East) Ltd.,
 * All rights reserved
 *
 * This source code and any compilation or derivative thereof is the
 * proprietary information and is confidential in nature.
 * Under no circumstances is this software to be exposed to or placed under an
 * Open Source License of any type without the expressed written permission of
 * Trident Microsystems (Far East) Ltd.
 *
 *  Name:        OMX_internal.h
 *  Description: OpenMAX IL core internal data structures.
 ******************************************************************************/
/* $Id: OMX_internal.h 219738 2011-08-09 14:13:26Z asethi $
 ******************************************************************************/
#ifndef __OMX_INTERNAL_H__
#define __OMX_INTERNAL_H__

#include <sys/ioctl.h>

/* OMX version information */
#define VERSION_MAJOR                       1
#define VERSION_MINOR                       0
#define VERSION_REVISION                    0
#define VERSION_STEP                        0

#define OMX_CONF_INIT_STRUCT(_s_, _name_)       \
    memset((_s_), 0x0, sizeof(_name_));         \
    (_s_)->nSize = sizeof(_name_);              \
    (_s_)->nVersion.s.nVersionMajor = VERSION_MAJOR;      \
    (_s_)->nVersion.s.nVersionMinor = VERSION_MINOR;      \
    (_s_)->nVersion.s.nRevision = VERSION_REVISION;       \
    (_s_)->nVersion.s.nStep = VERSION_STEP;

typedef enum
{
   MEDIA_TS_DATA,
   MEDIA_VIDEO_ES_DATA,
   MEDIA_AUDIO_ES_DATA
} MEDIA_DATA_TYPE;

typedef struct
{
   MEDIA_DATA_TYPE Type;
   unsigned char *pData;
   unsigned int   uLength;
   unsigned long  uPts;
} MEDIA_DATA_INFO;

/**
 * A/V Decoder Type
 */
typedef enum {
   DECODER_TYPE_VIDEO,
   DECODER_TYPE_AUDIO,
} DECODER_TYPE;

/**
 * Supported Video decoding types
 */
typedef enum {
   DECODER_VIDEO_TYPE_MPEG2   = 0x1,
   DECODER_VIDEO_TYPE_MPEG4,
   DECODER_VIDEO_TYPE_H264,
   DECODER_VIDEO_TYPE_WMV,
   DECODER_VIDEO_TYPE_VC1,
   DECODER_VIDEO_TYPE_H263,
   DECODER_VIDEO_TYPE_VP6,
   DECODER_VIDEO_TYPE_DIVX,
   DECODER_VIDEO_TYPE_SORENSON_SPARK,
   DECODER_VIDEO_TYPE_REALVIDEO8,
   DECODER_VIDEO_TYPE_REALVIDEO9
} DECODER_VIDEO_TYPE;

/**
 * Supported Video decoding modes
 */
typedef enum {
	DECODER_VIDEO_MODE_SD				= 0x1,
	DECODER_VIDEO_MODE_SD_SUB		= 0x1 << 1,
	DECODER_VIDEO_MODE_HD				= 0x1 << 2,
	DECODER_VIDEO_MODE_HD_SUB		= 0x1 << 3,
	DECODER_VIDEO_MODE_FHD				= 0x1 << 4,
	DECODER_VIDEO_MODE_FHD_SUB		= 0x1 << 5
} DECODER_VIDEO_MODE;

typedef enum {
	DECODER_VIDEO_ASPECT_RATIO_4_3,
	DECODER_VIDEO_ASPECT_RATIO_16_9,
} DECODER_VIDEO_ASPECT_RATIO;

/**
 * Supported Audio decoding modes
 */
typedef enum {
	DECODER_AUDIO_TYPE_MPEG1		= 0x1,
	DECODER_AUDIO_TYPE_MPEG2,		
	DECODER_AUDIO_TYPE_MPEG3,
	DECODER_AUDIO_TYPE_AC3,			
	DECODER_AUDIO_TYPE_AC3PLUS,	    
	DECODER_AUDIO_TYPE_AAC,			
	DECODER_AUDIO_TYPE_AACPLUS,	    
	DECODER_AUDIO_TYPE_DTS,	       
	DECODER_AUDIO_TYPE_PCM,	
	DECODER_AUDIO_TYPE_REALAUDIO,             
	DECODER_AUDIO_TYPE_WMA,	       
	DECODER_AUDIO_TYPE_WMAPRO,	       
} 	DECODER_AUDIO_TYPE;

typedef enum {
	DECODER_AUDIO_MODE_STEREO,
    DECODER_AUDIO_MODE_MONO_LEFT,
	DECODER_AUDIO_MODE_MONO_RIGHT,
    DECODER_AUDIO_MODE_MULTICH
} DECODER_AUDIO_MODE;

typedef enum AUDIO_AACPROFILETYPE{
  AUDIO_AACObjectNull = 0,      /**< Null, not used */
  AUDIO_AACObjectMain = 1,      /**< AAC Main object */
  AUDIO_AACObjectLC,            /**< AAC Low Complexity object (AAC profile) */
  AUDIO_AACObjectSSR,           /**< AAC Scalable Sample Rate object */
  AUDIO_AACObjectLTP,           /**< AAC Long Term Prediction object */
  AUDIO_AACObjectHE,            /**< AAC High Efficiency (object type SBR, HE-AAC profile) */
  AUDIO_AACObjectScalable,      /**< AAC Scalable object */
  AUDIO_AACObjectERLC = 17,     /**< ER AAC Low Complexity object (Error Resilient AAC-LC) */
  AUDIO_AACObjectLD = 23,       /**< AAC Low Delay object (Error Resilient) */
  AUDIO_AACObjectHE_PS = 29,    /**< AAC High Efficiency with Parametric Stereo coding (HE-AAC v2, object type PS) */
  AUDIO_AACObjectKhronosExtensions = 0x6F000000, /**< Reserved region for introducing Khronos Standard Extensions */
  AUDIO_AACObjectVendorStartUnused = 0x7F000000, /**< Reserved region for introducing Vendor Extensions */
  AUDIO_AACObjectMax = 0x7FFFFFFF
} AUDIO_AACPROFILETYPE;

typedef struct
{
  int nChannels;             /**< Number of channels */
  int nSampleRate;           /**< Sampling rate of the source data.  Use 0 for*/
  AUDIO_AACPROFILETYPE eAACProfile;   /**< AAC profile enumeration */
}AUD_DEC_AAC_PARAMS;

typedef struct
{
   DECODER_TYPE   decoder_type;
   
   
   union 
   {
      struct
      {
         DECODER_VIDEO_TYPE     video_type;
         DECODER_VIDEO_MODE     video_mode;
         OMX_U32                uFrameRate;
         OMX_U32                uFrameWidth;
         OMX_U32                uFrameHeight;
         PIPE_VIDEO_STREAM_MODE StreamMode;
		 //RMVB
		OMX_U32   				SubMOFTag;
		OMX_U32   				BitCount;
		OMX_U32   				PadWidth;
		OMX_U32   				PadHeight;
      } video_params;

      struct
      {
          DECODER_AUDIO_TYPE            audio_type;
          DECODER_AUDIO_MODE            audio_mode;
          AUD_DEC_AAC_PARAMS            audio_aac;
          OMX_RA_COOK                  *pRaInfo;  
          OMX_AUDIO_WMAMODETYPE        *audio_pWMA;
          OMX_AUDIO_PARAM_PCMMODETYPE  *audio_pPCM;
      } audio_params;

   } params;
   
} decoding_params_t;


#endif
